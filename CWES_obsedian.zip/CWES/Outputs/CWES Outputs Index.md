---
tags: [CWES, XMind, output, index]
source_file: CWES.xmind
output_topics: 917
---

# CWES XMind Outputs

> [!output]+ 🟨 Yellow Means Output
> Every one of the **917 yellow topics** across all three XMind sheets was classified as an output and mapped into Obsidian.
> Detected source colors: `#F3D321FF, #FDD834FF`.
> The text label **OUTPUT** is included so meaning does not depend on color alone.

## Totals

- Sheet `1`: **197**
- Sheet `2`: **492**
- Sheet `Methodology`: **228**
- **Grand total: 917**

## Original Methodology Outputs

- [[Methodology/CWES XMind Methodology|Open 228 outputs in their original methodology context]]

## Module Output Lists

### Sheet 1

- [[Outputs/Modules/Web Fundamental Outputs|Web Fundamental]] — **4** outputs
- [[Outputs/Modules/Web Proxy Outputs|Web Proxy]] — **1** outputs
- [[Outputs/Modules/Attacking Using Ffuf Outputs|Attacking Using Ffuf]] — **19** outputs
- [[Outputs/Modules/Javascript Deobfuscation Outputs|Javascript Deobfuscation]] — **0** outputs
- [[Outputs/Modules/Cross-Site Scripting (XSS) Outputs|Cross-Site Scripting (XSS)]] — **19** outputs
- [[Outputs/Modules/Information Gathering Outputs|Information Gathering]] — **5** outputs
- [[Outputs/Modules/SQL Injection Fundamentals Outputs|SQL Injection Fundamentals]] — **40** outputs
- [[Outputs/Modules/SQLMap Essentials Outputs|SQLMap Essentials]] — **32** outputs
- [[Outputs/Modules/Command Injection Outputs|Command Injection]] — **38** outputs
- [[Outputs/Modules/File Upload Attacks Outputs|File Upload Attacks]] — **39** outputs

### Sheet 2

- [[Outputs/Modules/Server-side Attacks Outputs|Server-side Attacks]] — **48** outputs
- [[Outputs/Modules/Login Brute Forcing Outputs|Login Brute Forcing]] — **14** outputs
- [[Outputs/Modules/Broken Authentication Outputs|Broken Authentication]] — **40** outputs
- [[Outputs/Modules/Web Attacks (can be found in any web application) Outputs|Web Attacks (can be found in any web application)]] — **42** outputs
- [[Outputs/Modules/File Inclusion Outputs|File Inclusion]] — **63** outputs
- [[Outputs/Modules/Attacking GraphQL Outputs|Attacking GraphQL]] — **42** outputs
- [[Outputs/Modules/API Attacks Outputs|API Attacks]] — **51** outputs
- [[Outputs/Modules/Attacking Common Applications Outputs|Attacking Common Applications]] — **192** outputs
- [[Outputs/Modules/Bug Bounty Hunting Process Outputs|Bug Bounty Hunting Process]] — **0** outputs
