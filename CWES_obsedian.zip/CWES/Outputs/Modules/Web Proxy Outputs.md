---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "1"
module: "Web Proxy"
output_topics: 1
---

# Web Proxy — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> ProxyChains-3.1 (http://proxychains.sf.net)
> &lt;!DOCTYPE html&gt;
>
> **Source path:** Web Proxy → Proxychains → Use in CLI → proxychains curl -k http://SERVER_IP:PORT → ProxyChains-3.1 (http://proxychains.sf.net) &lt;!DOCTYPE html&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2dbf1a75-7b36-469b-93ff-793ab9cf5a49 -->
