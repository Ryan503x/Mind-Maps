---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "1"
module: "Javascript Deobfuscation"
output_topics: 0
---

# Javascript Deobfuscation — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

> [!note] No yellow outputs
> Every topic in this source module was checked. No yellow/output topics were present.
