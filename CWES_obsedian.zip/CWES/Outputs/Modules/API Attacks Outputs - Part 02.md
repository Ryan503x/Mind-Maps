---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "API Attacks"
output_topics: 1
---

# API Attacks — Outputs 051–051

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

Return to [[Outputs/Modules/API Attacks Outputs|API Attacks output index]].

## Outputs

> [!output]+ 🟨 Output 051
> {
>   "successStatus": true,
>   "base64Data": "SFRCe2YxOTBiODBjZDU0M2E4NGIyMzZlOTJhMDdhOWQ4ZDU5fQo="
> }
>
> **Source path:** API Attacks → Skills Assessment → Submit the contents of the flag at '/flag.txt'. → /api/v2/suppliers/current-user/cv → GET → {   "successStatus": true,   "base64Data": "SFRCe2YxOTBiODBjZDU0M2E4NGIyMzZlOTJhMDdhOWQ4ZDU5fQo=" }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4568fe29-14ea-4143-99bf-6fedd44650cb -->
