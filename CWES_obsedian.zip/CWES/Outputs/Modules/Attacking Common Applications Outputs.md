---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "Attacking Common Applications"
output_topics: 192
---

# Attacking Common Applications — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Output Chunks

- [[Outputs/Modules/Attacking Common Applications Outputs - Part 01|Outputs 001–050]]
- [[Outputs/Modules/Attacking Common Applications Outputs - Part 02|Outputs 051–100]]
- [[Outputs/Modules/Attacking Common Applications Outputs - Part 03|Outputs 101–150]]
- [[Outputs/Modules/Attacking Common Applications Outputs - Part 04|Outputs 151–192]]
