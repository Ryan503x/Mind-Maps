---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "1"
module: "Web Fundamental"
output_topics: 4
---

# Web Fundamental — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> curl http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/api.php/city/london
> [{"city_name":"London","country_name":"(UK)"}]
>
> **Source path:** Web Fundamental → Fundamental → Introduction to web application → curl → CRUD API → Read data → curl http://&lt;SERVER_IP&gt;:&lt;PORT&gt;/api.php/city/london [{"city_name":"London","country_name":"(UK)"}]
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7fec6aa0-e211-4226-bc60-99d37519153d -->

> [!output]+ 🟨 Output 002
> curl -s http://94.237.123.87:34537/api.php/city/london | jq
> "city_name": "London",
>     "country_name": "(UK)"
>
> **Source path:** Web Fundamental → Fundamental → Introduction to web application → curl → CRUD API → Read data → retrieve all entries in the table: → curl -s http://94.237.123.87:34537/api.php/city/ | jq → curl -s http://94.237.123.87:34537/api.php/city/london | jq "city_name": "London",     "country_name": "(UK)"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 920d7128-9f8a-456a-877a-07807729a3d0 -->

> [!output]+ 🟨 Output 003
> curl -s http://94.237.123.87:34537/api.php/city/flag | jq
> "city_name": "flag",
>     "country_name": "(UK)"
>
> **Source path:** Web Fundamental → Fundamental → Introduction to web application → curl → CRUD API → Change data → PUT → curl -X PUT http://94.237.123.87:34537/api.php/city/london \ -H "Content-Type: application/json" \ -d '{"city_name": "flag", "country_name": "(UK)"}' → curl -s http://94.237.123.87:34537/api.php/city/flag | jq "city_name": "flag",     "country_name": "(UK)"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fb2f51f2-a6fb-4c8a-9ab7-fb42ca5aeab8 -->

> [!output]+ 🟨 Output 004
> curl 94.237.120.223:58055/index.php?id=1
> superadmin
>
> **Source path:** Web Fundamental → Introduction → Development Framwork &amp; API → API → example → curl 94.237.120.223:58055/index.php?id=1 superadmin
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9f013563-1278-4bc9-9bef-35ea405d4262 -->
