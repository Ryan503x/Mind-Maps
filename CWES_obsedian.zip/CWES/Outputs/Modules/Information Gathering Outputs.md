---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "1"
module: "Information Gathering"
output_topics: 5
---

# Information Gathering — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> curl -I inlanefreight.com
>
> Server: Apache/2.4.41
> X-Redirect-By: WordPress
>
> **Source path:** Information Gathering → Fingerprinting → Example → curl -I inlanefreight.com  Server: Apache/2.4.41 X-Redirect-By: WordPress
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: af9ca38d-1ed0-4e8b-a8c4-489926189aec -->

> [!output]+ 🟨 Output 002
> wafw00f inlanefreight.com
>
> [+] The site https://inlanefreight.com is behind Wordfence (Defiant) WAF.
>
> **Source path:** Information Gathering → Fingerprinting → Example → wafw00f inlanefreight.com  [+] The site https://inlanefreight.com is behind Wordfence (Defiant) WAF.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7be257c7-be2d-420a-913e-f64e642f8ae9 -->

> [!output]+ 🟨 Output 003
> web1337
>
> **Source path:** Information Gathering → Skills Assessment → ffuf -u http://94.237.48.12:43611/ -H "Host: FUZZ.inlanefreight.htb" -w ../wordlists/SecLists/Discovery/DNS/subdomains-top1million-110000.txt -fs 120 -t 50 → web1337
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 900b1e85-3332-4907-960b-20bc4338345c -->

> [!output]+ 🟨 Output 004
> Disallow
> /admin_h1dd3n/
>
> **Source path:** Information Gathering → Skills Assessment → ffuf -u http://94.237.48.12:43611/ -H "Host: FUZZ.inlanefreight.htb" -w ../wordlists/SecLists/Discovery/DNS/subdomains-top1million-110000.txt -fs 120 -t 50 → web1337 → curl -k http://94.237.48.12:43611/robots.txt -H "Host: web1337.inlanefreight.htb" → Disallow /admin_h1dd3n/
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bce4bdc1-cc9b-4f2f-8127-3b0afd1f169e -->

> [!output]+ 🟨 Output 005
> dev
>
> **Source path:** Information Gathering → Skills Assessment → ffuf -u http://94.237.48.12:43611/ -H "Host: FUZZ.inlanefreight.htb" -w ../wordlists/SecLists/Discovery/DNS/subdomains-top1million-110000.txt -fs 120 -t 50 → web1337 → curl -k http://94.237.48.12:43611/robots.txt -H "Host: web1337.inlanefreight.htb" → Disallow /admin_h1dd3n/ → curl http://94.237.48.12:43611/admin_h1dd3n/ -H "Host: web1337.inlanefreight.htb" → The admin panel is currently under maintenance, but the API is still accessible with the key e963d863ee0e82ba7080fbf558ca0d3f → ffuf -u http://94.237.48.12:43611/ -H "Host: FUZZ.web1337.inlanefreight.htb" -w ../wordlists/SecLists/Discovery/DNS/subdomains-top1million-110000.txt -fs 120 -t 50 → dev
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d3dfeb8c-7715-4b48-8224-4f8a889bf6f3 -->
