---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "File Inclusion"
output_topics: 63
---

# File Inclusion — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Output Chunks

- [[Outputs/Modules/File Inclusion Outputs - Part 01|Outputs 001–050]]
- [[Outputs/Modules/File Inclusion Outputs - Part 02|Outputs 051–063]]
