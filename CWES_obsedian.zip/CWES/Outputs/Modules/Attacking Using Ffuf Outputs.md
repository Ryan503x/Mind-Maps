---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "1"
module: "Attacking Using Ffuf"
output_topics: 19
---

# Attacking Using Ffuf — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> .php                    [Status: 200, Size: 0, Words: 1, Lines: 1]
> .phps                   [Status: 403, Size: 283, Words: 20, Lines: 10]
>
> **Source path:** Attacking Using Ffuf → Fuzz → Extension Fuzzing → usage → ffuf -w /opt/useful/seclists/Discovery/Web-Content/web-extensions.txt:FUZZ -u http://SERVER_IP:PORT/blog/indexFUZZ → .php                    [Status: 200, Size: 0, Words: 1, Lines: 1]  .phps                   [Status: 403, Size: 283, Words: 20, Lines: 10]
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a5941678-902d-4495-bec1-d325f974bd3b -->

> [!output]+ 🟨 Output 002
> id
>
> **Source path:** Attacking Using Ffuf → Parameter Fuzzing → POST → ffuf -w /opt/useful/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u http://admin.academy.htb:PORT/admin/admin.php -X POST -d 'FUZZ=key' -H 'Content-Type: application/x-www-form-urlencoded' -fs xxx → id
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 507d288c-905a-4532-8feb-9b5fee3893e8 -->

> [!output]+ 🟨 Output 003
> &lt;div class='center'&gt;&lt;p&gt;Invalid id!&lt;/p&gt;&lt;/div&gt;
>
> **Source path:** Attacking Using Ffuf → Parameter Fuzzing → POST → ffuf -w /opt/useful/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u http://admin.academy.htb:PORT/admin/admin.php -X POST -d 'FUZZ=key' -H 'Content-Type: application/x-www-form-urlencoded' -fs xxx → id → curl http://admin.academy.htb:PORT/admin/admin.php -X POST -d 'id=key' -H 'Content-Type: application/x-www-form-urlencoded' → &lt;div class='center'&gt;&lt;p&gt;Invalid id!&lt;/p&gt;&lt;/div&gt;
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9bb2a707-bc3f-4866-b200-47c5c6dcb374 -->

> [!output]+ 🟨 Output 004
> test
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → subdomain/vhost scan → ffuf -u http://academy.htb:54628/ -H "Host: FUZZ.archive.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → test
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 503df496-dba2-486a-92c3-d910a3997b82 -->

> [!output]+ 🟨 Output 005
> archive
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → subdomain/vhost scan → ffuf -u http://academy.htb:54628/ -H "Host: FUZZ.archive.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → archive
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fba3d82d-490b-4ab6-a356-e2909d70c9e0 -->

> [!output]+ 🟨 Output 006
> faculty
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → subdomain/vhost scan → ffuf -u http://academy.htb:54628/ -H "Host: FUZZ.archive.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → faculty
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 480a8baf-571a-4fea-b3be-12d5c5bff52f -->

> [!output]+ 🟨 Output 007
> .phps 403
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → extensions scan → ffuf -u http://academy.htb:54628/indexFUZZ  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → .phps 403
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c8cce7d1-ac27-426c-8c34-7abe1faba024 -->

> [!output]+ 🟨 Output 008
> .php 200
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → extensions scan → ffuf -u http://academy.htb:54628/indexFUZZ -H "Host: test.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → .php 200
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 84a7017c-d086-48b9-8711-ffc92cc5aa99 -->

> [!output]+ 🟨 Output 009
> .phps 403
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → extensions scan → ffuf -u http://academy.htb:54628/indexFUZZ -H "Host: test.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → .phps 403
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ef9c8158-4a5e-4349-a00f-914070ae0036 -->

> [!output]+ 🟨 Output 010
> .php 200
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → extensions scan → ffuf -u http://academy.htb:54628/indexFUZZ -H "Host: faculty.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → .php 200
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 950b7bb0-0a91-47cf-ac7d-19aa994aff18 -->

> [!output]+ 🟨 Output 011
> .php 200
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → extensions scan → ffuf -u http://academy.htb:54628/indexFUZZ -H "Host: faculty.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → .php 200
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: e2897218-7004-4d17-9e71-1aad66bc1acc -->

> [!output]+ 🟨 Output 012
> .phps 403
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → extensions scan → ffuf -u http://academy.htb:54628/indexFUZZ -H "Host: faculty.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → .phps 403
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ac4ba41a-24cd-45dc-9697-934bf6dee84f -->

> [!output]+ 🟨 Output 013
> .php 200
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → extensions scan → ffuf -u http://academy.htb:54628/indexFUZZ -H "Host: archive.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → .php 200
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6666ddfd-8938-43de-9e69-e102a7b015d2 -->

> [!output]+ 🟨 Output 014
> .phps 403
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → extensions scan → ffuf -u http://academy.htb:54628/indexFUZZ -H "Host: archive.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985 → .phps 403
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: cb01536e-89bc-49a2-a4d8-26fa79d378da -->

> [!output]+ 🟨 Output 015
> linux-security.php7
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → Page Fuzzing → Hint Run a recursive scan on all sub-domains you found, and use all of the extensions you found. Use 'PORT' instead of the port shown above, like http://xxxxx.academy.htb:PORT/xxxxxxx ..etc → ffuf -u 'http://academy.htb:54628/courses/FUZZ' -H 'Host: faculty.academy.htb'  -w /usr/share/seclists/Discovery/Web-Content/directory-list-lowercase-2.3-small.txt -recursion -recursion-depth 2  -e .php,.phps,.php7  -fs 284 → linux-security.php7
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 42c52ced-3e53-4b8d-ad8e-446d732ffcbc -->

> [!output]+ 🟨 Output 016
> user
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → Parameter fuzzing → ffuf -u 'http://academy.htb:54628/courses/linux-security.php7?FUZZ=key' -H 'Host: faculty.academy.htb'  -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt -fs 774 → user
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 0e032c7b-33b5-4018-ab78-d2f0187b5c4b -->

> [!output]+ 🟨 Output 017
> user
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → Parameter fuzzing → ffuf -u 'http://academy.htb:54628/courses/linux-security.php7' -X POST -H 'Host: faculty.academy.htb' -H 'Content-Type: application/x-www-form-urlencoded' -d 'FUZZ=key' -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ  -fs 774 → user
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d1f5146b-1149-4d49-95f5-f28d1a53b7ba -->

> [!output]+ 🟨 Output 018
> username
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → Parameter fuzzing → ffuf -u 'http://academy.htb:54628/courses/linux-security.php7' -X POST -H 'Host: faculty.academy.htb' -H 'Content-Type: application/x-www-form-urlencoded' -d 'FUZZ=key' -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ  -fs 774 → username
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a2f2e087-b59b-406b-9c47-5f8dd6ab5214 -->

> [!output]+ 🟨 Output 019
> harry
>
> **Source path:** Attacking Using Ffuf → Skills Assessment - Web Fuzzing → Get the value of parameters → Try fuzzing the parameters you identified for working values. One of them should return a flag. What is the content of the flag? → ffuf -u 'http://academy.htb:54628/courses/linux-security.php7' -X POST -H 'Host: faculty.academy.htb' -H 'Content-Type: application/x-www-form-urlencoded' -d 'username=FUZZ' -w /usr/share/seclists/Usernames/xato-net-10-million-usernames.txt -fs 781 → harry
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 498254a1-9c2b-459b-a6f6-5e06ea8a1bc5 -->
