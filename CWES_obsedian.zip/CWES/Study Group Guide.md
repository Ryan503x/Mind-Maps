---
tags: [CWES, study-group, collaboration]
type: guide
---

# CWES Study Group Guide

This guide helps a small authorized study group use the CWES notes consistently without losing commands, evidence, or personal observations.

## Start Here

- [[CWES Index|CWES Path Index]] — modules in their imported sheet order.
- [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]] — modules grouped by security domain.
- [[Glossary|CWES Glossary]] — common terms and distinctions.
- [[Templates/PT Study Session Template|PT Study Session Template]] — reusable session notes.
- [[Templates/Security Finding Template|Security Finding Template]] — professional finding format.

## Suggested Group Workflow

1. Choose one module and read its **Study Companion** section.
2. Assign a driver, observer, and note keeper; rotate roles each session.
3. Record the target, authorization, start time, tools, and lab reset state.
4. Establish a baseline before modifying requests or payloads.
5. Change one variable at a time and record both positive and negative results.
6. Preserve exact commands, sanitized requests/responses, screenshots, and cleanup actions.
7. End by explaining the root cause, impact, and remediation in your own words.
8. Convert confirmed findings into the shared finding template.

## Note Conventions

- Use `##` for major sections and `###` for individual techniques.
- Put commands and code in fenced blocks when adding new content.
- Use `[[wikilinks]]` for related modules and maps.
- Mark personal additions with `> [!note]` so they remain distinguishable from imported material.
- Mark lab-only secrets and flags with `> [!warning] Lab-only data`.
- Do not store real production credentials, customer data, or unredacted tokens.

## Quality Checklist

A complete study note should answer:

- What prerequisite knowledge is required?
- What is the security boundary being tested?
- What normal behavior establishes the baseline?
- Which input or state is attacker-controlled?
- What observation confirms or rejects the hypothesis?
- What privileges and user interaction are required?
- What is the smallest safe proof of impact?
- How should the issue be remediated and retested?

## Safety and Ethics

Use these procedures only in Hack The Box, personal labs, or systems for which every participant has explicit authorization. Respect scope, rate limits, account lockout constraints, privacy requirements, and cleanup obligations.
