---
tags: [CWES, start]
type: navigation
---

# CWES Vault

Start with one of these navigation notes:

- [[CWES Index|CWES Path Index]] — sequential module list and imported references.
- [[Methodology/CWES Methodology Map|CWES Methodology Decision Tree]] — observation-driven **if you see this, try this** workflow with attacks and tools.
- [[Methodology/CWES XMind Methodology|Original XMind Methodology]] — all 2,415 methodology, exam-note, and HTB-machine topics imported from `CWES.xmind`.
- [[Outputs/CWES Outputs Index|CWES XMind Outputs]] — all 917 yellow/output topics across every source sheet.
- [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]] — thematic navigation and related modules.
- [[Maps/CWES Mind Map|CWES Curriculum Mind Map]] — visual overview of the seven domains and 19 modules.
- [[Study Group Guide|CWES Study Group Guide]] — shared workflow, glossary, and reusable templates.

For a focused visual map, open the local graph from **CWES Knowledge Graph**.
