---
tags: [CWES, MOC, authentication, authorization]
type: domain-map
---

# Authentication and Access Control

## Modules

- [[Modules/Login Brute Forcing|Login Brute Forcing]] — bounded credential testing and defensive controls.
- [[Modules/Broken Authentication|Broken Authentication]] — login, recovery, MFA, and session weaknesses.
- [[Modules/Web Attacks (can be found in any web application)|Web Attacks]] — IDOR, method tampering, and common authorization failures.
- [[Modules/API Attacks|API Attacks]] — object-, property-, and function-level authorization.
- [[Modules/Attacking GraphQL|Attacking GraphQL]] — resolver and mutation authorization.

## Related domains

- Capture authentication flows with [[Maps/Reconnaissance and Tooling|Reconnaissance and Tooling]].
- Authorization failures often chain with [[Maps/API and Application Security|API and Application Security]].
- Report account-impact findings through [[Maps/Reporting and Bug Bounty|Reporting and Bug Bounty]].

Back to [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]].
