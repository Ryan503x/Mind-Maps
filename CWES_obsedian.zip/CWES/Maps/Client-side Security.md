---
tags: [CWES, MOC, client-side, xss]
type: domain-map
---

# Client-side Security

## Modules

- [[Modules/Javascript Deobfuscation|Javascript Deobfuscation]] — recover client behavior, endpoints, and indicators.
- [[Modules/Cross-Site Scripting (XSS)|Cross-Site Scripting (XSS)]] — stored, reflected, DOM, and blind XSS.
- [[Modules/Web Fundamental|Web Fundamental]] — DOM, browser behavior, and HTTP foundations.
- [[Modules/Web Proxy|Web Proxy]] — capture and modify browser requests and responses.

## Related domains

- Client discoveries inform [[Maps/API and Application Security|API and Application Security]].
- Session and victim context connect to [[Maps/Authentication and Access Control|Authentication and Access Control]].
- Findings should flow into [[Maps/Reporting and Bug Bounty|Reporting and Bug Bounty]].

Back to [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]].
