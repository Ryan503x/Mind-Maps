---
tags: [CWES, MOC, knowledge-graph]
type: knowledge-map
aliases: [CWES Graph, CWES Knowledge Map]
---

# CWES Knowledge Graph

Use this note as the center of the CWES graph. Each domain map connects related HTB modules without changing their complete technical references.

## Domain maps

- [[Maps/Reconnaissance and Tooling|Reconnaissance and Tooling]]
- [[Maps/Authentication and Access Control|Authentication and Access Control]]
- [[Maps/Injection and Code Execution|Injection and Code Execution]]
- [[Maps/Client-side Security|Client-side Security]]
- [[Maps/Files and Server-side Attacks|Files and Server-side Attacks]]
- [[Maps/API and Application Security|API and Application Security]]
- [[Maps/Reporting and Bug Bounty|Reporting and Bug Bounty]]

## Recommended learning flow

1. [[Maps/Reconnaissance and Tooling|Map the attack surface and capture traffic]]
2. [[Maps/Authentication and Access Control|Understand identities, sessions, and authorization]]
3. [[Maps/Injection and Code Execution|Test injection boundaries]]
4. [[Maps/Client-side Security|Review browser-side attack paths]]
5. [[Maps/Files and Server-side Attacks|Assess file and server-side processing]]
6. [[Maps/API and Application Security|Apply the methodology to APIs and common applications]]
7. [[Maps/Reporting and Bug Bounty|Document and communicate findings]]

Return to [[CWES Index|CWES Path]], open the [[Methodology/CWES Methodology Map|operational methodology map]], browse the [[Methodology/CWES XMind Methodology|complete original XMind methodology]], review all [[Outputs/CWES Outputs Index|yellow XMind outputs]], open the [[Maps/CWES Mind Map|CWES Curriculum Mind Map]], or use the [[Study Group Guide|CWES Study Group Guide]].
