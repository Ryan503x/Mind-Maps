---
tags: [CWES, MOC, injection, code-execution]
type: domain-map
---

# Injection and Code Execution

## Modules

- [[Modules/SQL Injection Fundamentals|SQL Injection Fundamentals]] — manual SQL injection reasoning and validation.
- [[Modules/SQLMap Essentials|SQLMap Essentials]] — controlled automation and database enumeration.
- [[Modules/Command Injection|Command Injection]] — shell metacharacters, filters, and execution context.
- [[Modules/Server-side Attacks|Server-side Attacks]] — SSTI, SSI, XSLT injection, and SSRF.
- [[Modules/API Attacks|API Attacks]] — injection and unsafe backend processing through APIs.
- [[Modules/Attacking GraphQL|Attacking GraphQL]] — resolver input handling and injection paths.

## Related domains

- Input locations come from [[Maps/Reconnaissance and Tooling|Reconnaissance and Tooling]].
- Upload and inclusion chains continue in [[Maps/Files and Server-side Attacks|Files and Server-side Attacks]].
- Browser execution is covered by [[Maps/Client-side Security|Client-side Security]].

Back to [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]].
