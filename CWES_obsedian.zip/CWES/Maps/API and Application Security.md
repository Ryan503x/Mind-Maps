---
tags: [CWES, MOC, API, applications]
type: domain-map
---

# API and Application Security

## Modules

- [[Modules/API Attacks|API Attacks]] — REST/API inventory, authorization, resource controls, and business flows.
- [[Modules/Attacking GraphQL|Attacking GraphQL]] — schema discovery, queries, mutations, resolvers, and complexity.
- [[Modules/Attacking Common Applications|Attacking Common Applications]] — CMS, management systems, thick clients, and known applications.
- [[Modules/Web Attacks (can be found in any web application)|Web Attacks]] — reusable web weaknesses such as IDOR and method tampering.
- [[Modules/Broken Authentication|Broken Authentication]] — identities and sessions used by applications and APIs.

## Related domains

- Discover endpoints through [[Maps/Reconnaissance and Tooling|Reconnaissance and Tooling]].
- Test object and function permissions through [[Maps/Authentication and Access Control|Authentication and Access Control]].
- Test resolver and backend inputs through [[Maps/Injection and Code Execution|Injection and Code Execution]].

Back to [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]].
