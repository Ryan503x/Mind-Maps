---
tags: [CWES, MOC, recon, tooling]
type: domain-map
---

# Reconnaissance and Tooling

## Modules

- [[Modules/Web Fundamental|Web Fundamental]] — HTTP, requests, responses, and web architecture.
- [[Modules/Information Gathering|Information Gathering]] — passive and active attack-surface discovery.
- [[Modules/Attacking Using Ffuf|Attacking Using Ffuf]] — content, parameter, and virtual-host discovery.
- [[Modules/Web Proxy|Web Proxy]] — interception, replay, modification, and evidence collection.

## Related domains

- Discovery feeds [[Maps/API and Application Security|API and Application Security]].
- Captured requests support [[Maps/Injection and Code Execution|Injection and Code Execution]].
- Session observations support [[Maps/Authentication and Access Control|Authentication and Access Control]].

Back to [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]].
