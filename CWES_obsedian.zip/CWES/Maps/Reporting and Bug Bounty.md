---
tags: [CWES, MOC, reporting, bug-bounty]
type: domain-map
---

# Reporting and Bug Bounty

## Primary module

- [[Modules/Bug Bounty Hunting Process|Bug Bounty Hunting Process]] — scope, validation, CVSS, CWE, evidence, disclosure, and communication.

## Reporting workflow

1. Start from a confirmed technical finding in another domain map.
2. Record the affected asset, role, request, response, prerequisite, and execution context.
3. Separate observed behavior from maximum credible impact.
4. Assign the root-cause CWE and justify the CVSS vector.
5. Provide reproducible low-impact steps and practical remediation.
6. Redact credentials, tokens, personal information, and unnecessary sensitive output.

## Evidence sources

- [[Maps/Reconnaissance and Tooling|Reconnaissance and Tooling]]
- [[Maps/Authentication and Access Control|Authentication and Access Control]]
- [[Maps/Injection and Code Execution|Injection and Code Execution]]
- [[Maps/Client-side Security|Client-side Security]]
- [[Maps/Files and Server-side Attacks|Files and Server-side Attacks]]
- [[Maps/API and Application Security|API and Application Security]]

Back to [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]].
