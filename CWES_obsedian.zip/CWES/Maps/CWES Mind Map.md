---
tags: [CWES, mind-map, excalidraw, navigation]
type: visual-map
---

# CWES Curriculum Mind Map

> [!info] Looking for the testing methodology?
> Open [[Methodology/CWES Methodology Map|CWES Methodology Decision Tree]] for the **if you see this, try this** workflow, attack families, and tools. This note is the curriculum/module overview.

## Recommended: Native Obsidian Canvas

- [[Maps/CWES Mind Map.canvas|Open the native CWES Canvas]] — works in Obsidian without a community plugin.

## Excalidraw Edition

![[Maps/CWES Mind Map.excalidraw]]

- [[Maps/CWES Mind Map.excalidraw|Open the editable Excalidraw drawing]]
- If Obsidian does not render the Excalidraw edition visually, install the **Excalidraw** community plugin or drag the `.excalidraw` file into [excalidraw.com](https://excalidraw.com/).

## What It Contains

- One central CWES node
- Seven security-domain branches
- All 19 HTB module nodes
- Clickable nodes that open their corresponding Obsidian notes
- Color-coded domains for fast visual navigation

## Navigation

- [[CWES Index|CWES Path Index]]
- [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]]
- [[Study Group Guide|CWES Study Group Guide]]
