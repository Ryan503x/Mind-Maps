---
tags: [CWES, MOC, file-security, server-side]
type: domain-map
---

# Files and Server-side Attacks

## Modules

- [[Modules/File Upload Attacks|File Upload Attacks]] — validation bypass, storage behavior, and controlled execution proofs.
- [[Modules/File Inclusion|File Inclusion]] — LFI, wrappers, logs, uploads, and inclusion chains.
- [[Modules/Server-side Attacks|Server-side Attacks]] — SSRF, SSTI, SSI, and XSLT processing.
- [[Modules/Command Injection|Command Injection]] — operating-system command boundaries.
- [[Modules/Attacking Common Applications|Attacking Common Applications]] — product-specific upload, deployment, and server-management paths.

## Common chains

- Upload → accessible file → server-side parsing or execution.
- File inclusion → source disclosure → credentials or configuration.
- Upload or log poisoning → file inclusion → controlled execution.
- SSRF → internal service discovery → privileged application access.

## Related domains

- Identify handlers with [[Maps/Reconnaissance and Tooling|Reconnaissance and Tooling]].
- Validate backend inputs through [[Maps/Injection and Code Execution|Injection and Code Execution]].

Back to [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]].
