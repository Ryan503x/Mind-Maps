---
tags: [CWES, methodology, decision-tree, canvas, excalidraw]
type: visual-methodology
aliases: [CWES Methodology Map, If You See This Map]
---

# CWES Methodology Decision Tree

This is the observation-driven map: **if you see a feature or clue, follow the matching branch to the attack families, manual checks, and tools recorded in the CWES notes.**

> [!tip] Original XMind methodology
> Open [[Methodology/CWES XMind Methodology|CWES XMind Methodology]] for all **2,415 source topics**, including the Arabic methodology branches, CWES exam notes, HTB machine notes, commands, URLs, and images.

## Recommended: Native Obsidian Canvas

- [[Methodology/CWES Methodology Decision Tree.canvas|Open the native methodology Canvas]]

It works directly in Obsidian without a community plugin.

### How to open the linked technical notes

Each decision has two connected cards:

1. The large card explains **IF / TRY / ATTACKS / TOOLS**.
2. The smaller file card directly underneath is the real note link.
3. The purple **Original XMind Methodology** card at the top opens the complete 2,415-topic source methodology.

**Double-click the smaller file card** to open the complete module note. A single click only selects or previews the Canvas card, which is why you may see only its title.

## Excalidraw Edition

![[Methodology/CWES Methodology Decision Tree.excalidraw]]

- [[Methodology/CWES Methodology Decision Tree.excalidraw|Open the editable Excalidraw methodology map]]
- Every colored decision card and its text carry the same Obsidian link. Click the card, then click the link icon that appears to open the complete technical note.
- If it does not render visually in Obsidian, install the Excalidraw community plugin or drag the file into [excalidraw.com](https://excalidraw.com/).

## Full Written Methodology

- [[Methodology/If You See This - Web Testing Methodology|If You See This — Try This]]

The written edition provides the detailed decision logic, attack families, tools, validation steps, continuation notes, and authorization boundaries behind each visual card.

## Map Sections

1. Discover and baseline
2. Identity and access
3. Injection and browser
4. Files and parsers
5. Server processing and APIs
6. Product validation and reporting

## Related Navigation

- [[Maps/CWES Mind Map|CWES Curriculum Mind Map]] — shows where the modules belong.
- [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]] — shows semantic relationships.
- [[Study Group Guide|CWES Study Group Guide]] — explains the group workflow.
