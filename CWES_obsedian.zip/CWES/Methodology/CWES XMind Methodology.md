---
tags: [CWES, methodology, XMind, imported-reference, index]
source_file: CWES.xmind
source_sheet: Methodology
topic_id: "c9cf9a95-60b2-46f2-8aa3-22d59847d52f"
topics_preserved: 2415
---

# CWES XMind Methodology

> [!success] Complete source methodology imported
> This index preserves all **2,415 topics** from the original XMind `Methodology` sheet.
> The Arabic and English source wording, commands, URLs, notes, and hierarchy are retained. Potentially active HTML is rendered as inert text.
> Yellow XMind topics are rendered as searchable **🟨 OUTPUT** callouts. Detected outputs: **228**.

## How This Fits the Vault

- [[Methodology/CWES Methodology Map|Operational visual decision tree]] — synthesized `IF → TRY → ATTACKS → TOOLS` workflow.
- [[Methodology/If You See This - Web Testing Methodology|Written operational methodology]] — curated testing decisions and evidence guidance.
- [[Outputs/CWES Outputs Index|CWES XMind Output Index]] — every yellow/output topic across all three source sheets.
- **This note and its child notes** — the complete methodology authored in the XMind source.

## Original Methodology Branches

- [[Methodology/XMind Methodology/01 - الفحص الاولي|الفحص الاولي — Initial reconnaissance]] — 106 topics
- [[Methodology/XMind Methodology/02 - هجمات الحقن|هجمات الحقن — Injection attacks]] — 779 topics
- [[Methodology/XMind Methodology/03 - الهوية والدخول|الهوية والدخول — Identity and access]] — 169 topics
- [[Methodology/XMind Methodology/04 - هجمات دخول|هجمات دخول — Access and exploitation techniques]] — 1157 topics
- [[Methodology/XMind Methodology/05 - CWES Exam Notes|CWES Exam Notes — CWES examination workflow and evidence notes]] — 198 topics
- [[Methodology/XMind Methodology/06 - HTB Machines|HTB Machines — Referenced Hack The Box machines]] — 5 topics

## Source Details

- Source: `C:\Users\rayan\Desktop\CWES.xmind`
- Sheet: `Methodology`
- Root title in XMind: `CWES Methodolgy`
- Imported topics: **2,415**
- Split threshold: 175 topics per rendered subtree
