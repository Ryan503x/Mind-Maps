---
tags: [CWES, methodology, decision-tree, tools, study-group]
type: methodology
aliases: [If You See This Try This, CWES Web Testing Methodology]
---

# If You See This — Try This

> [!warning] Authorized testing only
> Use this decision tree only in Hack The Box, personal labs, or explicitly authorized targets. Establish scope, rate limits, test accounts, and stop conditions before testing.

This methodology converts the CWES reference into an observation-driven workflow: identify what the application exposes, choose the matching test family, establish a baseline, change one variable at a time, and preserve evidence.

> [!info] Complete source methodology
> This curated workflow is complemented by [[Methodology/CWES XMind Methodology|CWES XMind Methodology]], which preserves all **2,415 topics** from the original XMind `Methodology` sheet.

## Universal Workflow

1. **Confirm scope** — target, accounts, roles, allowed techniques, rate limits, and cleanup requirements.
2. **Capture a baseline** — record the normal request, response, status, size, timing, and application state.
3. **Map trust boundaries** — identify attacker-controlled sources and security-sensitive sinks.
4. **Choose a branch below** — follow what you can observe rather than firing every tool.
5. **Test manually first** — confirm behavior before automation.
6. **Use the smallest safe proof** — demonstrate the root cause without unnecessary data access or service impact.
7. **Retest and chain carefully** — combine confirmed weaknesses only when scope allows it.
8. **Report and clean up** — use [[Templates/Security Finding Template|Security Finding Template]].

---

## 1. New Domain, Host, or Application

### If You See

- A new hostname, IP address, or web application with an unknown attack surface.

### Try This

- Identify DNS records, virtual hosts, exposed ports, TLS details, technologies, frameworks, and WAF behavior.
- Start passive-first, then validate discovered assets actively.
- Record which observations are confirmed versus inferred.

### Tools From the Notes

- `whois`, `dig`, `curl`, `nmap`, `whatweb`, `wafw00f`
- Then continue to `ffuf`, `gobuster`, or `feroxbuster` for scoped discovery.

### Continue To

- [[Modules/Information Gathering|Information Gathering]]
- [[Modules/Web Fundamental|Web Fundamental]]

---

## 2. Unknown Routes, Files, Extensions, Vhosts, or Parameters

### If You See

- A small visible application, predictable paths, missing endpoints, wildcard responses, or parameters referenced in HTML/JavaScript.

### Try This

- Fuzz directories, files, extensions, virtual hosts, parameter names, and bounded parameter values.
- Calibrate the baseline first and filter by response size, words, lines, status, or timing.
- Manually verify every interesting result; do not treat scanner output as proof.

### Tools From the Notes

- `ffuf`, `SecLists`, `curl`, Burp Intruder
- Alternatives present in the notes: `gobuster`, `feroxbuster`

### Continue To

- [[Modules/Attacking Using Ffuf|Attacking Using Ffuf]]
- [[Modules/Web Proxy|Web Proxy]]

---

## 3. JavaScript Files, Encoded Values, or Hidden Client Logic

### If You See

- Minified or obfuscated JavaScript, encoded strings, client-side validation, hidden routes, API endpoints, or secrets embedded in the front end.

### Try This

- Preserve the original script and beautify it.
- Identify whether the content is minified, packed, obfuscated, or merely encoded.
- Decode one layer at a time and trace data from browser-controlled sources to sensitive sinks.
- Compare client-side checks with the actual server-side behavior.

### Tools From the Notes

- Browser source viewer and developer tools
- Beautifiers and safe offline decoding workflows
- Burp for reproducing and modifying the discovered requests

### Continue To

- [[Modules/Javascript Deobfuscation|JavaScript Deobfuscation]]
- [[Modules/Web Proxy|Web Proxy]]

---

## 4. Login, Password Reset, MFA, or Session Tokens

### If You See

- Login forms, Basic Authentication, password-reset tokens, MFA codes, remember-me cookies, session identifiers, or protected routes.

### Try This

- Check user enumeration, default credentials, password policy, lockout, rate limiting, recovery-token entropy, MFA binding, direct route access, parameter modification, fixation, rotation, timeout, and logout invalidation.
- Compare behavior with at least two authorized accounts where possible.
- Use bounded attempts and explicit stop conditions to avoid lockout or availability impact.

### Tools From the Notes

- Burp, `ffuf`, `curl`, `SecLists`
- For explicitly permitted online password testing: `hydra`, `medusa`, `cupp`

### Continue To

- [[Modules/Broken Authentication|Broken Authentication]]
- [[Modules/Login Brute Forcing|Login Brute Forcing]]

---

## 5. Numeric IDs, UUIDs, Filenames, or Other Object References

### If You See

- Endpoints such as `/users/123`, object IDs in JSON, download filenames, report identifiers, GUIDs, or predictable references.

### Try This

- Build a two-user authorization matrix: owner, other user, privileged user, and unauthenticated user.
- Replay the baseline while changing only the object reference.
- Test read, update, delete, download, and nested-object operations independently.
- Decode or reconstruct references when the application only obscures them.

### Attack Families

- IDOR / BOLA
- Horizontal and vertical authorization failures
- Mass enumeration only after one object-level failure is safely confirmed

### Tools From the Notes

- Burp Repeater/Intruder, `curl`, `ffuf`, `jq`

### Continue To

- [[Modules/Web Attacks (can be found in any web application)|Web Attacks]]
- [[Modules/API Attacks|API Attacks]]

---

## 6. Admin Functions, Role Names, Alternate Methods, or Hidden API Operations

### If You See

- Admin-only UI actions, role strings, privileged endpoint names, method-dependent behavior, undocumented operations, or differences between frontend and API permissions.

### Try This

- Call the function with a lower-privileged identity.
- Test supported HTTP methods individually and compare route protection.
- Check whether the API trusts role or ownership fields supplied by the client.
- Compare frontend restrictions with backend enforcement.

### Attack Families

- BFLA / vertical privilege escalation
- HTTP verb tampering
- Authentication bypass through direct access or parameter modification

### Tools From the Notes

- Burp, `curl`, `ffuf`, browser developer tools

### Continue To

- [[Modules/API Attacks|API Attacks]]
- [[Modules/Broken Authentication|Broken Authentication]]
- [[Modules/Web Attacks (can be found in any web application)|Web Attacks]]

---

## 7. JSON Bodies with Optional, Hidden, or Sensitive Properties

### If You See

- Rich JSON objects, client-controlled role/status fields, undocumented properties, update objects, or responses containing more data than the UI needs.

### Try This

- Compare create, read, update, and patch schemas.
- Add, remove, or modify one property at a time.
- Test read exposure separately from write authorization.
- Verify server-side allowlists and field-level authorization.

### Attack Families

- BOPLA
- Mass assignment
- Excessive data exposure

### Tools From the Notes

- Burp Repeater, `curl`, `jq`, API documentation

### Continue To

- [[Modules/API Attacks|API Attacks]]

---

## 8. Search, Filter, Login, Sort, or Database-Like Input

### If You See

- Database errors, quotes changing behavior, search/filter parameters, sort/order fields, numeric conditions, or stable response differences.

### Try This

- Determine the input context and establish true/false behavior manually.
- Test quotes, comments, boolean conditions, timing, UNION behavior, and error handling as appropriate.
- Fingerprint the database only after confirming injection.
- Enumerate progressively and access the minimum data required for proof.

### Attack Families

- Error-based, UNION-based, boolean-blind, time-based, stacked, or out-of-band SQL injection

### Tools From the Notes

- Burp and manual payloads first
- `sqlmap` after manual confirmation, preferably with a captured request using `-r`

### Continue To

- [[Modules/SQL Injection Fundamentals|SQL Injection Fundamentals]]
- [[Modules/SQLMap Essentials|SQLMap Essentials]]

---

## 9. Ping, DNS, Conversion, Archive, Backup, or System Utility Features

### If You See

- A feature likely to invoke an operating-system command: ping/traceroute, file conversion, media processing, backup, compression, diagnostic, or administrative utilities.

### Try This

- Identify the expected argument and operating-system context.
- Test separators, whitespace alternatives, quoting, encoding, and filter behavior one variable at a time.
- Confirm execution with a harmless deterministic command.
- Record the process identity and execution context; avoid destructive commands.

### Attack Families

- OS command injection
- Argument injection
- Filter and encoding bypass

### Tools From the Notes

- Burp, browser developer tools, safe listener/diagnostic tools where scope allows

### Continue To

- [[Modules/Command Injection|Command Injection]]

---

## 10. Reflected, Stored, or DOM-Controlled Content

### If You See

- User input displayed in HTML, attributes, scripts, URLs, templates, filenames, admin panels, or DOM updates.

### Try This

- Identify whether the behavior is reflected, stored, DOM-based, or blind.
- Determine the exact output context and trace source-to-sink data flow.
- Start with a harmless marker, then use the smallest context-correct execution proof.
- Check whether the same value reaches a higher-privileged user or administrative interface.

### Attack Families

- Reflected XSS
- Stored XSS
- DOM XSS
- Blind XSS

### Tools From the Notes

- Browser developer tools, page source, Burp, controlled callback/listener for authorized blind tests

### Continue To

- [[Modules/Cross-Site Scripting (XSS)|Cross-Site Scripting]]
- [[Modules/Javascript Deobfuscation|JavaScript Deobfuscation]]

---

## 11. File Upload Functionality

### If You See

- Profile images, document imports, attachments, SVG/XML uploads, archives, media processing, or filename reflection.

### Try This

- Map client-side validation, extension handling, filename normalization, MIME checking, magic-byte/content validation, storage location, renaming, retrieval, and execution.
- Test blacklist and whitelist behavior, case changes, double/reverse-double extensions, Content-Type, content signatures, and allowed active formats.
- Check filename injection, path disclosure, SVG/XML behavior, and downstream processing separately.

### Attack Families

- Arbitrary file upload
- Extension/MIME/content bypass
- Stored XSS through active formats
- XXE through XML/SVG
- Filename injection
- Upload-to-file-inclusion chains

### Tools From the Notes

- Burp, `ffuf`, `curl`, `SecLists`, `exiftool`

### Continue To

- [[Modules/File Upload Attacks|File Upload Attacks]]
- [[Modules/File Inclusion|File Inclusion]]

---

## 12. File, Page, Language, Template, Download, or Path Parameters

### If You See

- Parameters such as `file=`, `page=`, `language=`, `template=`, `download=`, or paths returned from a database.

### Try This

- Determine whether the application reads or executes the resolved file.
- Test absolute paths, traversal depth, prefixes, appended extensions, encoding, approved-path checks, and second-order values.
- If PHP is involved, assess filter wrappers for source disclosure before considering execution paths.
- Treat upload, session, or log inclusion as separate chained prerequisites.

### Attack Families

- Path traversal
- Local/remote file inclusion
- Source disclosure through PHP filters
- Second-order inclusion
- Upload/session/log poisoning chains

### Tools From the Notes

- `ffuf`, `SecLists`, `curl`, Burp

### Continue To

- [[Modules/File Inclusion|File Inclusion]]
- [[Modules/File Upload Attacks|File Upload Attacks]]

---

## 13. URL Fetch, Webhook, Import, Proxy, or Remote Resource Feature

### If You See

- URL preview, image fetch, webhook, PDF generation, import-from-URL, callback, proxy, feed, or server-side API integration.

### Try This

- Confirm whether the server performs the request.
- Test destination controls, redirects, DNS behavior, protocol restrictions, loopback/private/link-local ranges, and response visibility.
- Distinguish visible SSRF from blind SSRF.
- Use controlled infrastructure and avoid cloud metadata or internal-state access unless explicitly authorized.

### Attack Families

- SSRF
- Blind SSRF
- Internal service discovery
- API trust/unsafe-consumption chains

### Tools From the Notes

- Burp, `ffuf`, `curl`, `Gopherus` for explicitly authorized protocol testing

### Continue To

- [[Modules/Server-side Attacks|Server-side Attacks]]
- [[Modules/API Attacks|API Attacks]]

---

## 14. Template Syntax, Rendering Errors, or Server-Generated Documents

### If You See

- Template expressions reflected in server output, engine-specific errors, generated emails/documents, previews, or customizable server-side pages.

### Try This

- Start with harmless arithmetic or string expressions.
- Fingerprint the template engine from syntax and error behavior.
- Determine whether expressions are evaluated, escaped, sandboxed, or treated as data.
- Move beyond identification only when required and authorized.

### Attack Families

- SSTI
- SSI injection
- XSLT injection

### Tools From the Notes

- Burp, manual engine probes, `tplmap` only after manual identification

### Continue To

- [[Modules/Server-side Attacks|Server-side Attacks]]

---

## 15. XML, SOAP, SVG, or XSLT Input

### If You See

- XML request bodies, SOAP services, SVG uploads, document imports, DTD-related errors, or XSLT transformations.

### Try This

- Determine parser type and whether DTDs or external entities are accepted.
- Use harmless local or controlled external references first.
- Test file disclosure, blind callbacks, and server-side requests separately.
- Check whether uploaded SVG/XML is parsed during upload, storage, conversion, or viewing.

### Attack Families

- XXE
- Blind XXE
- SSRF through XML parsers
- XSLT injection

### Tools From the Notes

- Burp, `curl`, controlled callback infrastructure

### Continue To

- [[Modules/Web Attacks (can be found in any web application)|Web Attacks]]
- [[Modules/File Upload Attacks|File Upload Attacks]]
- [[Modules/Server-side Attacks|Server-side Attacks]]

---

## 16. GraphQL Endpoint or GraphQL-Like Errors

### If You See

- `/graphql`, GraphQL content types, query/mutation syntax, field suggestions, resolver errors, or a single endpoint serving many operations.

### Try This

- Identify the GraphQL engine and recover the schema through documentation, introspection, suggestions, or error behavior.
- Enumerate queries, mutations, arguments, objects, and required roles.
- Test object/field authorization, IDOR, injection, batching, aliases, depth, and complexity with safe limits.

### Tools From the Notes

- Burp, InQL, GraphQL Voyager

### Continue To

- [[Modules/Attacking GraphQL|Attacking GraphQL]]
- [[Modules/API Attacks|API Attacks]]

---

## 17. REST API, OpenAPI/Swagger, Versioned Routes, or Mobile Backend

### If You See

- `/api/`, `/v1/`, Swagger/OpenAPI documents, JSON-only workflows, bearer tokens, or mobile application endpoints.

### Try This

- Inventory endpoints, versions, methods, identities, roles, object identifiers, properties, and business workflows.
- Build an authorization matrix for BOLA, BFLA, and BOPLA.
- Check authentication, rate/resource controls, injection, SSRF, inventory gaps, and unsafe third-party API consumption.
- Compare old and new API versions and undocumented endpoints.

### Tools From the Notes

- Burp, `curl`, `ffuf`, `SecLists`, `jq`

### Continue To

- [[Modules/API Attacks|API Attacks]]
- [[Modules/Attacking GraphQL|Attacking GraphQL]]

---

## 18. Recognizable CMS, Admin Console, Framework, or Product Banner

### If You See

- WordPress, Joomla, Drupal, Tomcat, Jenkins, Splunk, GitLab, ColdFusion, CGI, IIS behavior, or another identifiable product.

### Try This

- Confirm the product and exact version using multiple evidence sources.
- Enumerate exposed plugins, modules, management interfaces, files, and configuration artifacts.
- Correlate the exact version and prerequisites with vendor advisories and public research.
- Prefer safe configuration and exposure checks before exploit validation.

### Tools From the Notes

- `nmap`, `curl`, `gobuster`, `ffuf`, `searchsploit`, Burp
- Metasploit only after manual version/prerequisite confirmation and explicit authorization

### Continue To

- [[Modules/Attacking Common Applications|Attacking Common Applications]]

---

## After Any Confirmed Finding

### Validate

- Repeat from a clean baseline.
- Change one variable at a time.
- Capture positive and negative controls.
- Separate observed impact from hypothetical maximum impact.

### Look for Safe Chains

- Upload → File inclusion → Execution
- SSRF → Internal API → BOLA/BFLA
- JavaScript discovery → Hidden API → Authorization testing
- SQL injection → Minimal data/file impact proof
- Stored XSS → Higher-privileged viewing context
- Authentication weakness → Authorized-object boundary testing

### Record

- Exact sanitized request/command
- Response, timing, and state change
- Identity and prerequisites
- Root cause and affected security boundary
- Cleanup and retest evidence

### Report

- [[Templates/Security Finding Template|Security Finding Template]]
- [[Modules/Bug Bounty Hunting Process|Bug Bounty Hunting Process]]
- [[Study Group Guide|CWES Study Group Guide]]
