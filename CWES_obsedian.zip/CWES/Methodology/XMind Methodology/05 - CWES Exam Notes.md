---
tags: [CWES, methodology, XMind, imported-reference]
source_file: CWES.xmind
source_sheet: Methodology
topic_id: "53b474fc-9152-4b18-b16e-80cd1f4fd77e"
subtree_topics: 198
split_index: true
---

# CWES Exam Notes

> [!info] Imported XMind methodology
> This note preserves the original `Methodology` sheet structure. Source examples are displayed as inert text.

- CWES Exam Notes

## Child Topics

- [[Methodology/XMind Methodology/05.01 - scope|scope]] — 7 topics
- [[Methodology/XMind Methodology/05.02 - Information gathering|Information gathering]] — 8 topics
- [[Methodology/XMind Methodology/05.03 - Main Topic 3|Main Topic 3]] — 1 topic
- [[Methodology/XMind Methodology/05.04 - Hosts|Hosts]] — 181 topics
