---
tags: [CWES, methodology, XMind, imported-reference]
source_file: CWES.xmind
source_sheet: Methodology
topic_id: "d390b51a-8690-4b67-91ef-7b19bc7a41e8"
subtree_topics: 5
split_index: false
---

# HTB Machines

> [!info] Imported XMind methodology
> This note preserves the original `Methodology` sheet structure. Source examples are displayed as inert text.

## Complete XMind Reference

- HTB Machines
  - SQL Injection
    - without sqlmap
      - Union
        - https://www.youtube.com/watch?v=z5pdizHDvt8
          - Source link: <https://www.youtube.com/watch?v=z5pdizHDvt8>
