---
tags: [CWES, HTB, index]
source_file: "CWES.xmind"
---

# CWES Path

> [!summary] Professional CWES guidance
> Each module contains a concise assessment workflow followed by the complete imported XMind reference. Commands, hints, links, notes, and images remain preserved.
>
> [!tip] Reading split technical notes
> Security-signature-heavy modules are divided into smaller readable notes. A few literal web-shell signatures contain invisible HTML comments to prevent Windows Defender false positives; Obsidian Reading view displays the intended command text.

## Knowledge Graph and Methodology

- Open [[Methodology/CWES Methodology Map|CWES Methodology Decision Tree]] for **if you see this, try this** guidance based on the technical notes.
- Open [[Methodology/CWES XMind Methodology|Original XMind Methodology]] for all **2,415 topics** from the source Methodology sheet, including its Arabic branches, exam notes, and HTB machine notes.
- Open [[Outputs/CWES Outputs Index|CWES XMind Outputs]] for all **917 yellow/output topics** detected across the three source sheets.
- Open [[Maps/CWES Knowledge Graph|CWES Knowledge Graph]] as the graph's central navigation note.
- Open [[Maps/CWES Mind Map|CWES Curriculum Mind Map]] for a hand-drawn overview of all domains and modules.
- Use **Open local graph** on a domain map to see only relevant modules and relationships.
- In Global Graph, filter with `path:CWES` to hide unrelated vault content.
- The repeated **Complete Technical Reference** text is a heading inside module notes, not a separate graph node.

## Study Group Resources

- [[Study Group Guide|CWES Study Group Guide]] — collaboration workflow and note-quality checklist.
- [[Glossary|CWES Glossary]] — terminology and important distinctions.
- [[Templates/PT Study Session Template|PT Study Session Template]] — repeatable lab-session documentation.
- [[Templates/Security Finding Template|Security Finding Template]] — professional report structure.

## Sheet 1

- [[Modules/Web Fundamental|Web Fundamental]]
- [[Modules/Web Proxy|Web Proxy]]
- [[Modules/Attacking Using Ffuf|Attacking Using Ffuf]]
- [[Modules/Javascript Deobfuscation|Javascript Deobfuscation]]
- [[Modules/Cross-Site Scripting (XSS)|Cross-Site Scripting (XSS)]]
- [[Modules/Information Gathering|Information Gathering]]
- [[Modules/SQL Injection Fundamentals|SQL Injection Fundamentals]]
- [[Modules/SQLMap Essentials|SQLMap Essentials]]
- [[Modules/Command Injection|Command Injection]]
- [[Modules/File Upload Attacks|File Upload Attacks]]

## Sheet 2

- [[Modules/Server-side Attacks|Server-side Attacks]]
- [[Modules/Login Brute Forcing|Login Brute Forcing]]
- [[Modules/Broken Authentication|Broken Authentication]]
- [[Modules/Web Attacks (can be found in any web application)|Web Attacks (can be found in any web application)]]
- [[Modules/File Inclusion|File Inclusion]]
- [[Modules/Attacking GraphQL|Attacking GraphQL]]
- [[Modules/API Attacks|API Attacks]]
- [[Modules/Attacking Common Applications|Attacking Common Applications]]
- [[Modules/Bug Bounty Hunting Process|Bug Bounty Hunting Process]]
