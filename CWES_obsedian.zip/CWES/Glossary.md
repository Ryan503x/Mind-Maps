---
tags: [CWES, glossary, reference]
type: glossary
---

# CWES Glossary

## Core Concepts

**Attack surface** — All reachable assets, interfaces, identities, data flows, and features that may affect security.

**Authentication** — Verification of an identity. It answers: “Who are you?”

**Authorization** — Enforcement of what an authenticated or unauthenticated identity may do. It answers: “Are you allowed?”

**BOLA / IDOR** — Missing or insufficient object-level authorization when a caller supplies an object identifier.

**BFLA** — Broken Function Level Authorization; a caller reaches a function reserved for another role.

**BOPLA / Mass assignment** — Unauthorized reading or modification of sensitive object properties.

**Canonicalization** — Converting input into one normalized representation before validation or authorization decisions.

**Execution context** — The operating-system user, application identity, container, process, privileges, environment, and network position under which code runs.

**False positive** — A test or scanner result that appears vulnerable but cannot be reproduced as a real security weakness.

**Input validation** — Checking whether input matches an explicitly allowed format, type, length, range, and business rule.

**Output encoding** — Context-specific transformation that prevents data from being interpreted as executable HTML, JavaScript, SQL, or another language.

**Proof of concept (PoC)** — The smallest reproducible demonstration sufficient to confirm a vulnerability and its impact.

**Rate limiting** — Restricting request frequency, concurrency, or resource consumption by account, token, source, operation, or context.

**Sanitization** — Removing or transforming unsafe content. It is context-dependent and should not replace parameterization or safe APIs.

**Sink** — A function or operation where attacker-controlled data may cause a dangerous effect, such as a SQL query, shell command, DOM write, file include, or URL fetch.

**Source** — A location where untrusted data enters an application, including parameters, headers, cookies, files, database values, or messages.

**SSRF** — Server-Side Request Forgery; attacker-controlled input influences a server-side network or file request.

**SSTI** — Server-Side Template Injection; untrusted data is interpreted as template syntax.

**Threat chain** — Multiple weaknesses combined to achieve an impact greater than any single finding.

## Reporting Terms

**CWE** — A standardized category describing the underlying software weakness.

**CVSS** — A scoring framework for communicating vulnerability severity and exploitation conditions.

**Prerequisite** — A required role, configuration, victim action, network position, or prior weakness.

**Root cause** — The underlying design, implementation, or configuration failure that allowed the vulnerability.

Return to [[Study Group Guide|CWES Study Group Guide]].
