---
tags: [CWES, template, security-finding]
type: template
---

# [Vulnerability Type] in [Affected Component]

## Severity

- Rating:
- CVSS 3.1 score:
- CVSS vector:
- CWE:

## Brief Description

Explain the root cause, affected function, and attacker-controlled input in a short paragraph.

## Affected Asset

- Application/host:
- Endpoint/component:
- Method/parameter:
- Required role:

## Prerequisites

List required privileges, configuration, victim interaction, network position, and prior weaknesses.

## Reproduction Steps

1. Establish the authorized baseline.
2. Submit the controlled test input.
3. Observe and record the security-relevant behavior.
4. Repeat with a minimal proof sufficient to establish impact.

## Evidence

### Request or Command

```text
Insert sanitized evidence.
```

### Response or Observation

```text
Insert sanitized evidence.
```

## Security Impact

Describe demonstrated impact separately from credible maximum impact. Address confidentiality, integrity, availability, affected users, and business consequences.

## Remediation

Provide root-cause remediation, defense-in-depth controls, and a concrete retest procedure.

## References

- Relevant CWE:
- Vendor or framework guidance:
- Related module:

## Cleanup and Disclosure

- Cleanup completed:
- Sensitive data redacted:
- Disclosure channel/timeline:

Return to [[Study Group Guide|CWES Study Group Guide]].
