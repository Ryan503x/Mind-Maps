---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
source_file: "CWES.xmind"
---

# Preventing File Upload Vulnerabilities

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Extension Validation

### use both by whitelisting the allowed extensions and blacklisting dangerous extensions

- PHP
  - $fileName = basename($_FILES["uploadFile"]["name"]);  

    // blacklist test  
    if (preg_match('/^.*\.ph(p|ps|ar|tml)/', $fileName)) {  
    echo "Only images are allowed";  
    die();  
    }  

    // whitelist test  
    if (!preg_match('/^.*\.(jpg|jpeg|png|gif)$/', $fileName)) {  
    echo "Only images are allowed";  
    die();  
    }
## Content Validation

### Code: php

- $fileName = basename($_FILES["uploadFile"]["name"]);  
  $contentType = $_FILES['uploadFile']['type'];  
  $MIMEtype = mime_content_type($_FILES['uploadFile']['tmp_name']);  

  // whitelist test  
  if (!preg_match('/^.*\.png$/', $fileName)) {  
  echo "Only PNG images are allowed";  
  die();  
  }  

  // content test  
  foreach (array($contentType, $MIMEtype) as $type) {  
  if (!in_array($type, array('image/png'))) {  
  echo "Only PNG images are allowed";  
  die();  
  }  
  }
## Upload Disclosure

### avoid doing is disclosing the uploads directory

- We may write a download.php script to fetch the requested file from the uploads directory and then download the file for the end-user
- Additionally, users should not have direct access to the uploads directory. Any direct requests to this directory should return a 403 Forbidden
## HTTP headers

### Content-Disposition:

- Used to specify how the content should be displayed in the browser. Setting it to attachment instructs the browser to download the file rather than render it inline.
### Content-Type:

- Specifies the MIME type of the file, ensuring that the browser knows how to handle the file content appropriately.
### X-Content-Type-Options: nosniff

- Prevents the browser from MIME-type sniffing, which helps mitigate security risks by ensuring that the browser adheres strictly to the specified
### Content-Type.

## we should also randomize the names of the uploaded files in storage and store their "sanitized"

### users will neither know the uploads directory nor the uploaded file name

### avoid vulnerabilities caused by injections in the file names

## Another thing we can do is store the uploaded files in a separate server or container

## Further Security

### disabling specific functions that may be used to execute system commands through the web application.

- disable_functions configuration in php.ini
- and add such dangerous functions, like exec
- shell_exec, system, passthru, and a few others.
### disable showing any system or server errors

## few other tips

### Limit file size

### Update any used libraries

### Scan uploaded files for malware or malicious strings

### Utilize a Web Application Firewall (WAF) as a secondary layer of protection
