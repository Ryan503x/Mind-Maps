---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
source_file: "CWES.xmind"
---

# Blacklist Filters

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

The section is split into smaller notes to avoid local security-scanner false positives.

- [[Modules/File Upload Attacks/05 - Blacklist Filters/01 - Blacklisting Extensions|Blacklisting Extensions]]
- [[Modules/File Upload Attacks/05 - Blacklist Filters/02 - Non-Blacklisted Extensions|Non-Blacklisted Extensions]]
- [[Modules/File Upload Attacks/05 - Blacklist Filters/03 - LAB|LAB]]
