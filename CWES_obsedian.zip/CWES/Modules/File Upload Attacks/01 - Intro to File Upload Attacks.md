---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
source_file: "CWES.xmind"
---

# Intro to File Upload Attacks

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## CVE Reports

### <https://www.cvedetails.com/vulnerability-list/cweid-434/vulnerabilities.html>

## Types of File Upload Attacks

### worst possible kind

- unauthenticated arbitrary file upload
### most common and critical

- gaining remote command execution
