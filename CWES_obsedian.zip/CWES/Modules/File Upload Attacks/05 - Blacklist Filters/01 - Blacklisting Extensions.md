---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
section: "Blacklist Filters"
source_file: "CWES.xmind"
---

# Blacklisting Extensions

> [!info] Complete technical reference
> Imported without removing commands, hints, links, notes, or images.

## example code

### Example Blacklist Validation Logic

```php
$fileName = basename($_FILES["uploadFile"]["name"]);
$extension = pathinfo($fileName, PATHINFO_EXTENSION);
$blacklist = array('php', 'php7', 'phps');

if (in_array($extension, $blacklist)) {
    echo "File type not allowed";
    die();
}
```

## There are generally two common forms of validating a file extension on the back-end

### Testing against a blacklist of types

### Testing against a whitelist of types

## It is not comprehensive

### case-sensitive

- (e.g. pHp), which may bypass the blacklist as well
### Fuzzing Extensions

- Send to Intruder
  - PayloadsAllTheThings
    - .php
      - <https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Upload%20Insecure%20Files/Extension%20PHP/extensions.lst>
    - .NET
      - <https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Upload%20Insecure%20Files/Extension%20ASP>
  - SecLists/Discovery/Web-Content/web-extensions.txt
  - <https://github.com/danielmiessler/SecLists/blob/master/Discovery/Web-Content/web-extensions.txt>
    - Payload Options
      - un-tick the URL Encoding option to avoid encoding the (.)
        - File successfully uploaded. In contrast, the rest responded with an error message saying Extension not allowed
