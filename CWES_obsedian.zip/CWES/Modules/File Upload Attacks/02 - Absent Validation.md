---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
source_file: "CWES.xmind"
---

# Absent Validation

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Arbitrary File Upload

### accept All Files

### web shell

- has to be written in the same programming language that runs the web server
  - first step would be to identify what language runs the web application.
    - Web Routes
    - visit the /index.ext page, where we would swap out ext with various common web extensions, like php, asp, aspx
    - <https://www.wappalyzer.com/>
    - Burp/ZAP scanners
## Vulnerability Identification

### try uploading it to the web

- test.php
  - <?<!-- -->php echo "Hello HTB";?>
    - if we visit /test.php
      - Hello HTB
### LAB

- Try to upload a PHP script that executes the (hostname) command on the back-end server, and submit the first word of it as the answer.
  - echo '<?<!-- -->php echo gethostname();?>' > test.php
    - upload test.php
    - check the content of /test.php
