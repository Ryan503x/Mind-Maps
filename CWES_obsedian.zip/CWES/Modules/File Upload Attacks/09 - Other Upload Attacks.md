---
tags: [CWES, HTB, technical-reference]
module: "File Upload Attacks"
source_file: "CWES.xmind"
---

# Other Upload Attacks

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Injections in File Name

### Command Injection

- name a file like this
  - file$(whoami).jpg
  - file`whoami`.jpg
  - file.jpg||whoami
### XSS

- <script>alert(window.origin);</script>)
### SQL injection

- file';select+sleep(5);--.jpg
## Upload Directory Path Disclosure

### disclose the uploads directory

- like a feedback form or a submission form
  - utilize fuzzing to look for the uploads directory
  - other vulnerabilities (e.g., LFI/XXE)
  - IDOR
    - <https://enterprise.hackthebox.com/module/details/134>
### forcing error messages

- uploading a file with a name that already exists
- sending two identical requests simultaneously.
### read the content of API handle the upload

- upload SVG XXE to read the content of upload.php
## Windows-specific Attacks

### reserved characters

- (|, <, >, *, or ?)
  - may refer to another file (which may not exist) and cause an error
### Windows reserved names for the uploaded file

- CON, COM1, LPT1, or NUL
  - may also cause an error as the web application will not be allowed to write a file with this name.
### utilize the Windows 8.3 Filename Convention to overwrite existing files

- [utilize the Windows 8.3 Filename Convention to overwrite existing fileshttps://en.wikipedia.org/wiki/8.3_filename](https://en.wikipedia.org/wiki/8.3_filename)
  - Older versions of Windows were limited to a short length for file names
    - they used a Tilde character (~)
- to refer to a file called (hackthebox.txt)
  - use
    - (HAC~1.TXT)
    - or (HAC~2.TXT)
- (e.g. WEB~1.CON)
  - overwrite the web.conf
    - information disclosure through errors
    - causing a DoS
    - or even accessing private files.
## Advanced File Upload Attacks

### encoding a video

### compressing a file

### renaming a file

### Some commonly used libraries may have public exploits

- like the AVI upload vulnerability leading to XXE in ffmpeg
## Try to read some bug bounty reports to explore more advanced file upload vulnerabilities.
