---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "1"
source_file: "CWES.xmind"
---

# Attacking Using Ffuf

## Study Companion

### Prerequisites

HTTP fundamentals, wordlists, and basic shell usage.

### Learning Outcomes

- Calibrate wildcard responses before trusting results.
- Enumerate content, extensions, virtual hosts, parameters, and values.
- Tune filters, recursion, threads, and delays to reduce noise and impact.

### Practice Checkpoint

Run a bounded discovery pass, manually verify each result, and save the exact command and filter rationale.

### Related Knowledge Map

- [[Maps/Reconnaissance and Tooling|Reconnaissance and Tooling]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Use ffuf to discover authorized web content, extensions, virtual hosts, parameters, and valid values efficiently while controlling request volume and separating genuine behavior from wildcard or uniform responses.

### Assessment Workflow
1. Establish a baseline for the target URL and Host header, record response status, size, words, lines, redirects, and a known nonexistent path.
2. Select the smallest relevant SecLists wordlist and place a named `FUZZ` marker in one location at a time.
3. Enumerate directories, then extensions and files; recurse only into validated paths with an explicit depth and extension set.
4. Enumerate DNS names separately from name-based virtual hosts, preserving the correct destination IP and Host header.
5. Calibrate `-fc`, `-fs`, `-fw`, `-fl`, or `-fr` filters against wildcard responses and manually verify every promising result.
6. Fuzz GET and POST parameter names with the correct method and content type, then test bounded or purpose-built value lists for confirmed parameters.
7. Tune threads and delay to the authorization and target capacity, and save enough output to reproduce findings.

### Key Testing Principles
- A `200` response alone is not a finding; compare content characteristics and semantic differences.
- Keep concurrency conservative, especially with recursion, large DNS lists, and production targets.
- Use context-specific lists for directories, extensions, parameters, IDs, and usernames rather than one oversized list.
- Do not combine multiple unknown fuzz positions until each dimension has been characterized.
- Validate findings with `curl` or a proxy and add discovered hostnames locally only when required for the authorized lab.

### Evidence and Reporting
Record the exact ffuf command, target, Host header, wordlist and version, thread/delay settings, filters, baseline characteristics, and raw matching result. For each confirmed item, include a manual request/response, authentication context, discovery path, and why the difference matters; distinguish accessible content, forbidden resources, and probable false positives.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **19 yellow/output topics** in this module.

- [[Outputs/Modules/Attacking Using Ffuf Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## apt install ffuf -y

## What we look for

### Fuzzing for directories

### Fuzzing for files and extensions

### Identifying hidden vhosts

### Fuzzing for PHP parameters

### Fuzzing for parameter values

## options

### threading limit

- -t 200
- -t 10
### pause (delay) between requests

- -p 0.1
## Fuzz
> The term fuzzing refers to a testing technique that sends various types of user input to a certain interface to study how it would react. If we were fuzzing for SQL injection vulnerabilities, we would be sending random special characters and seeing how the server would react. If we were fuzzing for a buffer overflow, we would be sending long strings and incrementing their length to see if and when the binary would break.

### Wordlists

- <https://github.com/danielmiessler/SecLists>
  - directory-list-2.3
    - locate directory-list-2.3-small.txt
### Directory

- ffuf -w /opt/useful/seclists/Discovery/Web-Content/directory-list-2.3-small.txt:FUZZ -u http://SERVER_IP:PORT/FUZZ
### Extension Fuzzing

- FUZZ_1
  - index
- FUZZ_2
  - web-extensions.txt
- usage
  - ffuf -w /opt/useful/seclists/Discovery/Web-Content/web-extensions.txt:FUZZ -u http://SERVER_IP:PORT/blog/indexFUZZ
    - .php                    [Status: 200, Size: 0, Words: 1, Lines: 1]  
      .phps                   [Status: 403, Size: 283, Words: 20, Lines: 10]
  - ffuf -w /opt/useful/seclists/Discovery/Web-Content/directory-list-2.3-small.txt:FUZZ -u http://SERVER_IP:PORT/blog/FUZZ.php
### Recursive Fuzzing

- ffuf -w /opt/useful/seclists/Discovery/Web-Content/directory-list-2.3-small.txt:FUZZ -u http://SERVER_IP:PORT/FUZZ -recursion -recursion-depth 1 -e .php -v
## DNS Records

### Sub-domain Fuzzing

- ffuf -w /opt/useful/seclists/Discovery/DNS/subdomains-top1million-5000.txt:FUZZ -u https://FUZZ.inlanefreight.com/
- gobuster dns -d inlanefreight.com -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt
## Vhost Fuzzing

### ffuf -w /opt/useful/seclists/Discovery/DNS/subdomains-top1million-5000.txt:FUZZ -u http://academy.htb:PORT/ -H 'Host: FUZZ.academy.htb'

- all words in the wordlist are returning 200 OK! This is expected
### addition

- echo "154.57.164.81 inlanefreight.htb" | sudo tee -a /etc/hosts
- gobuster vhost -u http://inlanefreight.htb:81 -w /usr/share/seclists/Discovery/Web-Content/common.txt --append-domain
## Filtering Results

### ffuf -h

- -fc              Filter HTTP status codes from response. Comma separated list of codes and ranges  
  -fl              Filter by amount of lines in response. Comma separated list of line counts and ranges  
  -fr              Filter regexp  
  -fs              Filter HTTP response size. Comma separated list of sizes and ranges  
  -fw              Filter by amount of words in response. Comma separated list of word counts and ranges
  - ffuf -w /opt/useful/seclists/Discovery/DNS/subdomains-top1million-5000.txt:FUZZ -u http://academy.htb:PORT/ -H 'Host: FUZZ.academy.htb' -fs 900
## Parameter Fuzzing

### GET

- ffuf -w /opt/useful/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u http://admin.academy.htb:PORT/admin/admin.php?FUZZ=key -fs xxx
### POST

- ffuf -w /opt/useful/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u http://admin.academy.htb:PORT/admin/admin.php -X POST -d 'FUZZ=key' -H 'Content-Type: application/x-www-form-urlencoded' -fs xxx
  - id
    - curl http://admin.academy.htb:PORT/admin/admin.php -X POST -d 'id=key' -H 'Content-Type: application/x-www-form-urlencoded'
      - <div class='center'><p>Invalid id!</p></div>
## Value Fuzzing

### we may not always find a pre-made wordlist that would work for us

- since its id lets use wordlist could get it value like 1-1000
  - ffuf -u http://admin.academy.htb:54839/admin/admin.php -w ids.txt -X POST -d 'id=FUZZ' -H 'Content-Type: application/x-www-form-urlencoded' -fs 768
    - curl http://admin.academy.htb:54839/admin/admin.php -X POST -d 'id=73' -H 'Content-Type: application/x-www-form-urlencoded'
## Skills Assessment - Web Fuzzing

### subdomain/vhost scan

- ffuf -u http://FUZZ.academy.htb:54628/ -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt -fs 985
- ffuf -u http://academy.htb:54628/ -H "Host: FUZZ.archive.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985
  - test
  - archive
  - faculty
### extensions scan

- ffuf -u http://academy.htb:54628/indexFUZZ  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985
  - .phps 403
- ffuf -u http://academy.htb:54628/indexFUZZ -H "Host: test.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985
  - .php 200
  - .phps 403
- ffuf -u http://academy.htb:54628/indexFUZZ -H "Host: faculty.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985
  - .php 200
  - .php 200
  - .phps 403
- ffuf -u http://academy.htb:54628/indexFUZZ -H "Host: archive.academy.htb"  -w /usr/share/seclists/Discovery/Web-Content/web-extensions.txt -fs 985
  - .php 200
  - .phps 403
### Page Fuzzing

- Hint  
  Run a recursive scan on all sub-domains you found, and use all of the extensions you found. Use 'PORT' instead of the port shown above, like http://xxxxx.academy.htb:PORT/xxxxxxx ..etc
  - ffuf -u 'http://academy.htb:54628/courses/FUZZ' -H 'Host: faculty.academy.htb'  -w /usr/share/seclists/Discovery/Web-Content/directory-list-lowercase-2.3-small.txt -recursion -recursion-depth 2  -e .php,.phps,.php7  -fs 284
    - linux-security.php7
### Parameter fuzzing

- ffuf -u 'http://academy.htb:54628/courses/linux-security.php7?FUZZ=key' -H 'Host: faculty.academy.htb'  -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt -fs 774
  - user
- ffuf -u 'http://academy.htb:54628/courses/linux-security.php7' -X POST -H 'Host: faculty.academy.htb' -H 'Content-Type: application/x-www-form-urlencoded' -d 'FUZZ=key' -w /usr/share/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ  -fs 774
  - user
  - username
### Get the value of parameters

- Try fuzzing the parameters you identified for working values. One of them should return a flag. What is the content of the flag?
  - ffuf -u 'http://academy.htb:54628/courses/linux-security.php7' -X POST -H 'Host: faculty.academy.htb' -H 'Content-Type: application/x-www-form-urlencoded' -d 'username=FUZZ' -w /usr/share/seclists/Usernames/xato-net-10-million-usernames.txt -fs 781
    - harry
### Flag

- curl 'http://academy.htb:54628/courses/linux-security.php7' -X POST -H 'Host: faculty.academy.htb' -H 'Content-Type: application/x-www-form-urlencoded' -d 'username=Harry'
  - HTB{w3b_fuzz1n6_m4573r}
## addition

### wordlist

- DirBuster-2007_directory-list-lowercase-2.3-medium.txt
### tool

- wenum
  - pipx install git+https://github.com/WebFuzzForge/wenum
    - pipx runpip wenum install setuptools
### API Fuzzing

- git clone https://github.com/PandaSt0rm/webfuzz_api.git
  - cd webfuzz_api
    - pip3 install -r requirements.txt
      - python3 api_fuzzer.py http://IP:PORT
