---
tags: [CWES, HTB, technical-reference]
module: "SQLMap Essentials"
source_file: "CWES.xmind"
---

# Basic Scenario

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## accepts user input via a GET parameter (e.g., id)

### sqlmap -u "http://www.example.com/vuln.php?id=1" --batch
