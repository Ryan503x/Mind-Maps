---
tags: [CWES, HTB, technical-reference]
module: "SQLMap Essentials"
source_file: "CWES.xmind"
---

# Handling SQLMap Errors

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## to parse the DBMS errors

### --parse-errors

## stores the whole traffic content to an output file

### -t

- sqlmap -u "http://www.target.com/vuln.php?id=1" --batch -t /tmp/traffic.txt
## Verbose Output

### -v

- level
  - sqlmap -u "http://www.target.com/vuln.php?id=1" -v 6 --batch
## redirect the whole traffic through a (MiTM) proxy

### --proxy
