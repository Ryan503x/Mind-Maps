---
tags: [CWES, HTB, technical-reference]
module: "SQLMap Essentials"
source_file: "CWES.xmind"
---

# Output Description

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## target URL content is stable

### no major changes between responses

## GET parameter 'id' appears to be dynamic

### change in the response; hence the parameter may be linked to a database. In case the output is "static"

## heuristic (basic) test shows that GET parameter 'id' might be injectable (possible DBMS: 'MySQL')

### not proof of SQLi

## heuristic (XSS) test shows that GET parameter 'id' might be vulnerable to cross-site scripting (XSS) attacks

## GET parameter 'id' is vulnerable. Do you want to keep testing the others (if any)? [y/N]

### want to report all potential vulnerabilities

## sqlmap identified the following injection point(s) with a total of 46 HTTP(s) requests:
