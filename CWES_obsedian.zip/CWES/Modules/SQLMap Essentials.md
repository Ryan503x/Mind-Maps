---
tags: [CWES, HTB, index]
source_file: "CWES.xmind"
---

# SQLMap Essentials

## Study Companion

### Prerequisites

Manual SQL injection fundamentals and faithful HTTP request capture.

### Learning Outcomes

- Run a low-impact SQLMap baseline and interpret confirmed injection points.
- Tune techniques, risk, level, comparison, prefixes, and suffixes deliberately.
- Enumerate progressively while minimizing requests and accessed data.

### Practice Checkpoint

Capture a request with Burp, load it using `-r`, and explain every SQLMap option used.

### Related Knowledge Map

- [[Maps/Injection and Code Execution|Injection and Code Execution]]
- [[Study Group Guide|CWES Study Group Guide]]

## Professional Guidance

### Objective
Use SQLMap in an authorized, controlled manner to confirm SQL injection, tune detection to application behavior, enumerate only the data needed to establish impact, and produce reproducible evidence without destabilizing the database or application.

### Assessment Workflow
1. Capture a faithful request from browser developer tools or Burp, including method, body, JSON, cookies, headers, and any custom injection marker.
2. Run a low-impact baseline against the suspected parameter and interpret stability, dynamism, heuristics, and confirmed injection points separately.
3. Troubleshoot with parsed DBMS errors, traffic logs, verbosity, and an intercepting proxy before increasing test intensity.
4. Tune prefixes, suffixes, comparison signals, techniques, UNION column counts, `--level`, and `--risk` deliberately; avoid unnecessary stacked or time-based tests.
5. Enumerate progressively: banner/current context, databases, tables, selected columns, bounded rows, schema searches, and only then narrowly scoped dumps.
6. Handle anti-CSRF tokens, randomized or calculated parameters, session state, caching, WAF behavior, and tamper scripts with explicit justification.
7. Attempt file or OS interaction only when separately authorized and required to demonstrate material impact.

### Key Testing Principles
- A heuristic warning is not proof; report only a repeatable injection point and technique.
- Preserve complete request context and use `-r` for complex traffic where possible.
- Minimize requests and data access: high level/risk settings can expand testing from dozens to thousands of payloads and may cause data loss or denial of service.
- Use response codes, titles, strings, or text-only comparison to stabilize blind detection.
- Treat WAF bypass and tamper scripts as diagnostic tools, not substitutes for understanding the vulnerable query.

### Evidence and Reporting
Retain the sanitized request, command line, SQLMap version/options, confirmed parameter, DBMS and technique, payload/boundary, request count, relevant traffic excerpt, and minimal enumeration output. Document any protection bypass and operational risk, redact credentials and unrelated rows, and recommend parameterized queries, least-privileged database accounts, and server-side validation.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **32 yellow/output topics** in this module.

- [[Outputs/Modules/SQLMap Essentials Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

The original XMind hierarchy is split into section notes to keep Obsidian responsive and reduce security-scanner false positives.

- [[Modules/SQLMap Essentials/01 - overview|overview]]
- [[Modules/SQLMap Essentials/02 - Basic Scenario|Basic Scenario]]
- [[Modules/SQLMap Essentials/03 - Output Description|Output Description]]
- [[Modules/SQLMap Essentials/04 - Running SQLMap on an HTTP Request|Running SQLMap on an HTTP Request]]
- [[Modules/SQLMap Essentials/05 - Handling SQLMap Errors|Handling SQLMap Errors]]
- [[Modules/SQLMap Essentials/06 - Attack Tuning|Attack Tuning]]
- [[Modules/SQLMap Essentials/07 - Database Enumeration|Database Enumeration]]
- [[Modules/SQLMap Essentials/08 - Advanced Database Enumeration|Advanced Database Enumeration]]
- [[Modules/SQLMap Essentials/09 - Bypassing Web Application Protections|Bypassing Web Application Protections]]
- [[Modules/SQLMap Essentials/10 - OS Exploitation|OS Exploitation]]
- [[Modules/SQLMap Essentials/11 - Skills Assessment|Skills Assessment]]
