---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "1"
source_file: "CWES.xmind"
---

# Javascript Deobfuscation

## Study Companion

### Prerequisites

Basic JavaScript syntax, browser developer tools, and safe file handling.

### Learning Outcomes

- Differentiate minification, packing, obfuscation, and encoding.
- Beautify and simplify scripts one transformation layer at a time.
- Recover endpoints, data flow, dynamic execution, and indicators without unsafe evaluation.

### Practice Checkpoint

Preserve an original script, deobfuscate it offline, and document each reversible transformation.

### Related Knowledge Map

- [[Maps/Client-side Security|Client-side Security]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Safely transform minified, packed, obfuscated, or encoded JavaScript from an authorized target into readable code, recover its behavior and indicators, and document conclusions without executing untrusted logic in a sensitive environment.

### Assessment Workflow
1. Preserve the original script, source URL, retrieval time, and cryptographic hash before any transformation.
2. Determine whether the content is merely minified, packed, string-array obfuscated, JSFuck/JJEncode/AAEncode-style, or wrapped in one or more encoding layers.
3. Beautify first and compare structure without changing semantics; identify entry points, string decoders, dynamic execution, network calls, storage access, and DOM operations.
4. Unpack or simplify one layer at a time with offline tools, saving each intermediate artifact and noting the exact transformation.
5. Decode recognizable Base64, hexadecimal, ROT13/Caesar, or other strings independently and validate decoded output by format and context.
6. Perform static analysis before any execution; if runtime behavior is necessary, use an isolated console or sandbox with network and credential protections.
7. Reconstruct the high-level data flow and verify important findings against browser behavior or network traces.

### Key Testing Principles
- Obfuscation is not encryption, and minification alone is not evidence of maliciousness.
- Never paste sensitive proprietary scripts into public online deobfuscators without approval.
- Avoid direct `eval` of unknown code; instrument or replace dynamic execution where possible.
- Layered transformations require repeatable, incremental analysis rather than guessing from the final string.
- Encoding identification should be corroborated by alphabet, padding, length, and decoded structure.

### Evidence and Reporting
Provide the original and transformed hashes, tool names and versions, ordered transformation log, recovered strings, functions, endpoints, and behavior, plus confidence and unresolved layers. Include concise before/after excerpts, safe reproduction steps, and security relevance such as exposed secrets, hidden API calls, unsafe DOM sinks, or deceptive behavior; store full artifacts separately.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **0 yellow/output topics** in this module.

- [[Outputs/Modules/Javascript Deobfuscation Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## tools

### https://jsconsole.com/

### https://www.toptal.com/developers/javascript-minifier

- note: Code minification is not exclusive to JavaScript, and can be applied to many other languages, as can be seen on javascript-minifier.
- Usually, minified JavaScript code is saved with the extension .min.js.
## Packing JavaScript code

### obfuscate

- https://beautifytools.com/javascript-obfuscator.php
  - try it in jsconsole website to test its fumctionality
## Obfuscator

### [https://obfuscator.io](https://obfuscator.io./)

- change String Array Encoding to Base64
  - try it in jsconsole website to test its fumctionality
    - [][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]][([][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]]+[])[!+[]+!+[]+!+[]]+(!![]+[][(![]+[])[+[]]+([![]]+[][[]])[+!+[]+[+[]]]+(![]+[])[!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+!+[]]])[+!+[]+[+[]]]+([][[]]+[])[+!+[]]+(![]+[])[!+[]+!+[]+!+[]]+(!![]+[])[+[]]+(!![]+[])[+!+[]]+([][[]]+[])[+[]]+([][(!
      - the code may take some time to run, which shows how code obfuscation could affect the performance
### <https://utf-8.jp/public/jjencode.html>

### <https://utf-8.jp/public/aaencode.html>

## Deobfuscation

### Beautify

### <https://matthewfl.com/unPacker.html>

## Code Analysis

## Decoding

### encoding methods

- base64
  - Base64 Encode
    - echo https://www.hackthebox.eu/ | base64
      - base64 encoded strings are easily spotted
  - Base64 Decode
    - echo aHR0cHM6Ly93d3cuaGFja3RoZWJveC5ldS8K | base64 -d
- hex
  - ASCII table
    - You can find the full ASCII table in Linux using the
      - man ascii
  - spotting hex encoded strings just as easy as spotting base64
  - Hex Encode
    - echo https://www.hackthebox.eu/ | xxd -p
  - Hex Decode
    - echo 68747470733a2f2f7777772e6861636b746865626f782e65752f0a | xxd -p -r
- Caesar/Rot13
  - Caesar cipher
    - rot13, http://www becomes uggc://jjj
  - Rot13 Encode
    - echo https://www.hackthebox.eu/ | tr 'A-Za-z' 'N-ZA-Mn-za-m'
  - Rot13 Decode
    - echo uggcf://jjj.unpxgurobk.rh/ | tr 'A-Za-z' 'N-ZA-Mn-za-m'
  - online tool
    - https://rot13.com/
### Other Types of Encoding

- There are hundreds of other encoding methods we can find online
- <https://www.boxentriq.com/code-breaking/cipher-identifier>
