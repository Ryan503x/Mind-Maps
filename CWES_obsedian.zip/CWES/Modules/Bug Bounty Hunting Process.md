---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "2"
source_file: "CWES.xmind"
---

# Bug Bounty Hunting Process

## Study Companion

### Prerequisites

A confirmed technical finding and familiarity with the target program policy.

### Learning Outcomes

- Translate program scope and rules into a test checklist.
- Write reproducible findings with root cause, realistic impact, CWE, and CVSS rationale.
- Communicate through approved channels and preserve a defensible evidence timeline.

### Practice Checkpoint

Convert one lab finding into a professional report with sanitized evidence, remediation, CWE, and a justified CVSS vector.

### Related Knowledge Map

- [[Maps/Reporting and Bug Bounty|Reporting and Bug Bounty]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Conduct ethical bug bounty research that strictly follows the selected program's policy, scope, code of conduct, safe-harbor terms, and disclosure process, and produce a clear, reproducible report that communicates technical cause, realistic impact, severity, and remediation to both security and business stakeholders.

### Assessment Workflow
1. Select a public program or accept an authorized private invitation, then read the complete policy before testing. Record in-scope assets and vulnerability classes, exclusions, account-access rules, eligibility requirements, response SLAs, reward rules, disclosure terms, legal conditions, and official contacts.
2. Convert the policy into a working checklist and test plan. Confirm that every asset and technique is permitted, respect rate and data-handling limits, and follow the platform and program code of conduct throughout research.
3. Validate a suspected issue with the least harmful proof of concept. Capture the exact affected domain, endpoint, parameter, account role, prerequisites, baseline behavior, modified request, response, and resulting state while minimizing access to other users' data and avoiding persistence or service disruption.
4. Determine root cause and realistic maximum impact. Choose the CWE that best describes the originating weakness, especially for a vulnerability chain, and calculate the CVSS base score consistently across attack vector, complexity, privileges, user interaction, scope, confidentiality, integrity, and availability.
5. Write the submission with a precise title, concise vulnerability description, numbered reproduction steps, proof artifacts, impact statement, CWE, CVSS vector and rationale, and practical remediation. Translate technical consequences into business terms when the receiving organization is less mature.
6. Review the report against scope, eligibility, and reporting-format requirements before submission. Remove unnecessary secrets and personal data, ensure a fresh reviewer can reproduce the issue, and use only the program's official channel.
7. After submission, allow the triage team the documented SLA to respond. Do not spam staff or contact them through unofficial channels; if delays exceed a reasonable period, use the platform's mediation process. For severity or bounty disagreements, explain the CVSS metrics and policy basis professionally.

### Key Testing Principles
- Scope and program policy are the primary authority; safe harbor does not excuse testing excluded assets or techniques.
- Being first, providing a reproducible result, and following eligibility rules can determine whether a valid issue receives a bounty.
- A good report separates vulnerability cause, proof, and impact. Avoid inflated claims, but describe credible business consequences and vulnerability chains.
- Use the CWE for the root weakness and provide a transparent CVSS vector rather than only a numeric score.
- Proofs should be concise and low impact. Stored XSS reports should show the source, storage, execution context, and affected roles; CSRF reports should show the state-changing request, missing defense, victim prerequisites, and resulting action; RCE reports should establish controlled command execution and execution context without destructive follow-on activity.
- Communication quality matters: be patient, factual, professional, and limited to official program or mediation channels.
- Remediation may be optional in a bounty policy, but targeted defensive guidance improves report quality and triage efficiency.

### Evidence and Reporting
Submit a report containing the vulnerability type and affected asset in the title; CWE; CVSS base score, vector, and metric-by-metric justification; root-cause description; numbered proof-of-concept steps; sanitized requests, responses, screenshots, or network evidence; verified impact; and remediation. Clearly identify required privileges and user interaction, distinguish observed behavior from potential impact, and explain any chained finding. Preserve originals privately, redact credentials, tokens, customer data, and unnecessary payload details, and maintain a timeline of submission, vendor responses, retesting, disclosure coordination, and mediation.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **0 yellow/output topics** in this module.

- [[Outputs/Modules/Bug Bounty Hunting Process Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## Bug Bounty Programs

### <https://www.hackerone.com/>

- describes their bug bounty platform (that can host bug bounty programs) as "Continuous testing, constant protection"
### Bug Bounty Program Types

- A bug bounty program can be private or public.
  - bounty hunters can only participate in a private bug bounty program upon receiving specific invitations.
    - The vast majority of bug bounty programs start as private ones and become public
    - HackerOne deals with invitations based on specific criteria
      - <https://docs.hackerone.com/hackers/invitations.html>
### Bug Bounty Program Code of Conduct

- The violation record of a bug bounty hunter is always taken into consideration
- go over HackerOne's Code of Conduct to familiarize yourself with such documents.
  - <https://www.hacker101.com/resources/articles/code_of_conduct>
### Bug Bounty Program Structure

- Navigate to examples and go through their "Policy."
  - <https://hackerone.com/bug-bounty-programs>
    - <https://web.archive.org/web/20230128203334/https://docs.hackerone.com/programs/policy-and-scope.html>
  - <https://hackerone.com/alibaba?type=team>
  - <https://hackerone.com/amazonvrp?type=team>
### A bug bounty program usually consists of the following elements:

- Vendor Response SLAs	Defines when and how the vendor will reply  
  Access	Defines how to create or obtain accounts for research purposes  
  Eligibility Criteria	For example, be the first reporter of a vulnerability to be eligible, etc.  
  Responsible Disclosure Policy	Defines disclosure timelines, coordination actions to safely disclose a vulnerability, increase user safety, etc.  
  Rules of Engagement  
  Scope	In-scope IP Ranges, domains, vulnerabilities, etc.  
  Out of Scope	Out-of-scope IP Ranges, domains, vulnerabilities, etc.  
  Reporting Format  
  Rewards  
  Safe Harbor  
  Legal Terms and Conditions  
  Contact Information
### Please go over a bug bounty program's description/policy meticulously. The same goes for any "code of conduct" documents they may include. By doing so, you can meet expectations and avoid unnecessary back and forth that could cause significant time loss.

### Finding Bug Bounty Programs

- <https://hackerone.com/directory/programs>
### Which Bug Bounty Program part establishes expectations for behavior while participating in a bug bounty program?

- Code of Conduct
## Writing a Good Report

### when reporting to less mature companies

- we may have to translate technical security issues into more understandable/business terms
### The essential elements of a good bug report are

- Vulnerability Title
  - Including vulnerability type, affected domain/parameter/endpoint, impact etc.
- CWE & CVSS score
  - For communicating the characteristics and severity of the vulnerability.
- Vulnerability Description
  - Better understanding of the vulnerability cause.
- Proof of Concept (POC)
  - Steps to reproduce exploiting the identified vulnerability clearly and concisely.
- Impact
  - Elaborate more on what an attacker can achieve by fully exploiting the vulnerability. Business impact and maximum damage should be included in the impact statement.
- Remediation
  - Optional in bug bounty programs, but good to have.
### Why CWE & CVSS?

- CWE
  - It serves as a common language
  - and as a baseline for weakness identification, mitigation, and prevention efforts
  - In the case of a vulnerability chain, choose a CWE related to the initial vulnerability.
- CVSS
  - <https://www.first.org/cvss/>
  - <https://www.first.org/cvss/calculator/3.1>
    - focus on the Base Score area only.
      - Attack Vector
        - Network (N)
          - (remotely exploitable)
        - Adjacent (A)
          - (using secure VPN only)
        - Local (L)
          - (e.g., keyboard, terminal, etc.) or remotely (e.g., SSH)
        - Physical (P)
          - physical interaction/manipulation
      - Attack Complexity
        - Low (L)
          - No special preparations should take place to exploit the vulnerability successfully.
        - High (H)
          - Special preparations and information gathering should take place to exploit the vulnerability successfully.
      - Privileges Required
        - None (N)
          - unauthorized perspective.
        - Low (L)
          - user or non-sensitive assets.
        - High (H)
          - admin-level privileges
      - User Interaction
        - None (N)
          - independently.
        - Required (R)
          - A user should take some action before the attackers can successfully exploit
      - Scope
        - Unchanged (U)
          - affects the vulnerable component or affects resources managed by the same security authority.
        - Changed (C)
          - affected one or resources beyond the scope
      - Confidentiality
        - None (N)
          - The confidentiality of the vulnerable component does not get impacted.
        - Low (L)
          - the attackers do not have control over what information is obtained.
        - High (H)
          - the attackers have total (or some) control over what information is obtained.
      - Integrity
        - None (N)
          - The integrity of the vulnerable component does not get impacted.
        - Low (L)
          - Attackers can modify data in a limited manner on the vulnerable component
        - High (H)
          - Attackers can modify all or critical data on the vulnerable component
      - Availability
        - None (N)
          - The availability of the vulnerable component does not get impacted.
        - Low (L)
          - The vulnerable component will experience some loss of availability
        - High (H)
          - The vulnerable component will experience total (or severe) availability loss
### Good Report Examples

- some good report examples selected by HackerOne
  - <https://hackerone.com/reports/341876>
  - <https://hackerone.com/reports/783877>
  - <https://hackerone.com/reports/520518>
  - <https://hackerone.com/reports/980511>
  - <https://hackerone.com/reports/691611>
  - <https://hackerone.com/reports/474656>
### Which base metric value of the base score considers that attackers can only exploit a vulnerability if they reside in the same physical or logical network as the target host/application?

- adjacent
## Interacting with Organizations/BBP Hosts

### Suppose that you have submitted a bug report. How should you interact with the security/triage team after that?

- do not interact with them
  - Allow the security/triage team some time to process your report
- vendor response SLAs
  - do not spam the security/triage team within a short period of time.
- If the security/triage team does not get back to you in a reasonable amount of time
  - contact Mediation.
    - <https://docs.hackerone.com/hackers/hacker-mediation.html>
- Do not interact with the security/triage team through any unofficial communication channel (social media etc.)!
### there could be disagreements about the severity of the bug or the bounty

- Explain your rationale for choosing this severity score and guide the security/triage team through each metric value you specified in the CVSS calculator. Eventually, you will come to an agreement.
- Go over the bug bounty program's policy and scope and ensure that your submission complies with both
- make sure that the bounty amount resembles the policy of the bug bounty program.
## Example 1: Reporting Stored XSS

### Title: Stored Cross-Site Scripting (XSS) in X Admin Panel

### CWE: CWE-79: Improper Neutralization of Input During Web Page Generation ('Cross-site Scripting')

### CVSS 3.1 Score: 5.5 (Medium)

### Description: During our testing activities, we identified that the "X for administrators" web application is vulnerable to stored cross-site scripting (XSS) attacks due to inadequate sanitization of user-supplied data. Specifically, the file uploading mechanism at "Admin Info" -> "Secure Data Transfer" -> "Load of Data" utilizes a value obtained from user input, specifically the uploaded file's filename, which is not only directly reflected back to the user’s browser but is also stored into the web application’s database. However, this value does not appear to be adequately sanitized. It, therefore, results in the application being vulnerable to reflected and stored cross-site scripting (XSS) attacks since JavaScript code can be entered in the filename field.

### Impact: Cross-Site Scripting issues occur when an application uses untrusted data supplied by offensive users in a web browser without sufficient prior validation or escaping. A potential attacker can embed untrusted code within a client-side script to be executed by the browser while interpreting the page. Attackers utilize XSS vulnerabilities to execute scripts in a legitimate user's browser leading to user credentials theft, session hijacking, website defacement, or redirection to malicious sites. Anyone that can send data to the system, including administrators, are possible candidates for performing XSS attacks against the vulnerable application. This issue introduces a significant risk since the vulnerability resides in the "X for administrators” web application, and the uploaded files are visible and accessible by every administrator. Consequently, any administrator can be a possible target of a Cross-Site Scripting attack.

### POC:

- Step 1: A malicious administrator could leverage the fact that the filename value is reflected back to the browser and stored in the web application’s database to perform cross-site scripting attacks against other administrators by uploading a file containing malicious JavaScript code into its filename. The attack is feasible because administrators can view all uploaded files regardless of the uploader. Specifically, we named the file, as follows, using a Linux machine.  
  "><svg onload = alert(document.cookie)>.docx
  - https://academy.hackthebox.com/storage/modules/161/2.png
    ![[Attachments/7260aac3376b78a4680b98d3820e46e4994b6e6bee1a05c036eab304ff60afe4.png]]
- Step 2: When another administrator clicks the view button to open the abovementioned file, the malicious JavaScript code in the file’s filename will be executed on the browser.
  - Subtopic 1
    ![[Attachments/d5904f08ed711df1fdd8115e2fc833c81519070071327fa93cd526765a549327.png]]
### CVSS Score Breakdown

- Attack Vector:	Network - The attack can be mounted over the internet.
- Attack Complexity:	Low - All the attacker (malicious admin) has to do is specify the XSS payload eventually stored in the database.
- Privileges Required:	High - Only someone with admin-level privileges can access the admin panel.
- User Interaction:	None - Other admins will be affected simply by browsing a specific (but regularly visited) page within the admin panel.
- Scope:	Changed - Since the vulnerable component is the webserver and the impacted component is the browser
- Confidentiality:	Low - Access to DOM was possible
- Integrity:	Low - Through XSS, we can slightly affect the integrity of an application
- Availability:	None - We cannot deny the service through XSS
## Example 2: Reporting CSRF

### Title: Cross-Site Request Forgery (CSRF) in Consumer Registration

### CWE: CWE-352: Cross-Site Request Forgery (CSRF)

### CVSS 3.1 Score: 5.4 (Medium)

### Description: During our testing activities, we identified that the web page responsible for consumer registration is vulnerable to Cross-Site Request Forgery (CSRF) attacks. Cross-Site Request Forgery (CSRF) is an attack where an attacker tricks the victim into loading a page that contains a malicious request. It is malicious in the sense that it inherits the identity and privileges of the victim to perform an undesired function on the victim's behalf, like change the victim's e-mail address, home address, or password, or purchase something. CSRF attacks generally target functions that cause a state change on the server but can also be used to access sensitive data.

### Impact: The impact of a CSRF flaw varies depending on the nature of the vulnerable functionality. An attacker could effectively perform any operations as the victim. Because the attacker has the victim's identity, the scope of CSRF is limited only by the victim's privileges. Specifically, an attacker can register a fintech application and create an API key as the victim in this case.

### POC

- Step 1: Using an intercepting proxy, we looked into the request to create a new fintech application. We noticed no anti-CSRF protections being in place.
  - Subtopic 1
    ![[Attachments/855a7c023c14346a8b6f832615c7846fe989b7a0058f79d4868bbac5b1cc5565.png]]
- Step 2: We used the abovementioned request to craft a malicious HTML page that, if visited by a victim with an active session, a cross-site request will be performed, resulting in the advertent creation of an attacker-specific fintech application.
  - Subtopic 1
    ![[Attachments/0c8ed6db5d29cb950e907fb9f06ff50d8035e9f04a726c131f0ff21247b6364f.png]]
- Step 3: To complete the attack, we would have to send our malicious web page to a victim having an open session. The following image displays the actual cross-site request that would be issued if the victim visited our malicious web page.
  - Subtopic 1
    ![[Attachments/4368b5d52713124868598633e5d9e439182976ef5365c1769042a4641865907f.png]]
- Step 4: The result would be the inadvertent creation of a new fintech application by the victim. It should be noted that this attack could have taken place in the background if combined with finding 6.1.1. <-- 6.1.1 was an XSS vulnerability.
  - Subtopic 1
    ![[Attachments/18485fbac2b741409fca23080241365d6a8092ea29877ee91a7dd053afc11709.png]]
## CVSS Score Breakdown

### Attack Vector:	Network - The attack can be mounted over the internet.

### Attack Complexity:	Low - All the attacker has to do is trick a user that has an open session into visiting a malicious website.

### Privileges Required:	None - The attacker needs no privileges to mount the attack.

### User Interaction:	Required - The victim must click a crafted link provided by the attacker.

### Scope:	Unchanged - Since the vulnerable component is the webserver and the impacted component is again the webserver.

### Confidentiality:	Low - The attacker can create a fintech application and obtain limited information.

### Integrity:	Low - The attacker can modify data (create an application) but limitedly and without seriously affecting the vulnerable component's integrity.

### Availability:	None - The attacker cannot perform a denial-of-service through this CSRF attack.

## Example 3: Reporting RCE

### Title: IBM WebSphere Java Object Deserialization RCE

### CWE: CWE-502: Deserialization of Untrusted Data

### CVSS 3.1 Score: 9.8 (Critical)

### Description: During our testing activities, we identified that the remote WebSphere application server is affected by a vulnerability related to insecure Java object deserialization allowing remote attackers to execute arbitrary commands. By issuing a request to the remote WebSphere application server over HTTPS on port 8880, we identified the existence of raw, serialized Java objects that were base64-encoded. It is possible to identify base64 encoded serialized Java objects by the "rO0" header. We were able to craft a SOAP request containing a serialized Java object that can exploit the aforementioned vulnerability in the Apache Commons Collections (ACC) library used by the WebSphere application server. The crafted Java object contained a ping command to be executed by the affected system.

### Impact: Command injection vulnerabilities typically occur when data enters the application from an untrusted source, such as a terminal or a network socket, without authenticating the source, or the data is part of a string that is executed as a command by the application, again without validating the input against a predefined list of allowed commands, such as a whitelist. The application executes the provided command under the current user's security context. If the application is executed as a privileged user, administrative or driver interface, such as the SYSTEM account, it can potentially allow the complete takeover of the affected system.

### POC:

- Step 1: We identified that the application uses serialized data objects by capturing and decoding a request to port 8880 of the server. The following images display the original request and the remote server's response, along with its decoded content.
  - Subtopic 1
    ![[Attachments/4328a30291cd206f4e0b0c78e3f0c4a9dee838ce82022e7ad18eebae3295c411.png]]
- Step 2: We crafted a SOAP request containing a command to be executed by the remote server. The command would send ping messages from the affected server to our host. The image below displays the crafted request and its decoded payload.
  - Subtopic 1
    ![[Attachments/93cd79779cb0b81f834a0c7b0e4e4dfa3ec6678c926c2dee6723594093e9fc7a.png]]
- Step 3: The following image displays the crafted SOAP request allowing to remotely execute a ping command from the affected system. Capturing traffic via Wireshark, we observed the ping request from the Websphere application server to our machine.
  - Subtopic 1
    ![[Attachments/93bb9875aa708fe8a7e4872daaaf80e333266a7c751896de88ea5ae4d5fc202a.png]]
### CVSS Score Breakdown

- Attack Vector:	Network - The attack can be mounted over the internet.
- Attack Complexity:	Low - All the attacker has to do is send a crafted request against the vulnerable application.
- Privileges Required:	None - The attack can be mounted from an unauthenticated perspective.
- User Interaction:	None - No user interaction is required to exploit this vulnerability successfully.
- Scope:	Unchanged - Since the vulnerable component is the webserver and the impacted component is again the webserver.
- Confidentiality:	High - Successful exploitation of the vulnerability results in remote code execution, and attackers have total control over what information is obtained.
- Integrity:	High - Successful exploitation of the vulnerability results in remote code execution. Attackers can modify all or critical data on the vulnerable component.
- Availability:	High - Successful exploitation of the vulnerability results in remote code execution. Attackers can deny the service to users by powering the webserver off.
