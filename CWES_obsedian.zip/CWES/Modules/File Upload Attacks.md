---
tags: [CWES, HTB, index]
source_file: "CWES.xmind"
---

# File Upload Attacks

## Study Companion

### Prerequisites

HTTP multipart requests, file formats, and basic server-side execution concepts.

### Learning Outcomes

- Distinguish client-side, blacklist, whitelist, MIME, and signature validation.
- Assess storage, naming, retrieval, parsing, and execution independently.
- Evaluate SVG/XML, archive, metadata, filename, and resource-exhaustion risks.

### Practice Checkpoint

Map an upload from submission to retrieval and identify every validation and storage control encountered.

### Related Knowledge Map

- [[Maps/Files and Server-side Attacks|Files and Server-side Attacks]]
- [[Study Group Guide|CWES Study Group Guide]]

## Professional Guidance

### Objective
Assess upload functionality for paths from weak validation to stored client-side attacks, sensitive-file disclosure, denial of service, and server-side code execution, while keeping all activity within the authorized HTB scope.

### Assessment Workflow
1. Inventory every upload surface and identify the server technology, upload handler, accepted extensions, MIME expectations, size limits, storage naming, and retrieval path.
2. Establish a benign baseline, then determine whether validation is absent, client-side only, blacklist-based, whitelist-based, or dependent on controllable `Content-Type` values and weak file-signature checks.
3. Test server-side enforcement with controlled extension variants, double extensions, alternate executable extensions, case changes, crafted MIME types, and valid magic bytes; verify whether uploaded content is stored, rendered, parsed, or executed.
4. Evaluate constrained formats such as SVG, XML, HTML, images, documents, and archives for stored XSS, XXE, metadata injection, decompression/pixel abuse, traversal, filename injection, and upload-path disclosure.
5. Where execution is authorized and proven necessary, use the smallest harmless proof, record the effective URL and execution context, and stop after demonstrating impact.
6. Review defenses: canonicalized extension allowlists, content inspection, randomized names, non-web-accessible isolated storage, safe download headers, size limits, library patching, malware scanning, and disabled dangerous runtime functions.

### Key Testing Principles
- Treat browser-side checks and multipart headers as untrusted; validation must occur on the server against canonicalized names and actual content.
- A successful upload is not equivalent to exploitability: separately prove reachability, rendering/parsing behavior, and server execution.
- Test compound controls together because extension, MIME, signature, naming, and web-server handler behavior can interact in unexpected ways.
- Prefer low-impact markers over persistent shells, avoid destructive archive or resource-exhaustion payloads, and remove test artifacts when possible.

### Evidence and Reporting
Capture the original and modified multipart requests, validation responses, stored filename/path, retrieval response headers, and a minimal impact proof. Explain the bypassed control and root cause, distinguish client-side from server-side impact, and recommend defense in depth: strict allowlists, content reprocessing, isolated storage, safe serving headers, least privilege, monitoring, and explicit cleanup of uploaded test files.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **39 yellow/output topics** in this module.

- [[Outputs/Modules/File Upload Attacks Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

The original XMind hierarchy is split into section notes to keep Obsidian responsive and reduce security-scanner false positives.

- [[Modules/File Upload Attacks/01 - Intro to File Upload Attacks|Intro to File Upload Attacks]]
- [[Modules/File Upload Attacks/02 - Absent Validation|Absent Validation]]
- [[Modules/File Upload Attacks/03 - Upload Exploitation|Upload Exploitation]]
- [[Modules/File Upload Attacks/04 - Client-Side Validation|Client-Side Validation]]
- [[Modules/File Upload Attacks/05 - Blacklist Filters|Blacklist Filters]]
- [[Modules/File Upload Attacks/06 - Whitelist Filters|Whitelist Filters]]
- [[Modules/File Upload Attacks/07 - Type Filters|Type Filters]]
- [[Modules/File Upload Attacks/08 - Limited File Uploads|Limited File Uploads]]
- [[Modules/File Upload Attacks/09 - Other Upload Attacks|Other Upload Attacks]]
- [[Modules/File Upload Attacks/10 - Preventing File Upload Vulnerabilities|Preventing File Upload Vulnerabilities]]
- [[Modules/File Upload Attacks/11 - Skills Assessment|Skills Assessment]]
