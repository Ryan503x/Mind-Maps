---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# intro

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## most common place

### find LFI within is templating engines.

## wordlists

### https://github.com/danielmiessler/SecLists/tree/master/Fuzzing/LFI

## parameter

### /index.php?page=about

- sets static content (e.g. header/footer)
## Examples of Vulnerable Code

### PHP

- if (isset($_GET['language'])) {  
  include($_GET['language']);  
  }
  - parameter is directly passed to the include()
### NodeJS

- if(req.query.language) {  
  fs.readFile(path.join(__dirname, req.query.language), function (err, data) {  
  res.write(data);  
  });  
  }
  - Another example is the render() function in the Express.js
    - app.get("/about/:language", function(req, res) {  
      res.render(`/${req.params.language}/about.html`);  
      });
### Java

- <c:if test="${not empty param.language}">  
  <jsp:include file="<%= request.getParameter('language') %>" />  
  </c:if>
- <c:import url= "<%= request.getParameter('language') %>"/>
### .NET

- @if (!string.IsNullOrEmpty(HttpContext.Request.Query['language'])) {  
  <% Response.WriteFile("<% HttpContext.Request.Query['language'] %>"); %>  
  }
- @Html.Partial(HttpContext.Request.Query['language'])
- <!--#include file="<% HttpContext.Request.Query['language'] %>"-->
## Read vs Execute

### File Inclusion vulnerabilities may occur in any web server and any development frameworks

### some of the above functions only read the content of the specified files, while others also execute the specified files
