---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# File Inclusion Prevention

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## may require changing the whole architecture of an existing web application

## rely on program framework proper functions

### PHP has basename()

## use bash wildcards

### cat .?/.*/.?/etc/passwd

- ?, * and . will not work in php like bash
## prevent dangerous code

### system(), except...

## sanitize the user input

### recursively remove any attempts

- while(substr_count($input, '../', 0)) {  
  $input = str_replace('../', '', $input);  
  };
## Web Server Configuration

### setting allow_url_fopen and allow_url_include to Off.

### lock web applications to their web root directory

- by running the application within Docker
- In PHP that can be done by
  - open_basedir = /var/www in the php.ini
### dangerous modules are disabled

- <https://www.php.net/manual/en/wrappers.expect.php>
- <https://httpd.apache.org/docs/2.4/mod/mod_userdir.html>
## WAF

### ModSecurity minimizes false positives by offering a permissive mode

- only report things it would have blocked
## LAB

### What is the full path to the php.ini file for Apache?

- enter ssh
- find / -type f -iname php.ini 2>/dev/null
  - /etc/php/7.4/apache2/php.ini
### Edit the php.ini file to block system(), then try to execute PHP Code that uses system. Read the /var/log/apache2/error.log file and fill in the blank: system() has been disabled for ________ reasons.

- sudo sed -i 's/disable_functions = /disable_functions = system,/' /etc/php/7.4/apache2/php.ini
  - now the function disable_functions has system now
- echo '<?<!-- -->php system($_GET["cmd"]); ?>' | sudo tee /var/www/html/test.php
  - http://10.129.29.112/test.php?cmd=id
    - empty result
- tail -f /var/log/apache2/error.log
  - system() has been disabled for security reasons
