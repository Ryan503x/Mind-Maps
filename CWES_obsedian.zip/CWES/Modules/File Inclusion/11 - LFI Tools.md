---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# LFI Tools

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## <https://github.com/mzfr/liffy>

## <https://github.com/D35m0nd142/LFISuite>

## <https://github.com/OsandaMalith/LFiFreak>
