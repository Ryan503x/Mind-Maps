---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# Automated Scanning

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Fuzzing Parameters

### fuzz for exposed parameters

- ffuf -w /opt/useful/seclists/Discovery/Web-Content/burp-parameter-names.txt:FUZZ -u 'http://<SERVER_IP>:<PORT>/index.php?FUZZ=value' -fs 2287
  - language
## LFI wordlists

### https://github.com/danielmiessler/SecLists/tree/master/Fuzzing/LFI

### https://github.com/danielmiessler/SecLists/blob/master/Fuzzing/LFI/LFI-Jhaddix.txt

- contains various bypasses and common files
  - ffuf -w /opt/useful/seclists/Fuzzing/LFI/LFI-Jhaddix.txt:FUZZ -u 'http://<SERVER_IP>:<PORT>/index.php?language=FUZZ' -fs 2287
