---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "1"
source_file: "CWES.xmind"
---

# Web Proxy

## Study Companion

### Prerequisites

HTTP fundamentals and access to an authorized browser-based lab.

### Learning Outcomes

- Configure and scope Burp Suite or OWASP ZAP safely.
- Use Proxy, Repeater, and Intruder for controlled request manipulation.
- Preserve sessions, tokens, encodings, and evidence while testing.

### Practice Checkpoint

Replay a request in Repeater, modify one variable, and document the behavioral difference.

### Related Knowledge Map

- [[Maps/Reconnaissance and Tooling|Reconnaissance and Tooling]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Use Burp Suite, OWASP ZAP, and approved proxy routing to observe, reproduce, modify, fuzz, and scan authorized web traffic while maintaining scope, session context, and auditable evidence.

### Assessment Workflow
1. Configure the browser or CLI client to use the proxy, verify interception on a harmless request, and add only the authorized host to scope.
2. Build the site map through normal navigation and passive analysis before launching spiders, crawlers, or active scans.
3. Inspect request and response structure, then use Repeater for controlled single-variable changes; distinguish client-side HTML restrictions from server enforcement.
4. Apply URL, Base64, and other decoding/encoding carefully, preserving headers and content types when replaying modified data.
5. Use Intruder with precise payload positions, appropriate attack type, bounded wordlists, payload processing, encoding, and grep-match conditions.
6. Configure Match and Replace only for explicit, reversible transformations and verify it is not unintentionally changing unrelated traffic.
7. Route CLI, Nmap, or Metasploit web traffic through the proxy only where supported and authorized; review scanner findings manually.
8. Export sanitized project evidence and reports, then disable interception and temporary routing changes.

### Key Testing Principles
- Modified response HTML can reveal hidden or disabled controls but does not prove server-side authorization bypass.
- Prefer Repeater for confirmation before automation, and keep active scans and brute force inside scope and rate limits.
- Encoding errors, stale cookies, CSRF tokens, redirects, and compressed bodies commonly explain inconsistent results.
- Treat extensions as third-party code and install only trusted, necessary components.
- Proxy logs may contain credentials and tokens; minimize retention and protect project files.

### Evidence and Reporting
Include raw and decoded requests, relevant responses, timestamps, tool and extension versions, scope settings, payload positions, scanner configuration, and manual confirmation. Redact secrets, separate passive observations from actively validated issues, and state whether the server accepted a prohibited action rather than merely whether the browser UI was changed.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **1 yellow/output topic** in this module.

- [[Outputs/Modules/Web Proxy Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## ZAP

### Scan

- ZAP Spider
  - Alerts ( see all identified issues)
- tree constructed
  - Active Scan
- Report>Generate HTML Report
  - XML
  - Markdown
## Burp

### intercepting

- request
  - ping your ip (website function)
    - POST /ping HTTP/1.1  
      Host: 46.101.23.188:30820  
      Content-Length: 4  
      ip=1
      - change the ip parameter's value from 1 to ;ls;
        - ip=;cat+flag.txt;
- response
  - In Burp, we can enable response interception by going to (Proxy>Options) and enabling Intercept Response under Intercept Server Responses:
    - CTRL SHIFT R (full refresh)
      - try changing the type="number" on line 27 to type="text", which should enable us to write any value we want
        - change the maxlength="3" to maxlength="100" so we can enter longer input:
          - forward
            - input any value we want.
              - We may use the same technique to persistently enable any disabled HTML buttons by modifying their HTML code.
- Shpwing hidden fields
  - Proxy>Options>Response Modification, then select one of the options, like Unhide hidden form fields.
### Automatic Request Method

- Burp Match and Replace
  - Request Body
    - Change User Agent for all requests
    - Change any header/value
  - Response Body
    - adding another rule to change maxlength="3" to maxlength="100".
### Repeating Requests

- HTTP History
  - filtering/searching
    - Repeater
      - Shortcut
        - CTRL+R
        - CTRL+SHIFT+R
### Encoding / Decoding
> It is essential to ensure that our request data is URL-encoded and our request headers are correctly set. Otherwise, we may get a server error in the response.

- Repeater
  - highlight the text > CTRL + U
- Decoder
  - URL Encoding is key to HTTP requests
    - Full URL-Encoding
    - Unicode URL
- example
  - Decode the cookie that is base6  
    eyJ1c2VybmFtZSI6Imd1ZXN0IiwgImlzX2FkbWluIjpmYWxzZX0=
    - {"username":"guest","is_admin":false}
      - change guest to admin and false to true then encode it using original method base64
- Lab
  - Decode base64 several time
    - once we get %values decode in URL
      - Flag
### Intruder (fuzzing and brute-forcing)

- Target
  - shortcut
    - (CTRL + I) send request
    - (CTRL + SHIFT +  I) open tab
  - Position
    - Attack Type:
      - Sniper
        - one parameter only
      - Cluster Bomb
        - several payload positions
    - §value§
  - Payloads
    - Payload Set 1 (number)
    - types
      - Simple List: The basic and most fundamental
      - Runtime file: loads line-by-line avoid excessive memory usage by Burp.
        - In case you wanted to use a very large wordlist
      - Character Substitution: list of characters and their replacements, tries all potential permutations.
    - Payload Options [Simple list]
      - Add
        - /opt/useful/seclists/Discovery/Web-Content/common.txt
    - Payload Processing
      - determine fuzzing rules over the loaded wordlist
      - Add rule
        - Add prefix
        - skips any lines that start with a .
          - Skip if matches regex  
            pattern that matches lines starting with ., which is: ^\..*$
        - Encode
    - Payload Encoding
      - Enable URL Encoding special characters
  - options
    - Grep - match
      - Clear
      - 200 OK
        - Add
      - disable Exclude HTTP Headers
  - Attack
### Target

- Site Map(All directories)
  - right Click > Add to Scope
- Issue>Report issues for this host
### Dashboard Scaning

- Crawler
  - building web structure
    - Select from library
      - Crawl strategy - fastest
        - Application login tab  
          add a set of credentials for Burp
- Scanner
  - in History Right Click on Request > Scan
    - choose the Crawl and Audit option in the New Scan
      - Active Scan
      - Passive scan
- Tasks
  - results
### Extensions

- Decoder improved
- Recommended
  - .NET beautifier	J2EEScan	Software Vulnerability Scanner  
    Software Version Reporter	Active Scan++	Additional Scanner Checks  
    AWS Security Checks	Backslash Powered Scanner	Wsdler  
    Java Deserialization Scanner	C02	Cloud Storage Tester  
    CMS Scanner	Error Message Checks	Detect Dynamic JS  
    Headers Analyzer	HTML5 Auditor	PHP Object Injection Check  
    JavaScript Security	Retire.JS	CSP Auditor  
    Random IP Address Header	Autorize	CSRF Scanner  
    JS Link Finder
## Proxychains
> very useful tool in Linux is proxychains, which routes all traffic coming from any command-line tool to any proxy we specify.

### Edit to use

- sudo nano /etc/proxychains.conf
  - #socks4         127.0.0.1 9050  
    http 127.0.0.1 8080
    - we add comment to only proxy http
### Quiet Mode

- reduce noise by un-commenting quiet_mode
### Use in CLI

- proxychains curl -k http://SERVER_IP:PORT
  - ProxyChains-3.1 (http://proxychains.sf.net)  
    <!DOCTYPE html>
    - this request gone through Burp proxy we can intercept
### NMAP

- nmap --proxies http://127.0.0.1:8080 SERVER_IP -pPORT -Pn -sC
  - we can see requests NMAP in burp
### Metasploit

- auxiliary/server/socks_proxy
  - set SRVPORT  9050
  - set VERSION  5
  - run
    - jobs / netstat -antp
## Metasploit
> let's try to proxy web traffic made by Metasploit modules to better investigate and debug them.

### run proxy option

- use auxiliary/scanner/http/robots_txt
  - set PROXIES HTTP:127.0.0.1:8080
## Skill Assessment

### The /lucky.php page has a button that appears to be disabled. Try to enable the button, and then click it to get the flag.

- intercept response
  - type='text' instead of submit
  - in the button tag remove disabled
