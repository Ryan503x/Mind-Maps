---
tags: [CWES, HTB, technical-reference]
module: "SQL Injection Fundamentals"
source_file: "CWES.xmind"
---

# Mitigating SQL Injection

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Input Sanitization

## Input Validation

### $pattern = "/^[A-Za-z\s]+$/";

- '; SELECT 1,2,3,4-- - will fail now
## User Privileges

### the user querying the database only has minimum permissions

## Web Application Firewall

### open-source (ModSecurity)

### premium (Cloudflare)

## Parameterized Queries

### escaped and passed on by the drivers. Instead of directly passing the data into the SQL query
