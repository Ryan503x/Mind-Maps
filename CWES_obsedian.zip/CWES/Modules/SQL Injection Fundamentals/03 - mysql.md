---
tags: [CWES, HTB, technical-reference]
module: "SQL Injection Fundamentals"
source_file: "CWES.xmind"
---

# mysql

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## mysql -u root -h docker.hackthebox.eu -P 3306 -p

### SHOW TABLES;

### DESCRIBE logins;

### UPDATE table_name SET column1=newvalue1, column2=newvalue2, ... WHERE <condition>;

## mysql -u root -h 94.237.55.38 -P 35946 -p

### SELECT * FROM logins ORDER BY password;

### SELECT * FROM logins LIMIT 2;

### SELECT * FROM logins WHERE id > 1;

### SELECT * FROM logins where username = 'admin';

- SELECT * FROM logins WHERE username LIKE 'admin%';
### SELECT * FROM logins WHERE username like '___';

- | id | username | password | date_of_joining     |  
  +----+----------+----------+---------------------+  
  |  3 | tom      | tom123!  | 2020-07-02 15:18:56 |
### In the 'titles' table, what is the number of records WHERE the employee number is greater than 10000 OR their title does NOT contain 'engineer'?

- SELECT * FROM titles WHERE emp_no > 10000 or title NOT LIKE '%engineer%';
