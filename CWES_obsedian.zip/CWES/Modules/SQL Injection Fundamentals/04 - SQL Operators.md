---
tags: [CWES, HTB, technical-reference]
module: "SQL Injection Fundamentals"
source_file: "CWES.xmind"
---

# SQL Operators

> [!info] Complete technical reference
> Section imported without removing commands, hints, links, notes, or images.

## Division (/), Multiplication (*), and Modulus (%)

## Addition (+) and subtraction (-)

## Comparison (=, >, <, <=, >=, !=, LIKE)

## NOT (!)

## AND (&&)

## OR (||)
