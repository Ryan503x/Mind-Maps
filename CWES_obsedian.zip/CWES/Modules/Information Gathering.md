---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "1"
source_file: "CWES.xmind"
---

# Information Gathering

## Study Companion

### Prerequisites

DNS, HTTP, TLS, and basic command-line reconnaissance tools.

### Learning Outcomes

- Build a passive-first inventory with clear provenance and timestamps.
- Validate subdomains, virtual hosts, technologies, archives, and public artifacts.
- Separate verified assets from stale or low-confidence intelligence.

### Practice Checkpoint

Create a scoped attack-surface table containing asset, source, validation method, confidence, and next test.

### Related Knowledge Map

- [[Maps/Reconnaissance and Tooling|Reconnaissance and Tooling]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Create a complete, validated inventory of the authorized external web attack surface using passive-first reconnaissance and carefully controlled active checks, while preserving provenance and avoiding unnecessary alerting or service impact.

### Assessment Workflow
1. Confirm scope, exclusions, rate limits, approved source types, and whether active scanning is permitted.
2. Collect passive intelligence from WHOIS, DNS records, certificate-transparency logs, search engines, archives, public repositories, and approved OSINT sources.
3. Resolve and validate candidate subdomains, IPs, mail and name servers, historical hosts, and certificate names; deduplicate and timestamp findings.
4. Distinguish DNS-backed subdomains from name-based virtual hosts, then perform bounded vhost and subdomain enumeration with calibrated wordlists and response filters.
5. Fingerprint services through headers, banners, page traits, TLS data, WAF detection, and multiple tools, assigning confidence rather than assuming exact versions.
6. Crawl in-scope sites and inspect `robots.txt`, sitemaps, `.well-known` resources, comments, metadata, backups, configuration names, logs, and archived URLs.
7. Correlate assets and technologies into a prioritized attack-surface map and validate high-value discoveries manually.

### Key Testing Principles
- Start passive; active scans, brute force, spidering, and banner probes can trigger monitoring and must respect agreed rates.
- DNS records, CT logs, search results, and archives can be stale—resolve and verify before reporting.
- `robots.txt` is a discovery aid, not an authorization mechanism.
- Filter vhost fuzzing by baseline size, words, lines, status, or content to suppress wildcard responses.
- Never treat publicly indexed secrets as permission to use them; record and report exposure safely.

### Evidence and Reporting
For each asset, record hostname, IP, port, protocol, source, first/last observed time, resolution result, technology/WAF confidence, and supporting command or URL. Preserve sanitized crawler and DNS output, flag sensitive files without unnecessary retrieval, and deliver a deduplicated inventory plus prioritized follow-up hypotheses and coverage gaps.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **5 yellow/output topics** in this module.

- [[Outputs/Modules/Information Gathering Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## goals of web reconnaissance

### Identifying Assets

- Uncovering all publicly accessible components  web pages, subdomains, IP addresses
### Discovering Hidden Information

- Locating sensitive information
  - backup files
  - configuration files
  - internal documentation.
### Analysing the Attack Surface

- identify potential vulnerabilities and weaknesses.
### Gathering Intelligence

- Collecting information that can be leveraged for further exploitation
  - social engineering
## types

### Active (Can Raise Alarm)

- Port Scanning
- Vulnerability scanning
  - Nessus
  - Nikto
  - OpebVAS
- Netwok Mapping
  - Traceroute
- Banner Grabbing
  - curl
  - netcat
- OS Fingerprinting
  - NMAP -O
  - Xprobe2
- Service Enumeration
  - NMAP -sV
- Web Spidering
  - Burp
  - ZAP
  - Scrapy
  - Script
### Passive

- Search engine Query
  - Google
  - Shoudan
- whois
  - Identifying Key Personnel
    - social engineering
  - Discovering Network Infrastructure
    - identify potential entry points or misconfigurations.
  - Historical Data Analysis
    - whoisFreaks
- DNS/dig subdomains
  - records
    - A
    - AAAA
    - CNAME (Point to another Domain)
      - could pointing to an outdated server
    - MX
    - NS
    - TXT
    - SOA (Specifies administrative information)
    - SRV	(Service Record)
    - PTR (reverse)
      - 1.2.0.192.in-addr.arpa. IN PTR www.example.com.
        - IP is 192.0.2.1
  - subdomain
    - Active Subdomain Enumeration
      - brute-force enumeration
        - dnsenum --enum inlanefreight.com -f /usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt -r
      - DNS zone transfer
        - dig axfr @nsztm1.digi.ninja zonetransfer.me
    - Passive Subdomain Enumeration
      - Certificate Transparency (CT) logs
      - Google dork
        - site:example.com
  - tools
    - dig
      - basic, zone transfers (if allowed)
      - Use
        - dig domain.com
        - dig domain.com CNAME
        - Specifies a specific name server to query
          - dig @1.1.1.1 domain.com
        - Shows the full path of DNS resolution.
          - dig +trace domain.com
        - Performs a reverse lookup to find host name
          - dig -x 192.168.1.1
        - Retrieves all available DNS records
          - dig domain.com ANY
        - just want the answer
          - dig +short hackthebox.com
    - nslookup
    - ffuf / gobuster
      - subdomain bruteforce
    - amass
    - puredns
    - host
      - A, AAAA, and MX records.
    - dnsenum
      - Discovering subdomains and gathering DNS information efficiently.
      - automatically attempts zone transfers
    - fierce
      - subdomains and potential targets
    - dnsrecon
      - Comprehensive DNS enumeration
    - theHarvester
      - Collecting email addresses, employee information, and other data associated with a domain from multiple sources.
- Web Archive Analysis
  - Wayback Machine
- Social Media Analysis
  - LinkedIn
    - Searching LinkedIn for employees of a target organisation
      - potential social engineering targets.
  - Twitter
  - Specialized OSINT
- Code Repositories
  - GitHub
  - GitLab
## Virtual hosting
> configurations within a web server that allow multiple websites or applications to be hosted on a single server.

### VHOSTING & subdomain Differences

- VHOST
  - diffrent web on same server
- Subdomain
  - seperate web server seperated by DNS Server
### Example

- <VirtualHost *:80>  
  ServerName www.example1.com  
  DocumentRoot /var/www/example1  
  </VirtualHost>  
  <VirtualHost *:80>  
  ServerName www.example2.org  
  DocumentRoot /var/www/example2  
  </VirtualHost>  
  <VirtualHost *:80>  
  ServerName www.another-example.net  
  DocumentRoot /var/www/another-example  
  </VirtualHost>
### Types of VHOSTING

- Name-Based
- IP-Based
- Port-Based
### Discovery Tools

- gobuster
  - sudo nano /etc/hosts
    - Add this record  
      94.237.54.192 inlanefreight.htb
  - gobuster vhost -u http://inlanefreight.htb:30923 -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt --append-domain inlanefreight.htb
- feroxbuster
- ffuf
  - ffuf -w /usr/share/seclists/Discovery/DNS/subdomains-top1million-110000.txt -u http://FUZZ.target -H "Host: FUZZ.target" -fs 0
## CT Logs

### https://crt.sh/

### https://search.censys.io/

### curl

- url -s "https://crt.sh/?q=facebook.com&output=json" | jq -r '.[]  | select(.name_value | contains("dev")) | .name_value' | sort -u
## Fingerprinting

### Techniques

- Banner Grabbing
  - server software, version numbers, and other details.
- Analysing HTTP Headers
  - X-Powered-By header might reveal additional technologies
- Probing for Specific Responses
  - error messages
  - characteristic of particular web servers or software components.
- Analysing Page Content
### Tools

- Wappalyzer
- Builtwith
- Whatweb
  - for specific VHOST
    - whatweb http://10.129.166.130 --header "Host: app.inlanefreight.local"
- NMAP
- Netcraft
- wafw00f
  - pip3 install git+https://github.com/EnableSecurity/wafw00f
- curl
- Nikto
  - sudo apt update && sudo apt install -y perl
    - git clone https://github.com/sullo/nikto
      - cd nikto/program
        - chmod +x ./nikto.pl
### Example

- curl -I inlanefreight.com  
  Server: Apache/2.4.41  
  X-Redirect-By: WordPress
- wafw00f inlanefreight.com  
  [+] The site https://inlanefreight.com is behind Wordfence (Defiant) WAF.
- using Nikto, only running the fingerprinting modules
  - nikto -h inlanefreight.com -Tuning b
## Crawling

### Extracting Valuable Information

- Links
- Comments
- Metadata
  - titles, descriptions, keywords, author names, and dates
- Sensitive Files
  - backup files
    - .bak, .old
      - can get  
        database credentials, encryption keys
  - configuration files
    - web.config, settings.php
  - log files
    - error_log, access_log
  - API keys
### robots.txt

- Structure
  - User-agent: *
  - Directives
    - Disallow
      - Disallow: /admin/
    - Allow
      - Allow: /public/
    - Crawl-delay
      - Crawl-delay: 10
    - Sitemap
      - Sitemap: https://www.example.com/sitemap.xml
- Reconnaissance
  - Uncovering Hidden Directories
  - Mapping Website Structure
  - Detecting Crawler Traps
    - Some websites intentionally include "honeypot" directories in robots.txt to lure malicious bots.
### Well Known URI

- security.txt
- /.well-known/change-password
- openid-configuration
  - https://example.com/.well-known/openid-configuration
- assetlinks.json
- mta-sts.txt
### Creepy Crawlies

- Burp Suite Spider
- OWASP ZAP (Zed Attack Proxy)
- Scrapy (Python Framework)
  - Download
    - pip3 install scrapy
      - wget -O ReconSpider.zip https://academy.hackthebox.com/storage/modules/144/ReconSpider.v1.2.zip
        - unzip ReconSpider.zip
  - Run
    - python3 ReconSpider.py http://inlanefreight.com
      - cat result.json
- Apache Nutch (Scalable Crawler)
## Search Engine Discovery

### OSINT (Open Source Intelligence)

### Google Dork

- operations
  - site:example.com
  - inurl:login
  - filetype:pdf
  - intitle:"confidential report"
  - intext:"password reset"
  - cache:example.com
  - link:example.com
  - related:example.com
  - info:example.com
  - define:phishing
  - site:example.com numrange:1000-2000
  - allintext:admin password reset
  - allinurl:admin panel
  - allintitle:confidential report 2023
  - site:example.com AND (inurl:admin OR inurl:login)
  - "linux" OR "ubuntu" OR "debian"
  - site:bank.com NOT inurl:login
  - site:socialnetwork.com filetype:pdf user* manual
  - site:ecommerce.com "price" 100..500
  - "information security policy"
  - site:news.com -inurl:sports
- Examples
  - site:twitter.com/user intext:"keywords"
  - Find Login
    - site:example.com inurl:login
    - site:example.com (inurl:login OR inurl:admin)
  - Identify exposed files
    - site:example.com filetype:pdf
    - site:example.com (filetype:xls OR filetype:docx)
  - Uncover Configuration Files
    - site:example.com inurl:config.php
  - Search for files extensions
    - site:example.com (ext:conf OR ext:cnf)
  - Locating Database Backups:
    - site:example.com inurl:backup
    - site:example.com filetype:sql
## Web Archive

### wayback machine

- web.archive.org
## Automating Recon

### Reconnaissance Frameworks

- finalrecon: A Python-based
  - https://github.com/thewhiteh4t/FinalRecon
    - SSL certificate checking, Whois information gathering, header analysis, and crawling
- Recon-ng: A powerful framework written in Python
  - https://github.com/lanmaster53/recon-ng
    - perform DNS enumeration, subdomain discovery, port scanning, web crawling, and even exploit known vulnerabilities.
- theharvester: Specifically designed for gathering email addresses, written in Python.
  - https://github.com/laramies/theHarvester
    - gathering email addresses, subdomains, hosts, employee names, open ports, and banners from different public sources like search engines, PGP key servers, and the SHODAN database
- spiderfoot: An open-source intelligence automation tool
  - https://github.com/smicallef/spiderfoot
    - IP addresses, domain names, email addresses, and social media profiles. It can perform DNS lookups, web crawling, port scanning, and more.
- OSINT Framework: A collection of various tools
  - https://osintframework.com/
    - A collection of various tools and resources for open-source intelligence gathering. It covers a wide range of information sources, including social media, search engines, public records, and more.
### FinalRecon

- benefits
  - Header Information:
  - Whois Lookup:
  - SSL Certificate Information:
  - Crawler
  - DNS Enumeration:
  - Subdomain Enumeration:
  - Directory Enumeration
  - Wayback Machine: Retrieves URLs from the last five years to analyse website changes and potential vulnerabilities.
- Usage
  - git clone https://github.com/thewhiteh4t/FinalRecon.git
    - pip3 install -r requirements.txt
      - chmod +x ./finalrecon.py
        - ./finalrecon.py --help
  - ./finalrecon.py --headers --whois --url http://inlanefreight.com
## Skills Assessment

### ffuf -u http://94.237.48.12:43611/ -H "Host: FUZZ.inlanefreight.htb" -w ../wordlists/SecLists/Discovery/DNS/subdomains-top1million-110000.txt -fs 120 -t 50

- web1337
  - curl -k http://94.237.48.12:43611/robots.txt -H "Host: web1337.inlanefreight.htb"
    - Disallow  
      /admin_h1dd3n/
      - curl http://94.237.48.12:43611/admin_h1dd3n/ -H "Host: web1337.inlanefreight.htb"
        - The admin panel is currently under maintenance, but the API is still accessible with the key e963d863ee0e82ba7080fbf558ca0d3f
          - ffuf -u http://94.237.48.12:43611/ -H "Host: FUZZ.web1337.inlanefreight.htb" -w ../wordlists/SecLists/Discovery/DNS/subdomains-top1million-110000.txt -fs 120 -t 50
            - dev
            - sudo nano /etc/passwd
              - 92.25.86.34 dev.web1337.inlanefreight.htb
                - python ReconSpider.py http://dev.web1337.inlanefreight.htb:36945
                  - cat results.json
