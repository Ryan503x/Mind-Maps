---
tags: [CWES, HTB, index]
source_file: "CWES.xmind"
---

# SQL Injection Fundamentals

## Study Companion

### Prerequisites

Relational database concepts and basic SQL query syntax.

### Learning Outcomes

- Recognize how input changes SQL query structure.
- Classify UNION, error, boolean, time, stacked, and out-of-band techniques.
- Demonstrate minimum necessary impact and explain parameterized-query remediation.

### Practice Checkpoint

Manually confirm one injection using stable true/false behavior and document the inferred query context.

### Related Knowledge Map

- [[Maps/Injection and Code Execution|Injection and Code Execution]]
- [[Study Group Guide|CWES Study Group Guide]]

## Professional Guidance

### Objective
Determine whether application input can alter SQL query structure, classify the usable injection technique, demonstrate the minimum necessary confidentiality or authorization impact, and connect findings to durable database-layer remediation.

### Assessment Workflow
1. Understand the expected query behavior and establish baseline responses for valid, invalid, and boundary inputs.
2. Probe suspected parameters with controlled syntax, comments, quotes, arithmetic, comparison, boolean, and operator variations while monitoring content, status, errors, and timing.
3. Identify the query context and DBMS behavior, then confirm a stable true/false or error condition before extracting data.
4. For UNION testing, determine column count and compatible output positions, then retrieve only a benign identifier such as database version or current user.
5. Use error-based, boolean-blind, time-based, stacked, or out-of-band techniques only when the response model requires them and scope permits their risk.
6. Assess database privileges and whether the flaw affects authentication, data access, modification, or administrative functionality.
7. Review code for string concatenation and verify remediation with parameterized queries and a least-privileged application account.

### Key Testing Principles
- Apply SQL syntax knowledge—operators, `LIKE`, ordering, limits, and query structure—to explain results rather than relying on random payloads.
- Separate authentication bypass from data extraction and avoid destructive stacked statements.
- Keep blind timing tests conservative and repeat measurements to rule out latency noise.
- Sanitization, validation, and WAF rules are defense-in-depth; prepared statements with correct parameter binding are the primary fix.
- Restrict database permissions so a compromised query cannot administer schemas or access unrelated data.

### Evidence and Reporting
Provide the endpoint, parameter, request method, baseline and confirming requests, decoded payload, inferred query context, DBMS/technique, and response or timing comparison. Include only minimal sample data, describe affected records and privileges, redact secrets, and give language/framework-specific parameterization guidance plus a regression test.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **40 yellow/output topics** in this module.

- [[Outputs/Modules/SQL Injection Fundamentals Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

The original XMind hierarchy is split into section notes to keep Obsidian responsive and reduce security-scanner false positives.

- [[Modules/SQL Injection Fundamentals/01 - https---www.sqlinjection.net-stacked-queries-|https://www.sqlinjection.net/stacked-queries/]]
- [[Modules/SQL Injection Fundamentals/02 - https---www.mysqltutorial.org-sql-union-mysql.aspx-|https://www.mysqltutorial.org/sql-union-mysql.aspx/]]
- [[Modules/SQL Injection Fundamentals/03 - mysql|mysql]]
- [[Modules/SQL Injection Fundamentals/04 - SQL Operators|SQL Operators]]
- [[Modules/SQL Injection Fundamentals/05 - SQL Injection|SQL Injection]]
- [[Modules/SQL Injection Fundamentals/06 - Mitigating SQL Injection|Mitigating SQL Injection]]
- [[Modules/SQL Injection Fundamentals/07 - Skills Assessment|Skills Assessment]]
