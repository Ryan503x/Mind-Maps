---
tags: [CWES, HTB, index]
source_file: "CWES.xmind"
---

# File Inclusion

## Study Companion

### Prerequisites

Filesystem paths, web server structure, and PHP/application inclusion concepts.

### Learning Outcomes

- Distinguish traversal, file read, source disclosure, inclusion, and execution.
- Characterize prefixes, suffixes, canonicalization, encoding, and wrapper behavior.
- Understand controlled upload, session, and log-inclusion escalation paths.

### Practice Checkpoint

Document one vulnerable path from user input to resolved filesystem target, including every transformation.

### Related Knowledge Map

- [[Maps/Files and Server-side Attacks|Files and Server-side Attacks]]
- [[Study Group Guide|CWES Study Group Guide]]

## Professional Guidance

### Objective
Determine whether user-controlled paths reach file-reading, template-rendering, or inclusion functions and whether local or remote inclusion can disclose files, expose source code, or reach controlled code execution within the authorized HTB target.

### Assessment Workflow
1. Identify path-bearing inputs in query strings, routes, POST bodies, cookies, stored profile values, and template selectors; note the backend language and whether the sink reads or executes included content.
2. Establish a normal-language/template response, then test absolute and relative paths with known low-sensitivity files for Linux or Windows, minimizing traversal depth and recording prefix or suffix behavior.
3. Characterize filters and path construction: stripped traversal sequences, approved-path prefixes, appended extensions, encoding/decoding, canonicalization, legacy truncation, and second-order values retrieved from storage.
4. On PHP targets, use `php://filter` with base64 conversion to confirm source disclosure and review discovered configuration files for credentials, keys, webroots, logs, and additional include sinks.
5. If authorized, evaluate escalation paths in a controlled order: supported PHP wrappers, remote file inclusion settings, inclusion of an uploaded test file, and poisoning of accessible server logs.
6. Use parameter, LFI, webroot, log, and configuration wordlists only with bounded rates; corroborate automated hits manually and review fixes based on fixed identifier-to-file mappings rather than user-supplied paths.

### Key Testing Principles
- Distinguish traversal from inclusion and file read from code execution; document the exact sink behavior instead of inferring impact.
- Canonicalization matters: validate the resolved path after decoding and normalization, not a raw string or removable blacklist pattern.
- Legacy bypasses such as null bytes or path truncation are version-dependent and should be tested only when the stack supports them.
- Prefer harmless files and markers, avoid modifying logs beyond a minimal proof, and do not retrieve unnecessary sensitive material.

### Evidence and Reporting
Record the vulnerable parameter, baseline request, traversal depth, filter bypass, resolved target file, response excerpt, and backend/version assumptions. If escalation is demonstrated, preserve the minimal uploaded or logged marker and execution result, then clean up where possible. Recommend removing dynamic filesystem paths, using strict server-side maps and allowlists, canonical path containment, least-privileged filesystem permissions, disabled remote inclusion/wrappers, protected logs/uploads, and non-verbose errors.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **63 yellow/output topics** in this module.

- [[Outputs/Modules/File Inclusion Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

The original XMind hierarchy is split into section notes to keep Obsidian responsive and reduce security-scanner false positives.

- [[Modules/File Inclusion/01 - intro|intro]]
- [[Modules/File Inclusion/02 - Basic LFI|Basic LFI]]
- [[Modules/File Inclusion/03 - Basic Bypasses|Basic Bypasses]]
- [[Modules/File Inclusion/04 - PHP Filters|PHP Filters]]
- [[Modules/File Inclusion/05 - RCE via PHP Wrappers|RCE via PHP Wrappers]]
- [[Modules/File Inclusion/06 - Remote File Inclusion (RFI)|Remote File Inclusion (RFI)]]
- [[Modules/File Inclusion/07 - LFI and File Uploads|LFI and File Uploads]]
- [[Modules/File Inclusion/08 - Log Poisoning|Log Poisoning]]
- [[Modules/File Inclusion/09 - Automated Scanning|Automated Scanning]]
- [[Modules/File Inclusion/10 - Fuzzing Server Files|Fuzzing Server Files]]
- [[Modules/File Inclusion/11 - LFI Tools|LFI Tools]]
- [[Modules/File Inclusion/12 - File Inclusion Prevention|File Inclusion Prevention]]
- [[Modules/File Inclusion/13 - Skills Assessment - File Inclusion|Skills Assessment - File Inclusion]]
